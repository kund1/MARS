<?php
// Halaman ini sendiri jangan pernah di-cache browser — supaya tiap edit index.php langsung
// kelihatan begitu di-refresh, tanpa perlu hard-refresh manual tiap kali (beda dgn CSS/JS di
// bawah yg sudah pakai cache-busting ?v= lewat av()).
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');

// Cache-busting: tiap file css/js dikasih ?v=<waktu-terakhir-diubah> supaya browser user
// otomatis ambil versi baru begitu file-nya di-update (bukan pakai cache lama yg basi).
function av($path){ $full=__DIR__.'/'.$path; return $path.'?v='.(file_exists($full)?filemtime($full):time()); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMMS — Supply Mapping Monitoring System</title>
<link rel="stylesheet" href="<?= av('assets/css/app.css') ?>">
<link rel="stylesheet" href="<?= av('plane-sim/plane-sim.css') ?>">
<link rel="stylesheet" href="<?= av('assets/css/tailwind.css') ?>">
<script>
// Set tema SEBELUM CSS/body dirender supaya tidak ada kedipan (flash) warna salah.
(function(){
  var saved = localStorage.getItem("smms_theme");
  var theme = saved || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  document.documentElement.setAttribute("data-theme", theme);
})();
</script>
</head>
<body>

<div id="globalLoadingBar" class="loading-bar" aria-hidden="true"></div>

<header>
  <button id="sidebarToggle" title="Sembunyikan/tampilkan menu">☰</button>
  <div class="brand"><h1>SMMS <b>●</b></h1><span>Assy 1 · Dock 43</span></div>
  <div class="counterbox">
    <div class="cb"><div class="lbl">P-LANE (MROS)</div><select id="planeSel"></select></div>
    <div class="cb"><div class="lbl">C/D AWAL</div><select id="cdStartSel"></select></div>
    <div class="cb"><div class="lbl">COUNT DOWN</div>
      <div class="cdctl"><button id="cdMinus">−</button><div class="val cd" id="hdCd">—</div><button id="cdPlus">+</button></div>
    </div>
    <div class="cb"><div class="lbl">DURASI (detik)</div><input type="number" id="hdCdDuration" min="1" style="width:56px" title="Berapa detik 1 angka countdown berjalan"></div>
    <div class="cb"><div class="lbl">KECEPATAN TOWING</div>
      <select id="hdTowSpeed" title="Kecepatan gerak towing antar-halte, px per detik">
        <option value="10">10 px/dtk</option>
        <option value="20">20 px/dtk</option>
        <option value="30">30 px/dtk</option>
        <option value="50">50 px/dtk</option>
        <option value="100">100 px/dtk</option>
        <option value="150">150 px/dtk</option>
        <option value="200">200 px/dtk</option>
        <option value="300">300 px/dtk</option>
      </select>
    </div>
    <div class="cb"><div class="lbl">HALTE AKTIF</div><div class="val" id="hdHalte">—</div></div>
    <div class="cb"><div class="lbl">POSISI AKTIF</div><div class="val" id="hdPosisi">—</div></div>
    <div class="cb"><div class="lbl">ORDER NO</div><div class="val" id="hdOrder" style="font-size:17px">—</div></div>
    <button id="btnRoutePick">🗂 Pilih Route</button>
    <button id="btnAuto">▶ AUTO</button>
  </div>
  <div class="clock"><div class="t" id="clock">--:--:--</div><div class="d" id="cdate"></div></div>
</header>

<div id="shell">
<nav id="sidebar">
  <button class="on" id="navMon"><span class="ico">🖥</span><span class="lbl">Monitor</span></button>
  <button id="navEdit"><span class="ico">✎</span><span class="lbl">Editor</span></button>
  <button id="navPlaneSim"><span class="ico">📦</span><span class="lbl">Plane Simulation</span></button>
  <button id="navDb"><span class="ico">🗄</span><span class="lbl">Database</span><span class="chev">⌄</span></button>
  <button id="navSetting"><span class="ico">⚙</span><span class="lbl">Setting</span></button>
  <div id="dbsubnav">
    <button class="dbnavbtn on" data-sec="parts">Progress Lane</button>
    <button class="dbnavbtn" data-sec="halte">Halte &amp; Rack</button>
    <button class="dbnavbtn" data-sec="cd">Countdown → Halte</button>
    <button class="dbnavbtn" data-sec="racks">Posisi Rack</button>
    <button class="dbnavbtn" data-sec="path">Jalur Route</button>
    <button class="dbnavbtn" data-sec="supply">Patern Unload</button>
    <button class="dbnavbtn" data-sec="offset">Counter Offset</button>
    <button class="dbnavbtn" data-sec="masterpart">Master Part</button>
  </div>
  <div class="grow"></div>
  <button id="themeToggle" title="Ganti tema terang/gelap"><span class="ico">🌙</span><span class="lbl">Mode Gelap</span></button>
  <span id="saveState">—</span>
</nav>
<div id="content">
<?php include __DIR__.'/editor/view.php'; // markup toolbar tab Editor (mode/panel shape/tag halte), lihat editor/ ?>

<main>
  <div id="viewport">
    <div id="stage">
      <img id="layoutimg" src="assets/layout.png" alt="Layout Assy 1">
      <svg id="overlay"></svg>
    </div>
    <div id="zoomctl"><button id="zin">+</button><button id="zout">−</button><button id="zfit" style="font-size:10px">FIT</button><button id="zfollow" style="font-size:16px" title="Fullscreen + zoom 562.5% + ikuti towing">⛶</button></div>
    <div id="legend">
      <b>Rack disupply</b> · route terpilih<br>
      <span class="dot" style="background:var(--h1)"></span>Halte 1
      &nbsp;<span class="dot" style="background:var(--h2)"></span>Halte 2
      &nbsp;<span class="dot" style="background:var(--h3)"></span>Halte 3<br>
      <span class="dot" style="background:var(--act)"></span>Sedang disupply
      &nbsp;·&nbsp;<span class="dot" style="background:#fff;border:1.5px solid #94A3B8"></span>Rack lain
    </div>
    <!-- Cuma kelihatan pas Mode Follow fullscreen (toggle class "following" di #viewport, lihat
         04-viewport.js) — di luar fullscreen, info countdown/plane/status & daftar part tetap
         cuma di header+sidebar biasa (elemen ini duplikat kontennya, gak gantiin yg asli).
         Styling pakai utility Tailwind (prefix tw-, lihat tailwind.config.js) + arbitrary-value
         yg nunjuk ke CSS variable tema yg sudah ada (var(--panel) dst) biar tetap ngikutin
         dark/light mode, bukan warna hardcode baru. -->
    <div id="followStatus" class="tw-hidden tw-absolute tw-top-3 tw-left-3 tw-z-10 tw-flex tw-gap-2">
      <div class="tw-bg-[var(--panel)] tw-border tw-border-[var(--line)] tw-rounded-lg tw-px-3 tw-py-2 tw-text-center tw-shadow-lg tw-min-w-[74px]">
        <div class="tw-text-[10px] tw-font-bold tw-tracking-wide tw-opacity-70 tw-text-[color:var(--mut)]">P-LANE</div>
        <div class="tw-font-mono tw-text-xl tw-font-bold tw-text-[color:var(--ink)]" id="folPlane">—</div>
      </div>
      <div class="tw-bg-[var(--panel)] tw-border tw-border-[var(--line)] tw-rounded-lg tw-px-3 tw-py-2 tw-text-center tw-shadow-lg tw-min-w-[74px]">
        <div class="tw-text-[10px] tw-font-bold tw-tracking-wide tw-opacity-70 tw-text-[color:var(--mut)]">COUNT DOWN</div>
        <div class="tw-font-mono tw-text-xl tw-font-bold tw-text-[color:var(--act)]" id="folCd">—</div>
      </div>
      <div class="tw-bg-[var(--panel)] tw-border tw-border-[var(--line)] tw-rounded-lg tw-px-3 tw-py-2 tw-text-center tw-shadow-lg tw-min-w-[92px]">
        <div class="tw-text-[10px] tw-font-bold tw-tracking-wide tw-opacity-70 tw-text-[color:var(--mut)]">HALTE AKTIF</div>
        <div class="tw-font-mono tw-text-base tw-font-bold tw-text-[color:var(--ink)]" id="folHalte">—</div>
      </div>
      <div class="tw-bg-[var(--panel)] tw-border tw-border-[var(--line)] tw-rounded-lg tw-px-3 tw-py-2 tw-text-center tw-shadow-lg tw-min-w-[92px]">
        <div class="tw-text-[10px] tw-font-bold tw-tracking-wide tw-opacity-70 tw-text-[color:var(--mut)]">POSISI AKTIF</div>
        <div class="tw-font-mono tw-text-base tw-font-bold tw-text-[color:var(--ink)]" id="folPosisi">—</div>
      </div>
    </div>
    <div id="followParts" class="tw-hidden tw-absolute tw-top-3 tw-right-3 tw-z-10 tw-bg-[var(--panel)] tw-border tw-border-[var(--line)] tw-rounded-lg tw-shadow-lg tw-w-[420px] tw-max-h-[70vh] tw-flex tw-flex-col tw-overflow-hidden">
      <div class="tw-px-3 tw-py-2 tw-font-bold tw-text-sm tw-border-b tw-border-[var(--line)] tw-text-[color:var(--ink)]">
        Muatan · <span id="folPartsRoute">—</span>
      </div>
      <div id="folPartsBox" class="tw-overflow-y-auto"></div>
    </div>
  </div>
  <aside>
    <div class="asidehead"><h2>Status Towing</h2></div>
    <div id="routelist"></div>
    <div id="partshead"><h2 id="partstitle">Muatan · pilih towing</h2><span id="partscount"></span></div>
    <div id="statusLegend" class="status-legend">
      <span><span class="status-dot status-direct"></span>Direct</span>
      <span><span class="status-dot status-sorting"></span>Sorting</span>
      <span><span class="status-dot status-unpacking"></span>Unpacking</span>
      <span><span class="status-dot status-import"></span>Import</span>
      <span><span class="status-dot status-cu"></span>C/U</span>
    </div>
    <div id="supplywarn" style="display:none"></div>
    <div id="partsbox"><div id="partsempty">Buka <b>Editor</b> untuk menggambar jalur & memasang rack. Klik towing pada denah untuk melihat muatannya.</div></div>
  </aside>
</main>



<div id="tab-db" data-active-sec="parts">
  <div class="dbsection on" data-sec="parts">
    <div class="dbt-card dbt-uploadcard">
      <div class="dbt-head">
        <div>
          <h3 style="margin:0">Progress Lane</h3>
          <p class="meta" id="dbmeta" style="margin-top:3px"></p>
        </div>
      </div>
      <div class="dbt-uploadrow">
        <a id="plTemplateLink" class="btn-tpl" href="assets/templates/template_progress_lane.xlsx">⬇ Template</a>
        <button id="plUploadOpenBtn" class="btn-primary" type="button">↑ Upload</button>
        <div class="dbt-lastupload">
          <span class="ico">🕒</span>
          <div>
            <div class="lbl">LAST UPLOAD</div>
            <div class="val" id="plLastUpload">—</div>
          </div>
        </div>
        <div class="grow"></div>
        <button id="dbDownload" class="dbt-btn primary">⬇ Download</button>
      </div>
    </div>

    <div class="dbt-card dbt-tablecard">
      <div id="dbDatePills" class="dbt-datepills"></div>
      <div class="dbt-filters" style="margin-bottom:12px">
        <label>P-Lane <select id="dbPlane"></select></label>
        <label>Route <select id="dbRoute"></select></label>
        <button id="dbClear" class="dbt-btn ghost">↺ Clear</button>
      </div>
      <div class="dbt-search">
        <span>🔍</span>
        <input type="text" id="dbSearch" placeholder="Cari semua kolom...">
      </div>
      <div id="dbparts"></div>
      <div id="dbpager" class="dbt-pager"></div>
    </div>
  </div>

  <div class="dbsection" data-sec="halte">
    <div class="dbt-card dbt-uploadcard">
      <div class="mhead"><h3>Master Halte &amp; Rack</h3></div>
      <p>Referensi alamat halte per route (VLOOKUP dari Master Offset) + dolly yg disupply. Route sudah tetap (gak bisa ditambah/dihapus) — posisi di denah diatur lewat tab Editor.</p>
      <div class="dm-group dm-uploadbar">
        <button class="btn-upload" data-kind="halte_master">↑ Upload</button>
        <button id="hmCsvBtn" class="tmode dm-right">⬇ Download CSV</button>
      </div>
    </div>
    <div class="dbt-card dbt-tablecard">
      <div class="dm-group dm-databox">
        <div class="dm-searchwrap"><span>🔍</span><input type="search" id="hmSearch" class="dm-search" placeholder="Cari Route…"></div>
        <div class="dm-actions">
          <button id="hmEditBtn" class="tmode" disabled>✎ Edit Alamat</button>
          <button id="hmSaveDollyBtn" class="btn-primary">💾 Simpan Dolly</button>
        </div>
        <div class="dm-tablewrap"><table class="grid" id="halteGrid"></table></div>
      </div>
    </div>
  </div>

  <div class="dbsection" data-sec="cd">
    <div class="dbt-card dbt-uploadcard">
      <div class="mhead"><h3>Mapping Countdown → Halte</h3></div>
      <p>Ubah range countdown, pergerakan towing otomatis menyesuaikan.</p>
      <div class="dm-group dm-uploadbar">
        <button class="btn-upload" data-kind="cd_mapping">↑ Upload</button>
        <button id="cdCsvBtn" class="tmode dm-right">⬇ Download CSV</button>
      </div>
    </div>
    <div class="dbt-card dbt-tablecard">
      <div class="dm-group dm-databox">
        <div class="dm-searchwrap"><span>🔍</span><input type="search" id="cdSearch" class="dm-search" placeholder="Cari C/D Awal…"></div>
        <div class="dm-actions">
          <button id="cdAddBtn" class="btn-primary">+ Add</button>
          <button id="cdEditBtn" class="tmode" disabled>✎ Edit</button>
          <button id="cdDeleteBtn" class="tmode mp-danger" disabled>🗑 Delete</button>
        </div>
        <div class="dm-tablewrap"><table class="grid" id="cdGrid"></table></div>
      </div>
    </div>
  </div>

  <div class="dbsection" data-sec="racks">
    <div class="dbt-card dbt-uploadcard">
      <div class="mhead"><h3>Master Rack (posisi)</h3></div>
      <p>Alamat rack &amp; koordinat di denah (px). Bisa juga digeser langsung lewat tab Editor.</p>
      <div id="rkMissingWarn" style="display:none"></div>
      <div class="dm-group dm-uploadbar">
        <button class="btn-upload" data-kind="racks">↑ Upload</button>
        <button id="rkCsvBtn" class="tmode dm-right">⬇ Download CSV</button>
      </div>
    </div>
    <div class="dbt-card dbt-tablecard">
      <div class="dm-group dm-databox">
        <div class="dm-searchwrap"><span>🔍</span><input type="search" id="rkSearch" class="dm-search" placeholder="Cari Address…"></div>
        <div class="dm-actions">
          <button id="rkAddBtn" class="btn-primary">+ Add</button>
          <button id="rkEditBtn" class="tmode" disabled>✎ Edit</button>
          <button id="rkDeleteBtn" class="tmode mp-danger" disabled>🗑 Delete</button>
          <button id="rkAlignXBtn" class="tmode" disabled title="Samakan koordinat X semua rack terpilih (jadi 1 garis vertikal)">↕ Align X</button>
          <button id="rkAlignYBtn" class="tmode" disabled title="Samakan koordinat Y semua rack terpilih (jadi 1 garis horizontal)">↔ Align Y</button>
          <button id="rkDistXBtn" class="tmode" disabled title="Min. 3 rack — sebar rata jarak X-nya, Y gak disentuh">⋯ Ratakan X</button>
          <button id="rkDistYBtn" class="tmode" disabled title="Min. 3 rack — sebar rata jarak Y-nya, X gak disentuh">⋯ Ratakan Y</button>
        </div>
        <div id="racksTableBox" class="dm-tablewrap"></div>
        <div id="rkPager" class="dbt-pager"></div>
      </div>
    </div>
  </div>

  <div class="dbsection" data-sec="path">
    <div class="dbt-card dbt-uploadcard">
      <div class="mhead"><h3>Master Jalur Route (path)</h3></div>
      <p>Titik jalur per route berurutan (kolom Seq menentukan urutan) + tanda halte 1/2/3. Bisa juga digambar lewat tab Editor.</p>
      <div class="dm-group dm-uploadbar">
        <button class="btn-upload" data-kind="route_path">↑ Upload</button>
        <button id="pthCsvBtn" class="tmode dm-right">⬇ Download CSV</button>
      </div>
    </div>
    <div class="dbt-card dbt-tablecard">
      <div class="dm-group dm-databox">
        <div class="dm-searchwrap"><span>🔍</span><input type="search" id="pthSearch" class="dm-search" placeholder="Cari Route…"></div>
        <div class="dm-actions">
          <button id="pthAddBtn" class="btn-primary">+ Add</button>
          <button id="pthEditBtn" class="tmode" disabled>✎ Edit</button>
          <button id="pthDeleteBtn" class="tmode mp-danger" disabled>🗑 Delete</button>
        </div>
        <div id="pathTableBox" class="dm-tablewrap"></div>
        <div id="pthPager" class="dbt-pager"></div>
      </div>
    </div>
  </div>

  <div class="dbsection" data-sec="supply">
    <div class="dbt-card dbt-uploadcard">
      <div class="mhead">
        <h3>Pattern Unload</h3>
        <div class="pu-zoneswitch">
          <button class="pu-zonebtn on" data-zone="timur">Timur</button>
          <button class="pu-zonebtn" data-zone="barat">Barat</button>
        </div>
        <button class="btn-upload" data-kind="supply_order">↑ Upload dari Excel</button>
        <button id="puEditBtn" class="tmode">✎ Edit</button>
        <button id="puBulkDeleteBtn" class="tmode mp-danger" type="button" disabled>🗑 Hapus Terpilih</button>
        <button id="puSaveBtn" class="btn-primary" disabled>💾 Simpan</button>
      </div>
    </div>

    <div class="dbt-card dbt-tablecard">
      <div class="pu-wrap">
        <div class="pu-zone on" data-zone="timur">
          <div class="pu-zonehead" style="color:var(--zone-timur)">ZONE TIMUR <button class="pu-addcol" data-zone="timur">+ Route</button></div>
          <div class="pu-tablebox" id="puGridTimur"></div>
        </div>
        <div class="pu-zone" data-zone="barat">
          <div class="pu-zonehead" style="color:var(--zone-barat)">ZONE BARAT <button class="pu-addcol" data-zone="barat">+ Route</button></div>
          <div class="pu-tablebox" id="puGridBarat"></div>
        </div>
      </div>
    </div>
  </div>

  <div class="dbsection" data-sec="offset">
    <div class="dbt-card dbt-uploadcard">
      <div class="mhead"><h3>Master Offset</h3></div>
      <p>Proses yang dipakai: PREPARE → HALTE 1 → HALTE 2 → HALTE 3 → EMPTY → SUPPLY. Offset boleh 1 angka (posisi) atau rentang "max-min" (dipakai Halte 1/2/3, & rentang "POSISI AKTIF" yang dulu di Posisi Offset — sekarang digabung 1 tabel di sini). Alamat rack halte 1/2/3 diatur lewat menu "Atur Halte" (tab Halte &amp; Rack), bukan di sini.</p>

      <div class="dm-group dm-uploadbar">
        <a id="ofcTemplateLink" class="btn-tpl" href="api.php?action=offset_template">⬇ Template</a>
        <button id="ofcUploadOpenBtn" class="btn-primary">↑ Upload</button>
      </div>
    </div>

    <div class="dbt-card dbt-tablecard">
      <div class="dm-group dm-databox">
        <div class="dm-searchwrap"><span>🔍</span><input type="search" id="ofcSearch" class="dm-search" placeholder="Cari Process / Zone / Route…"></div>
        <div class="dm-actions">
          <button id="ofcAddBtn" class="btn-primary">+ Add</button>
          <button id="ofcEditBtn" class="tmode" disabled>✎ Edit</button>
          <button id="ofcDeleteBtn" class="tmode mp-danger" disabled>🗑 Delete</button>
        </div>
        <div id="ofcOffsetTableBox" class="dm-tablewrap"></div>
        <div id="ofcPager" class="dbt-pager"></div>
      </div>
    </div>
  </div>

  <div class="dbsection" data-sec="masterpart">
    <div class="dbt-card dbt-uploadcard">
      <div class="mhead"><h3>Master Part</h3></div>

      <div class="dm-group dm-uploadbar">
        <a id="mpTemplateLink" class="btn-tpl" href="api.php?action=master_part_template">⬇ Template</a>
        <button id="mpUploadOpenBtn" class="btn-primary">↑ Upload</button>
        <div class="dbt-lastupload">
          <span class="ico">🕒</span>
          <div>
            <div class="lbl">LAST UPLOAD</div>
            <div class="val" id="mpLastUpload">—</div>
          </div>
        </div>
        <button id="mpHistoryToggle" class="mp-linklike" type="button">Riwayat Upload ▾</button>
        <a id="mpCsvBtn" class="tmode dm-right" href="api.php?action=master_part_excel">⬇ Download Excel</a>
      </div>
      <div id="mpHistoryBox" class="mp-history-box" style="display:none"></div>
    </div>

    <div class="dbt-card dbt-tablecard">
      <div class="dm-group dm-databox">
        <div class="dm-searchwrap"><span>🔍</span><input type="search" id="mpSearch" class="dm-search" placeholder="Cari Kanban No / Supplier Name / Conveyance / Status / Part Name…"></div>
        <div class="dm-actions">
          <button id="mpAddBtn" class="btn-primary">+ Add</button>
          <button id="mpEditBtn" class="tmode" disabled>✎ Edit</button>
          <button id="mpBulkStatusBtn" class="tmode" disabled>🏷 Ubah Status Terpilih</button>
          <button id="mpDeleteBtn" class="tmode mp-danger" disabled>🗑 Delete</button>
        </div>
        <div id="masterPartTableBox" class="dm-tablewrap"></div>
        <div id="mpPagination" class="mp-pagination"></div>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__.'/plane-sim/view.php'; // markup menu Plane Simulation (tab + 2 modal) ?>

<!-- ===================================================================
     MENU "SETTING" (baru, top-level, terpisah dari Database & Plane Simulation) — sub-menu
     "Sorting Plane": physical area tempat skid hasil bongkar Plane menunggu proses SORTING,
     diidentifikasi lewat ROUTE (bukan nomor plane), kapasitas 1 atau 2 PLANE. Config-only (CRUD),
     BELUM ada movement/animasi (lihat assets/js/18-sorting-plane.js). "Physical Plane" (Data Plane
     Manual) TETAP di toolbar Plane Simulation (view.php di atas), TIDAK dipindah ke sini.
     =================================================================== -->
<div id="tab-setting">
  <h2>Setting</h2>
  <p class="meta">Konfigurasi tambahan di luar kategori Database.</p>

  <h3 style="margin-top:22px">Sorting Plane</h3>
  <p class="meta">Physical area tempat skid hasil bongkar Plane menunggu proses SORTING, diidentifikasi lewat <b>Route</b> (bukan nomor plane), dengan kapasitas <b>1 atau 2 Plane</b>. Config murni — belum ada movement/distribusi skid per-route.</p>
  <div style="display:flex;justify-content:flex-end;margin-top:10px">
    <button id="spAddBtn" class="btn-primary" style="padding:6px 14px">+ Add Sorting Plane</button>
  </div>
  <div id="spTableBox" class="dm-tablewrap" style="margin-top:8px"></div>

  <h3 style="margin-top:28px">Dolly Supply</h3>
  <p class="meta">Physical area penyimpanan Dolly per <b>Route</b>, padanan Sorting Plane di atas — config murni, belum ada movement/distribusi skid.</p>
  <div style="display:flex;justify-content:flex-end;margin-top:10px">
    <button id="dsAddBtn" class="btn-primary" style="padding:6px 14px">+ Add Dolly Supply</button>
  </div>
  <div id="dsTableBox" class="dm-tablewrap" style="margin-top:8px"></div>
</div>

<div id="dsFormModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 420px)">
    <h4 id="dsFormTitle">Tambah Dolly Supply</h4>
    <div class="mp-form-grid">
      <label>Dolly Supply Number<input id="dsfNum" type="number" min="1"></label>
      <label>Route<select id="dsfRoute"></select></label>
    </div>
    <div id="dsFormMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="dsFormCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="dsFormSave" class="btn-primary" style="margin-left:8px">Simpan</button>
    </div>
  </div>
</div>

<div id="spFormModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 460px)">
    <h4 id="spFormTitle">Tambah Sorting Plane</h4>
    <div class="mp-form-grid">
      <label>Sorting Plane Number<input id="spfNum" type="number" min="1"></label>
      <label>Route<select id="spfRoute"></select></label>
      <label>Plane Capacity
        <div style="display:flex;gap:14px;margin-top:6px;text-transform:none;letter-spacing:normal">
          <label style="display:flex;align-items:center;gap:5px;font-size:13px;color:var(--ink);text-transform:none"><input type="radio" name="spfCapacity" value="1" style="width:auto"> 1 Plane</label>
          <label style="display:flex;align-items:center;gap:5px;font-size:13px;color:var(--ink);text-transform:none"><input type="radio" name="spfCapacity" value="2" style="width:auto"> 2 Plane</label>
        </div>
      </label>
    </div>
    <div id="spFormMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="spFormCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="spFormSave" class="btn-primary" style="margin-left:8px">Simpan</button>
    </div>
  </div>
</div>

<div id="plUploadModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 460px)">
    <h4>Upload Progress Lane</h4>
    <p class="meta">File <b>Progress Line Contain YYYYMMDD.xlsx</b> (format PICS e-Kanban, 66 kolom — cuma 16 yang dipakai) · hanya baris <b>Dock 43</b>, route A–Q. Data part lama akan digantikan sepenuhnya oleh isi file baru.</p>
    <div class="dm-upload-modal-body">
      <button id="plChooseFile" class="tmode" type="button">📎 Choose File</button>
      <input type="file" id="fileXlsx" accept=".xlsx" style="display:none">
      <span id="plFileName" class="meta">Belum pilih file</span>
    </div>
    <div class="meta" id="upmeta" style="margin-top:10px"></div>
    <div id="upsummary"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="plUploadCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="plUploadBtn" class="btn-primary" style="margin-left:8px">↑ Upload</button>
    </div>
  </div>
</div>

<div id="mpUploadModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 460px)">
    <h4>Upload Master Part</h4>
    <div class="dm-upload-modal-body">
      <button id="mpChooseFile" class="tmode" type="button">📎 Choose File</button>
      <input type="file" id="mpFile" accept=".xlsx,.xlsm" style="display:none">
      <span id="mpFileName" class="meta">Belum pilih file</span>
      <label class="dm-upload-mode">Mode
        <select id="mpMode" title="Mode upload">
          <option value="additional">Additional (tambah data baru)</option>
          <option value="replace">Replace (ganti seluruh data)</option>
        </select>
      </label>
    </div>
    <div style="margin-top:16px;text-align:right">
      <button id="mpUploadCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="mpUploadBtn" class="btn-primary" style="margin-left:8px">↑ Upload</button>
    </div>
  </div>
</div>

<div id="mpFormModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(320px, 90vw, 660px);max-height:82vh;overflow:auto">
    <h4 id="mpFormTitle">Tambah Part</h4>
    <div class="mp-form-grid">
      <label>Uniq No<input id="mpfKanban" maxlength="4" placeholder="4 karakter"></label>
      <label>Part No<input id="mpfPartNo" maxlength="12" placeholder="12 karakter"></label>
      <label>Part Name<input id="mpfPartName"></label>
      <label>Volume Box<input id="mpfVolumeBox"></label>
      <label>Vol/Box Day<input id="mpfVolBoxDay"></label>
      <label>Route<input id="mpfConveyance"></label>
      <label>Status
        <select id="mpfStatus"><option>Direct</option><option>Sorting</option><option>Unpacking Murni</option><option>C/U</option></select>
      </label>
      <label>Supplier Name<input id="mpfSupplierName"></label>
      <label>Dock Code<input id="mpfDockCode" value="43" disabled></label>
      <label>Supplier Code<input id="mpfSupplierCode" maxlength="4" placeholder="4 karakter"></label>
      <label>Supplier Plant Code<input id="mpfSupplierPlant" maxlength="1" placeholder="1 karakter"></label>
      <label>Shipping Dock<input id="mpfShippingDock"></label>
      <label>SSC Code<input id="mpfSscCode"></label>
    </div>
    <div id="mpFormMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="mpFormCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="mpFormSave" class="btn-primary" style="margin-left:8px">Simpan</button>
    </div>
  </div>
</div>

<div id="mpDeleteModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 420px)">
    <h4>Konfirmasi Hapus</h4>
    <p>Anda yakin ingin menghapus <b id="mpDeleteCount">0</b> data terpilih? Tindakan ini tidak bisa dibatalkan.</p>
    <div style="margin-top:16px;text-align:right">
      <button id="mpDeleteCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="mpDeleteConfirm" class="btn-primary mp-danger" style="margin-left:8px">Hapus</button>
    </div>
  </div>
</div>

<div id="mpBulkStatusModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 420px)">
    <h4>Ubah Status Terpilih</h4>
    <p class="meta">Ubah status <b id="mpBulkStatusCount">0</b> part terpilih jadi:</p>
    <label style="display:block;margin-top:8px">Status baru
      <select id="mpBulkStatusSelect" style="display:block;width:100%;margin-top:4px;padding:6px 8px">
        <option>Direct</option><option>Sorting</option><option>Unpacking Murni</option><option>C/U</option>
      </select>
    </label>
    <div id="mpBulkStatusMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="mpBulkStatusCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="mpBulkStatusConfirm" class="btn-primary" style="margin-left:8px">Terapkan</button>
    </div>
  </div>
</div>

<div id="mpErrorModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(320px, 90vw, 680px);max-height:74vh;overflow:auto">
    <h4>Upload Ditolak</h4>
    <p class="meta" id="mpErrorSummary"></p>
    <table class="grid compact"><tr><th style="width:60px">Baris</th><th style="width:180px">Kolom</th><th>Masalah</th></tr>
      <tbody id="mpErrorRows"></tbody>
    </table>
    <div style="margin-top:16px;text-align:right">
      <button id="mpErrorClose" class="btn-primary">Tutup</button>
    </div>
  </div>
</div>

<div id="ofcFormModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(320px, 90vw, 560px)">
    <h4 id="ofcFormTitle">Tambah Baris Master Offset</h4>
    <div class="mp-form-grid">
      <label>Dock<input id="ofcfDock" value="43"></label>
      <label>Process<select id="ofcfProcess">
        <option value="SUPPLY">SUPPLY</option>
        <option value="PREPARE">PREPARE</option>
        <option value="HALTE 1">HALTE 1</option><option value="HALTE 2">HALTE 2</option><option value="HALTE 3">HALTE 3</option>
        <option value="EMPTY">EMPTY</option>
      </select></label>
      <label>Zone<select id="ofcfZone"><option value="timur">timur</option><option value="barat">barat</option></select></label>
      <label>Route<input id="ofcfRoute" list="ofcRouteList"></label>
      <label>Volume<input id="ofcfVolume" type="number"></label>
      <label>Offset<input id="ofcfOffset" placeholder="angka atau max-min"></label>
    </div>
    <div id="ofcFormMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="ofcFormCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="ofcFormSave" class="btn-primary" style="margin-left:8px">Simpan</button>
    </div>
  </div>
</div>

<div id="ofcUploadModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 460px)">
    <h4>Upload Master Offset</h4>
    <div class="dm-upload-modal-body">
      <button id="ofcChooseFile" class="tmode" type="button">📎 Choose File</button>
      <input type="file" id="ofcFile" accept=".xlsx" style="display:none">
      <span id="ofcFileName" class="meta">Belum pilih file</span>
      <label class="dm-upload-mode">Mode
        <select id="ofcUploadMode" title="Mode upload">
          <option value="0">Additional (tambah data baru)</option>
          <option value="1">Replace (ganti seluruh data)</option>
        </select>
      </label>
    </div>
    <div style="margin-top:16px;text-align:right">
      <button id="ofcUploadCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="ofcUploadBtn" class="btn-primary" style="margin-left:8px">↑ Upload</button>
    </div>
  </div>
</div>

<div id="ofcDeleteModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 420px)">
    <h4>Konfirmasi Hapus</h4>
    <p>Anda yakin ingin menghapus <b id="ofcDeleteCount">0</b> baris Master Offset terpilih? Tindakan ini tidak bisa dibatalkan.</p>
    <div style="margin-top:16px;text-align:right">
      <button id="ofcDeleteCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="ofcDeleteConfirm" class="btn-primary mp-danger" style="margin-left:8px">Hapus</button>
    </div>
  </div>
</div>

<div id="hmFormModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 420px)">
    <h4 id="hmFormTitle">Edit Alamat Halte</h4>
    <div class="mp-form-grid">
      <label>Halte 1 (address)<input id="hmf1"></label>
      <label>Halte 2 (address)<input id="hmf2"></label>
      <label>Halte 3 (address)<input id="hmf3"></label>
    </div>
    <div id="hmFormMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="hmFormCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="hmFormSave" class="btn-primary" style="margin-left:8px">Simpan</button>
    </div>
  </div>
</div>

<div id="cdFormModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 420px)">
    <h4 id="cdFormTitle">Tambah C/D Awal</h4>
    <div class="mp-form-grid">
      <label>C/D Awal<input id="cdfStart" type="number"></label>
      <label>Halte 1 (max-min)<input id="cdf1" placeholder="mis. 24-19"></label>
      <label>Halte 2 (max-min)<input id="cdf2" placeholder="mis. 18-13"></label>
      <label>Halte 3 (max-min)<input id="cdf3" placeholder="mis. 12-7"></label>
    </div>
    <div id="cdFormMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="cdFormCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="cdFormSave" class="btn-primary" style="margin-left:8px">Simpan</button>
    </div>
  </div>
</div>

<div id="cdDeleteModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 420px)">
    <h4>Konfirmasi Hapus</h4>
    <p>Yakin hapus <b id="cdDeleteCount">0</b> baris C/D Awal terpilih?</p>
    <div style="margin-top:16px;text-align:right">
      <button id="cdDeleteCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="cdDeleteConfirm" class="btn-primary mp-danger" style="margin-left:8px">Hapus</button>
    </div>
  </div>
</div>

<div id="rkFormModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 420px)">
    <h4 id="rkFormTitle">Tambah Rack</h4>
    <div class="mp-form-grid">
      <label>Address<input id="rkfAddr"></label>
      <label>X (px)<input id="rkfX" type="number" step="any"></label>
      <label>Y (px)<input id="rkfY" type="number" step="any"></label>
    </div>
    <div id="rkFormMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="rkFormCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="rkFormSave" class="btn-primary" style="margin-left:8px">Simpan</button>
    </div>
  </div>
</div>

<div id="rkDeleteModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 420px)">
    <h4>Konfirmasi Hapus</h4>
    <p>Yakin hapus <b id="rkDeleteCount">0</b> rack terpilih?</p>
    <div style="margin-top:16px;text-align:right">
      <button id="rkDeleteCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="rkDeleteConfirm" class="btn-primary mp-danger" style="margin-left:8px">Hapus</button>
    </div>
  </div>
</div>

<div id="pthFormModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 460px)">
    <h4 id="pthFormTitle">Tambah Titik Jalur</h4>
    <div class="mp-form-grid">
      <label>Route<input id="pthfRoute" list="ofcRouteList"></label>
      <label>Seq (urutan)<input id="pthfSeq" type="number"></label>
      <label>X (px)<input id="pthfX" type="number" step="any"></label>
      <label>Y (px)<input id="pthfY" type="number" step="any"></label>
      <label>Halte (0 = bukan)<input id="pthfH" type="number" min="0" max="3"></label>
    </div>
    <div id="pthFormMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="pthFormCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="pthFormSave" class="btn-primary" style="margin-left:8px">Simpan</button>
    </div>
  </div>
</div>

<div id="pthDeleteModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 420px)">
    <h4>Konfirmasi Hapus</h4>
    <p>Yakin hapus <b id="pthDeleteCount">0</b> titik jalur terpilih?</p>
    <div style="margin-top:16px;text-align:right">
      <button id="pthDeleteCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="pthDeleteConfirm" class="btn-primary mp-danger" style="margin-left:8px">Hapus</button>
    </div>
  </div>
</div>

<div id="puUniqModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(320px, 90vw, 640px);max-height:74vh;overflow:auto">
    <h4 id="puUniqTitle">Muatan Supplier</h4>
    <p class="meta" id="puUniqSubtitle"></p>
    <table class="grid compact"><tr><th style="width:110px">Uniq No</th><th style="width:140px">Part No</th><th>Part Name</th><th style="width:140px">Supplier</th></tr>
      <tbody id="puUniqRows"></tbody>
    </table>
    <div style="margin-top:16px;text-align:right">
      <button id="puUniqClose" class="btn-primary">Tutup</button>
    </div>
  </div>
</div>

<div id="puDeleteModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 420px)">
    <h4>Hapus dari Urutan?</h4>
    <p id="puDeleteMsg">Supplier <b id="puDeleteName">—</b> akan dikeluarkan dari urutan Pattern Unload route <b id="puDeleteRoute">—</b>. Bisa ditambahkan lagi lewat "+ Supplier" kalau berubah pikiran.</p>
    <div style="margin-top:16px;text-align:right">
      <button id="puDeleteCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="puDeleteConfirm" class="btn-primary mp-danger" style="margin-left:8px">Hapus</button>
    </div>
  </div>
</div>

<div id="puRouteAddModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 380px)">
    <h4>Tambah Route</h4>
    <p class="meta" id="puRouteAddSubtitle" style="margin-bottom:10px"></p>
    <label style="display:block;font-size:12px;font-weight:700">Nama Route
      <input id="puRouteAddInput" list="puRouteAddList" style="display:block;width:100%;margin-top:4px;padding:6px 8px;box-sizing:border-box" maxlength="10" placeholder="mis. E, C/U, UNP">
    </label>
    <datalist id="puRouteAddList"></datalist>
    <div id="puRouteAddMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="puRouteAddCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="puRouteAddSave" class="btn-primary" style="margin-left:8px">Tambah</button>
    </div>
  </div>
</div>

<div id="puUniqAddModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(320px, 90vw, 480px)">
    <h4>Tambah Part by Uniq No</h4>
    <p class="meta" id="puUniqAddSubtitle" style="margin-bottom:10px"></p>
    <div style="display:flex;gap:8px">
      <input id="puUniqAddInput" maxlength="4" placeholder="Kanban No (4 karakter)" style="flex:1;padding:6px 8px;box-sizing:border-box">
      <button id="puUniqAddSearch" class="tmode" type="button">Cari</button>
    </div>
    <div id="puUniqAddResults" class="pu-uniqresults"></div>
    <div id="puUniqAddMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="puUniqAddCancel" class="tmode" style="padding:8px 16px">Batal</button>
    </div>
  </div>
</div>

<div id="routePickModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 480px)">
    <h4>Pilih Route</h4>
    <p class="meta" style="margin-bottom:10px">Fokus ke satu route (sembunyikan yang lain di denah), atau tampilkan semua.</p>
    <div id="routePickGrid" class="routepick-grid"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="routePickCancel" class="tmode" style="padding:8px 16px">Tutup</button>
    </div>
  </div>
</div>

<div id="uploadModal" class="modal-overlay" style="display:none">
  <div class="modal-box">
    <h4 id="umTitle">Upload Master Data</h4>
    <p class="meta" id="umTemplateWrap"><a id="umTemplate" href="#" target="_blank">↓ Download Template</a></p>
    <p class="meta" id="umNote"></p>
    <input type="file" id="umFile" accept=".xlsx,.xlsm">
    <label class="form-check" style="display:block;margin-top:10px">
      <input type="checkbox" id="umReplace" checked> Ganti seluruh data lama (uncheck untuk tambah/gabung)
    </label>
    <div id="umMsg" class="meta" style="margin-top:8px"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="umCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="umSubmit" class="btn-primary" style="margin-left:8px">Upload</button>
    </div>
  </div>
</div>

</div>
</div>

<div class="toast" id="toast"></div>

<!-- JS dipecah per modul (assets/js/), urutan load PENTING (lihat komentar tiap file). -->
<script src="<?= av('assets/js/01-state.js') ?>"></script>
<script src="<?= av('assets/js/02-api.js') ?>"></script>
<script src="<?= av('assets/js/03-countdown.js') ?>"></script>
<script src="<?= av('assets/js/04-viewport.js') ?>"></script>
<script src="<?= av('editor/editor.js') ?>"></script>
<script src="<?= av('assets/js/06-render.js') ?>"></script>
<script src="<?= av('assets/js/07-sidebar.js') ?>"></script>
<script src="<?= av('assets/js/08-header.js') ?>"></script>
<script src="<?= av('assets/js/09-nav.js') ?>"></script>
<script src="<?= av('assets/js/10-database.js') ?>"></script>
<script src="<?= av('assets/js/11-upload-master.js') ?>"></script>
<script src="<?= av('assets/js/12-upload-progress.js') ?>"></script>
<script src="<?= av('assets/js/13-main.js') ?>"></script>
<script src="<?= av('assets/js/14-asset-upload.js') ?>"></script>
<script src="<?= av('assets/js/15-offset-counter.js') ?>"></script>
<script src="<?= av('assets/js/16-pattern-unload.js') ?>"></script>
<script src="<?= av('assets/js/17-master-part.js') ?>"></script>
<script src="<?= av('assets/js/18-sorting-plane.js') ?>"></script>
<script src="<?= av('assets/js/20-dolly-supply.js') ?>"></script>
<script src="<?= av('plane-sim/plane-sim.js') ?>"></script>
</body>
</html>
