<?php
/* =====================================================================
 * SORTING PLANE (smms_sorting_plane) — physical area tempat skid hasil bongkar Plane menunggu
 * proses SORTING, diidentifikasi lewat ROUTE (bukan nomor plane), kapasitas 1 atau 2 PLANE
 * (kapasitas Plane, BUKAN kapasitas skid/baris/kolom). Entity TERPISAH TOTAL dari "Physical Plane"
 * (smms_plane_manual, plane-sim/api.php) & "Sorting Store" (belum dibuat, entity beda) —
 * dikonfirmasi user eksplisit, JANGAN dicampur. Config-only fase ini: CRUD doang, BELUM ada
 * movement/distribusi skid per-route (itu fase integrasi data berikutnya).
 * ===================================================================== */

/** action=sorting_plane_list (GET) — semua baris, urut sorting_plane_num. */
function api_sorting_plane_list($db) {
    $q = $db->query("SELECT id,sorting_plane_num,route,plane_capacity FROM smms_sorting_plane ORDER BY sorting_plane_num");
    out(['rows'=>$q->fetch_all(MYSQLI_ASSOC)]);
}

/** action=sorting_plane_upsert_row (POST) — tambah/edit 1 baris (sorting_plane_num UNIQUE, dicek
 * manual di PHP dulu sblm insert biar pesan errornya jelas, bukan cuma "Duplicate entry" mentah dari
 * DB constraint). plane_capacity WAJIB 1 atau 2 (kapasitas PLANE, bukan skid). */
function api_sorting_plane_upsert_row($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    if (!is_array($in)) fail('payload?');
    $id = (int)($in['id'] ?? 0);
    $num = (int)($in['sorting_plane_num'] ?? 0);
    if ($num <= 0) fail('sorting_plane_num?');
    $route = strtoupper(trim($in['route'] ?? '')); if ($route === '') fail('route?');
    $capacity = (int)($in['plane_capacity'] ?? 0);
    if ($capacity !== 1 && $capacity !== 2) fail('plane_capacity harus 1 atau 2');

    // Cek duplikat sorting_plane_num -- kecuali baris yg sedang diedit (id sendiri).
    $st = $db->prepare("SELECT id FROM smms_sorting_plane WHERE sorting_plane_num=? AND id<>?");
    $dummyId = $id ?: -1;
    $st->bind_param('ii', $num, $dummyId);
    $st->execute();
    if ($st->get_result()->num_rows > 0) fail("Sorting Plane $num sudah ada");

    if ($id > 0) {
        $st = $db->prepare("UPDATE smms_sorting_plane SET sorting_plane_num=?,route=?,plane_capacity=? WHERE id=?");
        $st->bind_param('isii', $num, $route, $capacity, $id);
        $st->execute();
        out(['ok'=>true,'id'=>$id]);
    } else {
        $st = $db->prepare("INSERT INTO smms_sorting_plane (sorting_plane_num,route,plane_capacity) VALUES (?,?,?)");
        $st->bind_param('isi', $num, $route, $capacity);
        $st->execute();
        out(['ok'=>true,'id'=>$db->insert_id]);
    }
}

/** action=sorting_plane_delete_row (POST) — hapus 1 baris by id. */
function api_sorting_plane_delete_row($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    $id = (int)($in['id'] ?? 0);
    if ($id <= 0) fail('id?');
    $st = $db->prepare("DELETE FROM smms_sorting_plane WHERE id=?");
    $st->bind_param('i', $id);
    $st->execute();
    out(['ok'=>true]);
}

if ($act === 'sorting_plane_list') api_sorting_plane_list($db);
if ($act === 'sorting_plane_upsert_row' && $_SERVER['REQUEST_METHOD']==='POST') api_sorting_plane_upsert_row($db);
if ($act === 'sorting_plane_delete_row' && $_SERVER['REQUEST_METHOD']==='POST') api_sorting_plane_delete_row($db);
