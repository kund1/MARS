<?php
// ================= BACA DATA: bootstrap (meta+master+layout) & plane (part per plane) =================
// current_parts_batch() dipindah ke api/helpers.php (dipakai bareng oleh pattern_unload.php juga).

/** action=bootstrap — meta upload terakhir, daftar plane/address, layout rack+jalur, master halte/cd/supply-order. */
function api_bootstrap($db) {
    // Ambil semua meta info (nama file terakhir diupload, jumlah baris, waktu, dst)
    $meta = [];
    $q = $db->query("SELECT k,v FROM smms_meta"); while($r=$q->fetch_assoc()) $meta[$r['k']]=$r['v'];
    // Cuma pakai data dari upload TERBARU (batch_id terbesar) — upload sebelumnya tersimpan sbg cadangan saja
    $batch = current_parts_batch($db);
    // Daftar plane (P-Lane/MROS) yang ada di data part
    $planes = [];
    $q = $db->query("SELECT DISTINCT plane FROM smms_progress_lane WHERE batch_id=$batch ORDER BY plane"); while($r=$q->fetch_row()) $planes[]=$r[0];
    // Daftar alamat rack yang dipakai di data part
    $addr = [];
    $q = $db->query("SELECT DISTINCT addr FROM smms_progress_lane WHERE batch_id=$batch ORDER BY addr"); while($r=$q->fetch_row()) $addr[]=$r[0];
    // Posisi rack (koordinat x,y) di denah
    $racks = [];
    $q = $db->query("SELECT addr,x,y FROM smms_racks ORDER BY id"); while($r=$q->fetch_assoc()) $racks[]=['addr'=>$r['addr'],'x'=>(float)$r['x'],'y'=>(float)$r['y']];
    // Shape kotak vector (background "peta bersih" ala PPT/Google Maps, ditelusuri manual di Editor
    // di atas gambar denah asli — lihat smms_shapes, install.php).
    $shapes = [];
    $q = $db->query("SELECT id,x,y,w,h,rot,fill,stroke,text,kind,
        sorting_plane_id,sorting_plane_num,route,plane_capacity,
        dolly_supply_id,dolly_supply_num,dolly_route
        FROM smms_shapes ORDER BY id");
    while($r=$q->fetch_assoc()) $shapes[]=['x'=>(float)$r['x'],'y'=>(float)$r['y'],'w'=>(float)$r['w'],'h'=>(float)$r['h'],
        'rot'=>(float)$r['rot'],'fill'=>$r['fill'],'stroke'=>$r['stroke'],'text'=>$r['text'],'kind'=>$r['kind'],
        // kind='sortingplane' -- identity dibaca dari smms_sorting_plane, disalin ke shape saat ditempatkan
        // (lihat komentar kolom smms_shapes.sorting_plane_*, install.php).
        'sortingPlaneId'=>$r['sorting_plane_id']!==null?(int)$r['sorting_plane_id']:null,
        'sortingPlaneNum'=>$r['sorting_plane_num']!==null?(int)$r['sorting_plane_num']:null,
        'route'=>$r['route'], 'planeCapacity'=>(int)$r['plane_capacity'],
        // kind='dollysupply' -- padanan di atas, TANPA capacity.
        'dollySupplyId'=>$r['dolly_supply_id']!==null?(int)$r['dolly_supply_id']:null,
        'dollySupplyNum'=>$r['dolly_supply_num']!==null?(int)$r['dolly_supply_num']:null,
        'dollyRoute'=>$r['dolly_route']];
    // Titik-titik jalur (path) tiap route, dikelompokkan per route
    $paths = [];
    $q = $db->query("SELECT route,x,y,h,stage FROM smms_route_path ORDER BY route,seq");
    while($r=$q->fetch_assoc()) $paths[$r['route']][] = ['x'=>(float)$r['x'],'y'=>(float)$r['y'],'h'=>(int)$r['h'],'stage'=>$r['stage']];
    // Mapping countdown -> range halte (dikelompokkan per cd_start, diurut dari yg terbesar)
    $cdmap = [];
    $q = $db->query("SELECT * FROM smms_cd_mapping ORDER BY cd_start DESC, halte_no");
    while($r=$q->fetch_assoc()) $cdmap[$r['cd_start']][(int)$r['halte_no']-1] = [(int)$r['cd_max'],(int)$r['cd_min']];
    $cdlist=[]; foreach($cdmap as $s=>$h) $cdlist[]=['start'=>(int)$s,'h'=>$h];
    usort($cdlist, fn($a,$b)=>$b['start']-$a['start']);
    // Master halte (alamat rack per halte 1/2/3) tiap route — dari smms_halte_master (BALIK ke tabel
    // ini, bukan smms_offset lagi -- Master Offset sudah digabung 1 tabel & tidak punya kolom address
    // lagi, lihat komentar migrasi di install.php & api/config_save.php).
    $halte = [];
    $q = $db->query("SELECT route, halte_no, rack_addr FROM smms_halte_master");
    while($r=$q->fetch_assoc()){
        $halte[$r['route']][(int)$r['halte_no']-1] = $r['rack_addr'];
    }
    // Dolly nomor berapa (1-8, bisa lebih dari satu) yg lagi disupply di tiap halte per route —
    // dipakai nyalain kotak dolly-nya otomatis di Monitor pas towing berhenti di halte itu.
    $halteDolly = [];
    $q = $db->query("SELECT * FROM smms_halte_dolly ORDER BY route,halte_no,dolly_no");
    while($r=$q->fetch_assoc()) $halteDolly[$r['route']][(int)$r['halte_no']][] = (int)$r['dolly_no'];
    // Master urutan supply (Pattern Unload) tiap route
    $supplyOrder = [];
    $q = $db->query("SELECT route,seq,supplier,supplier_code,zone,offset_val FROM smms_pattern_unload ORDER BY route,seq");
    while($r=$q->fetch_assoc()) $supplyOrder[$r['route']][] = ['seq'=>(int)$r['seq'],'supplier'=>$r['supplier'],
        'supplier_code'=>$r['supplier_code'],'zone'=>$r['zone'],'offset'=>$r['offset_val']!==null?(int)$r['offset_val']:null];
    // Route -> zone (timur/barat), VLOOKUP dari Master Offset (smms_offset) — dipakai Pattern Unload
    // supaya pembagian kolom Zone Timur/Barat ikut data offset yang diupload, bukan daftar route hardcode.
    $routeZone = [];
    $q = $db->query("SELECT DISTINCT route,zone FROM smms_offset");
    while($r=$q->fetch_assoc()) $routeZone[$r['route']]=$r['zone'];
    // Semua baris Master Offset (dipakai offsetStatusFor() di header utk cari status route terpilih
    // di countdown sekarang — lihat 08-header.js).
    $offsetTable = [];
    $q = $db->query("SELECT process,zone,route,volume,offset_val FROM smms_offset");
    while($r=$q->fetch_assoc()) $offsetTable[] = ['process'=>$r['process'],'zone'=>$r['zone'],'route'=>$r['route'],
        'volume'=>(int)$r['volume'],'offset'=>$r['offset_val']];
    // Kembalikan semua data awal yang dibutuhkan frontend sekali jalan.
    // haltedolly di-cast (object) krn kalau kosong ([]), PHP nge-json_encode array kosong jadi "[]"
    // bukan "{}" — di JS itu tetap truthy jadi fallback "||{}" gak kepakai, HALTE_DOLLY jadi Array
    // kosong, terus tiap key (nama route) yg ditaruh situ diam-diam KEBUANG pas di-JSON.stringify lagi
    // buat save (JSON.stringify Array cuma nyimpen elemen ber-index, bukan property lain).
    out(['meta'=>$meta,'planes'=>$planes,'addresses'=>$addr,'racks'=>$racks,'shapes'=>$shapes,'paths'=>$paths,
         'cdmap'=>$cdlist,'halte'=>$halte,'haltedolly'=>(object)$halteDolly,'supply_order'=>$supplyOrder,
         'route_zone'=>(object)$routeZone, 'offset_table'=>$offsetTable,
         'counter_api'=>COUNTER_API !== '']);
}

/**
 * action=plane&p=NN — semua part utk satu plane, dikelompokkan per route.
 * Di-LEFT JOIN ke smms_master_part 2x:
 *  - by part_no: bawa volume_box & status (dipakai hitung jumlah dolly).
 *  - VLOOKUP by identitas supplier (supplier_code+supplier_plant+supplier_dock+route, setara
 *    SSC Code+Route di Master Part): bawa nama supplier "kanonik" dari Master Part, dipakai
 *    groupKeyForPart() di 03-countdown.js supaya pengelompokan dolly gak lagi fuzzy-match nama,
 *    tapi cocok persis by identitas. Kalau gak ketemu (data lama/belum lengkap), fallback ke
 *    nama supplier mentah dari Progress Lane (sp.supplier) — lihat COALESCE.
 * Index tiap baris (SETELAH array_shift route, lihat bawah — jadi -1 dari urutan SELECT di atas):
 * [9]=volume_box, [10]=status, [11]=vlookup_supplier, [12]=supplier_code, [13]=supplier_plant,
 * [14]=supplier_dock, [15]=dock_code, [16]=sub_route_code, [17]=cd_arrival_at, [18]=cd_departure_at.
 */
function api_plane($db) {
    // Validasi parameter plane (harus 2 digit angka, mis. "01")
    $p = $_GET['p'] ?? ''; if(!preg_match('/^\d\d$/',$p)) fail('plane?');
    // Default: data dari upload TERBARU (batch_id terbesar). $_GET['date'] opsional dipakai HANYA
    // oleh preview tabel Progress Lane di tab Database (lihat 10-database.js) — Monitor gak pernah
    // kirim parameter ini, jadi behavior defaultnya tetap sama persis kayak sebelumnya.
    $batch = current_parts_batch($db, $_GET['date'] ?? null);
    // Ambil semua part di plane ini, JOIN ke Master Part (by part_no & by identitas supplier)
    $st = $db->prepare("
        SELECT sp.route, sp.part_no, sp.part_name, sp.kanban, sp.qty, sp.lot, sp.addr, sp.supplier, sp.uniq_no, sp.order_no,
               COALESCE(mp.volume_box,0) AS volume_box, COALESCE(mp.status,'Direct') AS status,
               COALESCE((
                 SELECT mp2.supplier_name FROM smms_master_part mp2
                 WHERE mp2.supplier_code=sp.supplier_code AND mp2.supplier_plant_code=sp.supplier_plant
                   AND mp2.shipping_dock=sp.supplier_dock AND mp2.route=sp.route
                 LIMIT 1
               ), sp.supplier) AS vlookup_supplier,
               sp.supplier_code, sp.supplier_plant, sp.supplier_dock, COALESCE(mp.dock_code,'') AS dock_code,
               sp.sub_route_code, sp.cd_arrival_at, sp.cd_departure_at
        FROM smms_progress_lane sp
        LEFT JOIN smms_master_part mp ON mp.part_no = sp.part_no
        WHERE sp.plane=? AND sp.batch_id=? ORDER BY sp.route, sp.id
    ");
    $st->bind_param('si',$p,$batch); $st->execute();
    // Kelompokkan hasil per route (route dibuang dari tiap baris krn sudah jadi key)
    $res = $st->get_result(); $routes = [];
    while($r=$res->fetch_row()){ $rt=array_shift($r); $routes[$rt][]=$r; }
    out(['plane'=>$p,'routes'=>$routes]);
}

/** action=supplier_list — semua nama supplier unik yg pernah muncul di data part (semua plane). */
function api_supplier_list($db) {
    // Cuma pakai data dari upload TERBARU (batch_id terbesar)
    $batch = current_parts_batch($db);
    // Ambil semua nama supplier unik (buang yang kosong), urut abjad
    $q = $db->query("SELECT DISTINCT supplier FROM smms_progress_lane WHERE batch_id=$batch AND supplier <> '' ORDER BY supplier");
    $out = []; while($r=$q->fetch_row()) $out[] = $r[0];
    out(['suppliers'=>$out]);
}

if ($act === 'bootstrap') api_bootstrap($db);
if ($act === 'plane') api_plane($db);
if ($act === 'supplier_list') api_supplier_list($db);
