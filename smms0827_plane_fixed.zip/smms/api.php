<?php
// ================= ROUTER API SMMS =================
// File ini cuma dispatcher tipis. Logic tiap endpoint ada di folder api/ (satu file per fitur)
// supaya gampang di-maintain — cari action-nya di tabel $ROUTES, buka file yang dirujuk di situ.
require __DIR__.'/config.php';
require __DIR__.'/api/helpers.php';

$db = db();
header('Content-Type: application/json; charset=utf-8');
$act = $_GET['action'] ?? '';

// action => file di folder api/ yang menanganinya (beberapa action berbagi satu file).
$ROUTES = [
    'bootstrap'            => 'data.php',
    'plane'                => 'data.php',
    'supplier_list'         => 'data.php',
    'save_supply_order'     => 'master_uploads.php',
    'save_config'          => '../editor/api.php',
    'save_master'          => 'config_save.php',
    'upload'               => 'progress_lane.php',
    'progress_lane_upload_history' => 'progress_lane.php',
    'progress_lane_excel'   => 'progress_lane.php',
    'progress_lane_dates'   => 'progress_lane.php',
    'upload_halte_master'  => 'master_uploads.php',
    'upload_cd_mapping'    => 'master_uploads.php',
    'upload_racks'         => 'master_uploads.php',
    'upload_route_path'    => 'master_uploads.php',
    'upload_supply_order'  => 'master_uploads.php',
    'upload_master_part'          => 'master_part.php',
    'master_part_list'            => 'master_part.php',
    'master_part_add'             => 'master_part.php',
    'master_part_edit'             => 'master_part.php',
    'master_part_delete'           => 'master_part.php',
    'master_part_bulk_status'      => 'master_part.php',
    'master_part_excel'            => 'master_part.php',
    'master_part_upload_history'   => 'master_part.php',
    'master_part_template'         => 'master_part.php',
    'master_part_routes'           => 'master_part.php',
    'sorting_plane_list'           => 'sorting_plane.php',
    'sorting_plane_upsert_row'     => 'sorting_plane.php',
    'sorting_plane_delete_row'     => 'sorting_plane.php',
    'dolly_supply_list'            => 'dolly_supply.php',
    'dolly_supply_upsert_row'      => 'dolly_supply.php',
    'dolly_supply_delete_row'      => 'dolly_supply.php',
    'upload_asset'         => 'assets.php',
    'counter'              => 'counter.php',
    'offset_list'          => 'offset_counter.php',
    'upload_offset'        => 'offset_counter.php',
    'save_offset_settings' => 'offset_counter.php',
    'offset_upsert_row'    => 'offset_counter.php',
    'offset_delete_row'    => 'offset_counter.php',
    'offset_template'      => 'offset_counter.php',
    'pu_grouped_by_supplier' => 'pattern_unload.php',
    'pu_lookup_uniq'         => 'pattern_unload.php',
    // Sub-menu "Pengaturan Fisik Plane" (Plane Simulation) — filenya sengaja di luar folder api/,
    // disatukan di plane-sim/ bareng JS/CSS/HTML fitur ini (lihat plane-sim/api.php).
    'plane_sim_save_settings'  => '../plane-sim/api.php',
    'plane_sim_upload_config'  => '../plane-sim/api.php',
    'plane_sim_save_conveyor'  => '../plane-sim/api.php',
    'plane_sim_bulk'           => '../plane-sim/api.php',
    'plane_sim_manual_list'         => '../plane-sim/api.php',
    'plane_sim_manual_upsert_row'   => '../plane-sim/api.php',
    'plane_sim_manual_delete_row'   => '../plane-sim/api.php',
];

if (isset($ROUTES[$act])) {
    require __DIR__.'/api/'.$ROUTES[$act];
}

fail('action tidak dikenal');
