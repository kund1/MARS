<?php
/* =====================================================================
   PLANE-SIM/VIEW.PHP — markup HTML menu "Plane Simulation": tab utama
   (buffer 12 plane) + 2 modal (drill-down tumpukan & isi part 1 grup).
   Di-include dari index.php. SEMUA berkas fitur ini disatukan di 1 folder
   plane-sim/: view.php (ini), plane-sim.css, plane-sim.js, api.php —
   biar gampang dirawat dari 1 tempat.
   ===================================================================== */
?>
<div id="tab-planesim">
  <div class="ps-head">
    <h2>Plane Simulation</h2>
    <p class="meta">Visualisasi buffer P-Lane saat ini (1 kotak = 1 skid) dari data Progress Lane yang sedang aktif. Plane paling kiri (bertanda AKTIF) mengikuti countdown yang sedang berjalan; sisanya simulasi antrian mengisi.</p>
    <div style="display:flex;gap:10px;align-items:center;margin-top:8px;flex-wrap:wrap">
      <div class="ps-viewmode-switch">
        <button class="ps-viewmode-btn on" data-mode="fisik" type="button" title="Cuma tampilkan slot fisik sekarang (sejumlah Jumlah Slot Fisik), sesuai posisi towing aktual">🗂 Fisik</button>
        <button class="ps-viewmode-btn" data-mode="full" type="button" title="Tampilkan SEMUA nomor plane (1..MAX PLANE) sekaligus, disusun per baris sejumlah Jumlah Slot Fisik">🗺 Full Plane</button>
      </div>
      <div class="ps-daterange" title="Gabungkan data dari beberapa tanggal upload Progress Lane sekaligus (kronologis, tiap plane per-tanggal tetap entitas terpisah) — default keduanya = tanggal terbaru (sama seperti sekarang)">
        <label class="meta" style="margin:0">Dari <select id="psDateFromSel" style="margin-left:4px;padding:4px 8px"></select></label>
        <label class="meta" style="margin:0">Sampai <select id="psDateToSel" style="margin-left:4px;padding:4px 8px"></select></label>
      </div>
      <button id="psSettingsBtn" class="tmode" style="padding:6px 12px">⚙ Pengaturan Fisik Plane</button>
      <button id="psManualBtn" class="tmode" style="padding:6px 12px">🔢 Data Plane Manual</button>
      <button id="psSimTimeBtn" class="tmode" style="padding:6px 12px">🕐 Atur Waktu Simulasi</button>
      <span class="meta" id="psSimTimeNow" style="margin:0"></span>
    </div>
  </div>
  <div class="ps-legend">
    <span><span class="ps-dot" style="background:#3B82F6"></span>Sedang diproses</span>
    <span><span class="ps-dot" style="background:#16A34A"></span>Penuh / siap</span>
    <span><span class="ps-dot" style="background:#EAB308"></span>Sedang diisi</span>
  </div>
  <div id="psFisikWrap" class="ps-buffer-row">
    <div id="psAxis" class="ps-axis"></div>
    <div id="psBuffer" class="ps-buffer"></div>
  </div>
  <div id="psFullWrap" class="ps-full-wrap" style="display:none"></div>
</div>

<div id="psDetailModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(320px, 94vw, 1000px);max-height:88vh;overflow:auto">
    <h4 id="psDetailTitle">Plane —</h4>
    <p class="meta" id="psDetailSubtitle"></p>
    <div class="ps-detail-baris">
      <div class="ps-detail-barislbl">Baris 1</div>
      <div class="ps-detail-row">
        <div id="psDetailAxis1" class="ps-axis ps-detail-axis"></div>
        <div id="psDetailGrid1" class="ps-detail-grid"></div>
      </div>
    </div>
    <div class="ps-detail-baris">
      <div class="ps-detail-barislbl">Baris 2</div>
      <div class="ps-detail-row">
        <div id="psDetailAxis2" class="ps-axis ps-detail-axis"></div>
        <div id="psDetailGrid2" class="ps-detail-grid"></div>
      </div>
    </div>
    <h3 style="margin-top:22px">Daftar Supplier &amp; Part</h3>
    <div id="psDetailFullList" class="ps-fulllist"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="psDetailClose" class="tmode" style="padding:8px 16px">Tutup</button>
    </div>
  </div>
</div>

<div id="psPartsModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(320px, 90vw, 680px);max-height:76vh;overflow:auto">
    <h4 id="psPartsTitle">Isi Grup</h4>
    <p class="meta" id="psPartsSubtitle"></p>
    <table class="grid compact"><tr><th style="width:120px">Part No</th><th>Nama</th><th style="width:90px">Kanban</th><th style="width:90px">Qty×Lot</th><th style="width:60px">Route</th></tr>
      <tbody id="psPartsRows"></tbody>
    </table>
    <div style="margin-top:16px;text-align:right">
      <button id="psPartsClose" class="btn-primary">Tutup</button>
    </div>
  </div>
</div>

<div id="psManualModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(320px, 92vw, 640px);max-height:88vh;overflow:auto">
    <h4>Data Plane Manual (Physical Plane)</h4>
    <p class="meta">Tambahkan physical Plane satu per satu — tiap baris di sini BENERAN merepresentasikan 1 Plane fisik (nomor, Max Volume/kapasitas skid, Filled/isi sekarang), TERPISAH dari data Progress Lane. Selama ada &ge;1 baris di sini, buffer "Fisik" menampilkan PERSIS Plane yang kamu tambahkan (bukan lagi siklus otomatis dari Progress Lane) — kosongkan semua baris untuk kembali ke tampilan otomatis.</p>
    <div id="psManualWarning" class="meta" style="margin-top:6px"></div>
    <div style="display:flex;justify-content:flex-end;margin-top:10px">
      <button id="psManualAddBtn" class="btn-primary" style="padding:6px 14px">+ Add</button>
    </div>
    <div id="psManualTableBox" class="dm-tablewrap" style="margin-top:8px"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="psManualClose" class="tmode" style="padding:8px 16px">Tutup</button>
    </div>
  </div>
</div>

<div id="psManualFormModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(300px, 90vw, 420px)">
    <h4 id="psManualFormTitle">Tambah Plane Manual</h4>
    <div class="mp-form-grid">
      <label>Nomor Plane<input id="psManualfNum" type="number" min="1"></label>
      <label>Max Volume<input id="psManualfMax" type="number" min="0"></label>
      <label>Filled<input id="psManualfFilled" type="number" min="0" value="0"></label>
    </div>
    <div id="psManualFormMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="psManualFormCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="psManualFormSave" class="btn-primary" style="margin-left:8px">Simpan</button>
    </div>
  </div>
</div>

<div id="psSettingsModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(320px, 92vw, 900px);max-height:88vh;overflow:auto">
    <h4>Pengaturan Fisik Plane</h4>
    <p class="meta">Slot fisik P-Lane diisi berurutan 1..MAX PLANE nyebar ke tiap kolom slot, begitu lewat MAX PLANE nomornya balik ke 1 &amp; lanjut ngisi (bukan reset) — persis pola "VERSI FISIK 12 P-LANE SPIRAL". Atur MAX PLANE, jumlah slot fisik (kolom), dan jumlah baris tumpukan di sini — semuanya angka fisik nyata, jadi patokan tetap bagaimana simulasi digambar (bukan dihitung otomatis dari data lagi, kecuali MAX PLANE mode Otomatis).</p>
    <div style="margin-top:10px">
      <div style="font-size:12px;font-weight:700;margin-bottom:6px">MAX PLANE</div>
      <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">
        <label style="font-size:12px;font-weight:400;display:flex;align-items:center;gap:5px;cursor:pointer">
          <input type="radio" name="psMaxPlaneMode" id="psMaxPlaneModeAuto" value="auto">
          Otomatis — ambil MROS tertinggi dari data Progress Lane sekarang
        </label>
        <label style="font-size:12px;font-weight:400;display:flex;align-items:center;gap:5px;cursor:pointer">
          <input type="radio" name="psMaxPlaneMode" id="psMaxPlaneModeManual" value="manual">
          Manual — isi sendiri
        </label>
      </div>
      <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:8px">
        <input id="psMaxPlaneInput" type="number" min="12" max="999" style="width:80px;padding:4px 8px" />
        <label style="font-size:12px;font-weight:700">Jumlah Slot Fisik (kolom)
          <input id="psSlotCountInput" type="number" min="9" max="12" style="width:60px;margin-left:6px;padding:4px 8px" />
        </label>
        <label style="font-size:12px;font-weight:700">Jumlah Baris Tumpukan
          <input id="psOverviewRowsInput" type="number" min="4" max="60" style="width:60px;margin-left:6px;padding:4px 8px" />
        </label>
        <label style="font-size:12px;font-weight:700" title="Berapa tanggal upload Progress Lane terakhir yang disimpan sebelum yang terlama otomatis terhapus (ganti sistem H-1/H+1 lama)">Simpan N Tanggal Terakhir
          <input id="psRetainBatchesInput" type="number" min="1" max="30" style="width:60px;margin-left:6px;padding:4px 8px" />
        </label>
        <button id="psMaxPlaneSave" class="btn-primary" style="padding:6px 14px">Simpan</button>
        <span style="border-left:1px solid var(--line);height:20px"></span>
        <label class="tmode" style="padding:6px 14px;cursor:pointer">
          Upload file referensi
          <input id="psConfigUploadInput" type="file" accept=".xlsx,.xls,.csv" style="display:none" />
        </label>
      </div>
      <div id="psMaxPlaneAutoInfo" class="meta" style="display:none;margin-top:6px"></div>
      <div id="psSettingsMsg" class="meta" style="margin-top:6px"></div>
    </div>
    <h3 style="margin-top:20px">Preview Tabel (hasil kalkulasi)</h3>
    <div id="psSettingsPreview" style="overflow-x:auto;margin-top:8px"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="psSettingsClose" class="tmode" style="padding:8px 16px">Tutup</button>
    </div>
  </div>
</div>

<div id="psSimTimeModal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="width:clamp(320px, 92vw, 520px)">
    <h4>Atur Waktu Simulasi</h4>
    <p class="meta">Kategori kosong/lagi diisi/penuh dibandingkan ke "waktu simulasi" di bawah ini, bukan (selalu) ke jam sekarang sungguhan — pilih Mode Waktu di bawah sesuai kebutuhan.</p>
    <div style="margin-top:10px">
      <div style="font-size:12px;font-weight:700;margin-bottom:6px">Mode Waktu</div>
      <div style="display:flex;flex-direction:column;gap:6px">
        <label style="font-size:12px;font-weight:400;display:flex;align-items:flex-start;gap:6px;cursor:pointer">
          <input type="radio" name="psTimeMode" id="psTimeModeAktual" value="aktual" style="margin-top:3px">
          <span><b>Aktual</b> — jam komputer beneran + offset manual (di bawah). Berguna buat demo pakai data lama (mis. tanggal upload Progress Lane terakhir) seolah-olah lagi berjalan "sekarang". Sesudah diset, waktu simulasi tetap MAJU mengikuti kecepatan wall-clock asli (1 detik nyata = 1 detik simulasi), cuma titik awalnya digeser.</span>
        </label>
        <label style="font-size:12px;font-weight:400;display:flex;align-items:flex-start;gap:6px;cursor:pointer">
          <input type="radio" name="psTimeMode" id="psTimeModeSimulasi" value="simulasi" style="margin-top:3px">
          <span><b>Simulasi</b> — direntang otomatis mengikuti bar countdown yang sedang berjalan, dari 1st Cross Dock Arrival paling awal s/d Departcher paling akhir di Plane yang sekarang aktif (biru). Countdown baru mulai = waktu paling awal, countdown habis = waktu paling akhir.</span>
        </label>
      </div>
    </div>
    <div style="margin-top:10px;padding:10px 12px;border:1px solid var(--line);border-radius:8px;background:var(--panel2)">
      <div style="font-size:11px;font-weight:700;color:var(--mut);text-transform:uppercase;letter-spacing:.04em">Waktu Simulasi Sekarang</div>
      <div id="psSimTimeCurrent" class="tw-font-mono" style="font-size:18px;font-weight:700;margin-top:2px">—</div>
    </div>
    <div id="psSimTimeManualWrap" style="margin-top:14px">
      <label style="font-size:12px;font-weight:700;display:block">Set waktu simulasi jadi
        <input id="psSimTimeInput" type="datetime-local" step="1" style="display:block;width:100%;margin-top:4px;padding:6px 8px" />
      </label>
      <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap">
        <button id="psSimTimeFromData" class="tmode" type="button" style="padding:6px 12px" title="Isi otomatis dari 1st Cross Dock Arrival Date &amp; Time paling awal di data plane yang sudah dimuat">📋 Ambil dari arrival tertua di data</button>
        <button id="psSimTimeResetReal" class="tmode" type="button" style="padding:6px 12px">↺ Reset ke waktu asli</button>
      </div>
    </div>
    <div id="psSimTimeMsg" class="mp-form-msg"></div>
    <div style="margin-top:16px;text-align:right">
      <button id="psSimTimeCancel" class="tmode" style="padding:8px 16px">Batal</button>
      <button id="psSimTimeSave" class="btn-primary" style="margin-left:8px">Terapkan</button>
    </div>
  </div>
</div>
