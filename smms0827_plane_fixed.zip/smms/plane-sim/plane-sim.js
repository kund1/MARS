  /* =====================================================================
    PLANE-SIM/PLANE-SIM.JS — menu "Plane Simulation": visualisasi buffer 12
    plane dari data Progress Lane + drill-down per plane. Di-load PALING
    TERAKHIR dari semua script (lihat urutan <script> di index.php) krn
    pakai banyak fungsi/global dari file assets/js/01..18 (rcolor, loadPlane,
    PCACHE, PLANES, dst) — TETAP di posisi urutan load itu walau lokasi
    filenya sendiri sekarang di folder plane-sim/ (SEMUA berkas fitur ini
    disatukan di 1 folder: plane-sim.js (ini), plane-sim.css, view.php,
    api.php — biar gampang dirawat dari 1 tempat).

    Overview = PANDANGAN DARI ATAS kapasitas fisik plane: 2 kolom x 16 baris
    TETAP (32 slot tumpukan, gak berubah-ubah per plane) — 1 kotak di overview
    ini = 1 TUMPUKAN (stack, hasil psPackStacksForPlane), BUKAN 1 skid. Rincian
    "berapa skid & model tumpukannya kayak apa" itu urusan drill-down (dibuka
    pas nomor plane-nya diklik), overview cuma nunjukin seberapa penuh 32 slot
    itu keisi tumpukan.

    Konsep skid: part dikelompokkan per (dock_code+supplier_code+supplier_plant)
    — dikonfirmasi user, TANPA supplier_dock (kolom itu yg paling gak konsisten
    keisinya di data — 1 supplier_code+plant yg sama kadang ada dock-nya kadang
    kosong) & TANPA route sbg pembeda. Kalau route ikut jadi pembeda grup, tiap
    pecahan kecil per-route kena floor MAX(1,...) sendiri2 dan JUMLAH SKID JADI
    KEBENGKAK jauh dari realita (dicek langsung: plane 05 dgn route split = 90
    grup/94 stack, TANPA route split jauh lebih dekat ke actual ~32 baris yg
    dilaporkan user). Route tetap direkam PER PART (bukan per grup) buat
    ditampilkan di drill-down/parts modal.
    Part status "Unpacking Murni" dikecualikan dari grup supplier manapun, jadi
    1 grup tersendiri "UNPACKING" per plane (lintas semua route juga). Jumlah
    skid per grup = MAX(1, ROUND(total volume_box x lot)) — rumus SAMA PERSIS
    kayak jumlah dolly per supplier (lihat dollyGroups, 03-countdown.js).

    Model slot & penomoran (dikonfirmasi user eksplisit: "1=13, 2=14, 3=15,
    4=16 dan seterusnya, jadi posisinya adalah fix"): ada 12 POSISI LAYAR
    TETAP (gak pernah geser urutannya kiri-kanan), TIAP POSISI/slot N PUNYA
    PASANGAN NOMOR SENDIRI YG TETAP — gantian nampilin N lalu N+12, abis itu
    balik lagi ke N, dst selang-seling (psSlotGen, BUKAN counter global yg
    dibagi bareng semua slot — slot5 SELALU gantian 5<->17, gak pernah dapat
    nomor dari slot lain). Begitu slot yg lagi AKTIF (biru) selesai diproses
    (kosong), pasangan nomornya di-toggle (psAdvanceActiveSlot) & posisi itu
    mulai ngisi dari kuning lagi pakai data plane generasi berikutnya.
    SETELAHNYA baru status AKTIF (biru) pindah ke posisi sebelahnya
    (psActiveSlot maju 1, 12->balik ke 1).
    Kategori tiap posisi (hijau/kuning/kosong) dihitung RELATIF ke psActiveSlot
    pakai PS_FILL_PATTERN yg sama (psRelOf) — jadi pola warnanya "ikut"
    psActiveSlot berpindah, sementara POSISI di layar tetap diam, cuma NOMOR
    & datanya yg diperbarui pas gilirannya recycle.
    ===================================================================== */

  /** Parser TERPUSAT format waktu MROS/Progress Lane -> epoch ms (Number, NaN kalau format-nya gak
   * dikenali sama sekali). Terima 2 bentuk:
   * 1) Angka rapat "YYYYMMDDHHMMSS" (14 digit) / "YYYYMMDDHHMM" (12 digit, detik default "00") —
   *    format RAW asli kolom "1st Cross Dock Arrival/Departcher Date & Time" (AJ/AK) di file sumber
   *    MROS SEBELUM diformat backend (lihat validDateOrNull, plane-sim/api.php) — dites langsung ke
   *    file "Order by Receiving" real.
   * 2) String tanggal "standar" apa aja yg dikenali Date.parse (termasuk format MySQL "Y-m-d H:i:s"
   *    yg TERSIMPAN di DB sekarang, hasil normalisasi validDateOrNull — cukup ganti spasi jadi "T"
   *    dulu biar konsisten dikenali semua browser).
   * Dipakai GANTI semua `Date.parse(...)` manual yg sebelumnya cuma nanganin bentuk (2) doang (mis.
   * calculatePlaneArrivalState) — SEMUA titik parse tanggal di file ini sekarang lewat sini biar konsisten
   * & tetap aman kalau suatu saat ada data mentah (bentuk 1) yg lolos gak lewat validDateOrNull backend
   * dulu (mis. dipakai ulang langsung dari hasil parse upload). */
  function parseCustomDate(s){
    if(s===null || s===undefined || s==="") return NaN;
    const str=String(s).trim();
    const m=str.match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})?$/); // YYYYMMDDHHMM[SS] rapat
    if(m){
      const [,y,mo,d,h,mi,se]=m;
      return new Date(+y,+mo-1,+d,+h,+mi,+(se||0)).getTime();
    }
    const isoTs=Date.parse(str.replace(" ","T")); // "Y-m-d H:i:s" (DB) -> "Y-m-dTH:i:s" (ISO-ish)
    if(!isNaN(isoTs)) return isoTs;
    return Date.parse(str); // last resort -- format asli apa adanya (jaga2 kalau replace di atas malah bikin invalid)
  }

  // Jumlah slot fisik — dikonfigurasi user lewat sub-menu "Pengaturan Fisik Plane" (rentang 9-12,
  // smms_meta key 'plane_sim_slot_count'), fallback 12 kalau belum pernah diatur.
  const PS_SLOT_COUNT_MIN=5, PS_SLOT_COUNT_MAX=12;
  let PS_BUFFER_SIZE=Math.min(PS_SLOT_COUNT_MAX,Math.max(PS_SLOT_COUNT_MIN,+(META.plane_sim_slot_count||12)));
  const PS_OVERVIEW_COLS=2; // overview SELALU 2 kolom rata (pandangan dari atas) per slot plane.

  // Jumlah baris tumpukan per kolom overview — SAMA kayak Jumlah Slot Fisik, dikonfigurasi user lewat
  // "Pengaturan Fisik Plane" (smms_meta key 'plane_sim_overview_rows'), fallback 16 kalau belum
  // pernah diatur. FIXED sesuai angka fisik ini (BUKAN lagi dihitung otomatis dari tumpukan TERBANYAK
  // yg kebetulan ada di data sekarang kayak versi sebelumnya) -- representasi kapasitas rak/slot
  // tumpuk ASLI, konsisten sama semangat "Jumlah Slot Fisik" (kolom): dua-duanya angka fisik nyata,
  // bukan hasil kalkulasi data. Kalau data real py lebih banyak tumpukan drpd kapasitas ini,
  // psTargetFor() udah nge-cap ke psOverviewRows*PS_OVERVIEW_COLS (gauge penuh, gak overflow/pecah).
  const PS_OVERVIEW_ROWS_MIN=4, PS_OVERVIEW_ROWS_MAX=60;
  let psOverviewRows=Math.max(PS_OVERVIEW_ROWS_MIN,Math.min(PS_OVERVIEW_ROWS_MAX,+(META.plane_sim_overview_rows||16)));

  /* =====================================================================
     MULTI-TANGGAL — pilih rentang tanggal upload Progress Lane ("Dari"–"Sampai" di header tab ini)
     buat digabung jadi 1 simulasi kronologis, GANTI batasan lama "cuma bisa 1 batch aktif" (dikonfirmasi
     user: sisa skid shift kemarin yg belum di-unload harus tetap kelihatan pas simulasi mulai hari
     baru). Default (belum disentuh user) = tanggal terbaru SAJA -> collapse total ke perilaku lama.
     Tiap plane per-tanggal TETAP entitas terpisah (TIDAK digabung/merge by nomor sama, dikonfirmasi
     user eksplisit) -- lihat PS_DATA_SEQUENCE di bawah. PS_PCACHE cache LOKAL modul ini, TERPISAH
     TOTAL dari PCACHE/loadPlane milik Monitor (assets/js/02-api.js) supaya gak pernah collide.
     ===================================================================== */
  let psSequenceInitialized=false; // false SAMPAI render PERTAMA kelar -- cegah psRebuildDataSequence()
                                    // ngelaporin "changed" (=> psResetConveyor, buang state persisted)
                                    // cuma krn transisi dari kosong ke isi pas app baru dibuka.
  let PS_DATE_OPTIONS=[];        // [{batch_id,data_date,filename,rows_count,planes,active}], dari action=progress_lane_dates
  let PS_PLANES_BY_DATE={};      // data_date -> [nomor plane,...] (parsed dari kolom `planes` CSV)
  let PS_DATE_FROM=null, PS_DATE_TO=null;  // null = belum dipilih user -> default (tanggal `active`)
  let PS_RANGE_DATES=[];         // tanggal kronologis dlm [FROM..TO] yg beneran ada datanya
  let PS_PCACHE={};              // key "date|num" (atau "num" polos kalau range blm dipilih) -> routes
  let PS_DATA_SEQUENCE=[];       // [{date,num,pid}] REAL kronologis, TANPA padding/modulo-repeat
  let psDateOptionsFingerprint="", psSequenceFingerprint="";

  /** Format tanggal ISO ("2026-08-24") jadi label ringkas "24 Agu" (tanpa tahun -- ruang kartu plane
   * sempit) -- dipakai badge tanggal (psBuildPlaneCard) & judul drill-down (psOpenDetail). */
  function psCompactDateLabel(iso){
    const bulan=["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];
    const [,m,d]=String(iso).split("-").map(Number);
    return `${String(d).padStart(2,"0")} ${bulan[m-1]}`;
  }

  /** Ambil daftar tanggal Progress Lane yang masih ada (sumber SAMA dgn pill tanggal di tab Database,
   * lihat plRefreshDates/12-upload-progress.js) + bangun PS_PLANES_BY_DATE, set default Dari=Sampai=
   * tanggal `active:true` KALAU user belum pernah mengubah dropdown. Fingerprint-guarded (skip rebuild
   * DOM select kalau daftarnya gak beneran berubah) -- dipanggil tiap renderPlaneSim() (murah, 1 SELECT
   * ringan, pola sama kayak psSyncAutoMaxPlane yg juga jalan tiap render). */
  async function psLoadDateOptions(){
    const d=await apiGet('action=progress_lane_dates').catch(()=>({rows:[]}));
    const rows=d.rows||[];
    const newKey=rows.map(r=>r.data_date+":"+r.planes).join(",");
    if(newKey===psDateOptionsFingerprint) return;
    psDateOptionsFingerprint=newKey;
    PS_DATE_OPTIONS=rows; PS_PLANES_BY_DATE={};
    rows.forEach(r=>{ PS_PLANES_BY_DATE[r.data_date]=(r.planes||"").split(",").map(s=>s.trim()).filter(Boolean); });
    const activeRow=rows.find(r=>r.active);
    const defaultDate=activeRow?activeRow.data_date:(rows.length?rows[rows.length-1].data_date:null);
    if(PS_DATE_FROM===null || !rows.some(r=>r.data_date===PS_DATE_FROM)) PS_DATE_FROM=defaultDate;
    if(PS_DATE_TO===null || !rows.some(r=>r.data_date===PS_DATE_TO)) PS_DATE_TO=defaultDate;
    psPopulateDateSelect(document.getElementById("psDateFromSel"), rows, PS_DATE_FROM);
    psPopulateDateSelect(document.getElementById("psDateToSel"), rows, PS_DATE_TO);
    psRecomputeRangeDates();
  }
  function psPopulateDateSelect(sel, rows, selected){
    if(!sel) return;
    sel.innerHTML=rows.map(r=>`<option value="${r.data_date}">${plFormatDateLabel(r.data_date)}</option>`).join("");
    sel.value=selected||"";
  }
  function psRecomputeRangeDates(){
    if(!PS_DATE_FROM || !PS_DATE_TO || PS_DATE_FROM>PS_DATE_TO){ PS_RANGE_DATES=PS_DATE_TO?[PS_DATE_TO]:[]; return; }
    PS_RANGE_DATES = PS_DATE_OPTIONS.map(r=>r.data_date).filter(d=>d>=PS_DATE_FROM && d<=PS_DATE_TO);
  }
  function psApplyDateRange(){
    const from=document.getElementById("psDateFromSel").value, to=document.getElementById("psDateToSel").value;
    if(from>to){ toast("Tanggal 'Dari' tidak boleh setelah 'Sampai'"); return; }
    PS_DATE_FROM=from; PS_DATE_TO=to;
    psRecomputeRangeDates();
    if(typeof renderPlaneSim==="function") renderPlaneSim();
  }
  document.getElementById("psDateFromSel").onchange=psApplyDateRange;
  document.getElementById("psDateToSel").onchange=psApplyDateRange;

  /** Urutan KRONOLOGIS plane REAL yg lagi dimuat -- basis SATU-SATUNYA utk slot cycling (psEntryAtSlot)
   * & Auto-Scaling waktu (psGetGlobalTimeRange) -- GANTI PLANES polos milik Monitor yg cuma nyakup 1
   * tanggal. date=null,num=PLANES[i] kalau user belum pilih rentang custom (collapse total ke perilaku
   * lama). TIDAK ADA padding/modulo-repeat lagi -- lihat psPlaneRangeSizeEffective() utk kalibrasi
   * manual MAX_PLANE sbg floor opsional. Return true kalau urutannya BENERAN berubah dari sebelumnya
   * (dipakai caller buat mutuskan perlu psResetConveyor() apa enggak). */
  function psRebuildDataSequence(){
    const dates = PS_RANGE_DATES.length ? PS_RANGE_DATES : [null];
    const seq=[];
    dates.forEach(d=>{
      const nums = d===null ? PLANES : (PS_PLANES_BY_DATE[d]||[]);
      nums.forEach(num=>{ seq.push({date:d, num, pid: d===null?String(num):(d+"|"+num)}); });
    });
    const newKey=seq.map(e=>e.pid).join(",");
    // "changed" cuma dilaporkan MULAI render KE-2 dst -- render pertama (psSequenceInitialized masih
    // false) TIDAK BOLEH kepicu psResetConveyor() di caller, itu bakal buang state persisted
    // (smms_meta.plane_sim_conveyor_state) tiap kali app baru dibuka, padahal sequence-nya emang WAJAR
    // "berubah" dari kosong ke isi di titik itu (bukan konfigurasi yg beneran diganti user).
    const changed = psSequenceInitialized && newKey!==psSequenceFingerprint;
    psSequenceFingerprint=newKey;
    psSequenceInitialized=true;
    PS_DATA_SEQUENCE=seq;
    return changed;
  }

  /** Ambil data 1 plane dari PS_PCACHE (cache lokal Plane Simulation) -- date=null pakai action=plane
   * TANPA parameter date (behavior lama, current_parts_batch() default di server). */
  async function psLoadPlaneData(date, num){
    const key = date?(date+"|"+num):String(num);
    if(!PS_PCACHE[key]){
      const q='action=plane&p='+encodeURIComponent(num)+(date?('&date='+encodeURIComponent(date)):'');
      const d=await apiGet(q).catch(()=>({routes:{}}));
      PS_PCACHE[key]=d.routes||{};
    }
    return PS_PCACHE[key];
  }

  /** Prefetch SEMUA entry PS_DATA_SEQUENCE sekaligus (bukan cuma yg lagi tampil di 9-12 slot) — WAJIB
   * sebelum psGetGlobalTimeRange() (Auto-Scaling) supaya rentang waktunya akurat, bukan cuma dari
   * beberapa plane yg kebetulan lagi kelihatan. Pakai action=plane_sim_bulk (1 request per TANGGAL
   * yg belum ke-cache, bukan N request per plane -- bisa puluhan-ratusan kalau rentangnya lebar). */
  async function psPrefetchSequenceData(){
    const neededDates=[...new Set(PS_DATA_SEQUENCE.map(e=>e.date).filter(d=>d!==null))];
    const missingDates=neededDates.filter(d=>!PS_PCACHE["__loaded__"+d]);
    if(missingDates.length){
      const d=await apiGet('action=plane_sim_bulk&dates='+encodeURIComponent(missingDates.join(","))).catch(()=>({data:{}}));
      Object.entries(d.data||{}).forEach(([key,routes])=>{ PS_PCACHE[key]=routes; });
      missingDates.forEach(dt=>{ PS_PCACHE["__loaded__"+dt]=true; });
    }
    // Entry date=null (mode default, belum pilih rentang) TETAP lewat action=plane satuan spt biasa --
    // cuma 1 tanggal (batch aktif), gak perlu endpoint bulk.
    const defaultEntries=PS_DATA_SEQUENCE.filter(e=>e.date===null);
    await Promise.all(defaultEntries.map(e=>psLoadPlaneData(null, e.num)));
  }

  /** Pola isi RELATIF ke psActiveSlot (index0 = slot itu SENDIRI yg lagi aktif) -- simulasi visual murni
   * (gak ada data asli "plane depan udah keisi berapa persen"), DIHITUNG ULANG tiap kali PS_BUFFER_SIZE
   * berubah (bukan array tetap 12 entri lagi, krn jumlah slot skrg bisa 9-12). Selalu: 1 aktif (biru) +
   * maks 3 penuh (hijau) duluan, sisanya dibagi rata 2 (setengah pertama "sedang diisi" kuning, ramp
   * turun dari 0.7 ke 0.15; setengah sisanya kosong) — biar polanya tetap masuk akal walau slot dikit. */
  function psFillPatternFor(n){
    const full=Math.min(3, Math.max(0, n-1));
    const remainder=n-1-full;
    const fillingCount=Math.ceil(remainder/2), emptyCount=remainder-fillingCount;
    const rampBase=[0.7,0.5,0.3,0.15];
    const pattern=[1];
    for(let i=0;i<full;i++) pattern.push(1);
    for(let i=0;i<fillingCount;i++){
      const idx=fillingCount<=1?0:Math.round(i*(rampBase.length-1)/(fillingCount-1));
      pattern.push(rampBase[idx]);
    }
    for(let i=0;i<emptyCount;i++) pattern.push(0);
    return pattern;
  }
  let PS_FILL_PATTERN=psFillPatternFor(PS_BUFFER_SIZE);
  // Validasi tinggi tumpuk drill-down (koreksi rule stacking 2026-08-27): default maks 3 skid/stack,
  // boleh 4 KALAU (volume rata2/skid grup x k) + (0.15 x k) masih <= 3.0m IDEAL, k=4. Batas ABSOLUT
  // 3.3m gak pernah dilewatin apapun hasilnya (stack yg somehow masih nembus ini ditandai `valid:false`,
  // lihat psPackStacksForPlane -- bukan dipaksa "kelihatan OK" diam-diam).
  const PS_SKID_OVERHEAD_M=0.15, PS_STACK_IDEAL_HEIGHT_M=3.0, PS_STACK_MAX_HEIGHT_M=3.3;

  /**
   * Kunci grup skid utk 1 baris part (indeks p SETELAH array_shift(route) di data.php: p[9]=volume_box,
   * p[10]=status, p[11]=vlookup_supplier, p[12]=supplier_code, p[13]=supplier_plant, p[14]=supplier_dock,
   * p[15]=dock_code, p[17]=cd_arrival_at, p[18]=cd_departure_at — lihat SELECT di api_plane, data.php).
   *
   * DIROMBAK TOTAL (dikonfirmasi user via referensi macro VBA "ProsesGroupingDanSkidTanpaTanggal_Final"):
   * kunci = dock + supplier code + supplier plant + supplier dock + nama supplier + JAM ARRIVAL + JAM
   * DEPARTURE — beda dari versi sebelumnya yg TANPA supplier_dock & TANPA jam sama sekali di kuncinya
   * (jam dulu cuma dipakai buat "ngitung skid dari BANYAKNYA jam unik", BUKAN buat misahin grup — itu
   * yg bikin hasilnya jauh dari realita, lihat psSkidCountForGroup). TANPA route sbg pembeda (dikonfirmasi
   * dari awal). MROS/plane TIDAK literal ikut ke string kunci, TETAP efektif jadi kunci grouping paling
   * luar krn psComputeGroups(planeId) SELALU discope ke 1 plane doang (PS_PCACHE[planeId]), gak pernah
   * digabung lintas plane.
   *
   * Status part (Unpacking Murni, C/U, dst) SENGAJA GAK LAGI ikut nentuin kunci grup SAMA SEKALI
   * (dikonfirmasi user: "untuk unpacking jangan ada perlakuan khusus, tetap sama seperti yang lain") —
   * grup Unpacking Murni DULU dipaksa 1 grup gabungan lintas-supplier ("UNPACKING"), C/U DULU dikasih
   * prefix grup sendiri ("CU|...") — dua-duanya sekarang DIHAPUS, semua status digrupkan PERSIS sama
   * (by identitas supplier+jam). Pembeda formula skid "normal" vs "special" (C/U) sekarang murni terjadi
   * DI DALAM 1 grup yg sama, per-part (lihat psPartIsSpecial + psSkidCountForGroup) — persis pola macro
   * VBA-nya (1 mainKey bisa punya campuran part normal & part "kanban spesial", skid-nya dijumlah).
   */
  function psGroupKeyForPart(p){
    const supplierName=p[11]||p[6]||"";
    return `${p[15]||""}|${p[12]||""}|${p[13]||""}|${p[14]||""}|${supplierName}|${p[17]||""}|${p[18]||""}`;
  }

  // Kapasitas fisik maksimal 1 skid utk part "spesial" (mis. Unit Assy Air Conditioner DENSO, status
  // C/U) — dikonfirmasi user & macro VBA referensi: max 4 unit per skid, sisa 1-3 unit tetap makan 1
  // skid utuh (pembulatan KE ATAS, bukan dibulatkan biasa).
  const PS_CU_UNITS_PER_SKID=4;

  /** True kalau part INI (1 baris, bukan 1 grup) "spesial" — dihitung skid-nya dari QTY (lot, p[4])
   * dibagi 4, BUKAN dari volume_box seperti part biasa. Ditandai lewat status "C/U" di Master Part
   * (smms_master_part.status) — regex terima "C/U", "C-U", "CU" (semua dinormalisasi jadi "C/U" pas
   * disimpan, lihat master_part_validate di api/master_part.php). BEDA dari versi sebelumnya: dicek
   * PER PART di sini (bukan per grup) krn 1 mainKey (grup) sekarang BISA berisi campuran part biasa &
   * part spesial sekaligus (macro VBA referensi ngejumlah normalSkid + specialSkid dalam 1 grup yg sama). */
  function psPartIsSpecial(p){
    return /^c[\/\-]?u$/i.test((p[10]||"").toString().trim());
  }

  /**
   * Skid dari volume (part NON-spesial) — persis rumus macro VBA referensi (BUKAN Math.round() lagi):
   * vol<=0 -> 0 skid. vol<=1.5 -> selalu 1 skid (biar volume kecil dikit tetap wajar 1 skid, gak 0).
   * vol>1.5 -> bagian bulat (Int/floor) + 1 KALAU sisa desimalnya >0.3, kalau <=0.3 gak usah ditambah.
   * Ambang 0,3 ini BEDA dari pembulatan matematis biasa (ambang 0,5) — sengaja lebih "murah" nambah 1
   * skid ekstra (dites: pembulatan biasa bikin hasil under-estimate jauh dari realita operasional). */
  function psNormalSkidFromVolume(vol){
    if(vol<=0) return 0;
    if(vol<=1.5) return 1;
    const whole=Math.floor(vol);
    const frac=vol-whole;
    return frac<=0.3 ? whole : whole+1;
  }

  /** Jumlah skid 1 grup = normalSkid (dari g.normalVol, part biasa) + specialSkid (dari g.specialQty,
   * part C/U — ceil(qty/4)) — DIJUMLAH, bukan salah satu doang, persis macro VBA referensi (`skid =
   * normalSkid + specialSkid`). g.normalVol/g.specialQty sudah diakumulasi per-part di psComputeGroupsRaw. */
  function psSkidCountForGroup(g){
    const normalSkid=psNormalSkidFromVolume(g.normalVol);
    const specialSkid=g.specialQty>0 ? Math.ceil(g.specialQty/PS_CU_UNITS_PER_SKID) : 0;
    return normalSkid+specialSkid;
  }

  /** Semua grup (identitas supplier + jam arrival/departure, LINTAS semua route) dari SATU objek
   * routesData ({route: [...baris]}, bentuk SAMA persis dgn hasil action=plane/plane_sim_bulk) — TIDAK
   * baca PS_PCACHE sendiri lagi (GANTI versi lama yg langsung `PS_PCACHE[planeId]`), supaya fungsi
   * grouping/skid-count ini bisa dipakai ULANG oleh Monitor (06-render.js, shape "Plane Buffer" di
   * denah) lewat PLANEDATA milik Monitor sendiri — TANPA perlu Monitor ikut manggil psPrefetchSequenceData
   * atau nyentuh PS_PCACHE plane-sim sama sekali (2 cache/lifecycle TETAP terpisah total, cuma
   * ALGORITMA-nya yg direuse). Caller di dalam plane-sim sendiri (psComputeGroups di bawah) yg tetap
   * baca PS_PCACHE, dioper ke sini sbg parameter apa adanya.
   * Tiap grup: {key,supplierName,routes(Set),normalVol,specialQty,volume,skidCount,departureAt,
   * earliestDeparture,parts[{...row,route}]} — route direkam PER PART (bukan per grup, krn 1 grup bisa
   * beranggotakan part dari beberapa route sekaligus). volume (dipakai psAvgSkidHeight/psPackStacksForPlane
   * utk simulasi tumpukan fisik drill-down) dihitung dari normalVol APA ADANYA + estimasi tinggi part
   * "spesial" (C/U) — BUKAN lot×volBox mentah kayak part biasa (dites langsung: itu bikin bug nyata,
   * part C/U selalu jadi tumpukan sendiri 1 skid-1 skid gak pernah gabung — lihat catatan panjang di
   * bawah). Urutan list HASIL akhir: grup yg PUNYA cd_departure_at diurut KRONOLOGIS (paling awal
   * duluan), grup yg gak punya sama sekali ditaruh belakangan diurut skidCount terbanyak (fallback pas
   * data jam blm ada). */
  function psComputeGroupsRaw(routesData){
    routesData=routesData||{};
    const groups={};
    Object.keys(routesData).forEach(route=>{
      (routesData[route]||[]).forEach(p=>{
        const key=psGroupKeyForPart(p);
        if(!groups[key]){
          groups[key]={ key,
            supplierName: p[11]||p[6]||"(Tanpa Supplier)",
            dockCode:p[15]||"", supplierCode:p[12]||"", supplierPlant:p[13]||"", supplierDock:p[14]||"",
            arrivalAt: p[17]||null, departureAt: p[18]||null,
            volume:0, normalVol:0, specialQty:0, specialVolBoxSum:0, specialVolBoxCount:0,
            parts:[], routes:new Set() };
        }
        groups[key].parts.push({row:p, route});
        groups[key].routes.add(route);
        const lot=parseFloat(p[4])||0, volBox=parseFloat(p[9])||0;
        if(psPartIsSpecial(p)){
          groups[key].specialQty += lot;
          groups[key].specialVolBoxSum += volBox; groups[key].specialVolBoxCount++; // TANPA dikali lot, lihat bawah
        } else {
          groups[key].normalVol += lot*volBox;
        }
      });
    });
    const list=Object.values(groups);
    list.forEach(g=>{
      g.skidCount=psSkidCountForGroup(g);
      /**
       * "volume" fisik grup ini (dipakai avgSkidHeight -> psMaxPerStackForGroup -> psPackStacksForPlane
       * di drill-down) — normalVol APA ADANYA (part biasa: volume_box di Master Part = volume 1 UNIT,
       * jadi lot×volBox = total volume SEMUA unit, wajar dijumlah lurus) + kontribusi part "spesial"
       * (C/U) yg beda basisnya: Volume Box di Master Part utk part C/U UDAH LANGSUNG merepresentasikan
       * volume 1 SKID-nya (dikonfirmasi user — bukan volume 1 unit yg perlu direka-reka lagi cara
       * nyusunnya), jadi kontribusinya = specialSkidCount × volume_box itu APA ADANYA, BUKAN dikali qty
       * (qty/lot cuma dipakai buat NENTUIN JUMLAH skid-nya lewat rumus qty÷4, bukan buat ngali volume).
       * Rata-rata volBox dipakai (specialVolBoxSum/specialVolBoxCount) cuma jaga2 kalau 1 grup kebetulan
       * py lebih dari 1 part_no C/U dgn volume_box beda dikit — di data real sekarang semuanya sama
       * persis (1.32), jadi rata-ratanya = 1.32 itu sendiri (dites: grup DENSO skidCount=6 -> kontribusi
       * 6×1.32=7.92, persis kecocokannya).
       *
       * BUG YG INI PERBAIKI (versi sebelum ini): specialQty dulu ikut nyumbang lot×volBox APA ADANYA ke
       * "volume" (basis "volume 1 unit" kayak part biasa) — mis. lot=4, volBox=1.32 -> nyumbang 5.28,
       * padahal skidCount grup itu cuma 1 (ceil(4/4)). avgSkidHeight jadi 5.28m/skid — ngelewatin batas
       * fisik 4m bahkan buat 1 skid doang, bikin psMaxPerStackForGroup() gak sanggup ngasih maxPerStack
       * lebih dari 1 -- akibatnya SETIAP part C/U kepaksa jadi tumpukan sendiri2 (1 skid per tumpukan,
       * gak pernah gabung), persis yg dilaporkan user liat di BARIS 1: deretan panjang kolom "DEN..."
       * isinya cuma 1 kotak doang tiap kolom.
       */
      const specialSkidCount = g.specialQty>0 ? Math.ceil(g.specialQty/PS_CU_UNITS_PER_SKID) : 0;
      const specialVolPerSkid = g.specialVolBoxCount>0 ? g.specialVolBoxSum/g.specialVolBoxCount : 0;
      g.volume = g.normalVol + specialSkidCount*specialVolPerSkid;
      g.route=[...g.routes].sort().join(",");
      g.earliestDeparture=g.departureAt||null;
    });
    list.sort((a,b)=>{
      if(a.earliestDeparture && b.earliestDeparture) return a.earliestDeparture<b.earliestDeparture?-1:1;
      if(a.earliestDeparture) return -1;
      if(b.earliestDeparture) return 1;
      return b.skidCount-a.skidCount;
    });
    return list;
  }

  // Cache psComputeGroups PER RENDER PASS (bukan cache permanen) — dites langsung: fungsi ini kepanggil
  // ULANG ~5x per slot (lewat psCategoryForSlot/psFilledFor/psTargetFor/psTotalSkid, semuanya independen
  // manggil ulang) padahal datanya (PS_PCACHE[planeId]) gak berubah selama 1 kali renderPlaneSim() jalan —
  // benchmark data real (24 plane, ~618 baris/plane): pola lama ~11ms/render penuh (12 slot), setelah
  // cache ini ~2ms (turun ~80%). Tetap AMAN dari data basi krn psResetGroupsCache() dipanggil di awal
  // TIAP renderPlaneSim() (lifetime cache cuma "1x render", bukan disimpen lintas render/upload) — beda
  // dari alternatif nyimpen skid ke tabel DB yg butuh logic invalidasi eksplisit tiap Progress Lane/
  // Master Part berubah (dipertimbangkan tapi TIDAK dipakai: 11ms live-compute udah jauh di bawah
  // ambang "kerasa lambat" ~100ms, gak sepadan sama risiko cache DB nyangkut basi).
  let psGroupsCache=new Map();
  function psResetGroupsCache(){ psGroupsCache=new Map(); }
  function psComputeGroups(planeId){
    if(!psGroupsCache.has(planeId)) psGroupsCache.set(planeId, psComputeGroupsRaw(PS_PCACHE[planeId]));
    return psGroupsCache.get(planeId);
  }

  /** Total skid 1 plane (jumlah skidCount semua grupnya). */
  function psTotalSkid(planeId){
    return psComputeGroups(planeId).reduce((a,g)=>a+g.skidCount,0);
  }

  // Header "P-LANE (MROS)" = plane yg lagi DIBONGKAR/unload, BUKAN plane yg lagi diproses towing scr
  // fisik di simulasi ini — dikonfirmasi user: ada jeda 2 slot antara selesai unload sampai beneran
  // mulai diproses (konkretnya: header P-LANE=3 -> slot AKTIF/biru di simulasi = slot 5).
  const PS_ACTIVE_LAG=2;

  // "Waktu simulasi" — dikonfigurasi user lewat "Atur Waktu Simulasi" (psSimSettingsOpen dkk di bawah),
  // simpan ke smms_meta key 'plane_sim_time_offset'. Offset (milidetik, boleh negatif) DITAMBAHKAN ke
  // Date.now() (bukan snapshot titik waktu absolut) — dikonfirmasi user: "ini sebagai simulasi dulu blm
  // mengikuti real time", jadi kategori kosong/lagi diisi/penuh (psCategoryForNumber/calculatePlaneState)
  // JANGAN dibandingin ke jam komputer beneran apa adanya, tapi ke waktu simulasi yg operator atur
  // sendiri — biar bisa demo pakai data lama (mis. 21 Agustus) serasa "sekarang" tanpa nunggu tanggal
  // aslinya. Karena TETAP offset (bukan titik tetap), waktu simulasi tetap MAJU ngikutin kecepatan
  // wall-clock asli abis diset (1 detik nyata = 1 detik simulasi), cuma titik awalnya digeser bebas.
  // DIPAKAI CUMA di mode 'aktual' (lihat PS_TIME_MODE di bawah) — mode 'simulasi' gak pakai offset ini
  // sama sekali, "sekarang"-nya direntang dari countdown, bukan dari jam beneran + geseran.
  let PS_SIM_TIME_OFFSET=+(META.plane_sim_time_offset||0);

  // Mode "waktu simulasi" — 'aktual' (DEFAULT, perilaku LAMA): psSimNow() = jam beneran+PS_SIM_TIME_OFFSET,
  // 1 jam SAMA dipakai lintas plane (valid krn semua plane/MROS emang dari kalender NYATA yg sama).
  // 'simulasi' (Auto-Scaling PER-TANGGAL): psSimNow() SAMA SEKALI GAK ngikutin jam komputer lagi —
  // direntang LINEAR dari jam kedatangan (arrival) paling awal S/D jam keberangkatan paling akhir DI
  // TANGGAL YG LAGI AKTIF SAJA (BUKAN 1 rasio gabungan lintas-SEMUA-tanggal lagi — lihat komentar
  // panjang psRecomputeTimeLapseRatio soal alasan rombak ini), dibagi rata ke tick countdown tanggal
  // itu. Disimpan ke smms_meta key 'plane_sim_time_mode', diatur dari radio "Mode Waktu" di modal
  // "Atur Waktu Simulasi" (psSimTimeSave dkk di bawah).
  let PS_TIME_MODE=(META.plane_sim_time_mode==="simulasi")?"simulasi":"aktual";

  // Hasil psRecomputeTimeLapseRatio() TERAKHIR (di-cache, bukan dihitung ulang tiap psSimNow()
  // dipanggil — psSimNow() bisa kepanggil puluhan kali per render) -- key = data_date ("" utk grup
  // default/single-date, lihat psRebuildDataSequence), value = {minTs,maxTs,ratio} ATAU null kalau
  // tanggal itu blm py 1 pun jam valid. Direcompute tiap PS_DATA_SEQUENCE berubah (rentang tanggal
  // diganti/data baru) ATAU cdStart berubah (lihat pemanggil psRecomputeTimeLapseRatio: renderPlaneSim,
  // cdStartSel.onchange di 08-header.js).
  let PS_TIME_RANGES={};

  /** Rentang waktu GLOBAL (arrival paling awal s/d departure paling akhir, fallback ke arrival kalau
   * departure grup itu kosong) dari SELURUH plane di PS_DATA_SEQUENCE — lintas plane DAN lintas
   * tanggal. BUKAN dipakai psSimNow() lagi (lihat psRecomputeTimeLapseRatio) — SEKARANG cuma dipakai
   * convenience tombol "Ambil dari arrival tertua di data" (psSimTimeFromData) di modal Atur Waktu
   * Simulasi, biar operator liat titik PALING AWAL dari SEMUA data yg lagi dimuat. WAJIB dipanggil
   * SETELAH psPrefetchSequenceData() selesai -- kalau belum, groups sebagian plane bisa kosong & hasilnya
   * meleset. null kalau BENAR2 gak ada 1 pun jam valid di seluruh data yg lagi dimuat. */
  function psGetGlobalTimeRange(){
    let minTs=null, maxTs=null;
    PS_DATA_SEQUENCE.forEach(entry=>{
      psComputeGroups(entry.pid).forEach(g=>{
        const a=parseCustomDate(g.arrivalAt);
        const dep=parseCustomDate(g.departureAt);
        const end = !isNaN(dep) ? dep : a; // departure kalau ada, fallback arrival kalau kosong
        if(!isNaN(a) && (minTs===null||a<minTs)) minTs=a;
        if(!isNaN(end) && (maxTs===null||end>maxTs)) maxTs=end;
      });
    });
    return (minTs===null||maxTs===null) ? null : {minTs,maxTs};
  }

  /** Entry {date,num,pid} di PS_DATA_SEQUENCE yg cocok tanggal `d` (null = grup default/single-date),
   * urutan SAMA persis posisinya di PS_DATA_SEQUENCE (ascending by num dlm 1 tanggal, lihat
   * psRebuildDataSequence). Dipakai psRecomputeTimeLapseRatio (scope per-tanggal) & psFullEntries
   * (scope Full Plane, lewat psFullDate). */
  function psEntriesForDate(d){
    return PS_DATA_SEQUENCE.filter(e=>e.date===d);
  }

  // Percentile trim (BUKAN literal min/max lagi) buat jangkar Auto-Scaling — dikonfirmasi user: 1
  // upload/batch (mis. order no 20260823) WAJAR bawa data arrival yg nyebrang ke tanggal SEBELUM &
  // SESUDAHNYA (shift kerja pabrik: Shift 1 07.15-16.00, Shift 2 21.00-06.15 nyebrang tengah malam) —
  // TAPI cuma "beberapa grup saja" yg nyebrang segitu jauh, MAYORITAS tetap mengumpul rapat di jam
  // shift-nya sendiri. Literal min/maxTs kebawa jauh sama SEDIKIT grup nyeleneh itu (dites live: dari
  // ~1 hari jadi ~3,75 hari), bikin rasio jadi kekasaran & sebagian besar plane "macet" nunggu jam
  // simulasi ngerambat lewat outlier itu dulu. Percentile 5%-95% (PS_TIME_TRIM_LOW/HIGH) motong
  // outlier tapi TETAP data ASLI (bukan direka-reka) -- grup yg jamnya di LUAR jendela percentile ini
  // (baik lebih awal dari P5 maupun lebih akhir dari P95) TETAP dibandingin apa adanya di
  // calculatePlaneArrivalState (TIDAK di-clamp), jadi otomatis langsung "udah lewat"/masih "nunggu jauh
  // di depan" sesuai jam aslinya -- cuma jangkar+rasio SIMULASI-nya yg gak lagi dipengaruhi outlier itu.
  const PS_TIME_TRIM_LOW=0.05, PS_TIME_TRIM_HIGH=0.95;

  /** Nilai ke-p (0..1) dari array TERURUT ascending -- dipakai jangkar percentile psRecomputeTimeLapseRatio. */
  function psPercentile(sortedArr, p){
    if(!sortedArr.length) return null;
    const idx=Math.min(sortedArr.length-1, Math.max(0, Math.floor(p*(sortedArr.length-1))));
    return sortedArr[idx];
  }

  /** Hitung ulang rasio Auto-Scaling PER-TANGGAL — GANTI versi rasio GABUNGAN lintas-semua-tanggal
   * (dites langsung pakai data live 2 hari: rasio gabungan bikin plane tgl kedua "macet" lama, semua
   * kartu kosong, krn jam simulasi masih harus merambat lewat SELURUH tgl pertama dulu sebelum sampai
   * ke jam² asli tgl kedua yg ternyata mengumpul jauh di ujung rentang gabungan — TIDAK terdistribusi
   * merata per-index plane). Sekarang TIAP tanggal (batch upload, termasuk grup default "" kalau
   * rentang custom blm dipilih) py jangkar (minTs) + rasio (ms/tick) SENDIRI, dihitung dari durasi
   * LOKAL tanggal itu (jangkar percentile P5 arrival s/d P95 departure DI TANGGAL ITU SAJA — lihat
   * komentar PS_TIME_TRIM_LOW/HIGH soal kenapa percentile bukan literal min/max) dibagi total tick
   * tanggal itu (jumlah plane tanggal itu × cdStart) — begitu simulasi masuk ke tanggal baru, tempo
   * otomatis nyesuai rentang waktu asli tanggal itu sendiri, GAK PERNAH nunggu tanggal sebelumnya
   * "kelar" dulu. Efek "sisa skid semalam kelihatan" (tujuan awal fitur multi-tanggal) TETAP terpenuhi
   * lewat state konveyor yg dipersist (psSlotGen/psActiveSlot) — BUKAN dari psSimNow() harus merambat
   * linear lintas hari. */
  function psRecomputeTimeLapseRatio(){
    PS_TIME_RANGES={};
    const dates=[...new Set(PS_DATA_SEQUENCE.map(e=>e.date))];
    dates.forEach(d=>{
      const entries=psEntriesForDate(d);
      const arrivals=[], ends=[];
      entries.forEach(entry=>{
        psComputeGroups(entry.pid).forEach(g=>{
          const a=parseCustomDate(g.arrivalAt);
          const dep=parseCustomDate(g.departureAt);
          const end = !isNaN(dep) ? dep : a;
          if(!isNaN(a)) arrivals.push(a);
          if(!isNaN(end)) ends.push(end);
        });
      });
      const key=d===null?"":d;
      if(!arrivals.length || !ends.length){ PS_TIME_RANGES[key]=null; return; }
      arrivals.sort((a,b)=>a-b); ends.sort((a,b)=>a-b);
      const minTs=psPercentile(arrivals, PS_TIME_TRIM_LOW);
      const maxTs=Math.max(minTs, psPercentile(ends, PS_TIME_TRIM_HIGH)); // jaga2 P95 end < P5 arrival (data super dikit/aneh)
      const totalTicks=entries.length*Math.max(1,cdStart);
      PS_TIME_RANGES[key] = totalTicks>0
        ? {minTs, maxTs, ratio: Math.max(0,maxTs-minTs)/totalTicks}
        : null;
    });
  }

  /** Tanggal yg jadi acuan psSimNow() SEKARANG — tanggal TERAKHIR di PS_RANGE_DATES (representasi
   * "hari ini"/batch aktif sekarang), atau null kalau rentang custom blm dipilih (grup default). */
  function psActiveDateKey(){
    return PS_RANGE_DATES.length ? PS_RANGE_DATES[PS_RANGE_DATES.length-1] : null;
  }

  /** Index plane AKTIF sekarang DI DALAM tanggal acuan (psActiveDateKey) SAJA — dikonfirmasi user
   * eksplisit poin 3: pakai INDEKS posisi array (berapa plane yg SUDAH lewat), BUKAN nilai MROS/nomor
   * plane mentah (`plane`) yg bisa RESET ke angka kecil tiap hari — indeks TIDAK PERNAH reset selama
   * masih di tanggal yg sama. Discope PER-TANGGAL (bukan index global lintas-semua-tanggal lagi) biar
   * konsisten sama psRecomputeTimeLapseRatio yg sekarang juga per-tanggal. 0 kalau gak ketemu. */
  function psActivePlaneIndex(){
    const entries=psEntriesForDate(psActiveDateKey());
    const idx=entries.findIndex(e=>String(e.num)===String(plane));
    return idx<0 ? 0 : idx;
  }

  /** "Sekarang" versi simulasi (ms epoch) — GANTI semua pemakaian Date.now() polos di plane-sim.js buat
   * apapun yg dibandingin ke cd_arrival_at (calculatePlaneArrivalState dkk). Dual-mode,
   * lihat PS_TIME_MODE di atas: 'aktual' = jam beneran+offset (perilaku lama apa adanya, TIDAK
   * berubah); 'simulasi' = Auto-Scaling PER-TANGGAL — titik jangkar minTs tanggal AKTIF (psActiveDateKey)
   * + (tick yg SUDAH berlalu DI TANGGAL ITU × rasio dinamis tanggal itu). Tick berlalu = (index plane
   * aktif DI TANGGAL ITU × cdStart) + (cdStart-cd). Fallback ke Aktual kalau rasio/rentang tanggal itu
   * belum siap (data blm cukup / prefetch blm kelar) — JANGAN pernah return NaN/waktu ngaco ke caller. */
  function psSimNow(){
    if(PS_TIME_MODE==="simulasi"){
      const range=PS_TIME_RANGES[psActiveDateKey()===null?"":psActiveDateKey()];
      if(range){
        const elapsedTicks = psActivePlaneIndex()*Math.max(1,cdStart) + Math.max(0,cdStart-cd);
        return range.minTs + elapsedTicks*range.ratio;
      }
    }
    return Date.now()+PS_SIM_TIME_OFFSET;
  }

  // MAX PLANE — dikonfigurasi user lewat sub-menu "Pengaturan Fisik Plane" (psSettingsOpen dkk di bawah,
  // simpan ke smms_meta key 'plane_sim_max_plane'), fallback 24 kalau belum pernah diatur. Bareng
  // PS_MIN_PLANE (di bawah), 2 angka ini nentuin SELURUH pola "VERSI FISIK 12 P-LANE SPIRAL" (tabel
  // referensi user): MIN_PLANE..MAX_PLANE disebar berurutan ke 12 kolom (slot) row demi row, begitu
  // lewat MAX_PLANE baliknya ke MIN_PLANE & LANJUT ngisi (bukan reset tabel) — makanya kolom mana yg
  // kebagian nomor MIN_PLANE lagi geser2 tergantung rentang (MAX-MIN+1) mod 12.
  let PS_MAX_PLANE=+(META.plane_sim_max_plane||24);

  // Mode penentuan MAX PLANE — 'manual' (default, kompatibel install lama): angka murni dari input
  // operator, gak pernah berubah sendiri. 'auto': PS_MAX_PLANE ngikutin nomor plane TERTINGGI yg lagi
  // ada di data Progress Lane aktif SEKARANG (psAutoMaxPlane()), dihitung ULANG tiap renderPlaneSim()
  // jalan (psSyncAutoMaxPlane()) — jadi begitu ada upload Progress Lane baru dgn nomor plane lebih
  // tinggi/rendah dari sebelumnya, MAX PLANE ikut nyesuain otomatis tanpa perlu diatur ulang manual.
  let PS_MAX_PLANE_MODE=(META.plane_sim_max_plane_mode==="auto")?"auto":"manual";

  // Nomor plane TERENDAH yg lagi ada di data (PS_MIN_PLANE) — BEDA dari PS_MAX_PLANE, ini SELALU
  // live-auto (gak ada mode manual/tersimpan ke meta) krn gak ada alasan operator perlu maksa angka
  // batas bawah sendiri (beda dari MAX yg kadang emang perlu diset lebih tinggi dari data yg BARU
  // separuh keupload). Dikonfirmasi user (setelah patokan `plane` pindah ke "Main Route Order Seq",
  // lihat api/progress_lane.php): nomor plane SEKARANG gak mesti mulai dari 1 lagi (mis. Main Route
  // Order Seq bisa mulai dari 13) — rumus spiral LAMA yg hardcode "mulai dari 1" (`(...)%PS_MAX_PLANE+1`)
  // bikin nomor slot yg ditampilin (1,2,4,5...) gak PERNAH cocok sama nomor plane ASLI yg beneran ada
  // (13,14,...,24) — dilaporkan user liat langsung: "nomornya balik ke 1, harusnya nyambung ke Main
  // Route Order Seq". Sekarang rentang spiral SELALU [PS_MIN_PLANE, PS_MAX_PLANE], bukan [1, PS_MAX_PLANE].
  let PS_MIN_PLANE=1;

  /** Nomor plane TERTINGGI yg ada di PLANES (daftar plane dari batch Progress Lane aktif, lihat
   * bootstrap() di 02-api.js) — patokan MAX PLANE mode "Otomatis". Clamp minimal PS_MIN_PLANE+11 (biar
   * rentangnya muat minimal 12 slot fisik) & fallback ke PS_MAX_PLANE skrg/24 kalau PLANES kosong (blm
   * ada data sama sekali, mis. sebelum bootstrap() pertama kelar). */
  function psAutoMaxPlane(){
    const nums=(PLANES||[]).map(p=>parseInt(p,10)).filter(n=>Number.isFinite(n)&&n>0);
    return Math.max(PS_MIN_PLANE+11, nums.length?Math.max(...nums):(PS_MAX_PLANE||24));
  }

  /** Nomor plane TERENDAH yg ada di PLANES — patokan PS_MIN_PLANE (SELALU auto, lihat komentar di
   * atas). Fallback 1 kalau PLANES kosong (kompatibel data lama yg mulai dari 1). */
  function psAutoMinPlane(){
    const nums=(PLANES||[]).map(p=>parseInt(p,10)).filter(n=>Number.isFinite(n)&&n>0);
    return nums.length?Math.min(...nums):1;
  }

  /** Sinkron PS_MIN_PLANE (SELALU) + PS_MAX_PLANE (KALAU lagi mode "Otomatis") dari data plane terbaru
   * — dipanggil tiap renderPlaneSim() (yg sendirinya udah rutin jalan tiap ganti plane/buka tab/tick
   * countdown), jadi gak perlu nyari satu-satu tiap titik upload Progress Lane bisa terjadi. TIDAK lagi
   * nge-reset konveyor sendiri di sini (beda dari versi sebelumnya) -- keputusan reset SEKARANG
   * dipusatkan di renderPlaneSim(), berbasis return value psRebuildDataSequence() (yg sudah mencakup
   * efek perubahan PS_MIN_PLANE/PS_MAX_PLANE JUGA via psPlaneRangeSizeEffective), biar gak ada 2 titik
   * yg bisa reset dobel/tumpang tindih. */
  function psSyncAutoMaxPlane(){
    PS_MIN_PLANE=psAutoMinPlane();
    if(PS_MAX_PLANE_MODE==="auto") PS_MAX_PLANE=psAutoMaxPlane();
  }

  /**
   * Re-baca PS_BUFFER_SIZE/PS_MAX_PLANE/PS_MAX_PLANE_MODE/psOverviewRows dari META SEKARANG — dipanggil
   * SEKALI dari 13-main.js tepat setelah `await bootstrap()` beneran resolve (lihat komentar di sana).
   *
   * KENAPA INI PERLU: semua variabel di atas awalnya di-init dari `META.plane_sim_*` di baris top-level
   * (`let PS_BUFFER_SIZE=...+(META.plane_sim_slot_count||12)`, dst) — tapi baris top-level itu
   * DIEKSEKUSI SAAT SCRIPT plane-sim.js DI-PARSE BROWSER, BUKAN setelah bootstrap() (fetch AJAX ke
   * action=bootstrap yg ngisi META) selesai. plane-sim.js emang dimuat PALING TERAKHIR di <script> tag
   * index.php, TAPI itu cuma jaminan urutan LOAD, bukan jaminan bootstrap()-nya udah KELAR — parsing+load
   * semua file <script> lain (16+ file network round-trip) BISA kelar duluan drpd 1x fetch AJAX
   * bootstrap resolve (RACE CONDITION nyata, dites langsung pakai browser headless: PS_BUFFER_SIZE/
   * PS_MAX_PLANE kebaca fallback default 12/24, bukan setting asli user 9/27, gara2 META masih {}
   * kosong pas baris top-level itu jalan). Fungsi ini benerin itu — dipanggil belakangan, setelah
   * bootstrap() PASTI udah isi META dgn bener.
   */
  function psSyncFromMeta(){
    PS_BUFFER_SIZE=Math.min(PS_SLOT_COUNT_MAX,Math.max(PS_SLOT_COUNT_MIN,+(META.plane_sim_slot_count||12)));
    PS_MAX_PLANE=+(META.plane_sim_max_plane||24);
    PS_MAX_PLANE_MODE=(META.plane_sim_max_plane_mode==="auto")?"auto":"manual";
    PS_MIN_PLANE=psAutoMinPlane(); // SELALU auto, gak ada di meta -- lihat komentar deklarasinya di atas
    psOverviewRows=Math.max(PS_OVERVIEW_ROWS_MIN,Math.min(PS_OVERVIEW_ROWS_MAX,+(META.plane_sim_overview_rows||16)));
    PS_SIM_TIME_OFFSET=+(META.plane_sim_time_offset||0);
    PS_TIME_MODE=(META.plane_sim_time_mode==="simulasi")?"simulasi":"aktual";
    PS_FILL_PATTERN=psFillPatternFor(PS_BUFFER_SIZE);
  }

  // Tiap slot (1..12) py GENERASI SENDIRI (psSlotGen[slot], counter naik terus tiap slot itu selesai &
  // direcycle, TERPISAH per slot — bukan counter global bersama, dikonfirmasi user). Nomor yg
  // ditampilkan slot itu = ((slot-1) + generasi*12) mod (MAX_PLANE-MIN_PLANE+1) + MIN_PLANE — PERSIS
  // rumus yg cocok sama tabel referensi "VERSI FISIK 12 P-LANE SPIRAL" (tiap URUTAN di tabel itu = 1
  // kenaikan generasi), CUMA sekarang rentangnya digeser mulai dari PS_MIN_PLANE (BUKAN selalu 1 lagi).
  //
  // State ini (psSlotGen + psActiveSlot) DIPERSISTEN ke server (smms_meta key 'plane_sim_conveyor_state',
  // lihat plane-sim/api.php) — TANPA ini, siklus konveyor cuma hidup di variabel JS browser: refresh
  // halaman atau buka di layar/monitor lain bikin semuanya balik "generasi 0" walau siklus fisik
  // aslinya udah jalan jauh (bug yg dilaporkan user: "plane 3 harusnya ganti ke plane 13, bukan
  // balik ke 1"). psConveyorRestored dipakai sekali doang (baik berhasil restore dari META, ATAU abis
  // direset psApplySettings) biar psInitSlotsIfNeeded gak bolak-balik nyoba parse ulang META.
  let psSlotGen=null;
  let psConveyorRestored=false;
  /** Baca state konveyor tersimpan dari META (di-set bootstrap, lihat 02-api.js) -- null kalau belum
   * pernah disimpan/rusak/gak cocok jumlah slotnya sama PS_BUFFER_SIZE skrg (mis. abis ganti setting). */
  function psLoadPersistedConveyor(){
    try{
      const raw=META.plane_sim_conveyor_state;
      if(!raw) return null;
      const j=typeof raw==="string"?JSON.parse(raw):raw;
      if(j && Number.isFinite(+j.activeSlot) && j.slotGen && typeof j.slotGen==="object"
        && Object.keys(j.slotGen).length===PS_BUFFER_SIZE) return j;
    }catch(e){}
    return null;
  }
  /** Fire-and-forget: simpan state konveyor SEKARANG ke server (dipanggil tiap slot beneran
   * direcycle, psAdvanceActiveSlot) -- gak nunggu respons, gagal simpan sekali gak boleh ganggu UI
   * (nyoba lagi otomatis di recycle berikutnya). */
  function psSaveConveyorState(){
    apiPost("plane_sim_save_conveyor",{activeSlot:psActiveSlot,slotGen:psSlotGen}).catch(()=>{});
  }
  function psInitSlotsIfNeeded(){
    if(psSlotGen) return;
    if(!psConveyorRestored){
      psConveyorRestored=true;
      const saved=psLoadPersistedConveyor();
      if(saved){
        psSlotGen={}; for(let i=1;i<=PS_BUFFER_SIZE;i++) psSlotGen[i]=+(saved.slotGen[i]||0);
        psActiveSlot=+saved.activeSlot;
        return;
      }
    }
    psSlotGen={};
    for(let i=1;i<=PS_BUFFER_SIZE;i++) psSlotGen[i]=0;
  }
  /** Jumlah nomor DALAM 1 putaran spiral kalibrasi manual (MIN_PLANE s/d MAX_PLANE inklusif) — dipakai
   * psRenderSettingsPreview (preview tabel referensi "VERSI FISIK 12 P-LANE SPIRAL" di modal
   * Pengaturan), minimal 1 biar gak pernah modulo-by-zero. TIDAK LAGI jadi basis slot cycling/waktu
   * (lihat psSeqIndexAtSlot & PS_DATA_SEQUENCE di bawah, dikonfirmasi user poin 4: "PS_MIN_PLANE dan
   * PS_MAX_PLANE otomatis terikat pada panjang/indeks array PLANES agar menampung berapapun jumlah
   * pesawat secara penuh" — jadi basis cycling SEKARANG murni panjang data REAL yg lagi dimuat, kalibrasi
   * manual TIDAK PERNAH lagi memotongnya) — murni representasi kalibrasi fisik "MAX PLANE" yg diatur
   * user di modal Pengaturan buat kebutuhan preview/dokumentasi. */
  function psPlaneRangeSize(){
    return Math.max(1, PS_MAX_PLANE-PS_MIN_PLANE+1);
  }

  /** Physical sequence index: slot 1 = 0, slot 1 generation 1 = 12, dst.
   * Physical sequence TIDAK modulo ke panjang data dan TIDAK wrap ke 1 setelah MAX PLANE.
   * Data produksi hanya mengisi entry index tersebut; kalau belum ada data, physical identity tetap ada.
   */
  function psSeqIndexAtSlot(slot){
    psInitSlotsIfNeeded();
    return Math.max(0,(slot-1)+(psSlotGen[slot]||0)*PS_BUFFER_SIZE);
  }

  /** Nomor Plane untuk posisi fisik + generation. Dengan 12 slot:
   * slot 1 = 1,13,25,37...
   * slot 2 = 2,14,26,38...
   */
  function psExpectedPlaneNumberAtSlot(slot){
    return PS_MIN_PLANE + psSeqIndexAtSlot(slot);
  }

  /** Entry yang sedang berada pada physical slot. Bila data belum datang, kembalikan identitas
   * synthetic agar layout fisik tetap stabil dan tidak bergeser hanya karena data belum tersedia.
   */
  function psEntryAtSlot(slot){
    const idx=psSeqIndexAtSlot(slot);
    const actual=PS_DATA_SEQUENCE[idx];
    if(actual) return actual;
    const num=psExpectedPlaneNumberAtSlot(slot);
    const d=psActiveDateKey();
    return {date:d, num, pid:d ? `${d}|${num}` : String(num)};
  }

  // Slot (1..12) mana yg SEKARANG lagi jadi status AKTIF (biru) — INI yg geser tiap kali beneran ganti
  // plane (psAdvanceActiveSlot). Posisi LAYAR-nya sendiri gak geser, tapi lihat psSlotNumber di atas
  // buat nomor yg ditampilin di masing2 posisi (itu yg berubah pas recycle).
  let psActiveSlot=null;
  let psLastHeaderPlane=null;
  function psPhysicalSlotForPlaneNumber(num){
    const n=parseInt(num,10);
    if(!Number.isFinite(n)) return 1;
    return ((Math.max(0,n-PS_MIN_PLANE))%PS_BUFFER_SIZE)+1;
  }
  function psCurrentActiveSlot(){
    psInitSlotsIfNeeded();
    const headerKey=String(plane??"");
    // Persisted activeSlot adalah state conveyor, tetapi bila header P-LANE berubah, re-anchor
    // agar header dan visual active tidak pernah bertabrakan (mis. P-LANE 01 tetapi active P16).
    if(psActiveSlot===null || psLastHeaderPlane!==headerKey){
      const headerSlot=psPhysicalSlotForPlaneNumber(plane);
      psActiveSlot=((headerSlot-1+PS_ACTIVE_LAG)%PS_BUFFER_SIZE)+1;
      psLastHeaderPlane=headerKey;
    }
    return psActiveSlot;
  }
  /** Dipanggil dari stepCd (08-header.js) & pollCounter (02-api.js) tepat pas plane beneran ganti:
   * slot yg BARU SELESAI (lagi aktif skrg) generasinya NAIK 1 (psSlotGen, dipetakan ke entry berikutnya
   * lewat psEntryAtSlot — muter otomatis begitu lewat panjang PS_DATA_SEQUENCE) & mulai ngisi dari
   * kuning lagi dgn data plane baru itu, BARU status aktif (biru) pindah ke slot sebelahnya. */
  function psAdvanceActiveSlot(){
    const finished=psCurrentActiveSlot();
    psInitSlotsIfNeeded();
    const oldEntry=psEntryAtSlot(finished);
    psSlotGen[finished]++;
    // Hapus animation state plane lama. Jangan hapus progress Future Plane yang baru dipromosikan.
    delete psFillProgress[oldEntry.pid];
    psActiveSlot=(finished%PS_BUFFER_SIZE)+1;
    psLastHeaderPlane=null;
    psSaveConveyorState();
  }

  /** Reset TOTAL state konveyor (dipanggil dari sini pas MAX PLANE/jumlah slot berubah, ATAU dari
   * 08-header.js pas plane diganti manual lewat dropdown -- keduanya bikin state lama gak nyambung lagi)
   * -- regen fresh SESUAI kondisi (PS_BUFFER_SIZE/PS_MAX_PLANE/plane) skrg, lalu langsung persisten ke
   * server (bukan cuma di memori) biar reload abis reset ini gak balik "nyangkut" state basi sebelumnya. */
  function psResetConveyor(){
    psActiveSlot=null; psSlotGen=null;
    psConveyorRestored=true; META.plane_sim_conveyor_state=""; // jangan coba restore dari META lama
    psInitSlotsIfNeeded(); psCurrentActiveSlot();
    psSaveConveyorState();
  }

  /** Jarak RELATIF slot ini ke psActiveSlot sekarang (0=dia sendiri yg aktif, 1=1 slot setelah aktif,
   * dst, wrap 12->0). Dasar buat psCategoryForSlot & psFilledFor nentuin warna/isi tiap slot. */
  function psRelOf(slot){ return ((slot-psCurrentActiveSlot())%PS_BUFFER_SIZE+PS_BUFFER_SIZE)%PS_BUFFER_SIZE; }

  /* =====================================================================
     PLANE LIFECYCLE — ACTIVE/READY/FILLING (Master Spec "Plane Engine SMMS" Phase 1, 2026-08-27).
     READY WINDOW (3 physical Plane setelah Active) adalah konsep BARU, TERPISAH TOTAL dari
     PS_ACTIVE_LAG (dikonfirmasi user eksplisit: "Jangan mengganti PS_ACTIVE_LAG jadi 3. Jangan
     menggabungkan kedua konsep.") -- PS_ACTIVE_LAG TETAP cuma urusan header P-LANE(MROS) <-> slot
     Aktif/biru (TIDAK disentuh sama sekali di sini). READY dihitung SETELAH slot aktif sudah
     ketemu, murni dari jarak psRelOf/psRelOfNumber yg SUDAH ADA -- bukan mekanisme baru.
     READY = pure queue-position label, Arrival TIDAK menentukannya (spec eksplisit: "Arrival tidak
     menentukan READY") -- makanya psCategoryForSlot/psFilledFor short-circuit READY SEBELUM sempat
     manggil psRevealCategory sama sekali. FILLING window & ACTIVE (rel>PS_READY_WINDOW, atau rel=0)
     DIPERLAKUKAN SAMA -- warnanya dari progress animasi reveal (psRevealCategory, basis skid queue
     arrival-ordered + target STABIL, lihat Reset Arsitektur 2026-08-27 di dekat psCategoryForSlot),
     BUKAN lagi dari jam/CD (calculatePlaneState, DIHAPUS TOTAL).
     ===================================================================== */
  const PS_READY_WINDOW = 3;
  function psLifecycleForSlot(slot){
    const rel=psRelOf(slot);
    return rel===0 ? "active" : rel<=PS_READY_WINDOW ? "ready" : "filling";
  }
  function psLifecycleForNumber(num){
    const rel=psRelOfNumber(num);
    return rel===0 ? "active" : rel<=PS_READY_WINDOW ? "ready" : "filling";
  }

  /** Physical Position + Generation (Master Spec §4-5/§17) -- FORMALISASI NAMA SAJA di Phase 1, BUKAN
   * mekanisme baru: `slot` itu sendiri SUDAH physical position, `psSlotGen[slot]` (existing,
   * event-driven, naik tiap kali slot itu direcycle -- psAdvanceActiveSlot) SUDAH generation. Dipakai
   * Phase 1 murni sbg label/debug (psRenderDebugPanel) -- arithmetic generation-from-real-plane-number
   * (dibutuhkan utk Future Plane, spec §18-24) SENGAJA belum dibangun di sini, DEFERRED bareng Future
   * Plane itu sendiri (lihat plane-future-deferred, memory) -- membangunnya sekarang berisiko
   * mengulang model wraparound sintetik yg sudah dibongkar sesi ini krn nomor slot gak match data real. */
  function psPhysicalInfoForSlot(slot){
    psInitSlotsIfNeeded();
    return { physicalPosition: slot, generation: psSlotGen[slot]||0 };
  }

  /** Physical position + generation dari INDEX di PS_DATA_SEQUENCE (kebalikan psPhysicalInfoForSlot,
   * yg dari slot ke entry) — dipakai psFutureEntries buat nentuin entry mana yg BELUM direachable slot
   * manapun (Reset Arsitektur 2026-08-27, §18-24 master spec "Future Plane"). */
  function psPhysicalInfoForIndex(idx){
    return { physicalPosition: (idx % PS_BUFFER_SIZE)+1, generation: Math.floor(idx / PS_BUFFER_SIZE) };
  }

  /** Entry PS_DATA_SEQUENCE yg generation-nya LEBIH TINGGI drpd generation SEKARANG posisi fisiknya
   * (psSlotGen[physicalPosition]) — artinya BELUM ada satu slot pun yg sampai giliran kesitu. TIDAK
   * PERNAH salah satu dari 12 slot primer (psSeqIndexAtSlot SELALU resolve ke SATU entry via modulo,
   * gak pernah "kosong") — ini murni SISA di ekor array yg 12 slot itu belum reach. "Jangan diabaikan/
   * dihapus/digabung ke plane lain" (dikonfirmasi user eksplisit) — makanya ditampilkan terpisah
   * (#psFutureWrap, psRenderFisik) bukan dibuang. Promosi ke slot normal terjadi OTOMATIS begitu
   * psSlotGen posisi fisiknya naik lewat psAdvanceActiveSlot (real towing) -- TIDAK ADA fungsi
   * "promote" eksplisit, generation-nya sendiri yang berhenti > psSlotGen begitu itu terjadi. */
  function psFutureEntries(){
    psInitSlotsIfNeeded();
    return PS_DATA_SEQUENCE
      .map((entry,idx)=>({entry,idx,...psPhysicalInfoForIndex(idx)}))
      .filter(x=>x.generation>(psSlotGen[x.physicalPosition]||0))
      .sort((a,b)=>a.idx-b.idx);
  }

  /** Tinggi rata2 1 skid grup ini (meter, dari volume_box x lot / skidCount) — TANPA overhead pallet. */
  function psAvgSkidHeight(g){ return g.skidCount>0 ? g.volume/g.skidCount : 0; }

  /** maxPerStack KHUSUS 1 grup (dipakai fase "tumpukan murni" psPackStacksForPlane) — dites k=4 dulu
   * (boleh kalau tinggi totalnya <=3.0m IDEAL), fallback k=3, gak pernah nembus batas ABSOLUT 3.3m.
   * BISA turun di bawah 3 kalau tinggi per-skid grup ini SENDIRI sudah sangat besar (data ekstrem) --
   * stack yg kena kasus ini ditandai `belowMinLayers` di psPackStacksForPlane, BUKAN dipaksa "seolah 3
   * layer" (dikonfirmasi user: preferensi minimum 3 layer, TAPI jangan pura-pura valid kalau data
   * emang gak memungkinkan). */
  function psMaxPerStackForGroup(g){
    const avgH=psAvgSkidHeight(g);
    const heightOf=k=>k*avgH + k*PS_SKID_OVERHEAD_M;
    let maxPerStack = heightOf(4)<=PS_STACK_IDEAL_HEIGHT_M ? 4 : 3;
    while(maxPerStack>1 && heightOf(maxPerStack)>PS_STACK_MAX_HEIGHT_M) maxPerStack--;
    return maxPerStack;
  }

  /**
   * Bin-packing SEMUA grup 1 plane jadi tumpukan fisik, BOLEH campur >1 supplier per tumpukan —
   * dikonfirmasi user: di kondisi asli campur supplier gak masalah, yang penting TINGGI TUMPUKAN gak
   * lebih dari 3.3 meter ABSOLUT / 3.0 meter IDEAL (bukan batas JUMLAH skid).
   *
   * URUTAN PENYUSUNAN stack HARUS ngikutin urutan KRONOLOGIS `groups` (1st Cross Dock Arrival/Departcher
   * Date & Time, udah diurut di psComputeGroupsRaw) — dikonfirmasi user langsung liat drill-down: "boleh
   * acak kalau sudah penuh, namun harus urut sesuai 1st Cross Dock Arrival Date & Time dan 1st Cross
   * Dock Departcher Date & Time". Versi SEBELUMNYA nyortir SISA skid (leftover) by TINGGI FISIK
   * (First-Fit-Decreasing, demi efisiensi ruang) & nyari tumpukan "campuran" MANAPUN yg masih muat
   * (bisa yg jauh di awal array) — itu yg bikin tumpukan dari jam jauh berbeda numpuk bareng cuma krn
   * kebetulan tingginya mirip, keliatan "acak" di layar. Sekarang strateginya First-Fit KRONOLOGIS
   * (bukan Decreasing-by-height lagi), 1 pass, per grup (urutan grup = urutan waktu):
   * 1) Isi sebanyak mungkin tumpukan PENUH milik grup ini sendiri dulu (floor(skidCount/maxPerStack),
   *    psMaxPerStackForGroup — 3 atau 4 sesuai validasi tinggi grup itu) — SELALU mulai tumpukan baru
   *    (nutup tumpukan "lagi kebuka" `cur` kalau ada), supplier besar gak numpang nyempil ke sisa
   *    tumpukan grup lain yg beda jam.
   * 2) SISA (remainder, kalau ada) numpuk skid-demi-skid ke tumpukan yg LAGI KEBUKA (`cur`) — begitu
   *    `cur` udah gak muat lagi (4 skid ATAU tinggi lewat 4m), otomatis tutup & buka tumpukan baru.
   *    Grup BERIKUTNYA (kronologis) yg py sisa kecil lanjut numpuk ke `cur` YG SAMA kalau masih ada
   *    room — inilah "boleh acak" yg dimaksud user: isi 1 tumpukan kecil ini boleh campur grup manapun
   *    yg kebetulan lagi kebagian slot bareng secara kronologis, TAPI urutan tumpukan ke tumpukan
   *    (kiri-kanan/baris ke baris) TETAP murni ngikutin urutan waktu, gak pernah "loncat" nyari yg
   *    paling pas ukurannya kayak versi FFD sebelumnya.
   * Return: array tumpukan (URUT kronologis), tiap tumpukan = {items:[{g,count}], mixed:bool, height}.
   */
  function psPackStacksForPlane(groups){
    const stacks=[];
    // Tumpukan "lagi kebuka" (belum full) — tempat sisa grup KRONOLOGIS berikutnya numpuk duluan. BISA
    // nunjuk ke tumpukan MURNI (mixed:false) yg masih py SLACK (lihat bawah), bukan cuma tumpukan
    // campuran — dikonfirmasi user liat drill-down langsung: "ada yang ukuran tumpukan 2,8 dan 1,1,
    // kenapa gak ditumpuk aja jadi satu biar compact gak buang ruang" — versi SEBELUMNYA nutup PERMANEN
    // tiap tumpukan murni (fits() nolak `!cur.mixed`, dan `cur=null` dipaksa tiap kali tumpukan murni
    // baru kebentuk) walau tumpukan itu keitung maxPerStack<4 (artinya emang masih ada ruang sampai 4m,
    // cuma dibatasin krn preferensi "aman" 3.5m KHUSUS pas nge-batch skid SEJENIS) — item kronologis
    // BERIKUTNYA yg keciiil (mis. sisa 1 skid doang) jadi gak pernah dicoba numpuk ke situ, kepaksa
    // buka tumpukan baru sendirian & buang ruang.
    let cur=null;

    function fits(h){
      if(!cur) return false;
      const cnt=cur.items.reduce((a,it)=>a+it.count,0);
      return cnt<4 && (cur.height+h)<=PS_STACK_MAX_HEIGHT_M;
    }
    function addSkid(g,h){
      if(!fits(h)){ cur={items:[], mixed:false, height:0}; stacks.push(cur); }
      const existing=cur.items.find(it=>it.g===g);
      if(existing) existing.count++; else { cur.items.push({g,count:1}); if(cur.items.length>1) cur.mixed=true; }
      cur.height+=h;
    }

    groups.forEach(g=>{
      const maxPerStack=psMaxPerStackForGroup(g);
      let remaining=g.skidCount;
      while(remaining>=maxPerStack){
        // height SELALU dicatat (termasuk tumpukan murni, dulu cuma tumpukan campuran yg py height) --
        // dipakai nampilin "volume tumpukan" di drill-down (psRenderStackColumn).
        const h=(psAvgSkidHeight(g)+PS_SKID_OVERHEAD_M)*maxPerStack;
        const stack={items:[{g,count:maxPerStack}], mixed:false, height:h};
        stacks.push(stack);
        remaining-=maxPerStack;
        // Tumpukan murni yg BARU kebentuk ini jadi `cur` BARU (siap nampung item LAIN nanti, dari grup
        // ini sendiri ATAU grup kronologis berikutnya) CUMA kalau masih ada SLACK (maxPerStack<4 --
        // batasnya emang dari tinggi per-unit grup ini yg py preferensi 3.5m, BUKAN krn udah numpuk 4
        // penuh/mentok batas mutlak). Kalau udah pas 4 (gak ada slack sama sekali), `cur` LAMA (kalau
        // ada & masih muat, dari grup SEBELUM ini) dibiarin apa adanya — jangan ditimpa null cuma krn
        // ada tumpukan LAIN yg kebetulan lagi kepenuh duluan.
        if(maxPerStack<4) cur=stack;
      }
      for(let i=0;i<remaining;i++) addSkid(g, psAvgSkidHeight(g)+PS_SKID_OVERHEAD_M);
    });

    // Urutan tampil DALAM 1 tumpukan: yg PALING TINGGI/isinya banyak di BAWAH, yg isinya paling
    // sedikit di ATAS (sesuai kondisi aktual di lapangan) — array diurut desc, nanti dirender pakai
    // column-reverse (lihat psOpenDetail) jadi item pertama = bawah, item terakhir = atas. Ini urutan
    // DI DALAM 1 tumpukan doang (fisik/kestabilan), TERPISAH dari urutan stack-ke-stack yg kronologis.
    stacks.forEach(s=>s.items.sort((a,b)=>psAvgSkidHeight(b.g)-psAvgSkidHeight(a.g)));

    // Enrichment per-stack (koreksi rule stacking 2026-08-27) -- ADDITIVE, field lama (items/height/
    // mixed) TETAP ada apa adanya, konsumen existing (psRenderStackColumn/psOpenDetail/psTargetFor)
    // tidak perlu berubah. `valid`/`belowMinLayers` DITANDAI eksplisit (bukan dipaksa "kelihatan OK"
    // diam-diam, dikonfirmasi user prinsip #8) -- lihat psRenderStackColumn utk penanda visualnya.
    stacks.forEach((s,i)=>{
      const layerCount=s.items.reduce((a,it)=>a+it.count,0);
      s.stackNo=i+1;
      s.totalHeight=s.height;
      s.totalVolume=s.items.reduce((a,it)=>a+psAvgSkidHeight(it.g)*it.count,0); // TANPA overhead pallet, murni volume isi
      s.layers=s.items.flatMap(it=>Array(it.count).fill(it.g.key)); // identitas skid = key grup (skid dlm 1 grup identik/interchangeable, tidak py ID individual sendiri)
      s.valid=s.height<=PS_STACK_MAX_HEIGHT_M;
      s.belowMinLayers=layerCount<3;
    });
    return stacks;
  }
  /** Alias nama sesuai istilah requirement "stacking engine" (2026-08-27) -- implementasi SAMA PERSIS
   * psPackStacksForPlane (nama asli DIPERTAHANKAN krn dirujuk banyak komentar existing di file ini,
   * alias ini cukup utk konsistensi terminologi tanpa rename churn besar-besaran). */
  const calculatePlaneStacking = psPackStacksForPlane;

  /** Kategori visual slot (1..12) -> warna — RESET ARSITEKTUR 2026-08-27 ("Reset Logic Animasi Plane"):
   * versi SEBELUMNYA (hari ini juga) menghitung kategori dari calculatePlaneState, yg membandingkan
   * arrivalAt ke psSimNow() sbg GATE "berapa skid boleh tampil" — user TEGAS MEMBATALKAN itu ("Jangan
   * melakukan if(arrival <= simulationTime) tampilkan skid. Itu BUKAN requirement lagi"). Kategori
   * SEKARANG murni: 1) lifecycle posisi fisik (psLifecycleForSlot, Phase 1, TIDAK berubah) — READY
   * SELALU solid hijau, arrival diabaikan total. 2) selain itu (ACTIVE maupun FILLING window — dua2nya
   * DIPERLAKUKAN SAMA, "active" cuma tag/border terpisah lihat psBuildPlaneCard): warna dari progress
   * ANIMASI REVEAL (psRevealCategory) semata — target SEKARANG SELALU psTargetFor(pid) PENUH (bukan lagi
   * rasio arrived/total), timing "pelan-pelan kelihatan" murni urusan ANIMASI (psFillProgress mengejar
   * angka ini via psChaseStep), BUKAN business state lagi. calculatePlaneArrivalState/
   * calculatePlaneOutState/calculatePlaneState DIHAPUS TOTAL (tidak dipakai apa pun lagi) — Arrival
   * SEKARANG cuma menentukan URUTAN reveal (buildPlaneSkidSequence), CD Plane cuma progress countdown +
   * trigger recycle slot (stepCd/08-header.js, TIDAK disentuh), Departure TETAP tidak dipakai sama
   * sekali. */
  function psCategoryForSlot(slot){
    const lc=psLifecycleForSlot(slot);
    if(lc==="ready") return "ready";
    return psRevealCategory(psEntryAtSlot(slot).pid);
  }

  /** Target (kapasitas PENUH, fraksi=1) 1 plane di gauge overview — di-cap ke psOverviewRows*PS_OVERVIEW_COLS
   * (grid GLOBAL, "Jumlah Baris Tumpukan"×2 dari Pengaturan Fisik Plane). */
  function psTargetFor(planeId){
    return Math.min(psOverviewRows*PS_OVERVIEW_COLS, psPackStacksForPlane(psComputeGroups(planeId)).length);
  }

  /** Ordered skid queue 1 plane (Reset Logic 2026-08-27) — expand tiap grup jadi skid individual
   * (identik/interchangeable dlm 1 grup, konvensi SAMA kayak psPackStacksForPlane's s.layers), diurut
   * ASCENDING arrivalAt (grup TANPA arrivalAt valid ditaruh di belakang), tie-break deterministik (key
   * grup+index) biar urutan STABIL antar render (bukan random/berubah tiap panggil). Arrival SEKARANG
   * CUMA menentukan URUTAN reveal (dipakai debug panel & sbg basis konseptual psRevealCategory) — BUKAN
   * lagi menentukan "berapa boleh tampil" (peran lama calculatePlaneArrivalState/calculatePlaneState,
   * SUDAH DIHAPUS TOTAL sesuai instruksi eksplisit user). */
  function buildPlaneSkidSequence(planeId){
    const groups=psComputeGroups(planeId);
    const flat=[];
    groups.forEach(g=>{ for(let i=0;i<g.skidCount;i++) flat.push({ id:g.key+"#"+i, group:g, arrivalAt:g.arrivalAt }); });
    flat.sort((a,b)=>{
      const ta=parseCustomDate(a.arrivalAt), tb=parseCustomDate(b.arrivalAt);
      const va=!isNaN(ta), vb=!isNaN(tb);
      if(va&&vb&&ta!==tb) return ta-tb;
      if(va&&!vb) return -1;
      if(!va&&vb) return 1;
      return a.id<b.id?-1:a.id>b.id?1:0;
    });
    return flat;
  }

  /** Kategori dari progress ANIMASI (psFillProgress, lihat psChaseStep) vs target STABIL (psTargetFor)
   * — BUKAN dari jam/arrival lagi. "full" begitu reveal-nya kelar (psFillProgress[pid]>=target),
   * "filling" selagi masih jalan mengejar, "empty" cuma kalau plane ini BENAR2 gak py 1 pun stack (data
   * kosong). Dipakai SEMUA kartu non-ready (ACTIVE maupun window FILLING — keduanya sama persis). */
  function psRevealCategory(planeId){
    const total=psTargetFor(planeId);
    if(total<=0) return "empty";
    const shown=psFillProgress[planeId]??0;
    return shown>=total ? "full" : shown>0 ? "filling" : "empty";
  }

  /** Filled-slot count utk 1 slot (1..12) — SELALU target PENUH sekarang (psTargetFor), TIDAK LAGI
   * rasio arrived/total (Reset Arsitektur 2026-08-27) — "berapa yg KELIHATAN sekarang" murni urusan
   * ANIMASI (psFillProgress mengejar angka ini bertahap via psChaseStep), bukan urusan fungsi ini lagi.
   * READY dapat nilai SAMA (target penuh) — bedanya cuma KATEGORI (psCategoryForSlot: "ready" solid vs
   * "filling" yg mesti nunggu animasi ngejar dulu). Param `slot` dipertahankan di signature (dipanggil
   * dari banyak tempat dgn slot) walau gak dipakai lagi isinya — nilai SEKARANG murni fungsi dari planeId. */
  function psFilledFor(planeId, slot){
    const target=psTargetFor(planeId);
    const lifecycle=psLifecycleForSlot(slot);
    if(lifecycle==="ready") return target;
    return Number.isFinite(+psFillProgress[planeId]) ? +psFillProgress[planeId] : 0;
  }

  /* =====================================================================
     MODE "FULL PLANE" — persis pasangan psRelOf/psCategoryForSlot/psFilledFor di atas, TAPI beroperasi
     di ruang NOMOR PLANE (1..PS_MAX_PLANE) apa adanya, bukan ruang SLOT (1..PS_BUFFER_SIZE) — dipakai
     nampilin SEMUA nomor plane sekaligus (psRenderFull), bukan cuma sejumlah slot fisik yg lagi
     kepakai. "rel" di sini = jarak dari NOMOR yg lagi aktif (bukan dari SLOT aktif), pola simulasi
     fallback-nya (PS_FILL_PATTERN_FULL) juga di-generate ukuran PS_MAX_PLANE (bukan PS_BUFFER_SIZE).
     ===================================================================== */

  /** Pola isi simulasi fallback KHUSUS mode Full — sama fungsi (psFillPatternFor) dgn mode Fisik, cuma
   * ukurannya PS_MAX_PLANE (bisa puluhan) bukan PS_BUFFER_SIZE (9-12). Di-cache per render (psRenderFull)
   * krn PS_MAX_PLANE gak berubah di tengah 1x render, gak perlu di-generate ulang tiap nomor. */
  let PS_FILL_PATTERN_FULL=[];

  /** Tanggal cakupan mode Full Plane — SELALU tanggal "Sampai" (terakhir di PS_RANGE_DATES), BUKAN
   * ikut rentang multi-tanggal penuh spt mode Fisik (Full Plane sifatnya snapshot 1 momen, bukan
   * cycling lintas waktu — lihat psRenderFull) — null kalau rentang custom belum dipilih (default,
   * sama kayak PLANES polos Monitor). */
  function psFullDate(){
    return PS_RANGE_DATES.length ? PS_RANGE_DATES[PS_RANGE_DATES.length-1] : null;
  }
  /** Entry {date,num,pid} yg TERMASUK cakupan mode Full Plane (psFullDate()), urutan SAMA persis
   * kayak di PS_DATA_SEQUENCE (kronologis/ascending, dari psRebuildDataSequence). Alias tipis dari
   * psEntriesForDate (lihat di atas, dipakai bareng psRecomputeTimeLapseRatio). */
  function psFullEntries(){
    return psEntriesForDate(psFullDate());
  }
  /** pid data utk 1 NOMOR plane di mode Full — GANTI psPlaneDataForNumber lama (modulo-cycling
   * DIHAPUS): sekarang psRenderFull cuma meng-iterate nomor yg BENERAN py data real, jadi tinggal
   * cocokkan langsung ke tanggal cakupannya. */
  function psFullPidForNumber(num){
    const d=psFullDate();
    return d?(d+"|"+num):String(num);
  }

  /** Jarak RELATIF (0=aktif sendiri) nomor plane `num` ke plane AKTIF sekarang di mode Full — dihitung
   * dari POSISI ARRAY (index di psFullEntries()), BUKAN aritmetika nilai nomor (nomor sekarang bisa
   * berupa string MROS non-kontinu, mis. "05"/"13", bukan integer spiral buatan lagi) — dikonfirmasi
   * user poin 3: pakai indeks, bukan nilai nomor mentah. 0 kalau `num` gak ketemu di cakupan sekarang. */
  function psRelOfNumber(num){
    const entries=psFullEntries();
    const range=Math.max(1, entries.length);
    const idx=entries.findIndex(e=>String(e.num)===String(num));
    if(idx<0) return 0;
    const activeIdx=entries.findIndex(e=>String(e.num)===String(plane));
    const a=activeIdx<0?0:activeIdx;
    return ((idx-a)%range+range)%range;
  }

  /** Future (generation berikutnya, belum giliran) KHUSUS mode Full Plane — dihitung LOKAL dari
   * psFullEntries() sendiri (BUKAN index PS_DATA_SEQUENCE lintas-tanggal), krn psRelOfNumber di atas
   * juga nyari `activeIdx` LOKAL -- kalau Future dihitung dari index GLOBAL (lintas tanggal), "active"
   * & "future" bisa gak sinkron reference frame-nya begitu >1 tanggal lagi dipilih. Future = ordinal
   * generation (floor(idx/PS_BUFFER_SIZE)) nomor ini LEBIH BESAR drpd generation entry AKTIF sekarang —
   * persis pola "Plane 25 gen1 sementara Active masih gen0" di master spec, cuma basisnya snapshot
   * lokal Full Plane (Fisik mode py versi live-nya sendiri, psFutureEntries, basis psSlotGen beneran). */
  function psIsFutureNumber(num){
    const entries=psFullEntries();
    const idx=entries.findIndex(e=>String(e.num)===String(num));
    if(idx<0) return false;
    const activeIdx=entries.findIndex(e=>String(e.num)===String(plane));
    const a=activeIdx<0?0:activeIdx;
    return Math.floor(idx/PS_BUFFER_SIZE) > Math.floor(a/PS_BUFFER_SIZE);
  }

  /** Kategori visual utk 1 NOMOR plane — analog psCategoryForSlot (lihat komentar di sana soal Reset
   * Arsitektur 2026-08-27), basis psRevealCategory (animasi vs target stabil), + Future (generation
   * berikutnya, §18-24 master spec). READY diperiksa DULUAN (physical proximity ke Active menang atas
   * label generation — sejalan prinsip #1 "PHYSICAL SEQUENCE = MASTER lifecycle"). */
  function psCategoryForNumber(num){
    const lc=psLifecycleForNumber(num);
    if(lc==="ready") return "ready";
    if(psIsFutureNumber(num)) return "future";
    return psRevealCategory(psFullPidForNumber(num));
  }

  /** Filled-slot count utk 1 NOMOR plane — analog psFilledFor(planeId,slot), SELALU target penuh
   * sekarang (Reset Arsitektur 2026-08-27), basisnya nomor bukan slot. */
  function psFilledForNumber(num){
    const pid=psFullPidForNumber(num), target=psTargetFor(pid);
    const lifecycle=psLifecycleForNumber(num);
    if(lifecycle==="ready") return target;
    return Number.isFinite(+psFillProgress[pid]) ? +psFillProgress[pid] : 0;
  }

  /** Dispatcher kategori/isi-gauge PER KARTU (dataset.mode nempel di tiap .ps-plane-cols pas dibikin,
   * lihat psBuildPlaneCard) — dipakai psStartAnim() (animasi kuning) & psRefreshActiveCard() (refresh
   * kartu aktif tiap tick countdown) yg SAMA-SAMA jalan lintas mode tanpa peduli mana yg lagi kebuka,
   * krn cuma satu mode yg py kartu hidup di DOM kapan pun (mode lain di-kosongin pas psSetViewMode). */
  function psCategoryForCard(cols){
    // Future tail (Reset Arsitektur 2026-08-27, dataset.future="1" -- lihat psRenderFisik) BUKAN salah
    // satu dari 12 slot primer (gak py physical position/rel yg valid), jadi diperiksa DULUAN, sebelum
    // dispatch normal ke psCategoryForSlot/psCategoryForNumber.
    if(cols.dataset.future==="1") return "future";
    // dataset.num TETAP string apa adanya (BUKAN di-+ jadi Number lagi) -- nomor plane sekarang bisa
    // string MROS asli (mis. "05"), `+` bikin leading zero ilang & psFullPidForNumber jadi salah cocok.
    return cols.dataset.mode==="full" ? psCategoryForNumber(cols.dataset.num) : psCategoryForSlot(+cols.dataset.slot);
  }
  function psFilledForCard(cols){
    if(cols.dataset.future==="1") return psTargetFor(cols.dataset.plane);
    return cols.dataset.mode==="full" ? psFilledForNumber(cols.dataset.num) : psFilledFor(cols.dataset.plane,+cols.dataset.slot);
  }

  /** Bikin 1 kartu visual plane (dipakai BARENG oleh render mode Fisik, mode Full, & mode Manual/
   * Physical Plane, biar tampilan & perilakunya selalu identik) — num=nomor plane yg ditampilkan di
   * tombol, pid=plane data ASLI (buat skid count/klik drill-down psOpenDetail), cat=kategori warna,
   * initFill=isi gauge awal, target=TIDAK DIPAKAI LAGI (bekas kapasitas gauge cabang cat==="active",
   * dihapus koreksi arsitektur 2026-08-27 — parameter dipertahankan di signature krn caller lama masih
   * mengirimnya, sama pola layoutCols/layoutRows di bawah),
   * mode='fisik'|'full' + extraDataset (slot/num) nempel di dataset .ps-plane-cols biar dispatcher
   * psCategoryForCard/psFilledForCard tau cara baca kartu ini belakangan. layoutCols/layoutRows
   * OPSIONAL -- kalau dikirim, grid gauge kartu ini pakai ukuran ITU (bukan PS_OVERVIEW_COLS/
   * psOverviewRows global, lihat psRenderGauge); tidak ada caller yg mengirim ini lagi sekarang
   * (bekas Data Plane Manual, dihapus 2026-08-27) — parameter dipertahankan di signature krn masih
   * berguna kalau kelak ada mode lain yg butuh layout per-kartu sendiri. */
  function psBuildPlaneCard(pid, num, cat, initFill, target, isActive, mode, extraDataset, dateLabel, layoutCols, layoutRows){
    const card=document.createElement("div"); card.className="ps-plane-card"+(isActive?" active":"");
    const tag=document.createElement("div"); tag.className="ps-tag"; tag.textContent=isActive?"AKTIF":"";
    const cols=document.createElement("div"); cols.className="ps-plane-cols";
    cols.dataset.plane=pid; cols.dataset.mode=mode;
    Object.entries(extraDataset||{}).forEach(([k,v])=>{ cols.dataset[k]=v; });
    // Standby (absoluteTarget) CUMA dipasang buat kategori "filling"/"future" (keduanya lagi dlm proses
    // reveal-in animasi, Reset Arsitektur 2026-08-27) — bukan diaktifkan bulat2 utk SEMUA kategori.
    // Kategori "empty" (psFillProgress[pid] masih 0, belum sempat di-chase psStartAnim) dulu tetap
    // dikirimin psTargetFor(pid) sbg absoluteTarget, jadinya SELURUH kapasitas plane itu langsung
    // digambar full standby-oranye SEJAK DETIK PERTAMA — plane yg blm sama sekali kesentuh gilirannya
    // jadi keliatan "penuh" instan, bukan kosong. "full" gak kena dampak (filledCount==target udah
    // otomatis bikin standby=0, lihat psRenderGauge). Kategori "active" TETAP TIDAK ADA (category cuma
    // "ready"/"future"/"full"/"filling"/"empty" sekarang, param `target` di sini gak dipakai lagi).
    psRenderGauge(cols, initFill, cat, undefined, undefined, layoutCols, layoutRows);
    const skidLbl=document.createElement("div"); skidLbl.className="ps-skidcount";
    skidLbl.textContent=psTotalSkid(pid)+" skid";
    const btn=document.createElement("button"); btn.className="ps-plane-btn"; btn.type="button";
    btn.textContent=num; btn.title=`Lihat isi Plane ${num}`;
    btn.onclick=()=>psOpenDetail(pid,num,dateLabel);
    card.append(tag,cols,skidLbl,btn);
    // Badge tanggal kecil -- CUMA dipasang kalau rentang multi-tanggal beneran lagi aktif (>1 tanggal
    // terpilih), biar plane nomor sama dari tanggal beda kelihatan beda scr visual (dikonfirmasi user:
    // identitas TERPISAH per-tanggal, bukan digabung — lihat plane-sim.css .ps-plane-datebadge).
    if(dateLabel && PS_RANGE_DATES.length>1){
      const badge=document.createElement("div"); badge.className="ps-plane-datebadge";
      badge.textContent=psCompactDateLabel(dateLabel);
      card.appendChild(badge);
    }
    return card;
  }

  /** Render kotak ke dalam .ps-plane-cols: SELALU 2 kolom RATA (PS_OVERVIEW_COLS), tinggi fleksibel
   * ngikutin psOverviewRows. filledCount = berapa stack yg lagi "revealed" (psFillProgress, animasi
   * reveal arrival-ordered — lihat psRevealCategory/psChaseStep). Arah isi SELALU TOP-anchored (kotak
   * PALING ATAS keisi DULUAN, nambah ke bawah, `r<filledHere`) -- utk SEMUA kategori
   * (ready/future/full/filling/empty), TERMASUK kartu yg isActive (tag "AKTIF"), krn kategori "active"
   * (cabang bottom-anchored/drain-dari-target LAMA) sudah DIHAPUS TOTAL sejak koreksi arsitektur
   * 2026-08-27 — plane aktif dianimasikan SAMA persis kayak plane lain, basis reveal animasi, bukan
   * lagi cd/cdStart mentah.
   *
   * `absoluteTarget` = kapasitas TOTAL/mutlak plane ini (psTargetFor(pid), SEMUA tumpukan yg KEDATA
   * bakal ada, gak peduli waktunya udah lewat apa belum) — dipakai gambar sisa slot "Standby" (Early
   * Arrival: part yg udah kedaftar di MROS tapi jamnya blm masuk psSimNow(), jangan tercampur visual
   * sama yg udah beneran current). Slot standby ini ditaruh DI BAWAH slot yg udah "current"
   * (filledHere..absHere), pakai class .st-standby (lihat plane-sim.css). Opsional/mundur-kompatibel:
   * absoluteTarget gak dikirim (undefined) -> gak ada standby sama sekali.
   * Param `target` DIPERTAHANKAN di signature (kompat pemanggil lama) tapi TIDAK DIPAKAI lagi sama
   * sekali sejak cabang "active" dihapus -- semua pemanggil sekarang selalu kirim `undefined`.
   *
   * REUSE NODE, BUKAN wipe+rebuild (dikonfirmasi user: "animasi masih blm benar") — versi SEBELUMNYA
   * `colsEl.innerHTML=""` lalu bikin SEMUA elemen kolom/sel BARU tiap panggilan (dipanggil tiap 200ms
   * dari psStartAnim, tiap tick CD dari psRefreshActiveCard) — transisi CSS `.ps-cell` (fade .5s,
   * plane-sim.css) SAMA SEKALI GAK PERNAH kepakai krn transisi CSS cuma jalan kalau CLASS-nya BERUBAH
   * di elemen DOM yg SAMA/persisten dari 1 frame ke frame berikutnya; elemen BARU muncul LANGSUNG di
   * state akhirnya (gak ada histori "sebelumnya" buat difade dari situ) — makanya kelihatan patah/
   * nyentak instan walau CSS transition-nya udah bener. Sekarang: struktur kolom/baris DICEK dulu,
   * kalau SUDAH cocok (jumlah kolom==PS_OVERVIEW_COLS & tiap kolom udah py psOverviewRows sel) elemen
   * LAMA dipakai lagi apa adanya, cuma className tiap sel yg di-update — elemen persisten ini yg bikin
   * browser BENERAN nge-animasiin perubahan warnanya. Rebuild dari nol CUMA kalau strukturnya beda
   * (render pertama kali, atau psOverviewRows/PS_OVERVIEW_COLS abis diubah di Pengaturan). */
  function psRenderGauge(colsEl, filledCount, category, target, absoluteTarget, cols, rows){
    // `cols`/`rows` opsional -- default ke PS_OVERVIEW_COLS/psOverviewRows (GLOBAL, dari "Pengaturan
    // Fisik Plane"). Tidak ada caller yg mengirim override lagi sekarang (bekas Data Plane Manual,
    // dihapus 2026-08-27) -- parameter dipertahankan kalau kelak ada kebutuhan serupa.
    const nCols = cols||PS_OVERVIEW_COLS, nRows = rows||psOverviewRows;
    const absTgt = Math.max(absoluteTarget??filledCount, filledCount);
    const filledPerColBase=Math.floor(filledCount/nCols), extra=filledCount%nCols;
    const absPerColBase=Math.floor(absTgt/nCols), absExtra=absTgt%nCols;
    const needRebuild = colsEl.children.length!==nCols
      || [...colsEl.children].some(col=>col.children.length!==nRows);
    if(needRebuild){
      colsEl.innerHTML="";
      for(let c=0;c<nCols;c++){
        const col=document.createElement("div"); col.className="ps-col";
        for(let r=0;r<nRows;r++) col.appendChild(document.createElement("div"));
        colsEl.appendChild(col);
      }
    }
    for(let c=0;c<nCols;c++){
      const col=colsEl.children[c];
      const filledHere=Math.min(nRows, filledPerColBase+(c<extra?1:0));
      const absHere=Math.min(nRows, absPerColBase+(c<absExtra?1:0));
      for(let r=0;r<nRows;r++){
        const cell=col.children[r];
        const isFilled = r<filledHere;
        const isStandby = !isFilled && r<absHere; // "kedata" tapi belum "current" (r>=filledHere, r<absHere)
        cell.className = "ps-cell" + (isFilled ? " filled st-"+category : (isStandby ? " filled st-standby" : ""));
      }
    }
  }

  /** Render axis kiri (1..maxN, 1 di bawah) sekali aja -- statis, gak perlu direfresh tiap tick. */
  function psRenderAxis(elId, maxN){
    const axis=document.getElementById(elId);
    if(!axis || axis.childElementCount===maxN) return;
    axis.innerHTML="";
    for(let n=1;n<=maxN;n++){
      const el=document.createElement("div"); el.className="ps-axis-n"; el.textContent=n;
      axis.appendChild(el);
    }
  }

  // Mode tampilan Plane Simulation — 'fisik' (default): cuma sejumlah Jumlah Slot Fisik yg ditampilkan,
  // ngikutin posisi towing aktual sekarang (perilaku asli, sebelum fitur mode Full ada). 'full': SEMUA
  // nomor plane (1..PS_MAX_PLANE) ditampilkan sekaligus, disusun per baris sejumlah Jumlah Slot Fisik
  // (mis. 9 slot fisik & MAX PLANE 24 -> 3 baris: 9+9+6) — dikonfirmasi user, "systemnya masih sama
  // namun menampilkan semuanya". renderPlaneSim() (dipanggil dari BANYAK tempat lain: nav klik, ganti
  // plane, tick countdown, dst) jadi DISPATCHER tipis ke salah satu dari 2 fungsi di bawah sesuai mode
  // ini, biar semua caller yg SUDAH ADA gak perlu diubah sama sekali.
  let psViewMode="fisik";

  /** Render ulang seluruh buffer SLOT FISIK (dipanggil pas buka menu, atau pas plane aktif ganti).
   * Fetch data (psPrefetchSequenceData) & psRecomputeTimeLapseRatio() SEKARANG dikerjakan terpusat di
   * renderPlaneSim() (dispatcher, lihat bawah) SEBELUM fungsi ini dipanggil -- di sini tinggal render
   * dari PS_DATA_SEQUENCE/PS_PCACHE yg udah siap. Physical Plane murni dari "Pengaturan Fisik Plane"
   * (PS_BUFFER_SIZE/PS_MAX_PLANE/PS_MIN_PLANE/psSlotGen spiral, koreksi arsitektur 2026-08-27 --
   * konsep "Data Plane Manual" terpisah yg sempat dibangun sebelumnya sudah DIBATALKAN & dihapus). */
  async function psRenderFisik(){
    const box=document.getElementById("psBuffer");
    if(!box) return;

    const activeSlot=psCurrentActiveSlot();
    const slots=[]; for(let s=1;s<=PS_BUFFER_SIZE;s++) slots.push(s);
    const entries=slots.map(psEntryAtSlot);

    // Tinggi gauge (psOverviewRows) FIXED sesuai "Jumlah Baris Tumpukan" di Pengaturan Fisik Plane
    // (bukan lagi dihitung dari tumpukan terbanyak di data kayak sebelumnya) -- kalau data real py
    // lebih banyak tumpukan drpd kapasitas ini, psTargetFor() yg nge-cap gauge-nya (penuh, gak
    // overflow), jadi gak perlu dihitung ulang di sini tiap render.
    psRenderAxis("psAxis", psOverviewRows);

    box.innerHTML="";
    slots.forEach((slot,i)=>{
      const {pid,num,date}=entries[i];
      const cat=psCategoryForSlot(slot);
      const isActive=slot===activeSlot;
      // Reveal-in animasi (Reset Arsitektur 2026-08-27): SEMUA kategori SELAIN "ready" mulai dari
      // progress terakhirnya (atau 0 kalau baru pertama kali dilihat) -- kartu FRESH (psFillProgress[pid]
      // belum kebentuk) SELALU dikategorikan "empty" oleh psCategoryForSlot (lihat psRevealCategory),
      // jadi initFill=0 di situ KONSISTEN sama kategorinya sendiri (bukan lompat ke penuh duluan baru
      // animasinya keliatan turun). "ready" tetap solid penuh, arrival/animasi diabaikan total (spec §7).
      const initFill = cat==="ready" ? psFilledFor(pid,slot) : (psFillProgress[pid]??0);
      const card=psBuildPlaneCard(pid, num, cat, initFill, psTargetFor(pid), isActive, "fisik", {slot}, date);
      box.appendChild(card);
    });

    // Future tail (Reset Arsitektur 2026-08-27, §18-24 master spec) -- entry PS_DATA_SEQUENCE yg BELUM
    // direachable slot manapun (psFutureEntries), ditampilkan TERPISAH di bawah 12 slot primer (bukan
    // salah satu dari 12 itu -- 12 slot SELALU resolve ke SATU entry via modulo, gak pernah "future").
    // Reveal animasinya SAMA persis (psChaseStep/psRevealCategory, dataset.future="1" biar dispatcher
    // psCategoryForCard/psFilledForCard gak salah manggil psCategoryForSlot/psFilledFor dgn slot palsu).
    const futureWrap=document.getElementById("psFutureWrap");
    if(futureWrap){
      const futures=psFutureEntries();
      futureWrap.innerHTML="";
      futureWrap.style.display = futures.length ? "" : "none";
      futures.forEach(({entry})=>{
        const initFill=psFillProgress[entry.pid]??0;
        const card=psBuildPlaneCard(entry.pid, entry.num, "future", initFill, psTargetFor(entry.pid), false, "fisik", {future:"1"}, entry.date);
        futureWrap.appendChild(card);
      });
    }
    psStartAnim();
  }

  /** Render mode "Full Plane": SEMUA nomor plane REAL di tanggal cakupan (psFullDate(), SELALU tanggal
   * "Sampai" — snapshot 1 momen, TIDAK ikut rentang multi-tanggal penuh spt mode Fisik), dibagi per
   * baris sejumlah PS_BUFFER_SIZE (Jumlah Slot Fisik) — baris TERAKHIR boleh gak penuh. TIDAK ADA lagi
   * modulo-cycling/padding (beda dari versi lama yg selalu iterate MIN..MAX_PLANE penuh via
   * psPlaneDataForNumber) — cuma nomor yg BENERAN py data real yg dirender. */
  async function psRenderFull(){
    const wrap=document.getElementById("psFullWrap");
    if(!wrap) return;
    const cols=PS_BUFFER_SIZE;
    const entries=psFullEntries();
    const total=entries.length;
    PS_FILL_PATTERN_FULL=psFillPatternFor(Math.max(1,total));

    wrap.innerHTML="";
    if(!total) return;
    const rows=Math.ceil(total/cols);
    for(let r=0;r<rows;r++){
      const fromIdx=r*cols, toIdx=Math.min(total,(r+1)*cols)-1;
      const from=entries[fromIdx].num, to=entries[toIdx].num;
      const rowBlock=document.createElement("div"); rowBlock.className="ps-full-row-block";
      const lbl=document.createElement("div"); lbl.className="ps-full-rowlbl";
      lbl.textContent=`Baris ${r+1} · Plane ${from}–${to}`;
      const rowWrap=document.createElement("div"); rowWrap.className="ps-buffer-row";
      const axisId=`psFullAxis${r}`;
      const axis=document.createElement("div"); axis.className="ps-axis"; axis.id=axisId;
      const buf=document.createElement("div"); buf.className="ps-buffer";
      rowWrap.append(axis,buf);
      rowBlock.append(lbl,rowWrap);
      wrap.appendChild(rowBlock);
      psRenderAxis(axisId, psOverviewRows);
      for(let idx=fromIdx; idx<=toIdx; idx++){
        const {pid,num,date}=entries[idx];
        const cat=psCategoryForNumber(num);
        const isActive=String(num)===String(plane);
        // Lihat komentar sama di psRenderFisik -- initFill SELALU dari progress terakhir kecuali "ready".
        const initFill = cat==="ready" ? psFilledForNumber(num) : (psFillProgress[pid]??0);
        const card=psBuildPlaneCard(pid, num, cat, initFill, psTargetFor(pid), isActive, "full", {num}, date);
        buf.appendChild(card);
      }
    }
    psStartAnim();
  }

  /** Dispatcher — SEMUA caller yg sudah ada (nav klik, ganti plane, tick countdown, dst) manggil ini
   * apa adanya, gak perlu tau/peduli mode mana yg lagi aktif. Urutan WAJIB: opsi tanggal dulu (biar
   * PS_RANGE_DATES/PS_PLANES_BY_DATE siap) -> kalibrasi MAX PLANE -> bangun PS_DATA_SEQUENCE -> prefetch
   * SEMUA data yg dibutuhkan -> reset cache groups -> hitung ulang rasio Auto-Scaling (butuh groups &
   * PS_DATA_SEQUENCE final) -> reset konveyor KALAU sequence-nya beneran berubah -> baru render. */
  async function renderPlaneSim(){
    await psLoadDateOptions();
    psSyncAutoMaxPlane(); // mode "Otomatis" -- pastikan PS_MAX_PLANE ngikutin MROS tertinggi data SEKARANG
    const changed=psRebuildDataSequence();
    await psPrefetchSequenceData();
    psResetGroupsCache();
    psRecomputeTimeLapseRatio();
    if(changed) psResetConveyor();
    if(psViewMode==="full") await psRenderFull();
    else await psRenderFisik();
  }

  /** Pindah mode tampilan (tombol toggle Fisik/Full Plane) — kosongkan container mode yg DITINGGALKAN
   * (bukan cuma disembunyikan via CSS) supaya psStartAnim()/psRefreshActiveCard() yg nge-query SEMUA
   * ".ps-plane-cols" di DOM gak pernah kesenggol kartu dari mode yg lagi gak aktif (dataset.slot vs
   * dataset.num beda struktur antara 2 mode, kalau nyangkut bareng bisa salah baca NaN). */
  function psSetViewMode(mode){
    if(psViewMode===mode) return;
    psViewMode=mode;
    document.querySelectorAll(".ps-viewmode-btn").forEach(b=>b.classList.toggle("on", b.dataset.mode===mode));
    const fisikWrap=document.getElementById("psFisikWrap"), fullWrap=document.getElementById("psFullWrap");
    fisikWrap.style.display = mode==="fisik" ? "" : "none";
    fullWrap.style.display = mode==="full" ? "" : "none";
    if(mode==="fisik") fullWrap.innerHTML=""; else document.getElementById("psBuffer").innerHTML="";
    renderPlaneSim();
  }
  document.querySelectorAll(".ps-viewmode-btn").forEach(b=>b.onclick=()=>psSetViewMode(b.dataset.mode));

  /** SATU langkah "kejar target" (naik ATAU turun 1 kotak) utk 1 kartu — SATU-SATUNYA fungsi yg boleh
   * menulis psFillProgress (Reset Arsitektur 2026-08-27, "single animation driver": psStartAnim manggil
   * ini tiap 200ms utk SEMUA kartu di tab Plane Simulation; psRefreshActiveCard TIDAK LAGI manggil ini
   * sama sekali, cuma merender apa adanya -- lihat komentarnya). Target SEKARANG SELALU psTargetFor(pid)
   * (stabil, gak lagi turun krn CD sejak Reset Arsitektur), tapi mekanisme BIDIRECTIONAL tetap
   * dipertahankan apa adanya (harmless, gak ada yg bikin target turun lagi dlm praktiknya sekarang,
   * tapi tetap aman kalau kelak ada kebutuhan serupa). Kartu yg BARU PERTAMA KALI dilihat (belum py
   * psFillProgress tersimpan) langsung ditaruh DI target (bukan animasi dari 0), konsisten sama initFill
   * di psRenderFisik/psRenderFull. */
  function psChaseStep(cols){
    const pid=cols.dataset.plane;
    const target=psTargetFor(pid);
    const mode=cols.dataset.mode||"fisik";
    const lifecycle=cols.dataset.future==="1"
      ? "future"
      : (mode==="full" ? psLifecycleForNumber(cols.dataset.num) : psLifecycleForSlot(+cols.dataset.slot));
    let current=Number.isFinite(+psFillProgress[pid]) ? +psFillProgress[pid] : 0;
    current=Math.max(0,Math.min(target,current));
    // READY harus langsung penuh. ACTIVE/FILLING/FUTURE reveal perlahan.
    if(lifecycle==="ready") current=target;
    else if(current<target) current++;
    psFillProgress[pid]=current;
    const visualCategory = lifecycle==="ready" ? "ready" : (lifecycle==="future" ? "future" : (current>=target ? "full" : (current>0 ? "filling" : "empty")));
    psRenderGauge(cols,current,visualCategory,undefined,undefined);
  }

  /** RESET ARSITEKTUR 2026-08-27 — "SATU animation driver": psStartAnim() (200ms, cuma jalan selama tab
   * Plane Simulation kebuka) adalah SATU-SATUNYA yg boleh menulis psFillProgress (lihat psChaseStep).
   * Fungsi ini (dipanggil dari refreshHeader(), 08-header.js, tiap tick CD REAL -- termasuk saat tab
   * Plane Simulation TIDAK dibuka, demi clone Plane Buffer di Monitor) SEKARANG cuma MERENDER, TIDAK
   * PERNAH mengubah psFillProgress lagi -- dulu manggil psChaseStep (business transition KEDUA di luar
   * psStartAnim, persis yg dilarang user eksplisit: "Jangan psStartAnim dan psRefreshActiveCard sama2
   * mengubah animation state"). Ini AMAN sekarang krn target (psTargetFor) STABIL (gak lagi bergantung
   * jam/CD) -- kalau kartu ini udah settle di target, gak ada apa2 yg perlu dianimasikan; kalau baru
   * saja recycle (psFillProgress[pid] dihapus psAdvanceActiveSlot), tampil LANGSUNG penuh di sini benar
   * (gak ada yg nonton animasi reveal di tab Monitor), drpd "nyangkut" di 0 sampai tab Plane Simulation
   * dibuka lagi. */
  function psRefreshActiveCard(){
    const cols=document.querySelector("#psFisikWrap .ps-plane-card.active .ps-plane-cols");
    if(!cols) return;
    const pid=cols.dataset.plane;
    const lifecycle=psLifecycleForSlot(+cols.dataset.slot);
    const target=psTargetFor(pid);
    const shown=Number.isFinite(+psFillProgress[pid]) ? +psFillProgress[pid] : 0;
    if(lifecycle==="ready") psFillProgress[pid]=target;
    psRenderGauge(cols,lifecycle==="ready"?target:shown,psCategoryForCard(cols),undefined,undefined);
    if(typeof psRenderDebugPanel==="function") psRenderDebugPanel();
  }

  // Animasi "barang maju/keluar" (kuning naik/turun): tiap tick, gauge-nya NGEJAR target 1 kotak (naik
  // ATAU turun, lihat psChaseStep) lalu BERHENTI kalau udah pas. psFillProgress nyimpen progress
  // TERAKHIR tiap plane (key=planeId, BUKAN key=nomor/slot) biar konsisten dipakai bareng render awal
  // di psRenderFisik/psRenderFull (mulai dari situ, bukan langsung full). Mode Full SEKARANG cuma
  // iterate nomor yg BENERAN py data real (TIDAK ADA modulo-padding lagi, lihat psFullEntries/
  // psFullPidForNumber) — 1 pid gak lagi muncul dobel di >1 kartu Full Plane krn wrap modulo lama.
  // psStartAnim() TETAP jaga2 pakai Set (lihat di situ) andai 1 pid kebetulan muncul di >1 kartu dari
  // sumber lain (mis. transisi render/mode) biar gak dobel kecepatan.
  //
  // SEMUA kartu diproses tiap tick (koreksi arsitektur 2026-08-27) — filter lama "skip kalau kategori
  // bukan filling" DIHAPUS: itu tepat yg dulu bikin kartu AKTIF (dulu selalu kategori "active", gak
  // pernah "filling") permanen gak pernah dianimasikan. Kartu berkategori ready/full/empty yg
  // progress-nya udah pas target otomatis no-op sendiri (psChaseStep, `current===target` -> diem), jadi
  // aman diproses tiap tick tanpa beban tambahan berarti.
  //
  // TIDAK digantungkan ke `auto` (toggle countdown simulasi manual di header) — reveal animasi ini
  // (Reset Arsitektur 2026-08-27) murni efek visual settle-in sekali per plane, TIDAK LAGI bergantung
  // jam/psSimNow()/CD sama sekali (target=psTargetFor(pid), STABIL) — jalan terus SELAMA tab Plane
  // Simulation kebuka, gak peduli AUTO countdown lagi jalan/di-pause, biar reveal-nya konsisten kapan
  // pun sebuah plane pertama kali kelihatan.
  //
  // Interval 200ms (dikonfirmasi user, poin 5 "Animasi Sangat Mulus") + transisi CSS .5s (plane-sim.css)
  // bareng2 bikin reveal 1-kotak-per-tick ini keliatan mulus mengalir, bukan patah2/nyentak.
  let psAnimTimer=null;
  const psFillProgress=Object.create(null);
  function psStartAnim(){
    if(psAnimTimer) return;
    psAnimTimer=setInterval(()=>{
      if(!document.body.classList.contains("planesim")){ psStopAnim(); return; }
      const processed=new Set();
      document.querySelectorAll(".ps-plane-cols").forEach(cols=>{
        const pid=cols.dataset.plane;
        if(!pid || processed.has(pid)) return;
        processed.add(pid);
        psChaseStep(cols);
      });
      if(typeof psRenderDebugPanel==="function") psRenderDebugPanel();
    },200);
  }

  // Heartbeat WALL-CLOCK independen dari simulasi countdown/AUTO — render PENUH (renderPlaneSim(),
  // yg refresh PS_DATA_SEQUENCE/PS_PLANES_BY_DATE dari server) cuma dipicu klik nav/ganti plane/dst
  // secara normal. Kalau AUTO countdown lagi mati & operator diem gak ngapa2in, render penuh itu gak
  // pernah ke-trigger lagi — data Progress Lane BARU yg keupload di server (mis. plane generasi
  // berikutnya, calon masuk Future tail — lihat psFutureEntries) gak akan pernah kelihatan sampai
  // operator ngapa2in sesuatu scr manual. Interval INI jamin render penuh tetap jalan tiap 20 detik
  // biar data baru kepikup otomatis (render penuh sendiri dites ringan, ~2-11ms, lihat komentar
  // psGroupsCache di atas, jadi murah dipanggil serapat ini).
  // GAK LAGI di-gate ke tab Plane Simulation doang (`!body.classList.contains("planesim")`) — shape
  // "Plane Buffer" di denah Monitor (kind:'planebuffer', 06-render.js) nge-CLONE #psFisikWrap yg diisi
  // fungsi ini, jadi WAJIB tetap jalan biar clone-nya gak "beku" walau operator lagi di tab Monitor
  // terus-terusan gak pernah buka Plane Simulation sama sekali.
  setInterval(()=>{
    if(typeof renderPlaneSim==="function") renderPlaneSim();
  }, 20000);
  function psStopAnim(){ clearInterval(psAnimTimer); psAnimTimer=null; }

  const PS_DETAIL_BASE_HEIGHT=4; // "tinggi 4" -- default tinggi kolom (skid biasa ~1m/skid pas di sini)

  /** Bikin 1 elemen kolom "tumpukan" (dipakai psOpenDetail, dipanggil 2x buat Baris 1 & Baris 2).
   * `num` = nomor urut GLOBAL tumpukan ini (lintas Baris 1 & 2, sesuai posisi kronologisnya di
   * stacksList — lihat psOpenDetail) — label di bawah kolom nomor doang (dikonfirmasi user: "yang
   * dibawah indikasi angka aja jangan nama supplier"), bukan nama supplier lagi (dulu sering kepotong
   * gak kebaca, mis. "cam..." buat tumpukan campuran / nama supplier panjang). Nama supplier ASLI
   * tetap ada, cuma pindah ke tooltip (hover kolom / hover kotak masing2 skid).
   *
   * Info VOLUME (dikonfirmasi user, "tambahkan juga informasi volume setiap skid dan volume untuk
   * setiap baris/1 tumpukan skid"): volume PER SKID beda-beda tiap kotak di tumpukan campuran (masing2
   * skid ikut avgSkidHeight grup pemiliknya, psAvgSkidHeight) — ditaruh di tooltip TIAP kotak (bx.title,
   * sekalian sama info supplier yg udah ada). Volume TOTAL 1 tumpukan (stack.height, udah termasuk
   * overhead pallet PS_SKID_OVERHEAD_M/skid — itu emang bagian ruang fisik yg beneran kepakai) ditaruh
   * sbg baris kedua di label bawah kolom (di bawah nomor), + tooltip kolom.
   *
   * Penanda INVALID (koreksi rule stacking 2026-08-27, `stack.valid`/`belowMinLayers` dari
   * psPackStacksForPlane) — DITAMPILKAN, bukan didiamkan (dikonfirmasi user: "jangan diam-diam
   * memaksa... tandai INVALID STACK"): border merah + "⚠" di tooltip kalau tinggi tumpukan nembus
   * batas absolut 3.3m (kasus data ekstrem, seharusnya jarang terjadi kalau psMaxPerStackForGroup
   * bekerja benar); `belowMinLayers` (<3 layer) TIDAK dianggap invalid (bisa jadi wajar cuma sisa
   * remainder di ujung data), cuma ikut nempel di tooltip sbg info tambahan. */
  function psRenderStackColumn(stack, maxHeight, num){
    const colWrap=document.createElement("div"); colWrap.className="ps-stack-col"+(stack.valid===false?" invalid":"");
    const uniqueNames=[...new Set(stack.items.map(it=>it.g.supplierName))];
    const totalVol=stack.height||0;
    const flags=[stack.valid===false?"⚠ INVALID (>3.3m)":null, stack.belowMinLayers?"< 3 layer":null].filter(Boolean);
    colWrap.title=`Tumpukan ${num} · ${totalVol.toFixed(2)}m³: ${uniqueNames.join(" + ")}`+(flags.length?` [${flags.join(", ")}]`:"");
    const boxes=document.createElement("div"); boxes.className="ps-stack-boxes";
    const cellOwner=[]; stack.items.forEach(it=>{ for(let i=0;i<it.count;i++) cellOwner.push(it.g); });
    for(let r=0;r<maxHeight;r++){
      const bx=document.createElement("div"); bx.className="ps-stack-cell";
      const g=cellOwner[r];
      if(g){
        const primaryRoute=[...g.routes][0];
        const skidVol=psAvgSkidHeight(g);
        bx.style.background=rcolor(primaryRoute);
        bx.style.cursor="pointer";
        bx.title=`${g.supplierName} · route ${g.route} · vol ${skidVol.toFixed(2)}m³ — klik utk lihat part`;
        bx.onclick=(e)=>{ e.stopPropagation(); psOpenParts(g); };
      } else {
        bx.style.background="var(--panel2)";
      }
      boxes.appendChild(bx);
    }
    const lbl=document.createElement("div"); lbl.className="ps-stack-label";
    lbl.textContent=num;
    const volLbl=document.createElement("div"); volLbl.className="ps-stack-vol";
    volLbl.textContent=totalVol.toFixed(1)+"m³";
    colWrap.append(boxes,lbl,volLbl);
    return colWrap;
  }

  /** Buka modal drill-down: gaya CHART (kotak kecil bertumpuk, sama bahasa visual kayak overview) —
   * tumpukan dihitung lewat psPackStacksForPlane (BOLEH campur >1 supplier per tumpukan buat ngedeketin
   * jumlah tumpukan realita), tinggi maks 3.3m fisik/tumpukan. Sesuai struktur fisik asli (1 plane = 2
   * baris), daftar tumpukan (URUT kronologis) dibagi ke 2 baris eksplisit.
   *
   * PEMBAGIAN diselang-seling (stack ke-1→Baris1, ke-2→Baris2, ke-3→Baris1, ke-4→Baris2, dst) — BUKAN
   * dipotong 2 separuh berurutan (dulu: separuh pertama SEMUA masuk Baris1, separuh SISANYA masuk
   * Baris2). Dikonfirmasi user liat kondisi fisik asli: "baris 1 dan baris 2 memiliki kedudukan yang
   * sama, jadi yang didepan baris 1 dan baris 2 memiliki waktu yang sama karena memang bagian depan
   * yang diisi dulu" — dua baris itu SEJAJAR/paralel (keduanya keisi bareng dari depan), BUKAN baris 2
   * baru mulai keisi setelah baris 1 penuh semua — jadi posisi kolom ke-N di Baris1 & Baris2 harus
   * merepresentasikan momen yg berdekatan (bukan Baris2 seluruhnya "lebih telat" dari Baris1). Nomor
   * urut yg ditampilin (dari psRenderStackColumn) TETAP nomor kronologis ASLI (1,3,5,... di Baris1;
   * 2,4,6,... di Baris2), bukan dinomori ulang per-baris, biar urutan waktu aslinya tetap kebaca. */
  function psOpenDetail(planeId, slot, dateLabel){
    const groups=psComputeGroups(planeId);
    const stacksList=psPackStacksForPlane(groups);
    const baris1=[], baris2=[];
    stacksList.forEach((stack,i)=>{ (i%2===0?baris1:baris2).push({stack,num:i+1}); });
    // Tinggi frame kolom ngikutin tumpukan PALING PENUH yg beneran kejadian (bisa >4 kalau ada tumpukan
    // campuran isi item2 pendek yg msh muat <=4m fisik) — floor tetap 4 biar konsisten scr visual. Dihitung
    // SAMA (dari keseluruhan stacksList) buat kedua baris biar skala axis-nya konsisten kiri-kanan.
    const maxHeight=Math.max(PS_DETAIL_BASE_HEIGHT, ...stacksList.map(s=>s.items.reduce((a,it)=>a+it.count,0)));
    document.getElementById("psDetailTitle").textContent=`Plane ${slot}`+(dateLabel?` · ${psCompactDateLabel(dateLabel)}`:"");
    document.getElementById("psDetailSubtitle").textContent=
      `${groups.length} grup supplier/dock · ${groups.reduce((a,g)=>a+g.skidCount,0)} skid total · ${stacksList.length} tumpukan (tinggi fisik maks 3.3m/tumpukan)`;
    psRenderAxis("psDetailAxis1", maxHeight);
    psRenderAxis("psDetailAxis2", maxHeight);
    const grid1=document.getElementById("psDetailGrid1"); grid1.innerHTML="";
    baris1.forEach(({stack,num})=>grid1.appendChild(psRenderStackColumn(stack,maxHeight,num)));
    const grid2=document.getElementById("psDetailGrid2"); grid2.innerHTML="";
    baris2.forEach(({stack,num})=>grid2.appendChild(psRenderStackColumn(stack,maxHeight,num)));
    psRenderFullList(groups);
    document.getElementById("psDetailModal").style.display="flex";
  }

  /** Daftar lengkap SEMUA supplier (grup) + part-nya sekaligus, di bawah chart -- gak perlu klik satu2
   * kotak lagi cuma buat liat isinya. Tiap supplier jadi blok collapsible (defaultnya nutup) — urutan
   * ngikutin `groups` apa adanya (udah diurut kronologis by cd_departure_at di psComputeGroups kalau
   * datanya ada, fallback skid terbanyak kalau enggak). Jam unload ditampilin di meta kalau ada. */
  function psRenderFullList(groups){
    const box=document.getElementById("psDetailFullList");
    box.innerHTML=groups.map((g,i)=>{
      const rows=g.parts.map(({row:p,route})=>
        `<tr><td>${p[0]}</td><td>${p[1]}</td><td>${p[2]}</td><td>${p[3]}×${p[4]}</td><td>${route}</td></tr>`
      ).join("");
      const jam=g.earliestDeparture?` · unload ${g.earliestDeparture}`:"";
      return `<div class="ps-fl-group" data-i="${i}">
        <div class="ps-fl-head" onclick="this.parentElement.classList.toggle('open')">
          <span><span class="ps-fl-chevron">▶</span>${g.supplierName}</span>
          <span class="ps-fl-meta">${g.skidCount} skid · ${g.parts.length} part · route ${g.route}${jam}</span>
        </div>
        <div class="ps-fl-body">
          <table class="grid compact"><tr><th>Part No</th><th>Nama</th><th>Kanban</th><th>Qty×Lot</th><th>Route</th></tr>${rows}</table>
        </div>
      </div>`;
    }).join("");
  }

  /** Modal isi part 1 grup (dipanggil dari klik kotak stack di psOpenDetail). */
  function psOpenParts(g){
    document.getElementById("psPartsTitle").textContent=g.supplierName;
    document.getElementById("psPartsSubtitle").textContent=`${g.parts.length} baris part · ${g.skidCount} skid`;
    document.getElementById("psPartsRows").innerHTML=g.parts.map(({row:p,route})=>
      `<tr><td>${p[0]}</td><td>${p[1]}</td><td>${p[2]}</td><td>${p[3]}×${p[4]}</td><td>${route}</td></tr>`
    ).join("");
    document.getElementById("psPartsModal").style.display="flex";
  }

  document.getElementById("psDetailClose").onclick=()=>document.getElementById("psDetailModal").style.display="none";
  document.getElementById("psPartsClose").onclick=()=>document.getElementById("psPartsModal").style.display="none";
  document.getElementById("psDetailModal").addEventListener("click",e=>{ if(e.target.id==="psDetailModal") e.target.style.display="none"; });
  document.getElementById("psPartsModal").addEventListener("click",e=>{ if(e.target.id==="psPartsModal") e.target.style.display="none"; });

  /* ---- Sub-menu "Pengaturan Fisik Plane" (psSettingsModal) ---- */

  /** Render tabel preview (mirip referensi "VERSI FISIK 12 P-LANE SPIRAL"): isi berurutan 1..maxPlane
   * nyebar row demi row ke 12 kolom (A-L), balik ke 1 & LANJUT ngisi (bukan reset) begitu lewat
   * maxPlane & slotCount -- tampilin sampai ~3 siklus penuh (dibatasi 15 baris) biar keliatan jelas
   * polanya tanpa kepanjangan. Sel bernilai "1" (awal siklus baru) di-highlight. Dipanggil LIVE tiap
   * input berubah (preview, BELUM tentu tersimpan) maupun setelah beneran tersimpan. */
  /** Preview tabel "VERSI FISIK 12 P-LANE SPIRAL" — rentang nomor yg disebar SEKARANG selalu
   * PS_MIN_PLANE..maxPlane (BUKAN 1..maxPlane lagi, lihat komentar PS_MIN_PLANE) — PS_MIN_PLANE SELALU
   * live-auto (gak ada input-nya di modal ini, cuma dibaca apa adanya), jadi preview ini otomatis
   * ngikutin begitu data plane aktif berubah. */
  function psRenderSettingsPreview(maxPlane, slotCount){
    const box=document.getElementById("psSettingsPreview");
    const range=Math.max(1, maxPlane-PS_MIN_PLANE+1);
    const totalRows=Math.min(15, Math.ceil((range*3)/slotCount));
    const letters="ABCDEFGHIJKL".slice(0,slotCount);
    let html=`<table class="ps-settings-table"><caption>Plane ${PS_MIN_PLANE}–${maxPlane} · ${slotCount} slot fisik (preview ${totalRows} baris pertama)</caption>`;
    html+="<tr><th></th>"+letters.split("").map(l=>`<th>${l}</th>`).join("")+"</tr>";
    for(let r=0;r<totalRows;r++){
      html+=`<tr><td class="ps-urutan-lbl">Baris ${r+1}</td>`;
      for(let c=0;c<slotCount;c++){
        const k=r*slotCount+c;
        const val=(k%range)+PS_MIN_PLANE;
        const isStart=val===PS_MIN_PLANE;
        html+=`<td${isStart?' class="ps-cycle-start"':''}>${String(val).padStart(2,"0")}</td>`;
      }
      html+="</tr>";
    }
    html+="</table>";
    box.innerHTML=html;
  }

  /** Baca 2 input settings SEKARANG (belum tentu tersimpan) & render ulang preview -- dipanggil live
   * tiap salah satu input berubah, biar operator bisa lihat dulu hasilnya sebelum klik Simpan. */
  function psRefreshPreviewFromInputs(){
    const max=Math.max(12,Math.min(999,+document.getElementById("psMaxPlaneInput").value||PS_MAX_PLANE));
    const slots=Math.max(PS_SLOT_COUNT_MIN,Math.min(PS_SLOT_COUNT_MAX,+document.getElementById("psSlotCountInput").value||PS_BUFFER_SIZE));
    psRenderSettingsPreview(max, slots);
  }

  /** Mode MAX PLANE yg lagi dipilih di modal SEKARANG (radio, belum tentu tersimpan). */
  function psSelectedMaxPlaneMode(){
    return document.querySelector('input[name="psMaxPlaneMode"]:checked')?.value==="auto" ? "auto" : "manual";
  }

  /** Terapkan pilihan radio Otomatis/Manual ke tampilan input MAX PLANE -- mode Otomatis: input
   * dikunci (disabled) & diisi nilai hasil hitung psAutoMaxPlane() sekarang + info teks penjelas;
   * mode Manual: input dibuka lagi buat diisi bebas. Dipanggil tiap radio-nya diklik & sekali pas
   * modal dibuka (psOpenSettings). */
  function psUpdateMaxPlaneModeUI(){
    const mode=psSelectedMaxPlaneMode();
    const input=document.getElementById("psMaxPlaneInput");
    const info=document.getElementById("psMaxPlaneAutoInfo");
    if(mode==="auto"){
      input.disabled=true;
      input.value=psAutoMaxPlane();
      info.style.display="";
      info.textContent=`Otomatis dari nomor plane (Main Route Order Seq) tertinggi di data Progress Lane aktif sekarang: ${(PLANES&&PLANES.length)?PLANES.join(", "):"(belum ada data)"} — nomor terendah (${PS_MIN_PLANE}) SELALU ikut nyesuain data juga, gak bisa diatur manual.`;
    }else{
      input.disabled=false;
      info.style.display="none";
    }
    psRefreshPreviewFromInputs();
  }

  function psOpenSettings(){
    const mode=(META.plane_sim_max_plane_mode==="auto")?"auto":"manual";
    document.getElementById(mode==="auto"?"psMaxPlaneModeAuto":"psMaxPlaneModeManual").checked=true;
    document.getElementById("psMaxPlaneInput").value=PS_MAX_PLANE;
    document.getElementById("psSlotCountInput").value=PS_BUFFER_SIZE;
    document.getElementById("psOverviewRowsInput").value=psOverviewRows;
    document.getElementById("psRetainBatchesInput").value=+(META.plane_sim_retain_batches||5);
    document.getElementById("psSettingsMsg").textContent="";
    psUpdateMaxPlaneModeUI();
    document.getElementById("psSettingsModal").style.display="flex";
  }

  /** Habis MAX PLANE dan/atau jumlah slot/baris beneran berubah tersimpan (manual/upload) -- terapkan
   * ke simulasi yg lagi jalan: reset TOTAL state konveyor (generasi tiap slot + slot aktif + pola isi)
   * krn seluruh pola penomoran berubah, gak masuk akal nyambung dari state lama. overviewRows sendiri
   * gak ngaruh ke penomoran (cuma tinggi gauge render), tapi tetap ikut ke-reset bareng krn "Simpan"
   * di modal ini nyimpen ketiganya sekaligus dalam 1 klik -- gak masalah, reset di sini murni visual
   * (konveyor mulai lagi dari posisi wajar), bukan kehilangan data. */
  function psApplySettings(maxPlane, slotCount, overviewRows){
    PS_MAX_PLANE=maxPlane;
    if(slotCount) PS_BUFFER_SIZE=slotCount;
    if(overviewRows) psOverviewRows=overviewRows;
    PS_FILL_PATTERN=psFillPatternFor(PS_BUFFER_SIZE);
    psResetConveyor();
    if(typeof renderPlaneSim==="function") renderPlaneSim();
    psRenderSettingsPreview(PS_MAX_PLANE, PS_BUFFER_SIZE);
  }

  document.getElementById("psSettingsBtn").onclick=psOpenSettings;
  document.getElementById("psSettingsClose").onclick=()=>document.getElementById("psSettingsModal").style.display="none";
  document.getElementById("psSettingsModal").addEventListener("click",e=>{ if(e.target.id==="psSettingsModal") e.target.style.display="none"; });
  document.getElementById("psMaxPlaneModeAuto").onchange=psUpdateMaxPlaneModeUI;
  document.getElementById("psMaxPlaneModeManual").onchange=psUpdateMaxPlaneModeUI;
  document.getElementById("psMaxPlaneInput").oninput=psRefreshPreviewFromInputs;
  document.getElementById("psSlotCountInput").oninput=psRefreshPreviewFromInputs;

  document.getElementById("psMaxPlaneSave").onclick=async()=>{
    const mode=psSelectedMaxPlaneMode();
    const slots=+document.getElementById("psSlotCountInput").value;
    const rows=+document.getElementById("psOverviewRowsInput").value;
    const retainBatches=+document.getElementById("psRetainBatchesInput").value;
    const msg=document.getElementById("psSettingsMsg");
    if(!slots||slots<PS_SLOT_COUNT_MIN||slots>PS_SLOT_COUNT_MAX){ msg.textContent=`Jumlah slot fisik harus ${PS_SLOT_COUNT_MIN}-${PS_SLOT_COUNT_MAX}.`; return; }
    if(!rows||rows<PS_OVERVIEW_ROWS_MIN||rows>PS_OVERVIEW_ROWS_MAX){ msg.textContent=`Jumlah baris tumpukan harus ${PS_OVERVIEW_ROWS_MIN}-${PS_OVERVIEW_ROWS_MAX}.`; return; }
    if(!retainBatches||retainBatches<1||retainBatches>30){ msg.textContent=`Jumlah tanggal disimpan harus 1-30.`; return; }
    // Mode Otomatis: hitung ULANG dari PLANES sekarang (bukan pakai isi input, yg cuma snapshot pas
    // modal dibuka/terakhir di-render) -- biar klik Simpan selalu masukin angka paling anyar.
    let val;
    if(mode==="auto"){ val=psAutoMaxPlane(); }
    else{
      val=+document.getElementById("psMaxPlaneInput").value;
      // Batas bawah RELATIF ke PS_MIN_PLANE (bukan angka tetap 12 lagi) -- rentang MIN_PLANE..val WAJIB
      // muat minimal 12 nomor (PS_SLOT_COUNT_MAX), sesuai pola tabel referensi "VERSI FISIK 12 P-LANE
      // SPIRAL" (psPlaneRangeSize/psRenderSettingsPreview) -- kalibrasi ini murni dokumentasi/preview
      // sekarang, slot cycling asli sendiri udah gak terikat batas ini lagi (lihat psSeqIndexAtSlot).
      const minAllowed=PS_MIN_PLANE+11;
      if(!val||val<minAllowed||val>999){ msg.textContent=`MAX PLANE harus ${minAllowed}-999 (rentang ${PS_MIN_PLANE}..MAX WAJIB muat minimal 12 nomor).`; return; }
    }
    try{
      await apiPost("plane_sim_save_settings",{max_plane:val,slot_count:slots,max_plane_mode:mode,overview_rows:rows,retain_batches:retainBatches});
      META.plane_sim_max_plane=String(val); META.plane_sim_slot_count=String(slots);
      META.plane_sim_max_plane_mode=mode; META.plane_sim_overview_rows=String(rows);
      META.plane_sim_retain_batches=String(retainBatches);
      PS_MAX_PLANE_MODE=mode;
      psApplySettings(val, slots, rows);
      msg.textContent="Tersimpan.";
      toast(mode==="auto" ? `MAX PLANE=${val} (otomatis dari MROS), ${slots} slot fisik, ${rows} baris tumpukan, simpan ${retainBatches} tanggal terakhir` : `MAX PLANE=${val}, ${slots} slot fisik, ${rows} baris tumpukan, simpan ${retainBatches} tanggal terakhir`);
    }catch(e){ msg.textContent="Gagal simpan: "+e.message; }
  };

  document.getElementById("psConfigUploadInput").onchange=async(e)=>{
    const file=e.target.files[0]; if(!file) return;
    const msg=document.getElementById("psSettingsMsg");
    msg.textContent="Mengupload...";
    const fd=new FormData(); fd.append("file",file);
    try{
      const res=await apiPost("plane_sim_upload_config",fd,true);
      // Upload file referensi = angka tetap dari dokumen -- paksa balik ke mode Manual (server juga
      // udah nyimpen 'manual' di smms_meta, lihat api_plane_sim_upload_config di plane-sim/api.php)
      // biar gak ke-timpa diam2 sama psSyncAutoMaxPlane() abis ini.
      document.getElementById("psMaxPlaneModeManual").checked=true;
      PS_MAX_PLANE_MODE="manual"; META.plane_sim_max_plane_mode="manual";
      psUpdateMaxPlaneModeUI();
      document.getElementById("psMaxPlaneInput").value=res.max_plane;
      META.plane_sim_max_plane=String(res.max_plane);
      psApplySettings(res.max_plane); // slot count gak ikut disentuh dari upload (cuma deteksi MAX PLANE)
      msg.textContent=`Terdeteksi MAX PLANE=${res.max_plane} dari ${res.detected_from}, tersimpan.`;
      toast(`MAX PLANE disetel ke ${res.max_plane} (dari file)`);
    }catch(err){ msg.textContent="Gagal upload: "+err.message; }
    e.target.value="";
  };

  /* ---- "Atur Waktu Simulasi" (psSimTimeModal) — lihat komentar PS_SIM_TIME_OFFSET/psSimNow() di atas ---- */

  /** Format Date lokal jadi string buat <input type="datetime-local"> ("YYYY-MM-DDTHH:mm:ss"). */
  function psDateToLocalInputValue(d){
    const pad=n=>String(n).padStart(2,"0");
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }
  /** Format ms epoch jadi teks tampilan "DD Mon YYYY HH:MM:SS" (dipakai #psSimTimeNow header & modal). */
  function psFormatSimTime(ms){
    const d=new Date(ms);
    const bulan=["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];
    const pad=n=>String(n).padStart(2,"0");
    return `${pad(d.getDate())} ${bulan[d.getMonth()]} ${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }
  // Live ticker waktu simulasi -- update tiap detik SELAMA tab Plane Simulation kebuka (header +
  // modal kalau lagi kebuka), biar operator selalu tau lagi "sekarang" versi simulasi di titik mana
  // (beda dari jam asli di pojok kanan atas header utama app, yg TETAP nunjukin waktu komputer beneran).
  setInterval(()=>{
    if(!document.body.classList.contains("planesim")) return;
    const txt=psFormatSimTime(psSimNow());
    const headEl=document.getElementById("psSimTimeNow");
    if(headEl) headEl.textContent="🕐 "+txt;
    const modalEl=document.getElementById("psSimTimeCurrent");
    if(modalEl && document.getElementById("psSimTimeModal").style.display!=="none") modalEl.textContent=txt;
  }, 1000);

  /** Mode Waktu yg lagi dipilih di modal SEKARANG (radio, belum tentu tersimpan). */
  function psSelectedTimeMode(){
    return document.querySelector('input[name="psTimeMode"]:checked')?.value==="simulasi" ? "simulasi" : "aktual";
  }
  /** Sembunyikan blok "Set waktu simulasi jadi" (offset manual) pas mode Simulasi dipilih -- gak
   * relevan di mode itu, waktu simulasi murni direntang otomatis dari countdown (lihat psSimNow). */
  function psUpdateTimeModeUI(){
    document.getElementById("psSimTimeManualWrap").style.display = psSelectedTimeMode()==="simulasi" ? "none" : "";
  }
  document.getElementById("psTimeModeAktual").onchange=psUpdateTimeModeUI;
  document.getElementById("psTimeModeSimulasi").onchange=psUpdateTimeModeUI;

  function psOpenSimTimeSettings(){
    document.getElementById(PS_TIME_MODE==="simulasi"?"psTimeModeSimulasi":"psTimeModeAktual").checked=true;
    psUpdateTimeModeUI();
    document.getElementById("psSimTimeInput").value=psDateToLocalInputValue(new Date(psSimNow()));
    document.getElementById("psSimTimeMsg").textContent="";
    document.getElementById("psSimTimeCurrent").textContent=psFormatSimTime(psSimNow());
    document.getElementById("psSimTimeModal").style.display="flex";
  }
  document.getElementById("psSimTimeBtn").onclick=psOpenSimTimeSettings;
  document.getElementById("psSimTimeCancel").onclick=()=>document.getElementById("psSimTimeModal").style.display="none";
  document.getElementById("psSimTimeModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });

  document.getElementById("psSimTimeResetReal").onclick=()=>{
    document.getElementById("psSimTimeInput").value=psDateToLocalInputValue(new Date());
  };

  /** Isi dari cd_arrival_at PALING AWAL di SELURUH data yg lagi dimuat (psGetGlobalTimeRange(), lintas
   * plane DAN lintas tanggal kalau rentang multi-hari lagi aktif di Plane Simulation — BEDA dari
   * psSimNow() yg sekarang per-tanggal, ini SENGAJA tetap global krn cuma convenience "titik paling
   * awal dari SEMUA data" biar operator gak perlu cari manual) — dihitung ULANG di sini (bukan pakai
   * cache PS_TIME_RANGES lagi, itu udah per-tanggal) tinggal klik & langsung keisi. */
  document.getElementById("psSimTimeFromData").onclick=()=>{
    const msg=document.getElementById("psSimTimeMsg");
    const range=psGetGlobalTimeRange();
    if(!range){ msg.textContent="Belum ada data arrival yang termuat — buka tab Plane Simulation dulu biar datanya ke-fetch."; return; }
    document.getElementById("psSimTimeInput").value=psDateToLocalInputValue(new Date(range.minTs));
    msg.textContent=`Diisi dari arrival tertua di data yang lagi termuat: ${psFormatSimTime(range.minTs)}`;
  };

  document.getElementById("psSimTimeSave").onclick=async()=>{
    const mode=psSelectedTimeMode();
    const msg=document.getElementById("psSimTimeMsg");
    // max_plane WAJIB disertakan validasi backend (api_plane_sim_save_settings) — kirim nilai SEKARANG
    // apa adanya (gak diubah), efeknya no-op buat field itu.
    const payload={max_plane:PS_MAX_PLANE, time_mode:mode};
    if(mode==="aktual"){
      // Offset manual CUMA relevan (& CUMA divalidasi/dikirim) di mode Aktual -- mode Simulasi
      // ngabaiin offset ini sama sekali (psSimNow), jadi gak perlu isi/validasi input tanggalnya.
      const val=document.getElementById("psSimTimeInput").value;
      if(!val){ msg.textContent="Isi waktu dulu."; return; }
      const chosen=new Date(val); // datetime-local -> Date lokal
      if(isNaN(chosen.getTime())){ msg.textContent="Format waktu gak valid."; return; }
      payload.sim_time_offset=chosen.getTime()-Date.now();
    }
    try{
      await apiPost("plane_sim_save_settings",payload);
      PS_TIME_MODE=mode; META.plane_sim_time_mode=mode;
      if(payload.sim_time_offset!==undefined){
        PS_SIM_TIME_OFFSET=payload.sim_time_offset;
        META.plane_sim_time_offset=String(payload.sim_time_offset);
      }
      document.getElementById("psSimTimeModal").style.display="none";
      toast(mode==="simulasi" ? "Mode Waktu: Simulasi (mengikuti countdown Plane aktif)" : "Waktu simulasi diterapkan: "+psFormatSimTime(psSimNow()));
      renderPlaneSim();
    }catch(e){ msg.textContent="Gagal simpan: "+e.message; }
  };

  /* =====================================================================
     PLAYBACK SPEED & DEBUG MODE (2026-08-27, alat bantu "Plane Yellow Filling") — keduanya SENGAJA
     TIDAK dipersist ke smms_meta (mengikuti preseden toggle `auto` di 08-header.js yang juga cuma
     variabel in-memory), murni alat bantu playback/verifikasi sesi ini, reset ke default tiap reload.
     ===================================================================== */

  // Playback speed murni mengalikan LAJU heartbeat AUTO (satu-satunya titik dipakai: durMs di
  // 08-header.js dibagi angka ini) — TIDAK menyentuh business state apa pun (requirement eksplisit:
  // "playback tidak boleh memengaruhi hasil calculation"), jadi hasil akhir skenario identik berapa
  // pun speed-nya, cuma lebih cepat/lambat.
  let psPlaybackSpeed=1;
  document.getElementById("psPlaybackSpeedSel").onchange=function(){ psPlaybackSpeed=+this.value||1; };

  // Debug Mode -- checkbox, default OFF. Saat ON, panel kecil di bawah toolbar menampilkan physical
  // position/generation/lifecycle + skid queue + animasi utk kartu AKTIF sekarang + "Jump CD" (test aid:
  // set `cd` langsung, murni test aid -- lifecycle/physical sequence dihitung ULANG dari psRelOf/
  // psCurrentActiveSlot yg SUDAH pure function terhadap cd, TANPA replay).
  let psDebugOn=false;
  document.getElementById("psDebugToggle").onchange=function(){
    psDebugOn=this.checked;
    document.getElementById("psDebugPanel").style.display=psDebugOn?"":"none";
    psRenderDebugPanel();
  };
  /** RESET ARSITEKTUR 2026-08-27 — konten panel diganti total mengikuti "DEBUG YANG WAJIB": Plane
   * Number/Physical Slot/Generation/Lifecycle (dipertahankan, masih relevan) + Skid Queue (dari
   * buildPlaneSkidSequence, urutan arrival) + Animation (posisi reveal SEKARANG/target) + Active/Ready
   * boolean + CD (murni informasi countdown, TIDAK LAGI dipakai hitung fill apa pun). Arrived/Departed/
   * Current/Target-Yellow/Next-Arrival (basis calculatePlaneState lama) DIHAPUS -- konsep itu sendiri
   * sudah dibatalkan total, gak ada lagi yg perlu ditampilkan dari situ. */
  function psRenderDebugPanel(){
    const panel=document.getElementById("psDebugPanel");
    if(!psDebugOn || !panel) return;
    const card=document.querySelector("#psFisikWrap .ps-plane-card.active");
    const cols=card && card.querySelector(".ps-plane-cols");
    if(!cols){ panel.innerHTML=`<span class="meta">Belum ada kartu aktif utk ditampilkan.</span>`; return; }
    const pid=cols.dataset.plane;
    const numTxt=card.querySelector(".ps-plane-btn")?.textContent||pid;
    // Physical Position/Generation/Lifecycle -- cols.dataset.slot cuma ada di mode 'fisik' (mode 'full'
    // pakai dataset.num, gak py physical position/generation krn Full Plane sengaja gak mengelompokkan
    // slot -- lihat komentar psRenderFull).
    const physInfo = cols.dataset.slot ? psPhysicalInfoForSlot(+cols.dataset.slot) : null;
    const lifecycle = cols.dataset.slot ? psLifecycleForSlot(+cols.dataset.slot) : "active";
    const physTxt = physInfo ? `Pos ${physInfo.physicalPosition} · Gen ${physInfo.generation} · ${lifecycle.toUpperCase()}` : lifecycle.toUpperCase();
    const seq=buildPlaneSkidSequence(pid);
    const seqTxt = seq.length ? seq.slice(0,5).map(s=>s.id).join(" → ")+(seq.length>5?` … (+${seq.length-5})`:"") : "(kosong)";
    const target=psTargetFor(pid);
    panel.innerHTML=
      `<b>Plane ${numTxt}</b>`+
      ` &nbsp; ${physTxt}`+
      ` &nbsp; Active: <b>${lifecycle==="active"}</b>`+
      ` &nbsp; Ready: <b>${lifecycle==="ready"}</b>`+
      ` &nbsp; CD: <b>${cd}</b>/${cdStart}`+
      ` &nbsp; Animation: <b>${psFillProgress[pid]??0}</b>/${target}`+
      ` &nbsp; Skid Queue: <b>${seqTxt}</b>`+
      ` &nbsp; <label style="margin-left:8px">Jump CD=<input id="psDebugJumpCd" type="number" value="${cd}" style="width:60px;padding:2px 4px"></label>`+
      ` <button id="psDebugJumpBtn" type="button" class="tmode" style="padding:2px 8px">Set</button>`;
    const btn=document.getElementById("psDebugJumpBtn");
    if(btn) btn.onclick=()=>{
      const v=+document.getElementById("psDebugJumpCd").value;
      if(Number.isFinite(v)){ cd=Math.max(CD_END,Math.min(cdStart,v)); refreshHeader(); }
    };
  }
  