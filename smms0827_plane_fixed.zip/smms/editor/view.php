<?php
/* =====================================================================
   EDITOR/VIEW.PHP — markup toolbar tab Editor (mode geser/rack/jalur/shape/
   hapus, panel properti shape, tag halte/stage, ganti denah/towing). Di-include
   dari index.php. SEMUA berkas fitur Editor disatukan di 1 folder editor/:
   view.php (ini), editor.js, api.php — biar gampang dirawat dari 1 tempat
   (pola sama persis dgn plane-sim/, lihat komentar header plane-sim.js).

   CATATAN: beberapa tombol di markup ini DIWIRE dari file LAIN (bukan
   editor.js) krn fungsinya nyambung ke fitur di luar Editor murni — align/
   ratakan rack (edRkAlignXBtn dkk) dari assets/js/10-database.js (dipakai
   bareng tabel Posisi Rack di tab Database), ganti gambar denah/towing
   (btnChLayout/btnChTowing) dari assets/js/14-asset-upload.js. Ini WAJAR
   (lookup by id, gak peduli file markup-nya ada di mana) — TIDAK dipindah
   ke sini krn scope-nya emang lintas-tab, bukan Editor doang.
   ===================================================================== */
?>
<div id="toolbar">
  <button class="tmode on" data-m="pan" title="Klik rack/titik buat pilih (Shift+klik nambah); Shift+drag di area kosong buat pilih banyak sekaligus (blok)">Geser</button>
  <button class="tmode" data-m="rack">+ Rack</button>
  <button class="tmode" data-m="path">+ Jalur</button>
  <button class="tmode" data-m="shape" title="Tambah shape kotak (background peta bersih gaya PPT/Google Maps, ditelusuri manual di atas denah asli)">+ Shape</button>
  <button class="tmode" data-m="planebuffer" title="Tempatkan area Plane Buffer di denah — nampilin isi buffer plane aktif beneran (skid), bisa digeser/resize/rotate sama kayak shape biasa. Cuma boleh 1, klik ulang buat pilih yg sudah ada.">+ Plane Buffer</button>
  <button class="tmode" data-m="sortingplane" title="Tempatkan shape Sorting Plane — pilih dulu baris yang sudah dikonfigurasi di Setting > Sorting Plane, lalu klik denah.">+ Sorting Plane</button>
  <button class="tmode" data-m="dollysupply" title="Tempatkan shape Dolly Supply — pilih dulu baris yang sudah dikonfigurasi di Setting > Dolly Supply, lalu klik denah.">+ Dolly Supply</button>
  <button class="tmode" data-m="del">Hapus</button>
  <span id="shapePanel" style="display:none">│
    Isi: <input type="color" id="shFill" title="Warna isi shape">
    Garis: <input type="color" id="shStroke" title="Warna garis tepi shape">
    Teks: <input type="text" id="shText" maxlength="30" size="12" placeholder="label (opsional)">
    <button id="shRot0" class="tmode" type="button" title="Lurusin ke 0°">0°</button>
    <button id="shRot90" class="tmode" type="button" title="Lurusin ke 90°">90°</button>
    <button id="shRot180" class="tmode" type="button" title="Lurusin ke 180°">180°</button>
    <button id="shRot270" class="tmode" type="button" title="Lurusin ke 270°">270°</button>
  </span>
  <span>│ Denah asli: <input type="range" id="layoutOpacity" min="0" max="100" value="100" style="vertical-align:middle" title="Opacity gambar denah asli — geser ke 0 buat pratinjau peta bersih (shape doang), TIDAK tersimpan permanen"></span>
  <span>│ <button id="edRkAlignXBtn" class="tmode" type="button" disabled title="Pilih rack (Shift+klik / Shift+drag buat blok), lalu Align X — samain X-nya jadi 1 garis vertikal">↕ Align X</button>
  <button id="edRkAlignYBtn" class="tmode" type="button" disabled title="Pilih rack (Shift+klik / Shift+drag buat blok), lalu Align Y — samain Y-nya jadi 1 garis horizontal">↔ Align Y</button>
  <button id="edRkDistXBtn" class="tmode" type="button" disabled title="Min. 3 rack — sebar rata jarak X-nya, Y gak disentuh">⋯ Ratakan X</button>
  <button id="edRkDistYBtn" class="tmode" type="button" disabled title="Min. 3 rack — sebar rata jarak Y-nya, X gak disentuh">⋯ Ratakan Y</button></span>
  <span>│ Rack: <input list="addrlist" id="addrInput" placeholder="pilih / ketik address" size="16"><datalist id="addrlist"></datalist></span>
  <span>│ Sorting: <select id="edSortingPlaneSel"></select></span>
  <span>│ Dolly: <select id="edDollySupplySel"></select></span>
  <span>│ Route: <select id="editRouteSel"></select></span>
  <span>Titik terakhir jadi:</span>
  <button class="hbtn" onclick="tagHalte(1)">HALTE 1</button>
  <button class="hbtn b2" onclick="tagHalte(2)">HALTE 2</button>
  <button class="hbtn b3" onclick="tagHalte(3)">HALTE 3</button>
  <span>│</span>
  <button class="hbtn st-sorting" onclick="tagStage('SORTING')">SORTING</button>
  <button class="hbtn st-transfer" onclick="tagStage('TRANSFER')">TRANSFER</button>
  <button class="hbtn st-empty" onclick="tagStage('EMPTY')">EMPTY</button>
  <button class="hbtn st-prepare" onclick="tagStage('PREPARE')">PREPARE</button>
  <span>│
    <button class="imgbtn" id="btnChLayout" type="button">🖼 Ganti Denah</button><input type="file" id="fileLayout" accept="image/*" style="display:none">
    <button class="imgbtn" id="btnChTowing" type="button">🚚 Ganti Towing</button><input type="file" id="fileTowing" accept="image/*" style="display:none">
  </span>
  <span class="warn">Klik denah untuk menambah titik di ujung · klik pas di garis jalur untuk menyisipkan titik di tengah · seret untuk memindah · tersimpan otomatis</span>
  <span class="warn" style="color:#B45309">· Lingkaran putus-putus oranye = titik halte route ini dari diagram PICS (posisi akurat, urutan belum pasti — klik sesuai urutan aslinya)</span>
</div>
