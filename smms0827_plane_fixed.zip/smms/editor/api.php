<?php
/* =====================================================================
   EDITOR/API.PHP — simpan konfigurasi layout tab Editor: rack, jalur, & shape
   kotak vector (background peta bersih). SEMUA berkas fitur Editor disatukan
   di 1 folder editor/: api.php (ini), editor.js, view.php — biar gampang
   dirawat dari 1 tempat (pola sama persis dgn plane-sim/, lihat komentar
   header plane-sim.js). BUKAN endpoint ter-routing lewat file lokal sendiri
   — didaftarkan di $ROUTES root api.php (action=save_config => '../editor/api.php'),
   sama persis pola plane_sim_* di plane-sim/api.php.

   action=save_master (edit manual grid Countdown->Halte & Halte Master dari
   tab DATABASE, bukan tab Editor) TETAP di api/config_save.php — scope-nya
   beda tab, sengaja TIDAK dipindah ke sini.
   ===================================================================== */

/** action=save_config (POST) — replace penuh smms_racks, smms_route_path, & smms_shapes dari
 * payload Editor (CFG.racks/CFG.paths/CFG.shapes, dikirim BARENG oleh saveCfg(), 02-api.js — WAJIB
 * ketiganya selalu ikut, kalau salah satu field kelewat di payload bakal ke-TRUNCATE jadi kosong). */
function api_save_config($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    if(!is_array($in)) fail('payload?');
    $db->begin_transaction();
    $db->query("TRUNCATE smms_racks");
    $st=$db->prepare("INSERT INTO smms_racks (addr,x,y) VALUES (?,?,?)");
    foreach(($in['racks']??[]) as $r){ $st->bind_param('sdd',$r['addr'],$r['x'],$r['y']); $st->execute(); }
    $db->query("TRUNCATE smms_route_path");
    $st=$db->prepare("INSERT INTO smms_route_path (route,seq,x,y,h,stage) VALUES (?,?,?,?,?,?)");
    foreach(($in['paths']??[]) as $route=>$pts){
        foreach($pts as $i=>$p){
            $h=(int)($p['h']??0);
            $stage=trim((string)($p['stage']??'')); $stage=$stage===''?null:$stage;
            $st->bind_param('siddis',$route,$i,$p['x'],$p['y'],$h,$stage);
            $st->execute();
        }
    }
    // Shape kotak vector (background "peta bersih" digambar manual di Editor, lihat smms_shapes,
    // install.php) — TRUNCATE+reinsert penuh, pola SAMA PERSIS dgn racks/paths di atas, 1 transaksi
    // yang sama (saveCfg() di frontend ngirim ketiganya sekaligus tiap kali ada perubahan apa pun).
    $db->query("TRUNCATE smms_shapes");
    $st=$db->prepare("INSERT INTO smms_shapes (x,y,w,h,rot,fill,stroke,text,kind,
        sorting_plane_id,sorting_plane_num,route,plane_capacity,
        dolly_supply_id,dolly_supply_num,dolly_route)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    foreach(($in['shapes']??[]) as $s){
        $rot=(float)($s['rot']??0);
        $fill=trim((string)($s['fill']??'#E2E8F0')); $stroke=trim((string)($s['stroke']??'#475569'));
        $text=mb_substr(trim((string)($s['text']??'')),0,60);
        // kind='' (shape polos), 'planebuffer' (isi Plane Buffer beneran di denah Monitor),
        // 'sortingplane' (physical area Sorting per Route), atau 'dollysupply' (physical area Dolly
        // Supply per Route) -- lihat komentar smms_shapes.kind/sorting_plane_*/dolly_supply_*, install.php.
        $kind=trim((string)($s['kind']??''));
        $spId=isset($s['sortingPlaneId']) && $s['sortingPlaneId']!==null ? (int)$s['sortingPlaneId'] : null;
        $spNum=isset($s['sortingPlaneNum']) && $s['sortingPlaneNum']!==null ? (int)$s['sortingPlaneNum'] : null;
        $spRoute=trim((string)($s['route']??''));
        $spCap=(int)($s['planeCapacity']??0);
        $dsId=isset($s['dollySupplyId']) && $s['dollySupplyId']!==null ? (int)$s['dollySupplyId'] : null;
        $dsNum=isset($s['dollySupplyNum']) && $s['dollySupplyNum']!==null ? (int)$s['dollySupplyNum'] : null;
        $dsRoute=trim((string)($s['dollyRoute']??''));
        $st->bind_param('dddddssssiisiiis',
            $s['x'],$s['y'],$s['w'],$s['h'],$rot,$fill,$stroke,$text,$kind,
            $spId,$spNum,$spRoute,$spCap,$dsId,$dsNum,$dsRoute);
        $st->execute();
    }
    $db->commit();
    out(['ok'=>true]);
}

if ($act === 'save_config' && $_SERVER['REQUEST_METHOD']==='POST') api_save_config($db);
