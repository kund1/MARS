/* =====================================================================
   18-SORTING-PLANE — menu "Setting" > Sorting Plane: physical area tempat skid hasil bongkar Plane
   menunggu proses SORTING, diidentifikasi lewat ROUTE (bukan nomor plane), kapasitas 1 atau 2 PLANE
   (kapasitas Plane, BUKAN kapasitas skid/baris/kolom). Entity TERPISAH TOTAL dari "Physical Plane"
   (smms_plane_manual, plane-sim/plane-sim.js) & "Sorting Store" (belum dibuat) — dikonfirmasi user
   eksplisit, JANGAN dicampur. Config-only fase ini: CRUD doang, BELUM ada movement/distribusi skid
   per-route (itu fase integrasi data berikutnya, lihat memori project).

   Pola CRUD PERSIS "Data Plane Manual" (plane-sim/plane-sim.js: psManualAllRows/psManualRenderTable/
   psManualOpenForm dkk, plane-sim/api.php: api_plane_sim_manual_*) — tabel sederhana (bukan pager
   Master Offset, jumlah baris kecil) + popup form Add/Edit + tombol Edit/Delete inline.
   ===================================================================== */

let SP_ALL_ROWS=[], SP_MASTER_ROUTES=[], spEditId=null;

/** Dipanggil pas nav "Setting" diklik pertama kali (09-nav.js) -- muat dropdown Route (dari Master
 * Part, BUKAN hardcode ALLR spt dropdown route lain di app ini) + tabel Sorting Plane, lalu render. */
async function initSortingPlane(){
  const [routesRes, rowsRes] = await Promise.all([
    apiGet('action=master_part_routes').catch(()=>({routes:[]})),
    apiGet('action=sorting_plane_list').catch(()=>({rows:[]}))
  ]);
  SP_MASTER_ROUTES = routesRes.routes || [];
  SP_ALL_ROWS = (rowsRes.rows||[]).map(r=>({id:+r.id, sorting_plane_num:+r.sorting_plane_num, route:r.route, plane_capacity:+r.plane_capacity}));
  spRenderTable();
}

/** Kartu preview KECIL per baris — cuma identitas (Route) + slot placeholder KOSONG sejumlah
 * Plane Capacity ("PLANE 1"/"PLANE 2" kalau capacity=2, 1 slot tanpa label kalau capacity=1) —
 * SENGAJA TANPA grid skid asli: belum ada 1 pun data skid-per-route yang bisa digambar jujur di
 * fase config-only ini (lihat memori project "sorting-plane-future-visual" utk visi fase berikutnya). */
function spPreviewHtml(row){
  const slots=[];
  for(let i=1;i<=row.plane_capacity;i++){
    const lbl = row.plane_capacity>1 ? `<div class="sp-slot-lbl">PLANE ${i}</div>` : "";
    slots.push(`<div class="sp-slot">${lbl}</div>`);
  }
  return `<div class="sp-preview"><div class="sp-preview-route">ROUTE ${puEsc(row.route)}</div><div class="sp-preview-slots">${slots.join("")}</div></div>`;
}

function spRenderTable(){
  const box=document.getElementById("spTableBox");
  if(!box) return;
  const thead=`<tr><th>Sorting Plane</th><th>Route</th><th>Plane Capacity</th><th>Preview</th><th style="width:110px"></th></tr>`;
  box.innerHTML=`<div style="overflow-x:auto"><table class="grid compact">${thead}`+
    (SP_ALL_ROWS.length ? SP_ALL_ROWS.map(r=>
      `<tr><td>${r.sorting_plane_num}</td><td>${puEsc(r.route)}</td><td>${r.plane_capacity} Plane</td>`+
      `<td>${spPreviewHtml(r)}</td><td>`+
      `<button class="tmode spEditBtn" data-id="${r.id}" style="padding:3px 8px;font-size:11px">✎</button> `+
      `<button class="tmode mp-danger spDelBtn" data-id="${r.id}" style="padding:3px 8px;font-size:11px">🗑</button>`+
      `</td></tr>`
    ).join("") : '<tr><td colspan="5" style="text-align:center;color:var(--mut)">Belum ada data — klik + Add Sorting Plane</td></tr>')
    +`</table></div>`;
  box.querySelectorAll(".spEditBtn").forEach(b=>b.onclick=()=>spOpenForm("edit", SP_ALL_ROWS.find(r=>r.id===+b.dataset.id)));
  box.querySelectorAll(".spDelBtn").forEach(b=>b.onclick=()=>spDeleteRow(+b.dataset.id));
}

function spOpenForm(mode, row){
  spEditId = mode==="edit" ? row.id : null;
  document.getElementById("spFormTitle").textContent = mode==="add" ? "Tambah Sorting Plane" : "Edit Sorting Plane";
  document.getElementById("spFormMsg").textContent="";
  document.getElementById("spfNum").value = mode==="edit" ? row.sorting_plane_num : "";
  // Isi dropdown Route tiap buka form -- jaga2 Master Part berubah SEJAK initSortingPlane() terakhir
  // jalan (dikonfirmasi user: dropdown harus ikut data Master Part TERKINI, bukan snapshot lama).
  const sel=document.getElementById("spfRoute");
  sel.innerHTML = SP_MASTER_ROUTES.map(r=>`<option value="${puEsc(r)}">${puEsc(r)}</option>`).join("");
  sel.value = mode==="edit" ? row.route : (SP_MASTER_ROUTES[0]||"");
  const capacity = mode==="edit" ? row.plane_capacity : 1;
  document.querySelector(`input[name="spfCapacity"][value="${capacity}"]`).checked=true;
  document.getElementById("spFormModal").style.display="flex";
}
document.getElementById("spAddBtn").onclick=()=>spOpenForm("add");
document.getElementById("spFormCancel").onclick=()=>document.getElementById("spFormModal").style.display="none";
document.getElementById("spFormModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });

document.getElementById("spFormSave").onclick=async()=>{
  const msg=document.getElementById("spFormMsg");
  const num=+document.getElementById("spfNum").value;
  const route=document.getElementById("spfRoute").value;
  const capacity=+(document.querySelector('input[name="spfCapacity"]:checked')?.value||0);
  if(!num||num<1){ msg.textContent="Sorting Plane Number wajib diisi (angka > 0)."; return; }
  if(!route){ msg.textContent="Route wajib dipilih."; return; }
  if(capacity!==1 && capacity!==2){ msg.textContent="Plane Capacity wajib 1 atau 2."; return; }
  // Cek duplikat sorting_plane_num di client jg (pola sama psManualFormSave, plane-sim.js) --
  // pesan error jelas TANPA nunggu round-trip server dulu, backend tetap validasi ulang.
  if(SP_ALL_ROWS.some(r=>r.sorting_plane_num===num && r.id!==spEditId)){
    msg.textContent=`Sorting Plane ${num} sudah ada — edit baris itu langsung, bukan tambah baru.`;
    return;
  }
  try{
    await apiPost("sorting_plane_upsert_row",{id:spEditId, sorting_plane_num:num, route, plane_capacity:capacity});
    document.getElementById("spFormModal").style.display="none";
    toast(`Sorting Plane ${num} tersimpan`);
    await initSortingPlane();
  }catch(e){ msg.textContent="Gagal simpan: "+e.message; }
};

async function spDeleteRow(id){
  const row=SP_ALL_ROWS.find(r=>r.id===id);
  try{
    await apiPost("sorting_plane_delete_row",{id});
    toast(`Sorting Plane ${row?row.sorting_plane_num:id} dihapus`);
    await initSortingPlane();
  }catch(e){ toast("Gagal hapus: "+e.message); }
}
