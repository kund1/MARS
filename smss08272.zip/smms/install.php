<?php
// ================= INSTALLER SMMS =================
// Jalankan sekali: http://localhost/smms/install.php
require __DIR__.'/config.php';
set_time_limit(300);
$db = db();
header('Content-Type: text/plain; charset=utf-8');

$db->query("CREATE TABLE IF NOT EXISTS smms_progress_lane (
  id INT AUTO_INCREMENT PRIMARY KEY,
  batch_id INT NOT NULL DEFAULT 0,
  plane CHAR(2) NOT NULL, route CHAR(1) NOT NULL,
  part_no VARCHAR(30), part_name VARCHAR(60), kanban VARCHAR(12),
  qty INT DEFAULT 0, lot INT DEFAULT 0,
  addr VARCHAR(24), supplier VARCHAR(60), uniq_no VARCHAR(24), order_no VARCHAR(14),
  supplier_code VARCHAR(20) NOT NULL DEFAULT '', supplier_plant VARCHAR(10) NOT NULL DEFAULT '',
  supplier_dock VARCHAR(20) NOT NULL DEFAULT '', plant_no VARCHAR(10) NOT NULL DEFAULT '',
  build_out_flag VARCHAR(10) NOT NULL DEFAULT '', route_order_seq VARCHAR(10) NOT NULL DEFAULT '',
  INDEX idx_pr (plane, route), INDEX idx_addr (addr), INDEX idx_batch (batch_id),
  INDEX idx_supplier_composite (supplier_code, supplier_plant, supplier_dock, route)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_progress_lane OK\n";

$db->query("CREATE TABLE IF NOT EXISTS smms_racks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  addr VARCHAR(24) NOT NULL, x DOUBLE NOT NULL, y DOUBLE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_racks OK\n";

$db->query("CREATE TABLE IF NOT EXISTS smms_route_path (
  id INT AUTO_INCREMENT PRIMARY KEY,
  route VARCHAR(10) NOT NULL, seq INT NOT NULL,
  x DOUBLE NOT NULL, y DOUBLE NOT NULL, h TINYINT DEFAULT 0,
  stage VARCHAR(12) DEFAULT NULL,
  INDEX idx_route (route, seq)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_route_path OK\n";

// Shape kotak vector di tab Editor (background "peta bersih" gaya PPT/Google Maps, ditelusuri manual
// di atas gambar denah asli) — dikonfirmasi user: garis besar bangunan digambar ulang pakai kotak yg
// bisa diatur ukuran/rotasi/warna/teks, biar nantinya gambar raster bisa didim/disembunyikan dan yg
// kelihatan cuma shape vector ini. x,y = pojok kiri-atas SEBELUM rotasi (local space); rot = derajat.
$db->query("CREATE TABLE IF NOT EXISTS smms_shapes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  x DOUBLE NOT NULL, y DOUBLE NOT NULL, w DOUBLE NOT NULL, h DOUBLE NOT NULL,
  rot DOUBLE NOT NULL DEFAULT 0,
  fill VARCHAR(20) NOT NULL DEFAULT '#E2E8F0',
  stroke VARCHAR(20) NOT NULL DEFAULT '#475569',
  text VARCHAR(60) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_shapes OK\n";

// kind = jenis shape: '' (default, shape polos biasa) atau 'planebuffer' (SATU-satunya shape khusus,
// nampilin isi Plane Buffer beneran di denah Monitor, bukan cuma kotak warna — dikonfirmasi user:
// digambar/diposisikan/dirotasi lewat mekanisme shape yg SAMA (drag/resize/rotate), cuma isinya beda,
// lihat 06-render.js & tombol "+ Plane Buffer", editor/editor.js).
$db->query("ALTER TABLE smms_shapes ADD COLUMN IF NOT EXISTS kind VARCHAR(20) NOT NULL DEFAULT '' AFTER text");
echo "kolom smms_shapes.kind OK\n";

// kind='sortingplane' — shape physical area Sorting per Route (identity dari smms_sorting_plane,
// dipilih lewat picker "+ Sorting Plane" di Editor — lihat editor/editor.js). sorting_plane_id = FK
// lunak (tanpa constraint, konsisten app ini gak pakai FK) ke smms_sorting_plane.id, dipakai deteksi
// "row config ini sudah punya shape apa belum". route/plane_capacity DIDENORMALISASI (disalin apa
// adanya saat shape ditempatkan) biar render (06-render.js) berdiri sendiri tanpa fetch tambahan —
// konsekuensi: kalau route/capacity baris config diedit BELAKANGAN di Setting, shape yg SUDAH
// ditempatkan tetap tampilkan nilai lama sampai dihapus & ditempatkan ulang (sama persis perilaku
// Rack.addr/shape.text yg sudah ada, bukan regresi baru).
$db->query("ALTER TABLE smms_shapes ADD COLUMN IF NOT EXISTS sorting_plane_id INT NULL DEFAULT NULL AFTER kind");
$db->query("ALTER TABLE smms_shapes ADD COLUMN IF NOT EXISTS sorting_plane_num INT NULL DEFAULT NULL AFTER sorting_plane_id");
$db->query("ALTER TABLE smms_shapes ADD COLUMN IF NOT EXISTS route VARCHAR(10) NOT NULL DEFAULT '' AFTER sorting_plane_num");
$db->query("ALTER TABLE smms_shapes ADD COLUMN IF NOT EXISTS plane_capacity TINYINT NOT NULL DEFAULT 0 AFTER route");
echo "kolom smms_shapes.sorting_plane_* OK\n";

// kind='dollysupply' — shape physical area Dolly Supply per Route (identity dari smms_dolly_supply,
// dipilih lewat picker "+ Dolly Supply" di Editor). Pola IDENTIK sorting_plane_* di atas, TANPA
// capacity (tidak ada analog "1-2 Plane" utk Dolly).
$db->query("ALTER TABLE smms_shapes ADD COLUMN IF NOT EXISTS dolly_supply_id INT NULL DEFAULT NULL AFTER plane_capacity");
$db->query("ALTER TABLE smms_shapes ADD COLUMN IF NOT EXISTS dolly_supply_num INT NULL DEFAULT NULL AFTER dolly_supply_id");
$db->query("ALTER TABLE smms_shapes ADD COLUMN IF NOT EXISTS dolly_route VARCHAR(10) NOT NULL DEFAULT '' AFTER dolly_supply_num");
echo "kolom smms_shapes.dolly_supply_* OK\n";

// kind='sortingarea' — GANTIKAN 'sortingplane' (koreksi arsitektur 2026-08-27): shape physical area
// Sorting per Route dgn hierarchy Route->Slot->Stack (identity dari smms_sorting_area, dipilih lewat
// picker "+ Sorting Area" di Editor). Kolom sorting_plane_id/sorting_plane_num/plane_capacity DI ATAS
// DIBIARKAN (unused, tidak di-drop -- konsisten preseden smms_plane_manual). Kolom `route` (generic,
// sudah ada) DIREUSE di sini juga -- tidak perlu kolom route terpisah lagi.
$db->query("ALTER TABLE smms_shapes ADD COLUMN IF NOT EXISTS sorting_area_id INT NULL DEFAULT NULL AFTER dolly_route");
$db->query("ALTER TABLE smms_shapes ADD COLUMN IF NOT EXISTS sorting_code VARCHAR(20) NOT NULL DEFAULT '' AFTER sorting_area_id");
$db->query("ALTER TABLE smms_shapes ADD COLUMN IF NOT EXISTS row_count INT NOT NULL DEFAULT 0 AFTER sorting_code");
echo "kolom smms_shapes.sorting_area_* OK\n";

$db->query("CREATE TABLE IF NOT EXISTS smms_cd_mapping (
  cd_start TINYINT NOT NULL, halte_no TINYINT NOT NULL,
  cd_max TINYINT NOT NULL, cd_min TINYINT NOT NULL,
  PRIMARY KEY (cd_start, halte_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_cd_mapping OK\n";

$db->query("CREATE TABLE IF NOT EXISTS smms_halte_master (
  route VARCHAR(10) NOT NULL, halte_no TINYINT NOT NULL,
  rack_addr VARCHAR(24), PRIMARY KEY (route, halte_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_halte_master OK\n";

// Dolly nomor berapa (1-8, bisa lebih dari 1) yg lagi disupply pas towing berhenti di halte ini —
// diatur manual per route lewat grid Halte & Rack, dipakai buat nyalain kotak dolly-nya otomatis di
// Monitor. PK 3 kolom (bukan cuma route+halte_no) krn 1 halte boleh punya beberapa dolly sekaligus.
$db->query("CREATE TABLE IF NOT EXISTS smms_halte_dolly (
  route VARCHAR(10) NOT NULL, halte_no TINYINT NOT NULL,
  dolly_no TINYINT NOT NULL, PRIMARY KEY (route, halte_no, dolly_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_halte_dolly OK\n";

$db->query("CREATE TABLE IF NOT EXISTS smms_meta (
  k VARCHAR(32) PRIMARY KEY, v TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_meta OK\n";

// PK auto-increment (bukan route+supplier) karena 1 supplier bisa muncul di >1 posisi seq utk route yg sama.
// supplier_code bisa berisi key gabungan "kode|shipping_dock" (lihat pattern_unload.php).
$db->query("CREATE TABLE IF NOT EXISTS smms_pattern_unload (
  id INT AUTO_INCREMENT PRIMARY KEY,
  route VARCHAR(10) NOT NULL, seq INT NOT NULL,
  supplier VARCHAR(60) NOT NULL,
  supplier_code VARCHAR(64) NOT NULL DEFAULT '',
  zone VARCHAR(10) DEFAULT NULL, offset_val INT DEFAULT NULL,
  INDEX idx_route_seq (route, seq)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_pattern_unload OK\n";

// ================= COUNTER + OFFSET (mirip skema wp_app_offset/operation_recorded di IIS) =================
// Konsep: smms_counter adalah histori tick counter bersama (per zona), smms_offset memetakan tiap
// route ke "berapa tick di belakang counter sekarang" gilirannya (1 tabel tunggal, kolom persis
// Dock|Process|Zone|Route|Lane|Volume|Offset — dulu ada 2 tabel terpisah "Counter Offset" +
// "Posisi Offset" dgn Address, sudah DIGABUNG jadi 1 sesuai template Excel sumber; rentang posisi
// yg dulu disimpan offset_max/offset_min terpisah sekarang ditulis sbg teks "max-min" di kolom
// offset_val yang sama, format yg SUDAH dipakai HALTE 1/2/3 — lihat offsetRowMatches(),
// 03-countdown.js), smms_operation_recorded jadi worklist hasil resolusinya. Ini TAMBAHAN — tidak
// menggantikan countdown per-route yang sudah jalan sekarang.

// Histori tick counter (disimulasikan manual dari UI selama COUNTER_API blm nyambung ke PICS asli).
$db->query("CREATE TABLE IF NOT EXISTS smms_counter (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  counter_no INT NOT NULL DEFAULT 1,
  lane VARCHAR(10) NOT NULL DEFAULT '',
  counter_value INT NOT NULL DEFAULT 0,
  order_no VARCHAR(20) NOT NULL DEFAULT '',
  update_date DATETIME NOT NULL,
  INDEX idx_counter_date (counter_no, update_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_counter OK\n";

// Countdown Andon real-time PER ROUTE, ditarik langsung dari SQL Server PICS oleh bot Python
// terpisah (lihat bot.andon.py di root project — bukan lewat PHP/COUNTER_API). PK cuma `route`
// krn yang dibutuhkan cuma nilai TERBARU per route (upsert terus-terusan tiap beberapa detik).
$db->query("CREATE TABLE IF NOT EXISTS smms_andon_countdown (
  route VARCHAR(10) PRIMARY KEY,
  countdown_value INT NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_andon_countdown OK\n";

// Master: route ini gilirannya offset ke berapa (dari counter sekarang), per zone/process/volume.
// offset_val VARCHAR krn HALTE 1/2/3 (dan bekas "Posisi Offset") nyimpen RENTANG teks ("17-14"),
// bukan cuma 1 angka posisi (proses lain spt SUPPLY/PREPARE/EMPTY tetap 1 angka, disimpan sbg teks
// juga demi konsistensi kolom). TIDAK ADA lagi kolom "address" (dulu dipakai simpan alamat rack
// halte 1/2/3) -- alamat halte SEKARANG balik disimpan di smms_halte_master (lihat tabel itu di
// atas & api_bootstrap()/api_save_master()), lepas total dari Master Offset.
$db->query("DROP TABLE IF EXISTS smms_offset_position"); // digabung ke smms_offset, tabel ini sudah tidak dipakai
$db->query("CREATE TABLE IF NOT EXISTS smms_offset (
  id INT AUTO_INCREMENT PRIMARY KEY,
  dock VARCHAR(5) NOT NULL DEFAULT '43',
  process VARCHAR(20) NOT NULL DEFAULT 'SUPPLY',
  zone VARCHAR(10) NOT NULL,
  route VARCHAR(10) NOT NULL,
  volume INT NOT NULL DEFAULT 0,
  offset_val VARCHAR(20) NOT NULL DEFAULT '0',
  UNIQUE KEY uniq_offset (dock, process, zone, route, volume)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_offset OK\n";

// Migrasi (aman dijalankan berkali-kali, tabel ini sudah terisi data asli upload user -- TIDAK
// boleh drop+recreate lagi kaya migrasi address dulu, harus preservasi data): kolom "lane" dihapus
// (user putuskan gak perlu, cukup Dock|Process|Zone|Route|Volume|Offset) -- unique key ikut
// disesuaikan krn lane dulu ikut jadi bagian keunikan baris.
$laneExists = $db->query("SHOW COLUMNS FROM smms_offset LIKE 'lane'")->num_rows > 0;
if ($laneExists) {
    $db->query("ALTER TABLE smms_offset DROP KEY uniq_offset");
    $db->query("ALTER TABLE smms_offset DROP COLUMN lane");
    $db->query("ALTER TABLE smms_offset ADD UNIQUE KEY uniq_offset (dock, process, zone, route, volume)");
    echo "kolom smms_offset.lane dihapus (migrasi)\n";
}

// Proses SORTING & TRANSFER diputuskan user gak dipakai sama sekali (belum kepakai di Monitor) --
// baris lama dgn proses itu dihapus dari database (aman dijalankan berkali-kali, no-op kalau
// sudah gak ada). Sudah dihapus juga dari pilihan dropdown Process ("+ Add" Master Offset di
// index.php & OFC_PROCESSES, 15-offset-counter.js) supaya gak bisa dientri ulang.
$db->query("DELETE FROM smms_offset WHERE process IN ('SORTING','TRANSFER')");
echo "cleanup baris SORTING/TRANSFER di smms_offset OK\n";

// Worklist hasil resolusi offset->counter (dicatat tiap kali dihitung, is_processed menandai sudah ditindak/belum).
$db->query("CREATE TABLE IF NOT EXISTS smms_operation_recorded (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  dock VARCHAR(5) NOT NULL DEFAULT '43',
  process VARCHAR(20) NOT NULL DEFAULT 'SUPPLY',
  zone VARCHAR(10) NOT NULL,
  route VARCHAR(10) NOT NULL,
  lane VARCHAR(10) NOT NULL DEFAULT '',
  volume INT NOT NULL DEFAULT 0,
  order_no VARCHAR(20) NOT NULL DEFAULT '',
  current_count_down INT NOT NULL DEFAULT 0,
  plan_operation_time DATETIME NOT NULL,
  is_processed TINYINT NOT NULL DEFAULT 0,
  INDEX idx_lookup (dock, process, zone, is_processed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_operation_recorded OK\n";

// Data Plane MANUAL (kapasitas/isi per nomor plane fisik) — dipakai Plane Simulation utk "analisa
// kondisi kedepan" TANPA harus nunggu data Progress Lane asli (dikonfirmasi user: ini soal "Fisik
// Plane"/nomor plane dlm pola cycling slot, BUKAN data Progress Lane). Kalau 1 plane_num punya baris
// di sini, dia OVERRIDE hitungan asli (psTargetFor/psTotalSkid/psCategoryForSlot, plane-sim.js) utk
// plane itu; plane lain yg gak ada baris manual-nya tetap jalan dari data asli seperti biasa.
$db->query("CREATE TABLE IF NOT EXISTS smms_plane_manual (
  plane_num INT PRIMARY KEY,
  max_volume INT NOT NULL DEFAULT 0,
  filled INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_plane_manual OK\n";

// "Sorting Plane" -- physical area tempat skid hasil bongkar Plane menunggu proses SORTING,
// diidentifikasi lewat ROUTE (bukan nomor plane), kapasitas 1 atau 2 PLANE (kapasitas Plane, BUKAN
// kapasitas skid/baris/kolom) -- dikonfirmasi user, entity TERPISAH TOTAL dari smms_plane_manual
// (Physical Plane) & "Sorting Store" (belum dibuat, entity beda, lihat memori project). Config-only
// fase ini -- BELUM ada movement/distribusi skid per-route (lihat api/sorting_plane.php).
$db->query("CREATE TABLE IF NOT EXISTS smms_sorting_plane (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sorting_plane_num INT NOT NULL,
  route VARCHAR(10) NOT NULL,
  plane_capacity TINYINT NOT NULL DEFAULT 1,
  UNIQUE KEY uniq_sorting_plane_num (sorting_plane_num)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_sorting_plane OK\n";

// "Sorting Area" -- GANTIKAN "Sorting Plane" total (koreksi arsitektur 2026-08-27): hierarchy
// Sorting Area -> Slot -> Stack -> Skid -> Part. Slot DIHITUNG dari row_count*column_count (BUKAN
// disimpan sbg baris DB sendiri -- "jangan CRUD slot satu-satu", dikonfirmasi user), column_count
// SELALU 2 (fix). Stack/Skid BELUM ada tabelnya sama sekali -- belum ada 1 pun data skid real yg
// mengalir ke Sorting di fase ini (config+foundation doang, lihat api/sorting_area.php). Tabel
// smms_sorting_plane DI ATAS DIBIARKAN (unused, tidak di-drop, konsisten preseden smms_plane_manual).
$db->query("CREATE TABLE IF NOT EXISTS smms_sorting_area (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sorting_code VARCHAR(20) NOT NULL,
  route VARCHAR(10) NOT NULL,
  row_count INT NOT NULL,
  column_count TINYINT NOT NULL DEFAULT 2,
  UNIQUE KEY uniq_sorting_code (sorting_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_sorting_area OK\n";

// SORTING PLANE (baris.route ATAS itu) py padanan "DOLLY SUPPLY": physical area penyimpanan Dolly per
// Route (identity Route, TANPA capacity -- gak ada analog "1-2 Plane" utk Dolly). Entity TERPISAH,
// shape-nya (kind='dollysupply', smms_shapes) TERPISAH TOTAL dari mekanisme towing-dolly arc-length yg
// sudah jalan di Monitor (03-countdown.js dollyGroups/dollyPositions) -- shape ini murni representasi
// visual physical area, config-only, lihat api/dolly_supply.php.
$db->query("CREATE TABLE IF NOT EXISTS smms_dolly_supply (
  id INT AUTO_INCREMENT PRIMARY KEY,
  dolly_supply_num INT NOT NULL,
  route VARCHAR(10) NOT NULL,
  UNIQUE KEY uniq_dolly_supply_num (dolly_supply_num)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_dolly_supply OK\n";

// Master part: katalog referensi per part_no (volume box per unit + status penanganan).
// Terpisah dari smms_progress_lane (data transaksional hasil upload progress lane) — di-JOIN pakai part_no
// saat menghitung total volume box per supplier (utk nentuin jumlah dolly).
$db->query("CREATE TABLE IF NOT EXISTS smms_master_part (
  part_no VARCHAR(30) PRIMARY KEY,
  volume_box DECIMAL(14,7) NOT NULL DEFAULT 0,
  status VARCHAR(20) NOT NULL DEFAULT 'Direct',
  dock_code VARCHAR(10) NOT NULL DEFAULT '',
  supplier_code VARCHAR(20) NOT NULL DEFAULT '',
  supplier_plant_code VARCHAR(10) NOT NULL DEFAULT '',
  shipping_dock VARCHAR(20) NOT NULL DEFAULT '',
  ssc_code VARCHAR(30) NOT NULL DEFAULT '',
  uniq_no VARCHAR(20) NOT NULL DEFAULT '',
  vol_box_day VARCHAR(20) NOT NULL DEFAULT '',
  supplier_name VARCHAR(100) NOT NULL DEFAULT '',
  part_name VARCHAR(150) NOT NULL DEFAULT '',
  route VARCHAR(10) NOT NULL DEFAULT '',
  INDEX idx_status (status),
  INDEX idx_ssc_route (supplier_code, supplier_plant_code, shipping_dock, route)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_master_part OK\n";

// Cache nama supplier per identitas (supplier_code+shipping_dock+route) — di-upsert tiap kali ada
// data Master Part baru (upload/add/edit), TIDAK PERNAH di-TRUNCATE walau smms_master_part di-replace.
// Tujuannya: kalau supplier yg sudah dipilih di Pattern Unload identitasnya hilang dari Master Part
// terbaru (mis. gara2 upload ulang), nama aslinya tetap bisa ditampilkan (bukan kode mentah) walau
// datanya udah gak "live" lagi — lihat api/pattern_unload.php & assets/js/16-pattern-unload.js.
$db->query("CREATE TABLE IF NOT EXISTS smms_supplier_name_cache (
  supplier_code VARCHAR(20) NOT NULL,
  shipping_dock VARCHAR(20) NOT NULL,
  route VARCHAR(10) NOT NULL,
  supplier_name VARCHAR(100) NOT NULL,
  PRIMARY KEY (supplier_code, shipping_dock, route)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_supplier_name_cache OK\n";

// Riwayat upload Master Part (nama file, mode replace/additional, jumlah baris, waktu) — ditampilkan
// di UI sbg "Last Upload" + daftar riwayat, meniru pola IMPACS Content List.
$db->query("CREATE TABLE IF NOT EXISTS smms_master_part_uploads (
  id INT AUTO_INCREMENT PRIMARY KEY,
  filename VARCHAR(255) NOT NULL,
  mode VARCHAR(20) NOT NULL,
  rows_count INT NOT NULL DEFAULT 0,
  uploaded_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_master_part_uploads OK\n";

// Riwayat upload Progress Lane (nama file, jumlah baris, daftar plane, waktu) — sama polanya dgn
// riwayat Master Part, ditampilkan di tab Upload sbg "Last Upload" + daftar riwayat.
$db->query("CREATE TABLE IF NOT EXISTS smms_progress_lane_uploads (
  id INT AUTO_INCREMENT PRIMARY KEY,
  filename VARCHAR(255) NOT NULL,
  rows_count INT NOT NULL DEFAULT 0,
  planes VARCHAR(100) NOT NULL DEFAULT '',
  uploaded_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
echo "tabel smms_progress_lane_uploads OK\n";

// Tanggal data ini sebenarnya BUAT tanggal berapa (diekstrak dari 8 digit pertama order_no saat
// upload, lihat api/progress_lane.php) — dipakai poka-yoke retensi H-1/H+1 + preview per-tanggal
// di tab Database. Beda dari uploaded_at (kapan file di-upload).
$db->query("ALTER TABLE smms_progress_lane_uploads ADD COLUMN IF NOT EXISTS data_date DATE NULL AFTER planes");
echo "kolom smms_progress_lane_uploads.data_date OK\n";

// Sub Route Code (grouping truck sekali angkut/1 pengiriman) + jam kedatangan/unload cross-dock —
// dipakai jadi acuan urutan skid mana yg beneran lagi dibongkar sekarang (Plane Simulation), TERPISAH
// dari data_date di atas (ini per-BARIS part, bukan per-batch upload). Nullable krn kolom ini opsional
// di file sumbernya (kalau headernya gak ketemu pas upload, tetap NULL — fitur ordering-nya cuma
// gak sepresisi kalau ada data real, gak bikin apapun gagal).
$db->query("ALTER TABLE smms_progress_lane ADD COLUMN IF NOT EXISTS sub_route_code VARCHAR(20) NOT NULL DEFAULT '' AFTER route_order_seq");
$db->query("ALTER TABLE smms_progress_lane ADD COLUMN IF NOT EXISTS cd_arrival_at DATETIME NULL AFTER sub_route_code");
$db->query("ALTER TABLE smms_progress_lane ADD COLUMN IF NOT EXISTS cd_departure_at DATETIME NULL AFTER cd_arrival_at");
echo "kolom smms_progress_lane.sub_route_code/cd_arrival_at/cd_departure_at OK\n";

// Raw MROS (kolom "Plane (MROS)" file sumber) — DULU ini yg jadi patokan nomor `plane` (dipadding 2
// digit langsung). Dikonfirmasi user: patokan nomor plane PINDAH ke "Main Route Order Seq" (kolom AB,
// udah kesimpen duluan di route_order_seq) — MROS mentah TETAP disimpan di sini (bukan dibuang) sbg
// arsip/pembanding, TERPISAH dari `plane` yg sekarang isinya = route_order_seq dipadding 2 digit
// (lihat api_upload_progress_lane, api/progress_lane.php).
$db->query("ALTER TABLE smms_progress_lane ADD COLUMN IF NOT EXISTS mros_raw VARCHAR(10) NOT NULL DEFAULT '' AFTER route_order_seq");
echo "kolom smms_progress_lane.mros_raw OK\n";

// Bersihkan tanggal nol ("0000-00-00 00:00:00") yg kesimpen dari bug validDateOrNull() lama (fallback-nya
// dulu return $s mentah kalau nilai sel gak cocok pola manapun, alih2 null — MySQL diam2 nyimpennya jadi
// tanggal nol, BUKAN NULL, jadi keanggep "ada data" padahal harusnya kosong; lihat komentar validDateOrNull()
// di plane-sim/api.php). Idempotent — aman dijalankan ulang, gak ngaruh apa2 begitu udah bersih semua.
$db->query("UPDATE smms_progress_lane SET cd_arrival_at=NULL WHERE cd_arrival_at='0000-00-00 00:00:00'");
$db->query("UPDATE smms_progress_lane SET cd_departure_at=NULL WHERE cd_departure_at='0000-00-00 00:00:00'");
echo "cleanup tanggal nol cd_arrival_at/cd_departure_at OK\n";

// Backfill best-effort utk baris lama (upload sebelum kolom ini ada): ambil tanggal dari order_no
// baris part pertama di batch itu. Kalau gak ketemu, biarin NULL — bakal ke-purge upload berikutnya.
$db->query("UPDATE smms_progress_lane_uploads u SET u.data_date = (
    SELECT LEFT(sp.order_no,8) FROM smms_progress_lane sp
    WHERE sp.batch_id=u.id AND sp.order_no REGEXP '^[0-9]{8}' LIMIT 1
) WHERE u.data_date IS NULL");
echo "backfill data_date OK\n";

// ---- seed mapping countdown (Pembagian Halte Supply) ----
$cd = [
 [24,[[24,19],[18,13],[12,7]]],[23,[[23,18],[17,13],[12,7]]],
 [22,[[22,18],[17,13],[12,7]]],[21,[[21,17],[16,12],[11,7]]],
 [20,[[20,16],[15,11],[10,7]]],[19,[[19,15],[14,11],[10,7]]],
 [18,[[18,15],[14,11],[10,7]]],[17,[[17,14],[13,10],[9,7]]]];
$st=$db->prepare("REPLACE INTO smms_cd_mapping VALUES (?,?,?,?)");
foreach($cd as [$s,$hs]) foreach($hs as $i=>$r){ $h=$i+1; $st->bind_param('iiii',$s,$h,$r[0],$r[1]); $st->execute(); }
echo "seed cd_mapping OK\n";

// ---- seed halte master (stratifikasi 20 Apr 2026) ----
$halte = [
 'H'=>['SIP1R-I16','JDT1-T150','SF4R-H49'],'L'=>['SPTR-X10','FNL2-K117','SPTL2-X38'],
 'P'=>['SPT1-M92','ERDR-D180','SPDL-D50'],'O'=>['SPT1-M92','PLT-N41','CH1LH-C16'],
 'N'=>['SPTR2-X10','FNL2-K117','SPTL2-X38'],'J'=>['SIP1R-I16','JDT1-T128','JDT1-T150'],
 'Q'=>['FNL3-K28','FNL2-K117','SPT2L-Y27'],'F'=>['TRIM2-T228','FNL4L-H23','SF4R-H49'],
 'M'=>['SPTR2-X10','FNL2-K117','SPT2L-Y27'],
 'A'=>['CTR1-S28','CH2LH-C112',null],'C'=>['ALXL-A11','CH1RH-C66','SPEG-G12'],
 'I'=>['SIP1R-I16','JDT1-T150','FLQC-Q4'],'G'=>['TRIM2-T228','SF4R-H49','FLQC-Q4'],
 'B'=>['CH2RH-C80','ERDR-D180','SPDL-D50'],'E'=>['ALEG-E16','CH2RH-C80','CH2LH-C112'],
 'D'=>['ALXL-A11','CH1RH-C66','SPEG-G12'],'K'=>['SPT1-M92','ERDR-D180','SPDL-D50']];
$st=$db->prepare("REPLACE INTO smms_halte_master VALUES (?,?,?)");
foreach($halte as $r=>$hs) foreach($hs as $i=>$a){ $h=$i+1; $st->bind_param('sis',$r,$h,$a); $st->execute(); }
echo "seed halte_master OK\n";

// ---- seed parts dari data/parts_seed.json (jika tabel kosong) ----
$cnt = $db->query("SELECT COUNT(*) c FROM smms_progress_lane")->fetch_assoc()['c'];
if ($cnt == 0 && file_exists(__DIR__.'/data/parts_seed.json')) {
    $seed = json_decode(file_get_contents(__DIR__.'/data/parts_seed.json'), true);
    $rows = $seed['rows']; $n = 0;
    $db->begin_transaction();
    $chunk = [];
    foreach ($rows as $r) {
        $chunk[] = "('".implode("','", array_map(fn($v)=>$db->real_escape_string((string)$v), $r))."')";
        if (count($chunk) >= 500) {
            $db->query("INSERT INTO smms_progress_lane (plane,route,part_no,part_name,kanban,qty,lot,addr,supplier,uniq_no,order_no) VALUES ".implode(',',$chunk));
            $n += count($chunk); $chunk = [];
        }
    }
    if ($chunk) { $db->query("INSERT INTO smms_progress_lane (plane,route,part_no,part_name,kanban,qty,lot,addr,supplier,uniq_no,order_no) VALUES ".implode(',',$chunk)); $n += count($chunk); }
    $db->query("REPLACE INTO smms_meta VALUES ('parts_source','".$db->real_escape_string($seed['file'])." (Dock 43)'), ('parts_rows','$n'), ('parts_uploaded','".date('Y-m-d H:i:s')."')");
    $db->commit();
    echo "seed parts: $n baris OK\n";
} else {
    echo "seed parts dilewati (tabel sudah berisi $cnt baris)\n";
}
echo "\nSELESAI. Buka http://localhost/smms/\n";
