/* =====================================================================
   20-DOLLY-SUPPLY — menu "Setting" > Dolly Supply: physical area penyimpanan Dolly per Route, padanan
   Sorting Plane (lihat 18-sorting-plane.js, pola CRUD PERSIS sama) TAPI TANPA field capacity (gak ada
   analog "1-2 Plane" utk Dolly). Entity TERPISAH TOTAL dari mekanisme towing-dolly arc-length yg sudah
   jalan di Monitor (dollyGroups/dollyPositions, 03-countdown.js) — shape-nya di Editor (kind:
   'dollysupply', smms_shapes) murni representasi visual physical area, config-only.
   ===================================================================== */

let DS_ALL_ROWS=[], DS_MASTER_ROUTES=[], dsEditId=null;

/** Dipanggil pas nav "Setting" diklik pertama kali (09-nav.js), bareng initSortingPlane() -- muat
 * dropdown Route (dari Master Part, sumber sama persis Sorting Plane) + tabel Dolly Supply, render. */
async function initDollySupply(){
  const [routesRes, rowsRes] = await Promise.all([
    apiGet('action=master_part_routes').catch(()=>({routes:[]})),
    apiGet('action=dolly_supply_list').catch(()=>({rows:[]}))
  ]);
  DS_MASTER_ROUTES = routesRes.routes || [];
  DS_ALL_ROWS = (rowsRes.rows||[]).map(r=>({id:+r.id, dolly_supply_num:+r.dolly_supply_num, route:r.route}));
  dsRenderTable();
}

/** Kartu preview KECIL per baris — identitas (Route) + beberapa slot placeholder KOSONG, SENGAJA TANPA
 * grid skid asli (padanan spPreviewHtml, 18-sorting-plane.js). */
function dsPreviewHtml(row){
  const slots=[1,2,3].map(()=>`<div class="sp-slot"></div>`).join("");
  return `<div class="sp-preview"><div class="sp-preview-route">ROUTE ${puEsc(row.route)}</div><div class="sp-preview-slots">${slots}</div></div>`;
}

function dsRenderTable(){
  const box=document.getElementById("dsTableBox");
  if(!box) return;
  const thead=`<tr><th>Dolly Supply</th><th>Route</th><th>Preview</th><th style="width:110px"></th></tr>`;
  box.innerHTML=`<div style="overflow-x:auto"><table class="grid compact">${thead}`+
    (DS_ALL_ROWS.length ? DS_ALL_ROWS.map(r=>
      `<tr><td>${r.dolly_supply_num}</td><td>${puEsc(r.route)}</td>`+
      `<td>${dsPreviewHtml(r)}</td><td>`+
      `<button class="tmode dsEditBtn" data-id="${r.id}" style="padding:3px 8px;font-size:11px">✎</button> `+
      `<button class="tmode mp-danger dsDelBtn" data-id="${r.id}" style="padding:3px 8px;font-size:11px">🗑</button>`+
      `</td></tr>`
    ).join("") : '<tr><td colspan="4" style="text-align:center;color:var(--mut)">Belum ada data — klik + Add Dolly Supply</td></tr>')
    +`</table></div>`;
  box.querySelectorAll(".dsEditBtn").forEach(b=>b.onclick=()=>dsOpenForm("edit", DS_ALL_ROWS.find(r=>r.id===+b.dataset.id)));
  box.querySelectorAll(".dsDelBtn").forEach(b=>b.onclick=()=>dsDeleteRow(+b.dataset.id));
}

function dsOpenForm(mode, row){
  dsEditId = mode==="edit" ? row.id : null;
  document.getElementById("dsFormTitle").textContent = mode==="add" ? "Tambah Dolly Supply" : "Edit Dolly Supply";
  document.getElementById("dsFormMsg").textContent="";
  document.getElementById("dsfNum").value = mode==="edit" ? row.dolly_supply_num : "";
  const sel=document.getElementById("dsfRoute");
  sel.innerHTML = DS_MASTER_ROUTES.map(r=>`<option value="${puEsc(r)}">${puEsc(r)}</option>`).join("");
  sel.value = mode==="edit" ? row.route : (DS_MASTER_ROUTES[0]||"");
  document.getElementById("dsFormModal").style.display="flex";
}
document.getElementById("dsAddBtn").onclick=()=>dsOpenForm("add");
document.getElementById("dsFormCancel").onclick=()=>document.getElementById("dsFormModal").style.display="none";
document.getElementById("dsFormModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });

document.getElementById("dsFormSave").onclick=async()=>{
  const msg=document.getElementById("dsFormMsg");
  const num=+document.getElementById("dsfNum").value;
  const route=document.getElementById("dsfRoute").value;
  if(!num||num<1){ msg.textContent="Dolly Supply Number wajib diisi (angka > 0)."; return; }
  if(!route){ msg.textContent="Route wajib dipilih."; return; }
  if(DS_ALL_ROWS.some(r=>r.dolly_supply_num===num && r.id!==dsEditId)){
    msg.textContent=`Dolly Supply ${num} sudah ada — edit baris itu langsung, bukan tambah baru.`;
    return;
  }
  try{
    await apiPost("dolly_supply_upsert_row",{id:dsEditId, dolly_supply_num:num, route});
    document.getElementById("dsFormModal").style.display="none";
    toast(`Dolly Supply ${num} tersimpan`);
    await initDollySupply();
  }catch(e){ msg.textContent="Gagal simpan: "+e.message; }
};

async function dsDeleteRow(id){
  const row=DS_ALL_ROWS.find(r=>r.id===id);
  try{
    await apiPost("dolly_supply_delete_row",{id});
    toast(`Dolly Supply ${row?row.dolly_supply_num:id} dihapus`);
    await initDollySupply();
  }catch(e){ toast("Gagal hapus: "+e.message); }
}
