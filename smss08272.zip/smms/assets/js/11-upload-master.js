/* =====================================================================
   11-UPLOAD-MASTER — modal upload master data (halte/cd/rack/jalur/urutan
   supply). Pola sama dgn Master Offset di IIS: template + marker + replace toggle.
   ===================================================================== */
const MASTER_KINDS={
  halte_master:{title:'Upload Master Halte',tpl:'assets/templates/template_halte_master.xlsx'},
  cd_mapping:{title:'Upload Mapping Countdown',tpl:'assets/templates/template_cd_mapping.xlsx'},
  racks:{title:'Upload Master Rack',tpl:'assets/templates/template_racks.xlsx'},
  route_path:{title:'Upload Master Jalur Route',tpl:'assets/templates/template_route_path.xlsx'},
  supply_order:{title:'Upload Master Urutan Supply',tpl:'assets/templates/template_supply_order.xlsm',
    note:'Upload langsung file "UNLOAD PATTERN BASE ON SUPPLY ROUTE" asli dari Operation (blok ZONE TIMUR/ZONE BARAT) — tidak perlu ubah format.'},
  offset:{title:'Upload Master Offset',tpl:'assets/templates/template_offset.xlsx'},
  // master_part PUNYA UI upload sendiri (lihat 17-master-part.js) — tidak lewat modal generik ini,
  // krn butuh pilihan mode Additional/Replace + popup detail error per baris/kolom.
};
let umKind=null;
const umModal=document.getElementById("uploadModal");
document.querySelectorAll(".btn-upload").forEach(b=>b.onclick=()=>{
  umKind=b.dataset.kind; const cfg=MASTER_KINDS[umKind];
  document.getElementById("umTitle").textContent=cfg.title;
  document.getElementById("umTemplate").href=cfg.tpl;
  document.getElementById("umTemplate").textContent=cfg.note?"↓ Download contoh file (referensi)":"↓ Download Template";
  document.getElementById("umNote").textContent=cfg.note||"Isi file sesuai template (jangan ubah baris 1 & 3), lalu upload di sini.";
  document.getElementById("umFile").value=""; document.getElementById("umMsg").textContent="";
  umModal.style.display="flex";
});
document.getElementById("umCancel").onclick=()=>umModal.style.display="none";
umModal.addEventListener("click",e=>{ if(e.target===umModal) umModal.style.display="none"; });

/** Kirim file yang dipilih di modal upload master ke endpoint api sesuai umKind. */
document.getElementById("umSubmit").onclick=async()=>{
  const f=document.getElementById("umFile").files[0];
  if(!f){ document.getElementById("umMsg").textContent="Pilih file dulu."; return; }
  const fd=new FormData(); fd.append('file',f);
  fd.append('replace', document.getElementById("umReplace").checked?'1':'0');
  document.getElementById("umMsg").textContent="Mengunggah…";
  try{
    const res=await apiPost('upload_'+umKind, fd, true);
    if(res.error) throw new Error(res.error);
    umModal.style.display="none";
    toast(`${MASTER_KINDS[umKind].title}: ${res.rows} baris tersimpan`);
    await bootstrap(); buildGrids(); redrawAll(); refresh();
  }catch(e){ document.getElementById("umMsg").textContent="Gagal: "+e.message; }
};
