/* =====================================================================
   19-FLOW-ANIM — layer animasi visual PLANE → SORTING → DOLLY SUPPLY (di atas shape "Sorting Plane"/
   "Dolly Supply" yg dibangun bareng fitur ini, lihat editor/editor.js & 06-render.js). MURNI simulasi
   VISUAL, TERPISAH TOTAL dari Plane Simulation (plane-sim/plane-sim.js) — file ini HANYA MEMBACA
   psComputeGroups/PS_DATA_SEQUENCE/psSimNow/OFFSET_TABLE/CFG.shapes/cd/cdStart APA ADANYA, TIDAK
   PERNAH menulis balik ke variabel/fungsi Plane Simulation atau countdown manapun (menghindari
   duplicate source of truth, dikonfirmasi user eksplisit) — TIDAK ADA baris di plane-sim.js/
   03-countdown.js/08-header.js/06-render.js's renderPlaneBufferContent yg diubah demi fitur ini.

   REUSE TOTAL mekanisme CD/countdown existing: `cdRouteFor`/`supplyOffsetFor`/`offsetStatusFor`
   (03-countdown.js) — TIDAK ADA countdown baru, TIDAK ADA angka "6" di-hardcode di mana pun file ini;
   window "Prepare" dibaca APA ADANYA dari baris proses PREPARE di Master Offset per route (siapa pun
   nilainya, itu yg dipakai).

   Alur (lihat plan): tiap grup skid plane AKTIF yg `cd_departure_at`-nya (timestamp ASLI) baru lewat
   `psSimNow()` -> push token ke SORTING_STOCK[route] (FIFO) + animasi terbang dari shape Plane Buffer
   ke shape Sorting Plane route itu (kalau ada). Tiap kali `cd` GLOBAL beneran berubah (1 tick asli,
   bukan interval JS) -> utk tiap route yg sedang status "PREPARE" (offsetStatusFor) & masih py stock,
   shift() 1 token dari SORTING_STOCK ke DOLLY_STOCK + animasi terbang ke shape Dolly Supply route itu.
   ===================================================================== */

// FIFO array token skid per route -- MURNI visual/simulasi (TIDAK dipersist ke DB, reset tiap reload,
// sama prinsip psFillProgress/plane-sim.js). push()=ekor(terbaru), shift()=kepala(terlama) -- FIFO
// native array: skid LAMA selalu diproses duluan (dikonfirmasi user: "jangan otomatis mengambil skid
// baru lebih dahulu").
let SORTING_STOCK = {};
let DOLLY_STOCK = {};
let FLOW_SEEDED = false;
let FLOW_SEEN_DEPARTED = new Set(); // group.key yg SUDAH memicu animasi Plane->Sorting (anti-duplikat)
let FLOW_PREPARE_STATE = {};        // { route: status terakhir dari offsetStatusFor } -- sekedar catatan/debug
let FLOW_LAST_CD = null;            // deteksi PERUBAHAN `cd` ASLI (bukan interval JS) -- lihat flowTick
let FLOW_TOKEN_SEQ = 0;
function flowNewToken(){ return { id: ++FLOW_TOKEN_SEQ }; }

/** Shape (CFG.shapes) kind='sortingarea' pertama utk route ini (1 route BOLEH py >1 Sorting Area,
 * dikonfirmasi user -- versi animasi ini cukup salah satu). null kalau config-nya ada tapi shape-nya
 * belum ditempatkan di Editor (animasi utk route itu di-skip, stock tetap dihitung). GANTI dari
 * kind='sortingplane' (koreksi arsitektur 2026-08-27, "Sorting Plane" digantikan "Sorting Area"). */
function flowSortingShapeFor(route){ return (CFG.shapes||[]).find(s=>s.kind==="sortingarea" && s.route===route) || null; }
function flowDollyShapeFor(route){ return (CFG.shapes||[]).find(s=>s.kind==="dollysupply" && s.dollyRoute===route) || null; }
function flowPlaneBufferShape(){ return (CFG.shapes||[]).find(s=>s.kind==="planebuffer") || null; }

/** Titik tengah shape (x+w/2, y+h/2) — TIDAK perlu koreksi rotasi: `<g transform="rotate(rot, cx,
 * cy)">` (06-render.js, redrawAll) berputar PERSIS di titik tengahnya sendiri, jadi titik tengah TIDAK
 * PERNAH berpindah walau shape-nya diputar berapa derajat pun. Animasi terbang antar-shape cukup pakai
 * titik tengah asal & tujuan apa adanya, TIDAK perlu "engine transform" baru (dikonfirmasi user). */
function flowShapeCenter(s){ return { x: s.x+s.w/2, y: s.y+s.h/2 }; }

/** Seed SEKALI (dipanggil dari flowTick pas FLOW_SEEDED masih false) — isi SORTING_STOCK dari data
 * REAL 1-2 plane SEBELUM plane aktif di PS_DATA_SEQUENCE (bukan angka karangan — dikonfirmasi user:
 * Sorting/Dolly TIDAK BOLEH kosong di awal, TAPI juga TIDAK BOLEH ada data skid palsu). Kalau belum
 * ada plane sebelumnya (baru mulai dari awal / data belum termuat), tiap route mulai dari array
 * kosong — dibiarkan wajar, BUKAN dipaksa isi angka karangan. */
function flowSeedFromRealData(){
  FLOW_SEEDED = true;
  if(typeof PS_DATA_SEQUENCE==="undefined" || typeof psCurrentActiveSlot!=="function"
    || typeof psEntryAtSlot!=="function" || typeof psComputeGroups!=="function") return;
  if(!PS_DATA_SEQUENCE.length) return;
  const activeEntry = psEntryAtSlot(psCurrentActiveSlot());
  const activeIdx = PS_DATA_SEQUENCE.findIndex(e=>e.pid===activeEntry.pid);
  if(activeIdx<=0) return; // <=0: gak ketemu ATAU plane aktif = entry pertama (belum ada "sebelumnya")
  const prevEntries = PS_DATA_SEQUENCE.slice(Math.max(0,activeIdx-2), activeIdx); // maks 2 plane sebelumnya
  prevEntries.forEach(entry=>{
    psComputeGroups(entry.pid).forEach(g=>{
      const routes=[...g.routes];
      if(!routes.length || !g.skidCount) return;
      const share=Math.max(1, Math.round(g.skidCount/routes.length));
      routes.forEach(route=>{
        const arr=(SORTING_STOCK[route]=SORTING_STOCK[route]||[]);
        for(let i=0;i<share;i++) arr.push(flowNewToken());
      });
    });
  });
}

/** Animasikan 1 kotak kecil "terbang" dari titik tengah `fromShape` ke titik tengah `toShape`, warna
 * `rcolor(route)` (konsisten sama warna route yg sudah dipakai di seluruh app: jalur, badge towing,
 * dolly). Elemen SEMENTARA, di-append LANGSUNG ke `svg` (bukan di dalam <g> shape manapun) — otomatis
 * ikut pan/zoom ambient `#stage` (sama prinsip foreignObject Plane Buffer, TIDAK perlu kompensasi zoom).
 * TIDAK menyentuh redrawAll()/shape aslinya sama sekali — murni elemen visual sementara, mirip pola
 * towing yg juga `setAttribute`/CSS transform langsung tanpa redrawAll (06-render.js, moveTowings). */
function flowFlyToken(fromShape, toShape, route){
  if(typeof svg==="undefined" || !svg || !fromShape || !toShape) return;
  const from=flowShapeCenter(fromShape), to=flowShapeCenter(toShape);
  const size=14;
  const token=document.createElementNS("http://www.w3.org/2000/svg","rect");
  token.setAttribute("x", from.x-size/2); token.setAttribute("y", from.y-size/2);
  token.setAttribute("width", size); token.setAttribute("height", size);
  token.setAttribute("rx", 2);
  token.setAttribute("fill", typeof rcolor==="function" ? rcolor(route) : "#334155");
  token.setAttribute("stroke", "#1E293B"); token.setAttribute("stroke-width", 1);
  token.setAttribute("class", "flow-token");
  token.style.pointerEvents="none";
  token.style.transform="translate(0px,0px)";
  svg.appendChild(token);
  const dx=to.x-from.x, dy=to.y-from.y;
  const cleanup=()=>{ token.remove(); };
  token.addEventListener("transitionend", cleanup, {once:true});
  setTimeout(cleanup, 1200); // jaring pengaman -- transitionend gak kepicu kalau mis. redrawAll() motong svg.innerHTML di tengah animasi (token ikut kebuang bareng, remove() di elemen lepas aman no-op)
  requestAnimationFrame(()=>{
    requestAnimationFrame(()=>{
      token.style.transition="transform .7s ease-in-out";
      token.style.transform=`translate(${dx}px,${dy}px)`;
    });
  });
}

/** Detak utama layer animasi ini — dipanggil interval tetap (lihat setInterval di bawah), GAK
 * digantung ke tab mana yg lagi kebuka (sama prinsip renderPlaneSim's heartbeat 20 detik/plane-sim.js
 * & psRefreshActiveCard/refreshPlaneBufferShapes — shape di denah harus tetap "hidup" walau operator
 * lagi di tab lain). Dibungkus try/catch per-bagian: kesalahan di layer VISUAL murni ini TIDAK BOLEH
 * pernah nge-crash app (Plane Simulation/Monitor/Editor tetap harus jalan normal apapun yg terjadi
 * di sini). */
function flowTick(){
  if(typeof CFG==="undefined" || !CFG.shapes) return;
  if(!FLOW_SEEDED){ try{ flowSeedFromRealData(); }catch(e){ /* seed gagal -- lanjut kosong, bukan fatal */ } }

  // ---- PLANE -> SORTING: grup skid plane AKTIF yg cd_departure_at (timestamp ASLI)-nya baru lewat
  // psSimNow() (BUKAN fraksi gauge sintetis aktif -- lihat Analisis poin 3, plan). ----
  if(typeof psCurrentActiveSlot==="function" && typeof psEntryAtSlot==="function"
    && typeof psComputeGroups==="function" && typeof psSimNow==="function" && typeof parseCustomDate==="function"){
    try{
      const activeEntry=psEntryAtSlot(psCurrentActiveSlot());
      const groups=psComputeGroups(activeEntry.pid);
      const now=psSimNow();
      const fromShape=flowPlaneBufferShape();
      groups.forEach(g=>{
        if(FLOW_SEEN_DEPARTED.has(g.key)) return;
        const dep=parseCustomDate(g.departureAt);
        if(isNaN(dep) || dep>now) return;
        FLOW_SEEN_DEPARTED.add(g.key);
        const routes=[...g.routes];
        if(!routes.length || !g.skidCount) return;
        const share=Math.max(1, Math.round(g.skidCount/routes.length));
        routes.forEach(route=>{
          const arr=(SORTING_STOCK[route]=SORTING_STOCK[route]||[]);
          for(let i=0;i<share;i++) arr.push(flowNewToken());
          const toShape=flowSortingShapeFor(route);
          if(fromShape && toShape) flowFlyToken(fromShape, toShape, route);
        });
      });
    }catch(e){ /* jangan sampai animasi visual bikin app crash */ }
  }

  // ---- SORTING -> DOLLY: 1 token per ROUTE per TICK CD ASLI (bukan per interval JS -- drain dipacu
  // PERSIS sepace countdown beneran, lihat komentar file), selama route itu SEDANG status "PREPARE"
  // (dibaca APA ADANYA dari Master Offset via offsetStatusFor, TIDAK ADA angka "6" di-hardcode). ----
  if(typeof cd!=="undefined" && cd!==FLOW_LAST_CD){
    FLOW_LAST_CD=cd;
    if(typeof offsetStatusFor==="function" && typeof cdRouteFor==="function" && typeof cdStart!=="undefined"){
      try{
        Object.keys(SORTING_STOCK).forEach(route=>{
          if(!SORTING_STOCK[route] || !SORTING_STOCK[route].length) return;
          let st=null;
          try{ st=offsetStatusFor(route, cdRouteFor(route,cd,cdStart), cdStart); }catch(e){ st=null; }
          FLOW_PREPARE_STATE[route]=st;
          if(st!=="PREPARE") return;
          const token=SORTING_STOCK[route].shift();
          const arr=(DOLLY_STOCK[route]=DOLLY_STOCK[route]||[]);
          arr.push(token);
          const fromShape=flowSortingShapeFor(route), toShape=flowDollyShapeFor(route);
          if(fromShape && toShape) flowFlyToken(fromShape, toShape, route);
        });
      }catch(e){ /* jangan sampai animasi visual bikin app crash */ }
    }
  }

  // Badge angka stock (SORTING_STOCK/DOLLY_STOCK) di shape -- refresh RINGAN, TIDAK redrawAll() penuh
  // (lihat komentar refreshFlowShapeBadges, 06-render.js).
  if(typeof refreshFlowShapeBadges==="function"){ try{ refreshFlowShapeBadges(); }catch(e){} }
}

// Heartbeat TETAP (gak digantung tab manapun) -- 700ms: cukup rapat utk nangkep perubahan `cd` &
// psSimNow() tepat waktu, cukup jarang utk gak makan resource berlebihan (refreshFlowShapeBadges &
// flowFlyToken sendiri murah, bukan redrawAll penuh).
setInterval(flowTick, 700);
