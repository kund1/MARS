/* =====================================================================
   07-SIDEBAR — daftar route (Status Towing), popup pilih route/full,
   dan panel Muatan (part yang dibawa route terpilih).
   ===================================================================== */

/** Render daftar route di sidebar kiri (kode warna, halte saat ini, CD Route/Andon Supply, jumlah
 * part/rack, zona). */
function renderRouteList(){
  const el=document.getElementById("routelist");el.innerHTML="";
  allKnownRoutes().forEach(r=>{
    const hasPath=CFG.paths[r]&&CFG.paths[r].length>1;
    const p=hasPath?towXY(r):null;
    const n=routeParts(r).length, nr=routeRackSet(r).size;
    // "Andon Supply" route ini (CD Route = CD Plane + Supply Offset, wrap Volume — dikonfirmasi
    // user, lihat cdRouteFor/03-countdown.js) — ditampilkan eksplisit per-baris di sini (BEDA dari
    // Andon Plane di header yg tetap 1 angka bersama), biar SEMUA route kelihatan sekaligus posisi
    // countdown-nya masing2 persis kayak referensi "BATON PASS EAST ZONE" (NOW/NEXT beda angka per route).
    const routeCd=cdRouteFor(r, cd, cdStart);
    const row=document.createElement("div");
    row.className="rt-row"+(r===selRoute?" sel":"");
    row.innerHTML=`<div class="rt-code" style="color:${rcolor(r)};border-color:${rcolor(r)}">${r}</div>
      <div class="rt-halte">${!hasPath?"NO JALUR":(p.halte===0?"START":"HALTE "+p.halte)}</div>
      <div class="rt-info">CD ${routeCd}</div>
      <div class="rt-info">${n} part · ${nr} rack</div>
      <div class="rt-info">${zoneOf(r)==="barat"?"WEST":"EAST"}</div>`;
    row.onclick=()=>selectRoute(r);
    el.appendChild(row);
  });
}

let focusDolly=new Set(); // Set nomor dolly (1-8, bisa lebih dari satu) yg lagi disorot, diset otomatis via halte atau klik kotak dolly di denah

/** Refresh focusDolly (dolly mana yg seharusnya nyala, berdasar cd SEKARANG) + render ulang panel
 * Muatan — dipanggil sbg callback onArrive animateCd (lihat 06-render.js), BUKAN sebelum towing
 * mulai bergerak, biar panel Muatan gak "nebak" duluan status halte tujuan sebelum towing sampai. */
function refreshFocusAndParts(){
  if(selRoute){ focusDolly=autoFocusDollyFor(selRoute); renderParts(); }
}

/** Status Towing (daftar semua route) cuma tampil kalau BELUM ada route dipilih; begitu 1 route
 * dipilih, gantian panel Muatan (part yg dibawa route itu) yg tampil — gak pernah dua-duanya sekaligus. */
function updateAsidePanels(){ document.getElementById("routelist").style.display = selRoute ? "none" : ""; }

/** Pilih route aktif: update state, gambar ulang peta, render panel Muatan-nya. */
function selectRoute(r){ selRoute=r; editRoute=r; editRouteSel.value=r; focusDolly=autoFocusDollyFor(r); updateAsidePanels(); redrawAll(); renderParts(); refreshHeader(); }

/* ---- Popup Pilih Route (Monitor): fokus ke 1 route saja, atau FULL semua route ---- */
const routePickModal=document.getElementById("routePickModal");

/** Update label & state tombol "Pilih Route" sesuai mode fokus saat ini. */
function updateRoutePickBtn(){
  const btn=document.getElementById("btnRoutePick");
  btn.classList.toggle("on", mapFocusOnly);
  btn.textContent = mapFocusOnly ? `🗂 Route: ${selRoute}` : "🗂 Pilih Route";
}
document.getElementById("btnRoutePick").onclick=()=>{
  const grid=document.getElementById("routePickGrid");
  grid.innerHTML="";
  const fullBtn=document.createElement("div");
  fullBtn.className="routepick-item full"+(!mapFocusOnly?" active":"");
  fullBtn.textContent="🗺 FULL — Tampilkan Semua Route";
  fullBtn.onclick=()=>{
    mapFocusOnly=false; selRoute=null;
    document.getElementById("partstitle").textContent="Muatan · pilih towing";
    document.getElementById("partscount").textContent="";
    document.getElementById("partsbox").innerHTML='<div id="partsempty">Buka <b>Editor</b> untuk menggambar jalur & memasang rack. Klik towing pada denah untuk melihat muatannya.</div>';
    updateAsidePanels(); redrawAll(); renderRouteList(); updateRoutePickBtn(); routePickModal.style.display="none";
  };
  grid.appendChild(fullBtn);
  allKnownRoutes().forEach(r=>{
    const it=document.createElement("div");
    it.className="routepick-item"+(mapFocusOnly&&selRoute===r?" active":"");
    it.style.background=rcolor(r); it.style.color="#fff"; it.style.borderColor=rcolor(r);
    it.textContent=r;
    it.onclick=()=>{ selectRoute(r); mapFocusOnly=true; redrawAll(); updateRoutePickBtn(); routePickModal.style.display="none"; };
    grid.appendChild(it);
  });
  routePickModal.style.display="flex";
};
document.getElementById("routePickCancel").onclick=()=>routePickModal.style.display="none";
routePickModal.addEventListener("click",e=>{ if(e.target===routePickModal) routePickModal.style.display="none"; });

/** Render tabel Muatan (daftar part + nomor dolly) utk route yang sedang dipilih. */
function renderParts(){
  if(!selRoute)return;
  const parts=routeParts(selRoute);
  const {supplierIdx,unlisted,hasHierarchy,hasUnpacking,groups}=dollyGroups(selRoute);
  const active=activeHalteForCd(cd);
  document.getElementById("partstitle").textContent=`MUATAN ROUTE ${selRoute} · P-LANE ${plane}`;
  document.getElementById("partscount").textContent=parts.length+" part";
  const placed={}; CFG.racks.forEach(rk=>placed[rk.addr]=rk);
  const rowData=parts.map(p=>{
    const rk=placed[p[5]];
    const h=rk?passedHalteForRack(selRoute,rk.x,rk.y):0;
    const gkey=groupKeyForPart(p, hasUnpacking);
    const dolly=(supplierIdx[normSup(gkey)]??-1)+1;
    // Halte tujuan part ini udah kelewatan (< halte aktif skrg) -> udah tersupply/beres.
    const done = h>0 && active>0 && h<active;
    // Address-nya ADA di data part tapi rack-nya BELUM ditempatkan di peta (lihat rkMissingWarn di
    // 10-database.js) — part ini gak akan pernah kelihatan garis/rack tujuan di Monitor.
    const missing = !rk && !!p[5] && p[5]!=="—";
    return {p,h,dolly,done,missing};
  });
  // Slot dolly IMPORT gak pernah punya part ASLI (murni penanda manual di Pattern Unload, lihat
  // dollyGroups) — tanpa baris sintetis di sini, nomor dollynya bakal "hilang" gitu aja dari panel
  // Muatan (operator bisa ngira ada yg salah/kelewat), padahal emang sengaja kosong. p[] palsu cuma
  // diisi field yg dipakai render baris (0/1/5/7/10), sisanya biar undefined (aman, gak dipakai).
  groups.forEach((g,i)=>{
    if(g.supplier!=="IMPORT") return;
    const p=[]; p[0]="—"; p[1]="PART IMPORT"; p[2]="—"; p[3]=""; p[4]=""; p[5]="—"; p[7]="—"; p[10]="Import";
    rowData.push({p, h:0, dolly:i+1, done:false, missing:false});
  });
  // Part yg BELUM tersupply ditaruh di atas (urut nomor dolly), yg UDAH tersupply diturunin ke bawah
  // & diredupkan (lihat CSS .supplied-done) — biar operator fokus ke part yg masih perlu disupply.
  rowData.sort((a,b)=>(a.done-b.done)||((a.dolly||99)-(b.dolly||99)));
  const rows=rowData.map(({p,h,dolly,done,missing})=>
    `<tr data-h="${h}" data-dolly="${dolly}" class="${done?"supplied-done":""}"><td>${statusDotHtml(p[10])}${dolly||"—"}</td><td>${p[0]}</td><td>${p[1]}</td><td>${p[2]}</td><td>${p[3]}×${p[4]}</td><td class="${h?"rk"+h:""}">${missing?`<span class="rk-missing" title="Rack belum ditempatkan di peta — tambahkan di Database ▸ Posisi Rack">⚠ ${p[5]}</span>`:p[5]}</td></tr>`
  ).join("");
  document.getElementById("partsbox").innerHTML=
    `<table><tr><th>DOLLY</th><th>PART NO</th><th>NAMA</th><th>KBN</th><th>QTY×LOT</th><th>RACK</th></tr>${rows}</table>`;
  // Cerminan daftar part yg sama, khusus buat overlay Mode Follow fullscreen (04-viewport.js) —
  // kolom sesuai diminta: UNIQ(p[7]), PART NO, NAMA, STATUS(p[10]), ADDRESS, LOT; urutannya ikut
  // rowData yg udah disortir per nomor dolly (+ status tersupply) di atas. Dikasih border tiap sel
  // (tw-border) biar gampang dibaca dari jarak jauh pas fullscreen.
  document.getElementById("folPartsRoute").textContent = `${selRoute} · P-LANE ${plane}`;
  // Sama persis logic highlight tabel utama (.hl = halte part ini match halte aktif, .dollysel =
  // dolly-nya lagi difokus) — di sini di-bake langsung pas bikin HTML-nya (bukan lewat
  // highlightPartRows/highlightDollyRows terpisah spt tabel utama), krn tabel ini emang selalu
  // di-render ulang penuh bareng tabel utama tiap kali renderParts() jalan.
  const folRows = rowData.map(({p,h,dolly,done,missing})=>{
    const hl = h===active && active>0;
    const sel = focusDolly.has(dolly) && !done;
    const cls = [done&&"tw-opacity-40", hl&&"hl", sel&&"dollysel"].filter(Boolean).join(" ");
    return `<tr class="${cls}">`
    +`<td class="tw-border tw-border-[var(--line)] tw-px-2 tw-py-1">${p[7]||"—"}</td>`
    +`<td class="tw-border tw-border-[var(--line)] tw-px-2 tw-py-1">${p[0]}</td>`
    +`<td class="tw-border tw-border-[var(--line)] tw-px-2 tw-py-1">${p[1]}</td>`
    +`<td class="tw-border tw-border-[var(--line)] tw-px-2 tw-py-1">${statusBadgeHtml(p[10])}</td>`
    +`<td class="tw-border tw-border-[var(--line)] tw-px-2 tw-py-1">${missing?`<span class="rk-missing" title="Rack belum ditempatkan di peta">⚠ ${p[5]}</span>`:p[5]}</td>`
    +`<td class="tw-border tw-border-[var(--line)] tw-px-2 tw-py-1 tw-text-right">${p[4]}</td>`
    +`</tr>`;
  }).join("");
  document.getElementById("folPartsBox").innerHTML =
    `<table class="tw-w-full tw-text-xs tw-border-collapse tw-text-[color:var(--ink)]">`
    +`<tr class="tw-bg-[var(--th-bg)]">`
    +`<th class="tw-border tw-border-[var(--line)] tw-px-2 tw-py-1 tw-text-left">UNIQ</th>`
    +`<th class="tw-border tw-border-[var(--line)] tw-px-2 tw-py-1 tw-text-left">PART NO</th>`
    +`<th class="tw-border tw-border-[var(--line)] tw-px-2 tw-py-1 tw-text-left">NAMA</th>`
    +`<th class="tw-border tw-border-[var(--line)] tw-px-2 tw-py-1 tw-text-left">STATUS</th>`
    +`<th class="tw-border tw-border-[var(--line)] tw-px-2 tw-py-1 tw-text-left">ADDRESS</th>`
    +`<th class="tw-border tw-border-[var(--line)] tw-px-2 tw-py-1 tw-text-right">LOT</th>`
    +`</tr>${folRows}</table>`;
  const warnEl=document.getElementById("supplywarn");
  if(!hasHierarchy){
    warnEl.style.display="";
    warnEl.innerHTML=`<div class="swarn info">Belum ada Master Urutan Supply utk route ${selRoute} — dolly dipakai berdasar urutan kemunculan di file upload.</div>`;
  }else if(unlisted.length){
    warnEl.style.display="";
    warnEl.innerHTML=`<div class="swarn bad">⚠ ${unlisted.length} supplier belum terdaftar di Master Urutan Supply route ${selRoute}: ${unlisted.join(", ")}</div>`;
  }else{
    warnEl.style.display="none"; warnEl.innerHTML="";
  }
  highlightPartRows(active);
  highlightDollyRows();
}

/** Highlight baris part yang halte-nya sama dengan halte aktif saat ini. */
function highlightPartRows(active){
  document.querySelectorAll("#partsbox tr[data-h]").forEach(tr=>tr.classList.toggle("hl",+tr.dataset.h===active&&active>0));
}

/** Highlight baris part yang dolly-nya termasuk salah satu yang lagi difokuskan (focusDolly) — cuma
 * diwarnai beda (background oranye, lihat .dollysel di app.css), gak usah berkedip biar gak norak/
 * capek diliat lama-lama di layar monitoring. Baris yang udah "supplied-done" (.supplied-done, lihat
 * renderParts) SENGAJA dikecualikan walau dolly-nya masih focus — 1 dolly bisa bawa address dari >1
 * halte sekaligus (mis. dolly yg sama nganterin FRAML di halte 2 & JDT2 di halte 1), jadi dolly-nya
 * masih wajar focus (masih ada tugas), tapi address yg SPESIFIK ini udah beres gak boleh ikut nyala
 * lagi (itu penyebab bug "part yg udah disupply di halte sebelumnya nyala lagi di halte berikutnya"). */
function highlightDollyRows(){
  document.querySelectorAll("#partsbox tr[data-dolly]").forEach(tr=>{
    tr.classList.toggle("dollysel", focusDolly.has(+tr.dataset.dolly) && !tr.classList.contains("supplied-done"));
  });
}
