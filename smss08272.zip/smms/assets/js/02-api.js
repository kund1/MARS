/* =====================================================================
   02-API — komunikasi dengan api.php: bootstrap, polling counter live,
   load data per plane, simpan config layout.
   ===================================================================== */

/** Bar loading tipis di atas layar (lihat .loading-bar di app.css) — nyala otomatis kalau ADA
 * request API yg masih jalan lebih dari 200ms. Delay 200ms ini SENGAJA supaya polling background
 * pendek (mis. pollCounter tiap 5 detik) yg biasanya kelar dalam hitungan puluhan ms gak bikin bar
 * ikut kedip-kedip — cuma proses yg beneran butuh waktu tunggu (upload, save, dst) yg kelihatan. */
let apiInFlight=0, apiLoadingTimer=null;
function apiLoadingStart(){
  apiInFlight++;
  if(apiInFlight===1 && !apiLoadingTimer){
    apiLoadingTimer=setTimeout(()=>{ document.getElementById("globalLoadingBar")?.classList.add("on"); },200);
  }
}
function apiLoadingEnd(){
  apiInFlight=Math.max(0,apiInFlight-1);
  if(apiInFlight===0){
    clearTimeout(apiLoadingTimer); apiLoadingTimer=null;
    document.getElementById("globalLoadingBar")?.classList.remove("on");
  }
}

/** GET ke api.php dengan query string, return JSON. Lempar error kalau HTTP gagal. */
async function apiGet(q){
  apiLoadingStart();
  try{ const r=await fetch(API+'?'+q); if(!r.ok)throw new Error('API '+r.status); return await r.json(); }
  finally{ apiLoadingEnd(); }
}

/** POST ke api.php (JSON body atau FormData kalau isForm=true), return JSON. Lempar error dari field `error` kalau ada. */
async function apiPost(action,body,isForm=false){
  apiLoadingStart();
  try{
    const r=await fetch(API+'?action='+action,{method:'POST',
      headers:isForm?undefined:{'Content-Type':'application/json'},
      body:isForm?body:JSON.stringify(body)});
    const j=await r.json().catch(()=>null);
    if(!r.ok)throw new Error((j&&j.error)||('API '+r.status));
    return j;
  } finally{ apiLoadingEnd(); }
}

/** Ambil meta+master+layout awal dari server, isi ke variabel state global. */
async function bootstrap(){
  const b=await apiGet('action=bootstrap');
  META=b.meta||{}; PLANES=b.planes||[]; ADDRESSES=b.addresses||[];
  TOW_SPEED=+(META.tow_speed||30);
  CFG.racks=b.racks||[]; CFG.paths=b.paths||{}; CFG.shapes=b.shapes||[];
  CD_MAP=b.cdmap||[]; HALTE_MASTER=b.halte||{}; HALTE_DOLLY=b.haltedolly||{}; SUPPLY_ORDER=b.supply_order||{};
  ROUTE_ZONE=b.route_zone||{}; OFFSET_TABLE=b.offset_table||[];
  if(!PLANES.includes(plane)) plane=PLANES[0]||"01";
  liveMode=!!b.counter_api;
  setSaveState('terhubung MySQL · '+(META.parts_source||'?'));
}

/** Tanya counter live (kalau COUNTER_API terisi di config.php) tiap interval, sinkronkan plane/cd. */
async function pollCounter(){
  try{
    const d=await apiGet('action=counter');
    if(d.sim){ liveMode=false; toast('Counter live tidak tersedia, kembali ke mode manual: '+(d.error||'')); applyLiveUi(); return; }
    liveOrderNo=d.order_no; liveStale=!!d.stale;
    const prevCd=cd;
    let planeChanged=false;
    if(String(d.plane)!==plane){ plane=String(d.plane); planeSel.value=plane; await loadPlane(plane); if(selRoute)renderParts(); planeChanged=true; }
    if(d.cd_start!==cdStart){ cdStart=d.cd_start; cdStartSel.value=cdStart; }
    cd=d.cd;
    // Sama kayak stepCd() di 08-header.js: header+focusDolly+panel Muatan baru disegarkan begitu
    // towing BENERAN sampai (onArrive), bukan sebelum animasi jalan — kecuali planeChanged (redrawAll,
    // gak ada animasi transit yg perlu ditunggu, towing langsung "teleport" ke posisi awal plane baru).
    if(planeChanged){ refreshHeader(); refreshFocusAndParts(); redrawAll(); if(typeof psAdvanceActiveSlot==="function") psAdvanceActiveSlot(); if(typeof renderPlaneSim==="function") renderPlaneSim(); }
    else { animateCd(prevCd,cd,undefined,()=>{ refreshHeader(); refreshFocusAndParts(); }); }
  }catch(e){ /* biarkan tick berikutnya coba lagi */ }
}

/** Update tampilan header (badge LIVE/STALE, disable kontrol manual) sesuai status liveMode. */
function applyLiveUi(){
  document.getElementById("btnAuto").style.display=liveMode?"none":"";
  planeSel.disabled=cdStartSel.disabled=document.getElementById("cdMinus").disabled=document.getElementById("cdPlus").disabled=liveMode;
  let badge=document.getElementById("liveBadge");
  if(!badge){ badge=document.createElement("span"); badge.id="liveBadge";
    document.getElementById("btnAuto").insertAdjacentElement("beforebegin",badge); }
  badge.style.cssText="font-size:10px;font-weight:700;letter-spacing:.04em;padding:5px 10px;border-radius:999px;margin-right:8px;";
  if(!liveMode){ badge.style.display="none"; return; }
  badge.style.display="";
  if(liveStale){ badge.textContent="⚠ DATA STALE"; badge.style.background="#FEF3C7"; badge.style.color="#92400E"; }
  else { badge.textContent="● LIVE"; badge.style.background="#DCFCE7"; badge.style.color="#166534"; }
}

/** Load & cache data part satu plane (semua route), dari PCACHE kalau sudah pernah diambil. */
async function loadPlane(p){
  if(!PCACHE[p]){ const d=await apiGet('action=plane&p='+p); PCACHE[p]=d.routes||{}; }
  PLANEDATA=PCACHE[p];
}

/** Simpan CFG.racks + CFG.paths + CFG.shapes ke server (dipanggil tiap ada perubahan di Editor).
 * Panggilan DISERIALKAN (satu per satu, gak boleh overlap) — server (api_save_config) TRUNCATE lalu
 * insert ulang penuh smms_racks+smms_route_path+smms_shapes, dan TRUNCATE bikin implicit commit di
 * MySQL/MariaDB (transaction-nya gak beneran ngelindungin dari request lain nyelip di tengah). Dua
 * saveCfg() yang nyaris bareng (mis. drag cepat, atau Ctrl+Z ditahan & key-repeat OS nembak banyak
 * kali) bisa saling interleave dan bikin baris dobel/ilang kalau gak diantre begini.
 * PENTING: ketiga field WAJIB selalu dikirim bareng, TIDAK BOLEH ada yg kelewat — api_save_config
 * TRUNCATE+reinsert PENUH tiap tabel dari field yg dikirim (default array kosong kalau field-nya gak
 * ada di payload), jadi field yg lupa disertakan bakal HABIS/ke-TRUNCATE jadi kosong tiap kali fungsi
 * ini kepanggil dari titik manapun (bug nyata yg pernah kejadian: shapes baru ditambah lewat Editor
 * lalu hilang lagi begitu ada saveCfg() lain jalan, krn baris ini sempat cuma ngirim racks+paths). */
let saveCfgChain=Promise.resolve();
function saveCfg(){
  const run=async()=>{
    try{ await apiPost('save_config',{racks:CFG.racks,paths:CFG.paths,shapes:CFG.shapes}); setSaveState('layout tersimpan '+new Date().toLocaleTimeString('id-ID')); }
    catch(e){ setSaveState('GAGAL simpan: '+e.message); }
  };
  saveCfgChain=saveCfgChain.then(run,run);
  return saveCfgChain;
}

/** Tulis status singkat di pojok kanan nav (mis. "layout tersimpan 10:32:05"). */
function setSaveState(t){ document.getElementById("saveState").textContent=t; }
