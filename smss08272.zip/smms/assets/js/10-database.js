/* =====================================================================
   10-DATABASE — tab Database: tabel Part Aktif (search+pagination+CSV),
   dan tabel-tabel master (halte, cd mapping, rack, jalur, urutan supply).
   ===================================================================== */
ALLR.slice().sort().forEach(r=>{const o=document.createElement("option");o.value=o.textContent=r;dbRoute.appendChild(o);});
let DB_PAGE_SIZE=10; // start tebakan, langsung disesuaikan ke tinggi layar sebenarnya di render pertama
let dbFullRows=[], dbFilteredRows=[], dbPage=1, dbSizingPass=false;

/** Hitung berapa baris yang muat di tinggi #dbparts saat ini (diukur dari baris header + baris data
 * yang sudah kerender), biar tabel Progress Lane ngisi maksimal layar, gak mentok di angka tetap. */
function dbFitPageSize(){
  const box=document.getElementById("dbparts");
  if(!box||!box.clientHeight) return false;
  const rows=box.querySelectorAll("tr");
  if(rows.length<2) return false;
  const headH=rows[0].getBoundingClientRect().height;
  const rowH=rows[1].getBoundingClientRect().height;
  if(!rowH) return false;
  const fit=Math.max(5,Math.floor((box.clientHeight-headH)/rowH));
  if(fit!==DB_PAGE_SIZE){ DB_PAGE_SIZE=fit; return true; }
  return false;
}
let dbResizeT;
window.addEventListener("resize",()=>{
  clearTimeout(dbResizeT);
  dbResizeT=setTimeout(()=>{ if(document.getElementById("dbparts")?.clientHeight) renderDbTable(); },200);
});
const DB_COLS=["No","Uniq","Order No","Part No","Nama","Kanban","Qty","Lot","Rack Address","Supplier","Status"];
dbPlane.onchange=dbRoute.onchange=()=>{ document.getElementById("dbSearch").value=""; buildDbParts(); };

// Tanggal yang lagi di-preview di tabel Progress Lane tab Database (null = ikutin batch aktif
// default, sama kayak Monitor). Dipilih via pill tombol tanggal (lihat plRefreshDates() di
// 12-upload-progress.js) — SENGAJA cache-nya dipisah dari PCACHE (yang dipakai Monitor lewat
// loadPlane()) biar preview tanggal lain gak pernah kesenggol/ngaruh ke Monitor.
let dbActiveDate=null, DB_PCACHE={};

/** Ambil data satu plane utk batch sesuai dbActiveDate (null = batch aktif default), dari
 * DB_PCACHE kalau sudah pernah diambil. Terpisah dari loadPlane()/PCACHE punya Monitor. */
async function loadPlaneForDb(p,date){
  const key=(date||"latest")+"|"+p;
  if(!DB_PCACHE[key]){
    const d=await apiGet('action=plane&p='+p+(date?('&date='+encodeURIComponent(date)):''));
    DB_PCACHE[key]=d.routes||{};
  }
  return DB_PCACHE[key];
}

/** Ambil part utk plane+route yang dipilih di tab Database, reset ke halaman 1. */
async function buildDbParts(){
  const p=dbPlane.value||plane;
  const cache=await loadPlaneForDb(p,dbActiveDate).catch(()=>({}));
  const ps=cache[dbRoute.value]||[];
  // status = p2[10], VLOOKUP dari Master Part by part_no (lihat api_plane() di api/data.php) —
  // data yg sama persis dipakai panel Muatan Monitor, jadi gak perlu API call terpisah lagi di sini.
  dbFullRows=ps.map(p2=>({uniq:p2[7]||"",orderNo:p2[8]||"",partNo:p2[0],nama:p2[1],kanban:p2[2],qty:p2[3],lot:p2[4],rack:p2[5],supplier:p2[6]||"",status:p2[10]||"Direct"}));
  dbPage=1;
  applyDbSearch();
}

/** Filter dbFullRows berdasarkan teks pencarian (semua kolom), lalu render ulang. */
function applyDbSearch(){
  const q=(document.getElementById("dbSearch").value||"").trim().toLowerCase();
  dbFilteredRows=!q?dbFullRows:dbFullRows.filter(r=>Object.values(r).some(v=>String(v).toLowerCase().includes(q)));
  renderDbTable();
}

/** Render tabel Part Aktif utk halaman saat ini (dbPage) dari dbFilteredRows. */
function renderDbTable(){
  const total=dbFilteredRows.length;
  const totalPages=Math.max(1,Math.ceil(total/DB_PAGE_SIZE));
  if(dbPage>totalPages) dbPage=totalPages;
  const start=(dbPage-1)*DB_PAGE_SIZE;
  const rows=dbFilteredRows.slice(start,start+DB_PAGE_SIZE);
  const thead=`<tr>${DB_COLS.map(h=>`<th>${h}</th>`).join("")}</tr>`;
  document.getElementById("dbparts").innerHTML=`<table>${thead}`+
    (!total?`<tr><td colspan="${DB_COLS.length}" style="text-align:center;color:var(--mut);padding:20px;font-family:inherit">Tidak ada data</td></tr>`:
    rows.map((r,i)=>`<tr><td class="dbt-no">${start+i+1}</td><td>${r.uniq?`<span class="dbt-badge blue">${r.uniq}</span>`:""}</td><td>${r.orderNo}</td><td>${r.partNo}</td><td>${r.nama}</td><td>${r.kanban}</td><td>${r.qty}</td><td>${r.lot}</td><td>${r.rack?`<span class="dbt-badge green">${r.rack}</span>`:""}</td><td>${r.supplier}</td><td>${statusBadgeHtml(r.status)}</td></tr>`).join(""))
    +`</table>`;
  renderDbPager(total,totalPages);
  if(!dbSizingPass){
    dbSizingPass=true;
    const changed=dbFitPageSize();
    dbSizingPass=false;
    if(changed) renderDbTable();
  }
}

/** Render kontrol pagination (info "X-Y dari Z" + tombol halaman, dgn "…" kalau halaman banyak). */
function renderDbPager(total,totalPages){
  const start=total?(dbPage-1)*DB_PAGE_SIZE+1:0;
  const end=Math.min(dbPage*DB_PAGE_SIZE,total);
  const addBtn=n=>`<button class="${n===dbPage?"on":""}" data-p="${n}">${n}</button>`;
  let pageBtns="";
  if(totalPages<=7){
    for(let i=1;i<=totalPages;i++) pageBtns+=addBtn(i);
  }else{
    const nums=new Set([1,2,totalPages-1,totalPages,dbPage-1,dbPage,dbPage+1].filter(n=>n>=1&&n<=totalPages));
    let prev=0;
    [...nums].sort((a,b)=>a-b).forEach(i=>{
      if(prev&&i-prev>1) pageBtns+=`<span class="dots">…</span>`;
      pageBtns+=addBtn(i); prev=i;
    });
  }
  document.getElementById("dbpager").innerHTML=
    `<span>Menampilkan ${start}-${end} dari ${total} data</span>
     <div class="pages">
       <button id="dbPrev" ${dbPage<=1?"disabled":""}>‹</button>
       ${pageBtns}
       <button id="dbNext" ${dbPage>=totalPages?"disabled":""}>›</button>
     </div>`;
  document.getElementById("dbPrev").onclick=()=>{ dbPage--; renderDbTable(); };
  document.getElementById("dbNext").onclick=()=>{ dbPage++; renderDbTable(); };
  document.querySelectorAll("#dbpager .pages button[data-p]").forEach(b=>b.onclick=()=>{ dbPage=+b.dataset.p; renderDbTable(); });
}
document.getElementById("dbSearch").addEventListener("input",()=>{ dbPage=1; applyDbSearch(); });
document.getElementById("dbClear").onclick=()=>{ document.getElementById("dbSearch").value=""; dbPage=1; applyDbSearch(); };

/** Download seluruh data P-Lane+Route yg lagi dipilih (bukan cuma hasil search) sbg file .xlsx asli
 * (server-side, OpenSpout — lihat api_progress_lane_excel() di api/progress_lane.php), gak lagi CSV
 * blob di browser. Sama pola dgn tombol Download Excel di Master Part. */
document.getElementById("dbDownload").onclick=()=>{
  const p=dbPlane.value||plane, route=dbRoute.value;
  if(!route){ toast("Pilih route dulu"); return; }
  location.href=`${API}?action=progress_lane_excel&p=${encodeURIComponent(p)}&route=${encodeURIComponent(route)}`;
};

/** Widget drag & drop (persis polanya kayak Pattern Unload) buat pilih dolly (1-8, bisa lebih dari 1) di 1 halte. */
function hdWidget(route, haltIdx, selArr){
  const selected=(selArr||[]).slice().sort((a,b)=>a-b);
  const available=Array.from({length:8},(_,k)=>k+1).filter(n=>!selected.includes(n));
  return `<div class="hd-widget" data-r="${route}" data-di="${haltIdx}">
    <ul class="hd-list">
      ${selected.map(n=>`<li class="hd-row" draggable="true" data-n="${n}">
        <span class="hd-draghandle">⠿</span><span class="hd-num">${n}</span>
        <button type="button" class="hd-del" data-n="${n}" title="Hapus dolly ini">×</button>
      </li>`).join("")}
    </ul>
    <select class="hd-add" title="Tambah nomor dolly" ${!available.length?"disabled":""}>
      <option value="">+ Dolly</option>
      ${available.map(n=>`<option value="${n}">${n}</option>`).join("")}
    </select>
  </div>`;
}
/** Refresh opsi dropdown "+ Dolly" 1 widget sesuai sisa nomor yg belum dipakai di situ. */
function hdRefreshAdd(widget){
  const used=new Set(Array.from(widget.querySelectorAll(".hd-row")).map(li=>+li.dataset.n));
  const available=Array.from({length:8},(_,k)=>k+1).filter(n=>!used.has(n));
  const sel=widget.querySelector(".hd-add");
  sel.innerHTML=`<option value="">+ Dolly</option>`+available.map(n=>`<option value="${n}">${n}</option>`).join("");
  sel.disabled=!available.length;
}
// Tambah dolly (dropdown "+ Dolly") & hapus dolly (tombol ×) di widget Halte->Dolly.
document.addEventListener("change", e=>{
  if(!e.target.matches(".hd-add")) return;
  const sel=e.target, widget=sel.closest(".hd-widget"), n=+sel.value;
  if(!n) return;
  const li=document.createElement("li");
  li.className="hd-row"; li.draggable=true; li.dataset.n=n;
  li.innerHTML=`<span class="hd-draghandle">⠿</span><span class="hd-num">${n}</span><button type="button" class="hd-del" data-n="${n}" title="Hapus dolly ini">×</button>`;
  widget.querySelector(".hd-list").appendChild(li);
  hdRefreshAdd(widget);
});
document.addEventListener("click", e=>{
  const del=e.target.closest(".hd-del");
  if(!del) return;
  const widget=del.closest(".hd-widget");
  del.closest(".hd-row").remove();
  hdRefreshAdd(widget);
});
// Drag & drop urutan chip dolly (event delegation, sama polanya kayak .pu-row/.pu-list di Pattern Unload).
let hdDragN=null;
document.addEventListener("dragstart", e=>{
  const row=e.target.closest(".hd-row");
  if(!row) return;
  hdDragN=row.dataset.n;
  row.classList.add("dragging");
  e.dataTransfer.effectAllowed="move";
  e.dataTransfer.setData("text/plain", hdDragN);
});
document.addEventListener("dragend", e=>{
  const row=e.target.closest(".hd-row");
  if(row) row.classList.remove("dragging");
  document.querySelectorAll(".hd-list.drag-over").forEach(l=>l.classList.remove("drag-over"));
  hdDragN=null;
});
document.addEventListener("dragover", e=>{
  const list=e.target.closest(".hd-list");
  if(!list || hdDragN===null) return;
  e.preventDefault();
  list.classList.add("drag-over");
  const draggingEl=list.querySelector(".hd-row.dragging");
  if(!draggingEl) return;
  const afterEl=hdDragAfterElement(list, e.clientY);
  if(afterEl==null) list.appendChild(draggingEl);
  else list.insertBefore(draggingEl, afterEl);
});
document.addEventListener("dragleave", e=>{
  const list=e.target.closest(".hd-list");
  if(list && !list.contains(e.relatedTarget)) list.classList.remove("drag-over");
});
function hdDragAfterElement(container, y){
  const els=[...container.querySelectorAll(".hd-row:not(.dragging)")];
  return els.reduce((closest, child)=>{
    const box=child.getBoundingClientRect();
    const offset=y-box.top-box.height/2;
    if(offset<0 && offset>closest.offset) return {offset, element:child};
    return closest;
  }, {offset:-Infinity, element:null}).element;
}
document.addEventListener("drop", e=>{
  const list=e.target.closest(".hd-list");
  if(!list || hdDragN===null) return;
  e.preventDefault();
  list.classList.remove("drag-over");
});

/** Isi ulang semua grid master data non-part (halte, cd mapping, rack, jalur, urutan supply). */
function buildGrids(){
  buildHalteGrid(); buildCdGrid();
  buildRacksTable(); buildPathTable();
  if(typeof buildOfcAll==="function") buildOfcAll(); // refresh section Counter Offset (Master Offset dkk, 15-offset-counter.js)
  if(typeof initPatternUnload==="function") initPatternUnload(); // refresh grid Pattern Unload kalau modulnya sudah dimuat
  if(typeof initMasterPart==="function") initMasterPart(); // refresh tabel CRUD Master Part (modul 17-master-part.js)
}

/* =====================================================================
   MASTER HALTE & RACK — route TETAP (gak bisa Add/Delete), cuma Edit (popup, 3 alamat)
   + widget Dolly inline (drag-drop, spt sebelumnya) yg disimpan terpisah lewat "Simpan Dolly".
   ===================================================================== */
let hmSelected=new Set();
function buildHalteGrid(){
  const q=(document.getElementById("hmSearch")?.value||"").trim().toLowerCase();
  const routes=allKnownRoutes().filter(r=>!q||r.toLowerCase().includes(q));
  document.getElementById("halteGrid").innerHTML=
   "<tr><th style=\"width:26px\"><input type=\"checkbox\" id=\"hmSelectAll\"></th><th>Route</th><th>Zone</th><th>Halte 1</th><th>Dolly 1</th><th>Halte 2</th><th>Dolly 2</th><th>Halte 3</th><th>Dolly 3</th></tr>"+
   (routes.length?routes.map(r=>`<tr data-r="${r}"><td><input type="checkbox" class="hm-chk" data-r="${r}" ${hmSelected.has(r)?"checked":""}></td><td>${r}</td><td>${puRouteZone(r)==="barat"?"WEST":"EAST"}</td>`+
     [0,1,2].map(i=>
       `<td>${puEsc((HALTE_MASTER[r]||[])[i]||"—")}</td>`+
       `<td>${hdWidget(r, i, (HALTE_DOLLY[r]||{})[i+1])}</td>`
     ).join("")+"</tr>").join("") : '<tr><td colspan="9" style="text-align:center;color:var(--mut)">Tidak ada data</td></tr>');
  const allChk=document.getElementById("hmSelectAll");
  allChk.checked=routes.length>0 && routes.every(r=>hmSelected.has(r));
  allChk.onchange=e=>{ routes.forEach(r=>{ if(e.target.checked) hmSelected.add(r); else hmSelected.delete(r); }); buildHalteGrid(); };
  document.querySelectorAll(".hm-chk").forEach(cb=>cb.onchange=()=>{ if(cb.checked) hmSelected.add(cb.dataset.r); else hmSelected.delete(cb.dataset.r); hmUpdateButtons(); });
  hmUpdateButtons();
}
function hmUpdateButtons(){ document.getElementById("hmEditBtn").disabled=hmSelected.size!==1; }
document.getElementById("hmSearch").addEventListener("input", buildHalteGrid);
document.getElementById("hmEditBtn").onclick=()=>{
  if(hmSelected.size!==1) return;
  const r=[...hmSelected][0]; const a=HALTE_MASTER[r]||[];
  document.getElementById("hmFormTitle").textContent="Edit Alamat Halte — Route "+r;
  document.getElementById("hmFormMsg").textContent="";
  document.getElementById("hmf1").value=a[0]||""; document.getElementById("hmf2").value=a[1]||""; document.getElementById("hmf3").value=a[2]||"";
  document.getElementById("hmFormModal").dataset.route=r;
  document.getElementById("hmFormModal").style.display="flex";
};
document.getElementById("hmFormCancel").onclick=()=>document.getElementById("hmFormModal").style.display="none";
document.getElementById("hmFormModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });
document.getElementById("hmFormSave").onclick=async()=>{
  const modal=document.getElementById("hmFormModal"); const r=modal.dataset.route;
  const vals=[document.getElementById("hmf1").value.trim(),document.getElementById("hmf2").value.trim(),document.getElementById("hmf3").value.trim()];
  HALTE_MASTER[r]=vals;
  try{
    await apiPost("save_master",{halte:{[r]:vals}});
    modal.style.display="none";
    toast("Alamat halte route "+r+" tersimpan");
    hmSelected.clear(); buildHalteGrid();
  }catch(e){ document.getElementById("hmFormMsg").textContent="Gagal simpan: "+e.message; }
};
document.getElementById("hmSaveDollyBtn").onclick=async()=>{
  document.querySelectorAll("#halteGrid tr[data-r]").forEach(tr=>{
    const r=tr.dataset.r; HALTE_DOLLY[r]=HALTE_DOLLY[r]||{};
    tr.querySelectorAll(".hd-widget").forEach(widget=>{
      const vals=Array.from(widget.querySelectorAll(".hd-row")).map(li=>+li.dataset.n).filter(n=>n>=1&&n<=8);
      HALTE_DOLLY[r][+widget.dataset.di+1]=vals;
    });
  });
  try{ await apiPost("save_master",{haltedolly:HALTE_DOLLY}); toast("Dolly tersimpan"); }
  catch(e){ toast("Gagal simpan dolly: "+e.message); }
};
document.getElementById("hmCsvBtn").onclick=()=>{
  const csv=["Route,Zone,Halte1,Halte2,Halte3", ...allKnownRoutes().map(r=>`${r},${puRouteZone(r)==="barat"?"WEST":"EAST"},"${(HALTE_MASTER[r]||[])[0]||""}","${(HALTE_MASTER[r]||[])[1]||""}","${(HALTE_MASTER[r]||[])[2]||""}"`)].join("\n");
  const blob=new Blob(["﻿"+csv],{type:"text/csv;charset=utf-8;"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="smms_halte_master.csv"; a.click(); URL.revokeObjectURL(a.href);
};

/* =====================================================================
   MAPPING COUNTDOWN -> HALTE — checkbox+search+Add/Edit/Delete(popup), simpan
   ulang FULL CD_MAP (spt sebelumnya, backend-nya emang TRUNCATE+reinsert semua).
   ===================================================================== */
let cdSelected=new Set();
function buildCdGrid(){
  const q=(document.getElementById("cdSearch")?.value||"").trim();
  const rows=CD_MAP.map((m,ri)=>[ri,m]).filter(([ri,m])=>!q||String(m.start).includes(q));
  document.getElementById("cdGrid").innerHTML=
   "<tr><th style=\"width:26px\"><input type=\"checkbox\" id=\"cdSelectAll\"></th><th>C/D P-Lane</th><th>Halte 1</th><th>Halte 2</th><th>Halte 3</th></tr>"+
   (rows.length?rows.map(([ri,m])=>`<tr data-ri="${ri}"><td><input type="checkbox" class="cd-chk" data-ri="${ri}" ${cdSelected.has(String(ri))?"checked":""}></td><td>${m.start}</td>`+
     m.h.map(h=>`<td>${h[0]}-${h[1]}</td>`).join("")+"</tr>").join("") : '<tr><td colspan="5" style="text-align:center;color:var(--mut)">Tidak ada data</td></tr>');
  const allChk=document.getElementById("cdSelectAll");
  allChk.checked=rows.length>0 && rows.every(([ri])=>cdSelected.has(String(ri)));
  allChk.onchange=e=>{ rows.forEach(([ri])=>{ if(e.target.checked) cdSelected.add(String(ri)); else cdSelected.delete(String(ri)); }); buildCdGrid(); };
  document.querySelectorAll(".cd-chk").forEach(cb=>cb.onchange=()=>{ if(cb.checked) cdSelected.add(cb.dataset.ri); else cdSelected.delete(cb.dataset.ri); cdUpdateButtons(); });
  cdUpdateButtons();
}
function cdUpdateButtons(){ document.getElementById("cdEditBtn").disabled=cdSelected.size!==1; document.getElementById("cdDeleteBtn").disabled=cdSelected.size<1; }
document.getElementById("cdSearch").addEventListener("input", buildCdGrid);

let cdFormMode="add", cdEditIdx=null;
function cdParseRange(s){ const m=String(s||"").match(/(\d+)\s*-\s*(\d+)/); return m?[+m[1],+m[2]]:[0,0]; }
function cdOpenForm(mode,idx){
  cdFormMode=mode; document.getElementById("cdFormTitle").textContent=mode==="add"?"Tambah C/D Awal":"Edit C/D Awal"; document.getElementById("cdFormMsg").textContent="";
  document.getElementById("cdfStart").disabled=(mode==="edit");
  if(mode==="edit"){
    cdEditIdx=idx; const m=CD_MAP[idx];
    document.getElementById("cdfStart").value=m.start;
    document.getElementById("cdf1").value=m.h[0].join("-"); document.getElementById("cdf2").value=m.h[1].join("-"); document.getElementById("cdf3").value=m.h[2].join("-");
  }else{
    cdEditIdx=null;
    document.getElementById("cdfStart").value=""; document.getElementById("cdf1").value=""; document.getElementById("cdf2").value=""; document.getElementById("cdf3").value="";
  }
  document.getElementById("cdFormModal").style.display="flex";
}
document.getElementById("cdAddBtn").onclick=()=>cdOpenForm("add");
document.getElementById("cdEditBtn").onclick=()=>{ if(cdSelected.size!==1) return; cdOpenForm("edit",+[...cdSelected][0]); };
document.getElementById("cdFormCancel").onclick=()=>document.getElementById("cdFormModal").style.display="none";
document.getElementById("cdFormModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });
document.getElementById("cdFormSave").onclick=async()=>{
  const start=+document.getElementById("cdfStart").value;
  if(!start){ document.getElementById("cdFormMsg").textContent="C/D Awal wajib diisi"; return; }
  const h=[cdParseRange(document.getElementById("cdf1").value),cdParseRange(document.getElementById("cdf2").value),cdParseRange(document.getElementById("cdf3").value)];
  if(cdFormMode==="edit") CD_MAP[cdEditIdx].h=h;
  else{
    if(CD_MAP.some(m=>m.start===start)){ document.getElementById("cdFormMsg").textContent="C/D Awal "+start+" sudah ada"; return; }
    CD_MAP.push({start,h});
  }
  try{
    await apiPost("save_master",{cdmap:CD_MAP});
    document.getElementById("cdFormModal").style.display="none";
    toast(cdFormMode==="add"?"C/D Awal ditambahkan":"C/D Awal diperbarui");
    cdSelected.clear(); buildCdGrid(); buildPlaneSel();
  }catch(e){ document.getElementById("cdFormMsg").textContent="Gagal simpan: "+e.message; }
};
document.getElementById("cdDeleteBtn").onclick=()=>{ if(!cdSelected.size) return; document.getElementById("cdDeleteCount").textContent=cdSelected.size; document.getElementById("cdDeleteModal").style.display="flex"; };
document.getElementById("cdDeleteCancel").onclick=()=>document.getElementById("cdDeleteModal").style.display="none";
document.getElementById("cdDeleteModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });
document.getElementById("cdDeleteConfirm").onclick=async()=>{
  const idxs=[...cdSelected].map(Number).sort((a,b)=>b-a);
  idxs.forEach(i=>CD_MAP.splice(i,1));
  try{
    await apiPost("save_master",{cdmap:CD_MAP});
    document.getElementById("cdDeleteModal").style.display="none";
    toast(`${idxs.length} baris dihapus`);
    cdSelected.clear(); buildCdGrid(); buildPlaneSel();
  }catch(e){ toast("Gagal hapus: "+e.message); }
};
document.getElementById("cdCsvBtn").onclick=()=>{
  const csv=["CD_Awal,Halte1,Halte2,Halte3", ...CD_MAP.map(m=>`${m.start},${m.h[0].join("-")},${m.h[1].join("-")},${m.h[2].join("-")}`)].join("\n");
  const blob=new Blob(["﻿"+csv],{type:"text/csv;charset=utf-8;"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="smms_cd_mapping.csv"; a.click(); URL.revokeObjectURL(a.href);
};

/* =====================================================================
   MASTER RACK (Posisi) — checkbox+search+pagination+popup Add/Edit/Delete,
   mutasi langsung CFG.racks lalu saveCfg() (replace penuh smms_racks+smms_route_path,
   sudah ada dari Editor — dipakai ulang di sini, gak perlu endpoint API baru).
   ===================================================================== */
const RK_PAGE_SIZE=15;
let rkFiltered=[], rkSelected=new Set(), rkPage=1;

function rkRowHtml(i,r){
  return `<tr data-i="${i}"><td><input type="checkbox" class="rk-chk" data-i="${i}" ${rkSelected.has(String(i))?"checked":""}></td>`+
    `<td>${puEsc(r.addr)}</td><td>${r.x.toFixed(1)}</td><td>${r.y.toFixed(1)}</td></tr>`;
}
/** Tampilkan alamat rack yang MUNCUL di data part (ADDRESSES, dari upload Progress Lane) tapi
 * BELUM ditempatkan di peta (CFG.racks) — part-nya jadi gak akan pernah kelihatan garis/rack tujuan
 * di Monitor sampai posisinya ditambahin di sini (atau tab Editor, mode "+ Rack"). */
function rkRefreshMissingWarn(){
  const el=document.getElementById("rkMissingWarn");
  if(!el) return;
  const placed=new Set(CFG.racks.map(r=>r.addr));
  const missing=(ADDRESSES||[]).filter(a=>!placed.has(a)).sort();
  if(!missing.length){ el.style.display="none"; el.innerHTML=""; return; }
  el.style.display="";
  el.innerHTML=`<div class="swarn bad">⚠ ${missing.length} alamat rack dipakai di data part tapi belum ditempatkan di peta: `
    +missing.map(a=>puEsc(a)).join(", ")+`</div>`;
}
function buildRacksTable(){
  rkRefreshMissingWarn();
  const q=(document.getElementById("rkSearch")?.value||"").trim().toLowerCase();
  rkFiltered=CFG.racks.map((r,i)=>[i,r]).filter(([i,r])=>!q||r.addr.toLowerCase().includes(q));
  const total=rkFiltered.length, totalPages=Math.max(1,Math.ceil(total/RK_PAGE_SIZE));
  if(rkPage>totalPages) rkPage=totalPages;
  const start=(rkPage-1)*RK_PAGE_SIZE;
  const page=rkFiltered.slice(start,start+RK_PAGE_SIZE);
  const box=document.getElementById("racksTableBox");
  box.innerHTML=!CFG.racks.length ? '<p class="meta">Belum ada rack.</p>' :
    `<div style="overflow-x:auto"><table class="grid compact"><tr><th style="width:26px"><input type="checkbox" id="rkSelectAll"></th><th>Address</th><th>X</th><th>Y</th></tr>`+
    (page.length?page.map(([i,r])=>rkRowHtml(i,r)).join(""):'<tr><td colspan="4" style="text-align:center;color:var(--mut)">Tidak ada data</td></tr>')+`</table></div>`;
  if(CFG.racks.length){
    const allChk=document.getElementById("rkSelectAll");
    allChk.checked=page.length>0 && page.every(([i])=>rkSelected.has(String(i)));
    allChk.onchange=e=>{ page.forEach(([i])=>{ if(e.target.checked) rkSelected.add(String(i)); else rkSelected.delete(String(i)); }); buildRacksTable(); };
    document.querySelectorAll(".rk-chk").forEach(cb=>cb.onchange=()=>{ if(cb.checked) rkSelected.add(cb.dataset.i); else rkSelected.delete(cb.dataset.i); rkUpdateButtons(); });
  }
  rkRenderPager(total,totalPages);
  rkUpdateButtons();
}
function rkRenderPager(total,totalPages){
  const start=total?(rkPage-1)*RK_PAGE_SIZE+1:0, end=Math.min(rkPage*RK_PAGE_SIZE,total);
  const addBtn=n=>`<button class="${n===rkPage?"on":""}" data-p="${n}">${n}</button>`;
  let pageBtns=""; if(totalPages<=7){ for(let i=1;i<=totalPages;i++) pageBtns+=addBtn(i); }
  else{ const nums=new Set([1,2,totalPages-1,totalPages,rkPage-1,rkPage,rkPage+1].filter(n=>n>=1&&n<=totalPages)); let prev=0;
    [...nums].sort((a,b)=>a-b).forEach(i=>{ if(prev&&i-prev>1) pageBtns+=`<span class="dots">…</span>`; pageBtns+=addBtn(i); prev=i; }); }
  document.getElementById("rkPager").innerHTML=!total?"":`<span>Menampilkan ${start}-${end} dari ${total} rack</span><div class="pages"><button id="rkPrev" ${rkPage<=1?"disabled":""}>‹</button>${pageBtns}<button id="rkNext" ${rkPage>=totalPages?"disabled":""}>›</button></div>`;
  if(total){ document.getElementById("rkPrev").onclick=()=>{rkPage--;buildRacksTable();}; document.getElementById("rkNext").onclick=()=>{rkPage++;buildRacksTable();};
    document.querySelectorAll("#rkPager .pages button[data-p]").forEach(b=>b.onclick=()=>{rkPage=+b.dataset.p;buildRacksTable();}); }
}
function rkUpdateButtons(){
  document.getElementById("rkEditBtn").disabled=rkSelected.size!==1;
  document.getElementById("rkDeleteBtn").disabled=rkSelected.size<1;
  // Align/Ratakan Jarak bisa dipakai ke RACK, TITIK JALUR, atau CAMPURAN keduanya sekaligus — makanya
  // dihitung dari total rkSelected+ptSelected, bukan rkSelected doang (beda dari Edit/Delete di atas
  // yg emang murni aksi tabel rack, gak berlaku ke titik jalur).
  const total=rkSelected.size+ptSelected.size;
  document.getElementById("rkAlignXBtn").disabled=total<2;
  document.getElementById("rkAlignYBtn").disabled=total<2;
  document.getElementById("rkDistXBtn").disabled=total<3;
  document.getElementById("rkDistYBtn").disabled=total<3;
  // Tombol yg sama juga ada di toolbar Editor (pilih langsung di denah) — disable/enable-nya ngikutin
  // seleksi yg sama persis, biar sinkron mau dipilih dari tabel Database atau dari denah.
  const edX=document.getElementById("edRkAlignXBtn"), edY=document.getElementById("edRkAlignYBtn");
  const edDX=document.getElementById("edRkDistXBtn"), edDY=document.getElementById("edRkDistYBtn");
  if(edX) edX.disabled=total<2;
  if(edY) edY.disabled=total<2;
  if(edDX) edDX.disabled=total<3;
  if(edDY) edDY.disabled=total<3;
}
/** Kumpulkan SEMUA titik yg lagi diseleksi — rack (rkSelected) DAN/ATAU titik jalur (ptSelected) —
 * jadi 1 list referensi objek {x,y} asli (bukan salinan), biar Align/Distribute bisa langsung
 * ngedit x/y-nya di tempat, gak peduli asalnya dari CFG.racks atau CFG.paths[route]. */
function selectedAlignPoints(){
  const pts=[];
  rkSelected.forEach(i=>{ const o=CFG.racks[+i]; if(o) pts.push(o); });
  ptSelected.forEach(key=>{ const [r,i]=key.split("|"); const o=CFG.paths[r]&&CFG.paths[r][+i]; if(o) pts.push(o); });
  return pts;
}
/** Samakan koordinat (X atau Y) semua titik terpilih (rack dan/atau titik jalur) jadi rata-rata
 * mereka, biar jadi 1 garis lurus. Sumbu SATUNYA gak disentuh — kalau mau jaraknya sekalian
 * diratakan, pakai tombol Ratakan X/Y terpisah (rkDistribute) SETELAH ini. */
async function rkAlign(axis){
  const pts=selectedAlignPoints();
  if(pts.length<2) return;
  pushHistory(snapshotCfg());
  const avg=pts.reduce((s,o)=>s+o[axis],0)/pts.length;
  pts.forEach(o=>o[axis]=avg);
  await saveCfg();
  toast(`${pts.length} titik disejajarkan (${axis.toUpperCase()}=${avg.toFixed(1)})`);
  buildRacksTable(); redrawAll();
}
/** Sebar rata JARAK semua titik terpilih (rack dan/atau titik jalur) di 1 sumbu (X atau Y) —
 * TERPISAH dari Align, sumbu satunya gak disentuh sama sekali. Titik plg kecil & plg besar (posisi
 * existing-nya) jadi patokan ujung, yg di tengah-tengah disebar rata jaraknya di antara keduanya.
 * Butuh min. 3 titik (2 titik selalu "rata" trivial, gak ada yg perlu disebar di tengah). */
async function rkDistribute(axis){
  const pts=selectedAlignPoints();
  if(pts.length<3){ toast("Pilih minimal 3 titik buat meratakan jarak"); return; }
  pushHistory(snapshotCfg());
  const sorted=[...pts].sort((a,b)=>a[axis]-b[axis]);
  const lo=sorted[0][axis], hi=sorted[sorted.length-1][axis];
  const step=(hi-lo)/(sorted.length-1);
  sorted.forEach((o,k)=>{ o[axis]=lo+step*k; });
  await saveCfg();
  toast(`Jarak ${axis.toUpperCase()} ${pts.length} titik diratakan`);
  buildRacksTable(); redrawAll();
}
document.getElementById("rkAlignXBtn").onclick=()=>rkAlign("x");
document.getElementById("rkAlignYBtn").onclick=()=>rkAlign("y");
document.getElementById("rkDistXBtn").onclick=()=>rkDistribute("x");
document.getElementById("rkDistYBtn").onclick=()=>rkDistribute("y");
document.getElementById("edRkAlignXBtn").onclick=()=>rkAlign("x");
document.getElementById("edRkAlignYBtn").onclick=()=>rkAlign("y");
document.getElementById("edRkDistXBtn").onclick=()=>rkDistribute("x");
document.getElementById("edRkDistYBtn").onclick=()=>rkDistribute("y");
document.getElementById("rkSearch").addEventListener("input",()=>{ rkPage=1; buildRacksTable(); });

let rkFormMode="add", rkEditIdx=null;
function rkOpenForm(mode,idx){
  rkFormMode=mode; document.getElementById("rkFormTitle").textContent=mode==="add"?"Tambah Rack":"Edit Rack"; document.getElementById("rkFormMsg").textContent="";
  if(mode==="edit"){ rkEditIdx=idx; const r=CFG.racks[idx]; document.getElementById("rkfAddr").value=r.addr; document.getElementById("rkfX").value=r.x; document.getElementById("rkfY").value=r.y; }
  else{ rkEditIdx=null; document.getElementById("rkfAddr").value=""; document.getElementById("rkfX").value=""; document.getElementById("rkfY").value=""; }
  document.getElementById("rkFormModal").style.display="flex";
}
document.getElementById("rkAddBtn").onclick=()=>rkOpenForm("add");
document.getElementById("rkEditBtn").onclick=()=>{ if(rkSelected.size!==1) return; rkOpenForm("edit",+[...rkSelected][0]); };
document.getElementById("rkFormCancel").onclick=()=>document.getElementById("rkFormModal").style.display="none";
document.getElementById("rkFormModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });
document.getElementById("rkFormSave").onclick=async()=>{
  const addr=document.getElementById("rkfAddr").value.trim();
  const x=+document.getElementById("rkfX").value, y=+document.getElementById("rkfY").value;
  if(!addr){ document.getElementById("rkFormMsg").textContent="Address wajib diisi"; return; }
  // Address yg udah dipakai rack LAIN gak boleh dipakai lagi (cegah duplikat) — rack yg lagi diedit
  // sendiri dikecualikan (boleh disave ulang tanpa ganti address).
  if(CFG.racks.some((r,i)=>r.addr===addr && i!==rkEditIdx)){ document.getElementById("rkFormMsg").textContent=`Address "${addr}" sudah dipakai rack lain`; return; }
  if(rkFormMode==="edit") Object.assign(CFG.racks[rkEditIdx],{addr,x,y});
  else CFG.racks.push({addr,x,y});
  await saveCfg();
  document.getElementById("rkFormModal").style.display="none";
  toast(rkFormMode==="add"?"Rack ditambahkan":"Rack diperbarui");
  rkSelected.clear(); buildRacksTable(); redrawAll(); buildAddrList();
};
document.getElementById("rkDeleteBtn").onclick=()=>{ if(!rkSelected.size) return; document.getElementById("rkDeleteCount").textContent=rkSelected.size; document.getElementById("rkDeleteModal").style.display="flex"; };
document.getElementById("rkDeleteCancel").onclick=()=>document.getElementById("rkDeleteModal").style.display="none";
document.getElementById("rkDeleteModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });
document.getElementById("rkDeleteConfirm").onclick=async()=>{
  const idxs=[...rkSelected].map(Number).sort((a,b)=>b-a);
  idxs.forEach(i=>CFG.racks.splice(i,1));
  await saveCfg();
  document.getElementById("rkDeleteModal").style.display="none";
  toast(`${idxs.length} rack dihapus`);
  rkSelected.clear(); buildRacksTable(); redrawAll(); buildAddrList();
};
document.getElementById("rkCsvBtn").onclick=()=>{
  const csv=["Address,X,Y", ...CFG.racks.map(r=>`"${r.addr}",${r.x},${r.y}`)].join("\n");
  const blob=new Blob(["﻿"+csv],{type:"text/csv;charset=utf-8;"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="smms_racks.csv"; a.click(); URL.revokeObjectURL(a.href);
};

/* =====================================================================
   MASTER JALUR ROUTE (path) — sama pola dgn Rack, tiap baris = 1 titik jalur
   (route+index), mutasi CFG.paths lalu saveCfg().
   ===================================================================== */
const PTH_PAGE_SIZE=15;
let pthFlat=[], pthFiltered=[], pthSelected=new Set(), pthPage=1;

function pthRebuildFlat(){
  pthFlat=[];
  Object.keys(CFG.paths).filter(r=>CFG.paths[r].length).sort().forEach(r=>{
    CFG.paths[r].forEach((p,i)=>pthFlat.push({route:r,idx:i,p}));
  });
}
function pthKey(item){ return item.route+"|"+item.idx; }
function pthRowHtml(item){
  const k=pthKey(item), p=item.p;
  return `<tr data-k="${k}"><td><input type="checkbox" class="pth-chk" data-k="${k}" ${pthSelected.has(k)?"checked":""}></td>`+
    `<td>${item.route}</td><td>${item.idx}</td><td>${p.x.toFixed(1)}</td><td>${p.y.toFixed(1)}</td><td>${p.h||"—"}</td><td>${p.stage||"—"}</td></tr>`;
}
function buildPathTable(){
  pthRebuildFlat();
  const q=(document.getElementById("pthSearch")?.value||"").trim().toLowerCase();
  pthFiltered=!q?pthFlat:pthFlat.filter(it=>it.route.toLowerCase().includes(q));
  const total=pthFiltered.length, totalPages=Math.max(1,Math.ceil(total/PTH_PAGE_SIZE));
  if(pthPage>totalPages) pthPage=totalPages;
  const start=(pthPage-1)*PTH_PAGE_SIZE;
  const page=pthFiltered.slice(start,start+PTH_PAGE_SIZE);
  const box=document.getElementById("pathTableBox");
  box.innerHTML=!pthFlat.length ? '<p class="meta">Belum ada jalur.</p>' :
    `<div style="overflow-x:auto"><table class="grid compact"><tr><th style="width:26px"><input type="checkbox" id="pthSelectAll"></th><th>Route</th><th>Seq</th><th>X</th><th>Y</th><th>Halte</th><th>Stage</th></tr>`+
    (page.length?page.map(pthRowHtml).join(""):'<tr><td colspan="7" style="text-align:center;color:var(--mut)">Tidak ada data</td></tr>')+`</table></div>`;
  if(pthFlat.length){
    const allChk=document.getElementById("pthSelectAll");
    allChk.checked=page.length>0 && page.every(it=>pthSelected.has(pthKey(it)));
    allChk.onchange=e=>{ page.forEach(it=>{ const k=pthKey(it); if(e.target.checked) pthSelected.add(k); else pthSelected.delete(k); }); buildPathTable(); };
    document.querySelectorAll(".pth-chk").forEach(cb=>cb.onchange=()=>{ if(cb.checked) pthSelected.add(cb.dataset.k); else pthSelected.delete(cb.dataset.k); pthUpdateButtons(); });
  }
  pthRenderPager(total,totalPages);
  pthUpdateButtons();
}
function pthRenderPager(total,totalPages){
  const start=total?(pthPage-1)*PTH_PAGE_SIZE+1:0, end=Math.min(pthPage*PTH_PAGE_SIZE,total);
  const addBtn=n=>`<button class="${n===pthPage?"on":""}" data-p="${n}">${n}</button>`;
  let pageBtns=""; if(totalPages<=7){ for(let i=1;i<=totalPages;i++) pageBtns+=addBtn(i); }
  else{ const nums=new Set([1,2,totalPages-1,totalPages,pthPage-1,pthPage,pthPage+1].filter(n=>n>=1&&n<=totalPages)); let prev=0;
    [...nums].sort((a,b)=>a-b).forEach(i=>{ if(prev&&i-prev>1) pageBtns+=`<span class="dots">…</span>`; pageBtns+=addBtn(i); prev=i; }); }
  document.getElementById("pthPager").innerHTML=!total?"":`<span>Menampilkan ${start}-${end} dari ${total} titik</span><div class="pages"><button id="pthPrev" ${pthPage<=1?"disabled":""}>‹</button>${pageBtns}<button id="pthNext" ${pthPage>=totalPages?"disabled":""}>›</button></div>`;
  if(total){ document.getElementById("pthPrev").onclick=()=>{pthPage--;buildPathTable();}; document.getElementById("pthNext").onclick=()=>{pthPage++;buildPathTable();};
    document.querySelectorAll("#pthPager .pages button[data-p]").forEach(b=>b.onclick=()=>{pthPage=+b.dataset.p;buildPathTable();}); }
}
function pthUpdateButtons(){ document.getElementById("pthEditBtn").disabled=pthSelected.size!==1; document.getElementById("pthDeleteBtn").disabled=pthSelected.size<1; }
document.getElementById("pthSearch").addEventListener("input",()=>{ pthPage=1; buildPathTable(); });

let pthFormMode="add", pthEditKey=null;
function pthOpenForm(mode,item){
  pthFormMode=mode; document.getElementById("pthFormTitle").textContent=mode==="add"?"Tambah Titik Jalur":"Edit Titik Jalur"; document.getElementById("pthFormMsg").textContent="";
  if(mode==="edit"){
    pthEditKey={route:item.route,idx:item.idx};
    document.getElementById("pthfRoute").value=item.route; document.getElementById("pthfSeq").value=item.idx;
    document.getElementById("pthfX").value=item.p.x; document.getElementById("pthfY").value=item.p.y; document.getElementById("pthfH").value=item.p.h||0;
  }else{
    pthEditKey=null;
    document.getElementById("pthfRoute").value=""; document.getElementById("pthfSeq").value=(CFG.paths[document.getElementById("pthfRoute").value]||[]).length;
    document.getElementById("pthfX").value=""; document.getElementById("pthfY").value=""; document.getElementById("pthfH").value=0;
  }
  document.getElementById("pthFormModal").style.display="flex";
}
document.getElementById("pthAddBtn").onclick=()=>pthOpenForm("add");
document.getElementById("pthEditBtn").onclick=()=>{
  if(pthSelected.size!==1) return;
  const k=[...pthSelected][0]; const item=pthFlat.find(it=>pthKey(it)===k);
  if(item) pthOpenForm("edit",item);
};
document.getElementById("pthFormCancel").onclick=()=>document.getElementById("pthFormModal").style.display="none";
document.getElementById("pthFormModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });
document.getElementById("pthFormSave").onclick=async()=>{
  const route=document.getElementById("pthfRoute").value.trim().toUpperCase();
  const x=+document.getElementById("pthfX").value, y=+document.getElementById("pthfY").value, h=+document.getElementById("pthfH").value||0;
  if(!route){ document.getElementById("pthFormMsg").textContent="Route wajib diisi"; return; }
  CFG.paths[route]=CFG.paths[route]||[];
  if(pthFormMode==="edit" && pthEditKey && pthEditKey.route===route){
    Object.assign(CFG.paths[route][pthEditKey.idx],{x,y,h});
  }else{
    if(pthFormMode==="edit" && pthEditKey){ CFG.paths[pthEditKey.route].splice(pthEditKey.idx,1); } // route diganti: hapus dari route lama
    CFG.paths[route].push({x,y,h,stage:null});
  }
  await saveCfg();
  document.getElementById("pthFormModal").style.display="none";
  toast(pthFormMode==="add"?"Titik ditambahkan":"Titik diperbarui");
  pthSelected.clear(); buildPathTable(); redrawAll();
};
document.getElementById("pthDeleteBtn").onclick=()=>{ if(!pthSelected.size) return; document.getElementById("pthDeleteCount").textContent=pthSelected.size; document.getElementById("pthDeleteModal").style.display="flex"; };
document.getElementById("pthDeleteCancel").onclick=()=>document.getElementById("pthDeleteModal").style.display="none";
document.getElementById("pthDeleteModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });
document.getElementById("pthDeleteConfirm").onclick=async()=>{
  const keys=[...pthSelected];
  // urutkan hapus dari index TERBESAR dulu per route, biar index yg lebih kecil gak kegeser sebelum kehapus
  const byRoute={};
  keys.forEach(k=>{ const [route,idx]=k.split("|"); (byRoute[route]=byRoute[route]||[]).push(+idx); });
  Object.entries(byRoute).forEach(([route,idxs])=>{ idxs.sort((a,b)=>b-a).forEach(i=>CFG.paths[route].splice(i,1)); });
  await saveCfg();
  document.getElementById("pthDeleteModal").style.display="none";
  toast(`${keys.length} titik dihapus`);
  pthSelected.clear(); buildPathTable(); redrawAll();
};
document.getElementById("pthCsvBtn").onclick=()=>{
  pthRebuildFlat();
  const csv=["Route,Seq,X,Y,Halte,Stage", ...pthFlat.map(it=>`${it.route},${it.idx},${it.p.x},${it.p.y},${it.p.h||0},${it.p.stage||""}`)].join("\n");
  const blob=new Blob(["﻿"+csv],{type:"text/csv;charset=utf-8;"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="smms_route_path.csv"; a.click(); URL.revokeObjectURL(a.href);
};

