/* =====================================================================
   03-COUNTDOWN — matematika posisi towing/dolly di sepanjang jalur,
   dan pemetaan dolly -> supplier.
   ===================================================================== */

// Angka countdown di mana towing dianggap sudah sampai tujuan akhir (biasanya 1).
const CD_END = 1;

// Kecepatan towing bergerak antar-tick (px per detik) — dipakai animateCd/stepCd buat ngitung durasi
// animasi 1 tick berdasar JARAK sebenarnya yg ditempuh (bukan durasi tetap kayak dulu), biar towing
// gak jalan lebih cepat/lambat dari kecepatan nyatanya cuma krn jarak antar-halte beda-beda. `let`
// (bukan const) krn bisa diubah manual dari dropdown "Kecepatan Towing" di header (08-header.js),
// nilainya disimpan ke smms_meta.tow_speed & dimuat balik di bootstrap() (02-api.js).
let TOW_SPEED = 30;

/**
 * Durasi (ms) animasi towing route ini dari fromCd ke toCd, berdasar JARAK sebenarnya (px, arc-length)
 * yg ditempuh dibagi TOW_SPEED — dipakai animateCd (lihat 06-render.js) supaya kecepatan towing
 * konsisten px/detiknya, bukan cuma "1 tick = sekian ms" tanpa peduli jaraknya. Fallback ke durasi
 * tetap kalau route-nya blm punya jalur (mis. belum digambar di Editor).
 */
function towTickDurationMs(route, fromCd, toCd){
  const a=towProgress(route, fromCd), b=towProgress(route, toCd);
  if(!a || !b) return 1100;
  const dist=Math.abs(b.target-a.target);
  return Math.max(200, (dist/TOW_SPEED)*1000);
}

/** Halte aktif saat ini utk route yang sedang dipilih (dipakai highlight rack & panel Muatan). */
function halteInfo(val){
  // Karena letak halte setiap rute berbeda-beda di kanvas,
  // indikator "Halte Aktif" UI kita ambil dari posisi fisik rute yang sedang dipilih.
  if(!selRoute) return { no: 0 };
  const p = towXY(selRoute, val);
  return { no: p ? p.halte : 0 };
}

/**
 * Cocokkan 1 baris Master Offset (OFFSET_TABLE) ke 1 nilai countdown — offset boleh angka tunggal
 * (match persis) atau rentang teks "max-min" (match kalau cdVal di antara keduanya, dipakai HALTE
 * 1/2/3 & bekas Posisi Offset). Dipakai bareng oleh offsetStatusFor & offsetPositionFor di bawah —
 * SATU-satunya tempat parsing "offset boleh angka atau rentang" ditulis (dulu ada 2 salinan logic
 * krn 2 tabel terpisah, sekarang 1 tabel jadi cukup 1 fungsi cocok).
 */
function offsetRowMatches(r, cdVal){
  const ov=String(r.offset).trim();
  const m=ov.match(/^(\d+)\s*-\s*(\d+)$/);
  return m ? (cdVal<=+m[1] && cdVal>=+m[2]) : (+ov===cdVal);
}

/**
 * Cari status route ini di Master Offset (OFFSET_TABLE) utk Volume=cdStart & countdown sekarang —
 * dipakai "HALTE AKTIF" di header supaya ikut data Master Offset (bukan cuma cd_mapping lama).
 * null kalau gak ada baris yg cocok utk route+volume ini.
 */
function offsetStatusFor(route, cdVal, volume){
  if(!route) return null;
  for(const r of OFFSET_TABLE){
    if(r.route!==route || +r.volume!==volume) continue;
    if(offsetRowMatches(r, cdVal)) return r.process;
  }
  return null;
}

/**
 * "POSISI AKTIF" di header — dulu dari tabel TERPISAH (Master Offset Position/smms_offset_position,
 * pola wp_app_offset vs wp_app_offset_position di IIS), SEKARANG digabung jadi 1 tabel dgn Master
 * Offset biasa (OFFSET_TABLE) sesuai template Excel sumber (Dock|Process|Zone|Route|Lane|Volume|
 * Offset, tanpa Address) — rentang offset_max/offset_min yg dulu terpisah sekarang ditulis sbg
 * teks "max-min" di kolom offset yang sama, dicocokkan pakai offsetRowMatches() yang sama persis
 * dgn offsetStatusFor. null kalau gak ada baris yg cocok (fallback tetap dipakai, lihat di bawah).
 */
function offsetPositionFor(route, cdVal, volume){
  if(!route) return null;
  for(const r of OFFSET_TABLE){
    if(r.route!==route || +r.volume!==volume) continue;
    if(offsetRowMatches(r, cdVal)) return r.process;
  }
  // Fallback kalau route+volume ini belum ada baris Master Offset yg cocok sama sekali: pakai
  // threshold tetap ala IIS punya get_position() (count_down<=2->B/PASS, <=4->EMPTY, selain itu
  // gak nunjuk apa-apa) — cuma dipakai selama datanya belum diisi manual di atas, begitu ada baris
  // yg cocok, itu yg menang (upload/isi Master Offset kapan aja buat nimpa fallback ini).
  if(cdVal<=2) return "PREPARE";
  if(cdVal<=4) return "EMPTY";
  return null;
}

/** Ambil Supply Offset (offset_val) route ini dari Master Offset (OFFSET_TABLE), KHUSUS baris
 * process='SUPPLY' (dicocokkan by route+Volume=cdStart) — basis SATU-SATUNYA rumus CD Route
 * (cdRouteFor di bawah). Beda dari offsetStatusFor di atas (itu buat cari PROSES yg aktif di 1 cdVal
 * tertentu, offset-nya bisa berupa rentang "max-min") — di sini offset SELALU angka tunggal (bukan
 * rentang), dipakai sbg nilai TAMBAH tetap, bukan threshold. null kalau route/volume ini belum py
 * baris Supply Offset (data blm diisi manual di Master Offset). */
function supplyOffsetFor(route, volume){
  if(!route) return null;
  for(const r of OFFSET_TABLE){
    if(r.route!==route || +r.volume!==volume) continue;
    if(String(r.process||"").trim().toUpperCase()!=="SUPPLY") continue;
    const n=parseInt(r.offset,10);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

/**
 * CD Route ("Andon Supply") — dikonfirmasi user via referensi nyata "BATON PASS EAST ZONE" (tiap
 * route py countdown SENDIRI-SENDIRI yg beda, bukan bareng-bareng lagi kayak sebelumnya) — rumus
 * PERSIS (dites cocok dgn contoh angka user: Volume=23, CD_Plane=13, offset 9/6/0/21/18 -> CD
 * 22/19/13/11/8):
 *
 *   CD_Route = MOD(CD_Plane - 1 + Supply_Offset, Volume) + 1
 *
 * (pola "1-indexed modulo" standar — hasil SELALU 1..Volume, gak pernah 0/negatif; `((...)%volume+
 * volume)%volume` jaga2 dari hasil negatif kalau offset/CD_Plane kombinasinya bikin sisa MOD negatif,
 * krn operator % JavaScript beda dari MOD matematis pas operand-nya negatif).
 *
 * INI SEKARANG DIPAKAI nentuin posisi towing/dolly TIAP ROUTE (lihat towProgress di bawah) — GANTI
 * `cd` bersama polos yg dulu dipakai SEMUA route bareng2 (towing lockstep). Andon Plane (COUNT DOWN
 * di header, `cd` mentah) TETAP TIDAK BERUBAH sama sekali — itu "cd utamanya"/patokan utama
 * (dikonfirmasi user eksplisit) — cdRouteFor ini ("Andon Supply") yg dipakai di TEMPAT LAIN yg
 * menampilkan info per-route (HALTE AKTIF/POSISI AKTIF di header, sidebar Status Towing, posisi
 * towing itu sendiri). Fallback ke cdPlane APA ADANYA kalau route ini belum py Supply Offset (biar
 * gak NaN/macet — route itu ya "gak ke-geser" dari CD Plane biasa, PERSIS perilaku lama).
 */
function cdRouteFor(route, cdPlane, volume){
  if(!volume || volume<=0) return cdPlane;
  const off=supplyOffsetFor(route, volume);
  if(off===null) return cdPlane;
  return ((cdPlane-1+off) % volume + volume) % volume + 1;
}

const routeParts=r=>PLANEDATA[r]||[];
const routeRackSet=r=>new Set(routeParts(r).map(p=>p[5]));

/**
 * Rack(s) alamat tujuan dari isi 1 slot dolly (grup supplier) — dicocokkan by address PERSIS (p[5])
 * ke CFG.racks, di-dedupe per address (1 grup bisa punya banyak part tapi tujuannya sama). Dipakai
 * gambar garis dolly -> rack pas dolly itu lagi aktif disupply (lihat redrawAll/moveTowings, 06-render.js).
 */
function dollySupplyRacks(group){
  if(!group || !group.parts || !group.parts.length) return [];
  const seen=new Set(); const out=[];
  group.parts.forEach(p=>{
    const addr=p[5]; if(!addr||seen.has(addr)) return;
    const rk=CFG.racks.find(x=>x.addr===addr);
    if(rk){ seen.add(addr); out.push(rk); }
  });
  return out;
}

/** Hitung panjang tiap segmen jalur sekali saja, dipakai bareng oleh towing & ke-8 dolly di belakangnya. */
function pathMetrics(path){
  let lens = [], totalLength = 0;
  for(let i = 1; i < path.length; i++){
    const d = Math.hypot(path[i].x - path[i-1].x, path[i].y - path[i-1].y);
    lens.push(d); totalLength += d;
  }
  return {lens, totalLength};
}

/** Titik koordinat pada jarak tempuh tertentu (pixel, arc-length) sepanjang jalur. */
function pointAtDistance(path, metrics, dist){
  const lens = metrics.lens;
  let target = Math.max(0, Math.min(dist, metrics.totalLength));
  let currentHalte = 0;
  for(let i = 0; i < lens.length; i++){
    if (path[i].h) currentHalte = path[i].h;
    if (target <= lens[i] || i === lens.length - 1) {
      const k = lens[i] ? Math.min(1, target / lens[i]) : 1;
      // k===1 gak dipakai strict — "target" sering hasil pengurangan berantai dari arc-length yg
      // DIHITUNG PERSIS sama panjangnya kayak lens[i] (mis. towing lagi diam PERSIS di titik halte,
      // lihat haltTargetArcLength) tapi urutan operasi floating-point-nya beda, jadi k bisa jadi
      // 0.999999999999999x bukan 1 persis — akibatnya titik halte gagal kedeteksi & dolly gak
      // pernah keanggep "lagi di halte" (gak berkedip/ganti warna). Toleransi kecil biar tetap kehitung.
      if (k >= 1-1e-6 && path[i+1] && path[i+1].h) currentHalte = path[i+1].h;
      return {
        x: path[i].x + (path[i+1].x - path[i].x) * k,
        y: path[i].y + (path[i+1].y - path[i].y) * k,
        halte: currentHalte
      };
    }
    target -= lens[i];
  }
  return { ...path[path.length-1], halte: currentHalte };
}

/**
 * Halte mana yang aktif utk nilai countdown ini (1/2/3), berdasar range di tabel Countdown→Halte
 * (CD_MAP, utk cdStart yg lagi dipakai). null kalau cdStart-nya gak ada di mapping, atau cd-nya
 * di luar semua range (gak seharusnya terjadi kalau mapping-nya lengkap nutup cdStart..CD_END).
 *
 * cdVal>=cdStart dianggap "halte 0" — titik PALING AWAL jalur (arc-length 0), BUKAN Halte 1. Ini
 * biar towing diam dulu di titik 0 pas countdown di posisi maksimal (baru direset/plane baru mulai),
 * dan cuma pindah ke Halte 1 lewat animasi tick normal (animateCd) begitu countdown mulai turun dari
 * cdStart — gak "teleport" langsung ke Halte 1.
 */
function activeHalteForCd(cdVal){
  if(cdVal>=cdStart) return 0;
  const m = CD_MAP.find(x=>x.start===cdStart);
  if(!m) return null;
  for(let i=0;i<3;i++){
    const [hi,lo] = m.h[i];
    if(cdVal<=hi && cdVal>=lo) return i+1;
  }
  return null;
}

/**
 * Jarak-tempuh (arc length) titik berhenti halte tertentu di jalur route ini. Halte 0 = titik
 * paling awal jalur (arc-length 0), lihat activeHalteForCd.
 *
 * PRIORITAS UTAMA: tag manual "HALTE 1/2/3" di tab Editor (path[i].h) — ini posisi yg SUDAH
 * divalidasi manusia langsung di jalur, jadi paling bisa dipercaya kalau ADA. FALLBACK (dipakai
 * HANYA kalau halte ini belum ditandai manual sama sekali di jalurnya): posisi rack yg di-assign ke
 * halte ini lewat Master Offset (HALTE_MASTER, proses "HALTE 1/2/3") — titik DI JALUR yg paling
 * sejajar/dekat sama rack itu (nearestArcLengthOnPath) jadi titik berhenti pengganti. Rack-based
 * TIDAK dijadikan prioritas utama krn banyak alamat di Master Offset ternyata gak match presisi sama
 * jalur asli routenya (rack salah/gak sejajar) — override tag manual yg SUDAH bener jadi malah bikin
 * towing gak berhenti pas di haltenya (lihat riwayat: buat Route A ini jadi manfaat krn Halte 1-nya
 * emang belum pernah ditag manual, tapi buat route LAIN yg tag manualnya sudah benar, ini bikin salah).
 */
function haltePointArcLength(path, metrics, haltNo, route){
  if(haltNo===0) return 0;
  const idx = path.findIndex(p=>p.h===haltNo);
  if(idx>=0){
    let acc=0;
    for(let i=0;i<idx;i++) acc+=metrics.lens[i];
    return acc;
  }
  const addr = route && HALTE_MASTER[route] && HALTE_MASTER[route][haltNo-1];
  if(addr){
    const rk = CFG.racks.find(r=>r.addr===addr);
    if(rk) return nearestArcLengthOnPath(path, metrics, rk.x, rk.y);
  }
  return null;
}

/**
 * Target jarak-tempuh berdasar HALTE (bukan proporsional lagi) — towing DIAM PENUH di titik halte
 * aktif selama countdown masih di range halte itu (lihat Countdown→Halte), baru geser pas countdown
 * masuk range halte berikutnya. cdVal bisa pecahan (dipanggil per-frame oleh animateCd pas transisi
 * antar-halte) — di situ hasilnya di-interpolasi halus antara titik halte lama & halte tujuan supaya
 * towing+dolly-nya tetap menyusuri bentuk jalur (bukan potong lurus). Return null kalau cdStart-nya
 * sama sekali gak ada di mapping Countdown→Halte → towProgress fallback total ke cara lama.
 *
 * Kalau CUMA SEBAGIAN halte yg ke-tag di jalur (mis. Halte 1&2 ada, Halte 3 belum ditandai di
 * Editor) — halte yg BELUM ke-tag itu arc-length-nya disubstitusi pakai rumus proporsional (bukan
 * langsung nge-null-in seluruh fungsi), supaya towing tetap nyambung mulus keluar dari halte
 * TERAKHIR yg beneran ke-tag, bukan LONCAT tiba-tiba ke posisi proporsional begitu masuk cd range
 * halte yg belum ke-tag itu (tanpa ini, towing kelihatan "blink"/teleport, bukan jalan pelan-pelan).
 */
function haltTargetArcLength(path, metrics, cdVal, route){
  const lo=Math.floor(cdVal), hi=Math.ceil(cdVal);
  const haltLo=activeHalteForCd(lo), haltHi=activeHalteForCd(hi);
  if(haltLo===null || haltHi===null) return null;
  let arcLo=haltePointArcLength(path,metrics,haltLo,route);
  let arcHi=haltePointArcLength(path,metrics,haltHi,route);
  if(arcLo===null && arcHi===null) return null; // dua2nya gak ke-tag, bener2 gak ada acuan
  const proportional=cdv=>{ let p=(cdStart-cdv)/(cdStart-CD_END); if(p<0)p=0; if(p>1)p=1; return p*metrics.totalLength; };
  if(arcLo===null) arcLo=proportional(lo);
  if(arcHi===null) arcHi=proportional(hi);
  if(lo===hi || haltLo===haltHi) return arcLo; // gak lagi transisi, diam di 1 titik halte
  const t=(hi-cdVal)/(hi-lo); // 0 di cd=hi (posisi halte lama) -> 1 di cd=lo (posisi halte tujuan)
  return arcHi + (arcLo-arcHi)*t;
}

/** Progress (0..1) towing di route ini berdasarkan countdown saat ini, + metrics jalurnya. */
function towProgress(route, cdOverride){
  const path = CFG.paths[route];
  if(!path || path.length < 2) return null;
  const metrics = pathMetrics(path);

  // GANTI: dulu `useCd` = cdOverride/cd APA ADANYA (semua route pakai angka yg SAMA, lockstep) —
  // sekarang diterjemahkan dulu lewat cdRouteFor() jadi CD Route ("Andon Supply") route ini SENDIRI
  // (dikonfirmasi user: tiap route py countdown sendiri-sendiri sesuai Supply Offset masing2, lihat
  // komentar panjang cdRouteFor di atas). SATU-SATUNYA titik ubah — towXY/towDirection/towShouldFlip/
  // dollyPositions SEMUA manggil towProgress, jadi otomatis ikut kebawa tanpa disentuh sendiri2.
  const rawCd = cdOverride === undefined ? cd : cdOverride;
  const useCd = cdRouteFor(route, rawCd, cdStart);
  const haltTarget = haltTargetArcLength(path, metrics, useCd, route);
  if(haltTarget!==null) return {path, metrics, target: haltTarget};

  // Fallback: route ini blm ditag halte lengkap / cdStart blm ada di Countdown→Halte —
  // tetap pakai cara lama (proporsional linear sepanjang jalur).
  // Contoh: cdStart 24. Jika useCd turun ke 12, maka progress = 52% dari panjang garis.
  let progress = (cdStart - useCd) / (cdStart - CD_END);
  if (progress < 0) progress = 0;
  if (progress > 1) progress = 1;
  return {path, metrics, target: progress * metrics.totalLength};
}

/** Posisi kepala towing (x,y,halte) di route ini pada countdown tertentu. */
function towXY(route, cdOverride){
  const pr = towProgress(route, cdOverride);
  if(!pr) return null;
  return pointAtDistance(pr.path, pr.metrics, pr.target);
}

/**
 * Arah gerak towing saat ini (vektor dx,dy), diambil dari selisih posisi sedikit sebelum & sesudah
 * titik sekarang di sepanjang jalur. Dipakai buat mirror gambar towing (gambar aslinya digambar
 * menghadap kiri/atas) — pas jalur mengarah ke kanan/bawah gambarnya di-flip biar gak keliatan mundur.
 */
function towDirection(route, cdOverride){
  const pr = towProgress(route, cdOverride);
  if(!pr) return {dx:0, dy:0};
  const EPS = 3;
  const a = pointAtDistance(pr.path, pr.metrics, Math.max(0, pr.target-EPS));
  const b = pointAtDistance(pr.path, pr.metrics, Math.min(pr.metrics.totalLength, pr.target+EPS));
  return {dx: b.x-a.x, dy: b.y-a.y};
}

// Flip towing DIBEKUKAN dari gerakan sumbu X TERAKHIR, per route — gerak dominan sumbu Y (naik/turun)
// SENGAJA gak ngubah arah hadap sama sekali, cuma warisin apa adanya dari X terakhir (lihat
// towShouldFlip). Gambar towing side-view gak punya "hadap atas/bawah" yg bermakna scr fisik, jadi
// nebak polaritas dari dy selalu berujung ambigu/kebalik-balik di beberapa segmen (riwayat panjang
// bolak-balik towShouldFlip sebelum ini). Manghindari itu, bukan nyoba nebak lagi.
let lastXFlip={};

/**
 * Berdasar towDirection: true kalau gambar towing perlu di-mirror (Posisi B = towing.png di-flip
 * sumbu Y / scale(-1,1); Posisi A = foto asli, apa adanya — depan mobilnya emang menghadap KIRI,
 * dicek langsung dari gambar: setir+roda kecil di kiri, kursi+roda besar+antena di kanan).
 *
 * Keputusan flip HANYA dihitung ulang pas gerakan DOMINAN di sumbu X (X+ kanan -> flip; X- kiri ->
 * normal) — hasilnya dibekukan per route ke lastXFlip. Pas gerakan dominan di sumbu Y, TIDAK dihitung
 * ulang sama sekali — cuma pakai lagi lastXFlip[route] apa adanya (arah hadap gak berubah selama
 * towing lagi naik/turun, ngikutin arah horizontal terakhir sebelum itu).
 */
function towShouldFlip(route, cdOverride){
  const {dx,dy} = towDirection(route, cdOverride);
  if (Math.abs(dx) >= Math.abs(dy)) lastXFlip[route] = dx > 0;
  return lastXFlip[route] ?? false;
}

const DOLLY_N=8, DOLLY_SPACING=45;

/** Arc-length titik stage tertentu (SORTING/TRANSFER/EMPTY/PREPARE) di jalur ini — Infinity kalau
 * stage itu gak ditandai sama sekali di route ini (dianggap "gak ada", gak ngaruh ke apapun). */
function stageArc(path, metrics, stageName){
  let acc=0;
  for(let i=0;i<path.length;i++){
    if(path[i].stage===stageName) return acc;
    if(i<metrics.lens.length) acc+=metrics.lens[i];
  }
  return Infinity;
}

/**
 * Posisi 8 dolly di belakang towing, masing-masing mundur DOLLY_SPACING px sepanjang jalur yang
 * sama. PREPARE & TRANSFER sekarang masing-masing jadi ambang batas di UJUNG AWAL & UJUNG AKHIR
 * rangkaian dolly (bukan "zona lepas di tengah jalur" spt versi lama):
 * - PREPARE = posisi towing pas AWAL MULA countdown (titik towing mulai jalan/narik dolly).
 *   Dolly ke-i baru mulai kegambar (nyambung) begitu POSISI DOLLY ITU SENDIRI (target - offset)
 *   udah lewat arc PREPARE — efeknya dolly NYAMBUNG SATU-SATU dari yg paling deket towing (dolly 1)
 *   begitu towing narik maju dari titik prepare, sampai semua ke-8 nyambung (animasi "nambah dolly
 *   satu-satu" pas towing berangkat). Kalau PREPARE gak ditandai, dianggap nempel di paling awal
 *   jalur (-Infinity) — semua dolly langsung nyambung dari awal, gak ada animasi nambah (perilaku
 *   lama sebelum PREPARE ada).
 * - TRANSFER = posisi towing pas SELESAI nganter (titik dolly mulai dilepas/diturunin). Dolly
 *   ke-i lepas satu-satu dari yg paling deket towing (dolly 1) begitu posisinya sendiri lewat arc
 *   TRANSFER. Kalau gak ditandai, gak pernah lepas (Infinity).
 */
function dollyPositions(route, cdOverride){
  const pr = towProgress(route, cdOverride);
  if(!pr) return [];
  const transferArc = stageArc(pr.path, pr.metrics, 'TRANSFER');
  const prepareArcRaw = stageArc(pr.path, pr.metrics, 'PREPARE');
  const prepareArc = prepareArcRaw===Infinity ? -Infinity : prepareArcRaw;
  const out=[];
  for(let i=1;i<=DOLLY_N;i++){
    const dArc = pr.target - i*DOLLY_SPACING;
    if(dArc<prepareArc || dArc>=transferArc){ out.push(null); continue; }
    out.push(pointAtDistance(pr.path, pr.metrics, dArc));
  }
  return out;
}

// Jumlah dolly per supplier sekarang dihitung dari VOLUME (volume_box master part x lot), bukan cuma
// jumlah baris part. Supplier ke-9 dst (setelah slot 1-8 fisik habis) digabung ke dolly 8 (tampungan sisa).
const normSup=s=>(s||"").trim().toUpperCase();

// Master urutan supply (dari Operation) pakai nama singkat/kode ("SHINTO", "SEKISO (DUCK TRIM1)"),
// sedangkan data part hasil upload PICS pakai nama resmi lengkap ("SHINTO KOGYO INDONESIA").
// coreSup buang bagian dalam kurung supaya bisa dicocokkan sebagai substring kedua arah.
const coreSup=s=>normSup(s).replace(/\([^)]*\)/g," ").replace(/\s+/g," ").trim();

/** Kelas + label status part (Direct/Sorting/Unpacking Murni/Import/C-U), dipakai bareng oleh
 * statusBadgeHtml & statusDotHtml di bawah — definisi "unpacking"/"sorting" SENGAJA sama persis dgn
 * groupKeyForPart biar indikator visual & logika pengelompokan dolly gak pernah kebaca beda utk baris
 * yg sama. "C/U" (Cooling Unit) TIDAK dikecualikan dari grouping dolly Monitor kayak Unpacking (tetap
 * dikelompokkan per-supplier biasa di sini) — status ini cuma ngubah rumus jumlah SKID di Plane
 * Simulation (psIsCoolingUnitGroup, plane-sim.js), bukan cara Monitor ngelompokin dolly. */
function statusInfo(status){
  const s=(status||"Direct").toString().trim();
  if(/^import$/i.test(s)) return {cls:"status-import", label:"Import"};
  if(/unpacking/i.test(s)) return {cls:"status-unpacking", label:"Unpacking"};
  if(/sorting/i.test(s)) return {cls:"status-sorting", label:"Sorting"};
  if(/^c[\/\-]?u$/i.test(s)) return {cls:"status-cu", label:"C/U"};
  return {cls:"status-direct", label:"Direct"};
}
/** Badge teks penuh (dipakai di overlay Mode Follow, tabelnya cukup lebar). */
function statusBadgeHtml(status){
  const {cls,label}=statusInfo(status);
  return `<span class="status-badge ${cls}">${label}</span>`;
}
/** Titik kecil berwarna (dipakai di panel Muatan Monitor yg sempit — nempel di sel DOLLY, gak
 * makan kolom baru) — tooltip title tetap nampilin nama statusnya penuh pas di-hover. */
function statusDotHtml(status){
  const {cls,label}=statusInfo(status);
  return `<span class="status-dot ${cls}" title="${label}"></span>`;
}

/**
 * Grup (=nama supplier) efektif utk satu baris part, memperhitungkan status dari Master Part:
 * - status Unpacking: semua digabung jadi 1 grup sintetis "GABUNGAN UNPACKING" (kode MIX), terlepas
 *   dari nama supplier aslinya.
 * - status Sorting: KALAU route ini ada part Unpacking juga -> ikut numpuk ke dolly "GABUNGAN
 *   UNPACKING" yg sama (gak dapat dolly sendiri). KALAU route ini SAMA SEKALI gak ada Unpacking ->
 *   dapat dolly sendiri, dikelompokkan per ALAMAT RACK tujuan (p[5]) — bukan per supplier, krn intent
 *   Sorting itu konsolidasi per lokasi fisik, bukan per asal barang. hasUnpacking WAJIB dihitung dari
 *   SELURUH part di route ini (bukan per-part), lihat dollyGroups/renderParts pemanggilnya.
 * - selainnya (Direct dkk): nama supplier hasil VLOOKUP ke Master Part (p[11], dicocokkan by identitas
 *   supplier_code+supplier_plant+supplier_dock+route), fallback ke nama mentah Progress Lane (p[6]).
 */
function groupKeyForPart(p, hasUnpacking){
  const status = (p[10]||"Direct").toString().trim();
  if (/unpacking/i.test(status)) return "GABUNGAN UNPACKING";
  if (/sorting/i.test(status)) return hasUnpacking ? "GABUNGAN UNPACKING" : (p[5] || "(Tanpa Alamat)");
  return p[11] || p[6] || "(Tanpa Supplier)";
}

/**
 * Kalau ada Master Urutan Supply (smms_pattern_unload) utk route ini, urutan dolly ikut hirarki situ
 * (skip supplier yg datanya gak ada di plane ini, tapi tetap pegang urutan) — KECUALI IMPORT, yg SELALU
 * dikasih slot dolly kosong tersendiri sesuai hirarki (emang gak pernah punya part asli, jadi kalau
 * dilewatin pas kosong malah gak pernah muncul sama sekali). UNPACKING & supplier lain sebaliknya cuma
 * dikasih slot kalau BENERAN ada part yg cocok di plane ini — kalau kosong ya gak ditampilkan, dilewatin
 * diam-diam persis kayak supplier lain yg part-nya kosong. Supplier yg muncul di data tapi gak
 * terdaftar/gak cocok di hirarki ditandai "unlisted" (bukan otomatis ditaruh diam-diam). Kalau belum
 * ada master utk route ini sama sekali, fallback ke urutan kemunculan pertama di file upload.
 *
 * Jumlah dolly per grup = MAX(1, ROUND(total volume_box x lot)) — kecuali grup GABUNGAN UNPACKING yang
 * DIKUNCI selalu 1 dolly berapa pun volumenya. 1 grup bisa memakai LEBIH dari 1 slot dolly fisik berturutan
 * kalau volumenya besar (mis. grup dgn hasil 2 -> menempati 2 dolly sekaligus).
 */
function dollyGroups(route){
  const parts = routeParts(route);
  const hasUnpacking = parts.some(p=>/unpacking/i.test((p[10]||"").toString()));
  const bySupplier = {}; const firstSeenOrder = [];
  parts.forEach(p=>{
    const sup = groupKeyForPart(p, hasUnpacking);
    const key = normSup(sup);
    if(!bySupplier[key]){ bySupplier[key]={supplier:sup, parts:[], volume:0, isMix:sup==="GABUNGAN UNPACKING"}; firstSeenOrder.push(key); }
    bySupplier[key].parts.push(p);
    bySupplier[key].volume += (parseFloat(p[9])||0) * (parseFloat(p[4])||0);
  });
  Object.values(bySupplier).forEach(g=>{ g.dollyCount = g.isMix ? 1 : Math.max(1, Math.round(g.volume)); });

  const hierarchy = SUPPLY_ORDER[route] || [];
  let orderedKeys, unlisted = [];
  if(hierarchy.length){
    // 1 supplier bisa muncul di >1 posisi seq (mis. dua batch berurutan) — dedupe pakai "inti" namanya,
    // pegang seq pertama munculnya. KECUALI "IMPORT": itu boleh dipilih berulang di Pattern Unload (tiap
    // pilihan = slot dolly kosong tersendiri, gak ada part asli), jadi tiap kemunculan tetap dipertahankan.
    const seenHier = new Set(); const hierCores = [];
    hierarchy.slice().sort((a,b)=>a.seq-b.seq).forEach(h=>{
      const core = coreSup(h.supplier);
      if(!core) return;
      if(core==="IMPORT" || !seenHier.has(core)){ seenHier.add(core); hierCores.push(core); }
    });
    const matched = new Set(); const present = []; let importN=0;
    hierCores.forEach(core=>{
      // IMPORT ngikutin setingan Pattern Unload murni — selalu dikasih slot dolly kosong tersendiri
      // tiap kali dipilih di situ (gak peduli data part), biar supplier sesudahnya gak ikut geser.
      if(core==="IMPORT"){
        const synthKey="__IMPORT_"+(importN++)+"__";
        bySupplier[synthKey]={supplier:"IMPORT", parts:[], volume:0, isMix:false, dollyCount:1};
        present.push(synthKey);
        return;
      }
      // UNPACKING (& supplier lain) ngikutin DATA part yg beneran keluar di plane ini — kalau gak ada
      // part yg cocok (mis. plane ini kebetulan kosong dari part berstatus Unpacking utk route ini),
      // ya gak dikasih slot sama sekali (dilewatin diam-diam, slot kosong emang sengaja gak ditampilkan).
      const foundKey = firstSeenOrder.find(k=>!matched.has(k) && (k.includes(core)||core.includes(k)));
      if(foundKey){ present.push(foundKey); matched.add(foundKey); }
    });
    unlisted = firstSeenOrder.filter(k=>!matched.has(k));
    orderedKeys = [...present, ...unlisted];
  } else {
    orderedKeys = firstSeenOrder;
  }

  // Isi slot dolly fisik (1-8); 1 grup bisa memakai >1 slot berturutan sesuai dollyCount-nya.
  // Kalau slot fisik sudah habis (cursor>=8), sisanya numpuk di slot terakhir (dolly 8 = tampungan sisa).
  const groups = Array.from({length:DOLLY_N}, ()=>({supplier:null, parts:[], primarySlot:null, boxIndex:0, boxCount:0}));
  const contributedTo = Array.from({length:DOLLY_N}, ()=>new Set()); // slot idx -> set of group key yg sudah nyumbang part ke situ (cegah dobel kalau 1 grup sendiri numpuk >1x di slot yg sama)
  const supplierIdx = {};
  let cursor = 0;
  orderedKeys.forEach(key=>{
    const g = bySupplier[key];
    const primary = Math.min(cursor, DOLLY_N-1);
    supplierIdx[key] = primary;
    for(let k=0; k<g.dollyCount; k++){
      const idx = Math.min(cursor, DOLLY_N-1);
      // Kalau slot ini "numpuk" (overflow, sudah diklaim grup lain sebelumnya), tetap akumulasikan
      // partnya (jangan ditimpa) — nama supplier yg ditampilkan tetap punya klaim pertama.
      if(groups[idx].supplier===null) groups[idx].supplier=g.supplier;
      if(!contributedTo[idx].has(key)){ groups[idx].parts.push(...g.parts); contributedTo[idx].add(key); }
      groups[idx].primarySlot = primary;
      groups[idx].boxIndex = k+1;
      groups[idx].boxCount = g.dollyCount;
      cursor++;
    }
  });
  // Jumlah slot dolly yg BENERAN kepake utk route+plane ini SEKARANG (bisa < DOLLY_N=8, tergantung
  // berapa banyak grup supplier/unpacking/import yg ada di data plane ini + hirarki Pattern Unload) —
  // dipakai render (06-render.js) biar towing gak nyeret kotak dolly kosong yg emang gak akan pernah
  // kepake utk route ini, bukan cuma nyembunyiin visualnya doang.
  const usedSlots = Math.min(cursor, DOLLY_N);
  return {groups, supplierIdx, unlisted:unlisted.map(k=>bySupplier[k].supplier), hasHierarchy:hierarchy.length>0, hasUnpacking, usedSlots};
}

/**
 * Arc-length (jarak tempuh dari titik awal jalur) dari titik (x,y) mana pun — dicari titik TERDEKAT
 * di SEPANJANG polyline jalur (proyeksi ke tiap segmen), bukan cuma titik yg ditag. Dipakai buat
 * urutan "udah kelewatan jalur apa belum" suatu rack, bukan sekadar jarak lurus ke titik tag halte.
 */
function nearestArcLengthOnPath(path, metrics, x, y){
  let bestArc=0, bestDist=Infinity, acc=0;
  for(let i=0;i<path.length-1;i++){
    const ax=path[i].x, ay=path[i].y, dx=path[i+1].x-ax, dy=path[i+1].y-ay;
    const len2=dx*dx+dy*dy;
    let t = len2 ? ((x-ax)*dx+(y-ay)*dy)/len2 : 0;
    t = Math.max(0, Math.min(1, t));
    const px=ax+dx*t, py=ay+dy*t;
    const d=(px-x)**2+(py-y)**2;
    if(d<bestDist){ bestDist=d; bestArc=acc+metrics.lens[i]*t; }
    acc+=metrics.lens[i];
  }
  return bestArc;
}

/**
 * Halte TUJUAN rack address ini — rack diproyeksikan dulu ke titik terdekat DI SEPANJANG JALUR
 * (nearestArcLengthOnPath, bukan garis lurus mentah ke rack), lalu dicocokkan ke HALTE (1/2/3, yg
 * beneran punya posisi valid di route ini) yg arc-length-nya PALING DEKAT ke proyeksi itu.
 *
 * Kenapa bukan garis lurus (euclidean) ke posisi rack langsung: rack yg letaknya jauh di ujung
 * SATU koridor yg sama persis dgn suatu halte (mis. JDT2-U49..U52, koridornya nempel ke halte 1)
 * bisa jadi scr garis lurus lebih "dekat" ke marker halte LAIN yg beda koridor (nyebrang gap besar)
 * krn kebetulan jaraknya lebih pendek di peta — padahal towing gak pernah lewat situ buat nyampe ke
 * halte itu. Proyeksi ke jalur dulu baru bandingin arc-length menghindari salah-koridor ini (dites
 * langsung: JDT2-U49/50/51/52 -> halte 1, FRAML-F4/F6/F7/F11/F23 tetap -> halte 2, sesuai actual).
 *
 * Kenapa bukan arc-length MENTAH tanpa proyeksi (cara paling lama): kalau jalurnya berkelok/nyilang,
 * titik jalur "terdekat by index" bisa nyasar ke segmen yg salah — proyeksi tegak lurus per segmen
 * (nearestArcLengthOnPath) yg dipakai di sini udah nangani itu dgn benar (ambil jarak tegak lurus
 * TERPENDEK ke tiap segmen, bukan urutan index).
 *
 * Rack cuma punya SATU jawaban TETAP (halte tujuan-nya sendiri), gak pernah balik dianggap "butuh
 * disupply lagi" di halte lain setelah haltenya sendiri lewat — activeSupplyRackAddrs (halte SAMA
 * PERSIS = aktif sekarang) & dollyFullySupplied (halte LEBIH KECIL = udah lewat/beres) sama-sama
 * cuma bandingin 1 angka ini ke halte aktif, jadi otomatis gak akan disupply dobel.
 */
function passedHalteForRack(route,x,y){
  const path=CFG.paths[route]; if(!path||path.length<2) return 0;
  const metrics=pathMetrics(path);
  const rackArc=nearestArcLengthOnPath(path,metrics,x,y);
  let best=0, bestD=Infinity;
  for(let h=1; h<=3; h++){
    const harc=haltePointArcLength(path,metrics,h,route);
    if(harc===null) continue;
    const d=Math.abs(harc-rackArc);
    if(d<bestD){ bestD=d; best=h; }
  }
  return best;
}

/**
 * Rack address-address yg dianggap AKTIF SEKARANG utk route ini — sebuah rack aktif kalau ADA dolly
 * yg lagi disupply (baru sampai/berhenti di halte-nya, lihat passedHalteForRack) yg BENERAN membawa
 * part dgn address itu persis (dollySupplyRacks, cocok by p[5]). Dipakai nyaring rack mana yg
 * ditampilkan/diperbesar di Monitor (06-render.js) — rack yg gak aktif SENGAJA disembunyikan total,
 * bukan cuma diredupkan. Set kosong kalau route-nya blm di halte manapun (mis. baru direset ke titik 0).
 */
function activeSupplyRackAddrs(route){
  const out=new Set();
  const haltNo=activeHalteForCd(cd);
  if(!haltNo || !route) return out;
  const {groups}=dollyGroups(route);
  groups.forEach(g=>{
    dollySupplyRacks(g).forEach(rk=>{
      if(passedHalteForRack(route,rk.x,rk.y)===haltNo) out.add(rk.addr);
    });
  });
  return out;
}

/**
 * True kalau SEMUA rack tujuan dolly ini (dollySupplyRacks) udah kelewatan (halte-nya < halte aktif
 * sekarang) — brarti isi dolly ini udah "abis"/tuntas disupply semua. Dolly yg gak punya rack cocok
 * sama sekali (mis. IMPORT, atau supplier yg address-nya blm diisi di Posisi Rack) gak pernah
 * dianggap "abis" lewat cara ini (gak ada acuan buat nentuin) — tetap netral. Dipakai kasih indikasi
 * abu-abu di kotak dolly peta (06-render.js) yg udah tuntas isinya.
 */
function dollyFullySupplied(route, group){
  const active=activeHalteForCd(cd);
  if(!active) return false;
  const racks=dollySupplyRacks(group);
  if(!racks.length) return false;
  return racks.every(rk=>passedHalteForRack(route,rk.x,rk.y)<active);
}

/**
 * True kalau POSISI DOLLY ke-i (slot 0-based, sama urutan dgn dollyPositions) SUDAH lewat titik
 * stage EMPTY (area staging "dolly kosong" bersama, 1 titik fisik yg sama dipakai semua route —
 * lihat tagStage di editor/editor.js) — independen dari status supply part per-rack (dollyFullySupplied).
 * Dipakai kasih tampilan "kosong" (abu-abu, sama kayak var(--mut) dolly tuntas) ke kotak dolly di
 * denah begitu dolly itu numpang lewat zona ini. Kalau EMPTY gak ditandai di route ini, selalu false.
 */
function dollyPassedEmpty(route, dollyIndex){
  const pr=towProgress(route);
  if(!pr) return false;
  const emptyArc=stageArc(pr.path,pr.metrics,'EMPTY');
  if(emptyArc===Infinity) return false;
  const dArc=pr.target-(dollyIndex+1)*DOLLY_SPACING;
  return dArc>=emptyArc;
}

/**
 * Set berisi nomor-nomor dolly (1-8, bisa lebih dari satu) yg seharusnya nyala otomatis (warna +
 * kedip) utk route ini SEKARANG — gabungan dari 2 sumber:
 * 1) OTOMATIS: dolly yg BENERAN membawa part yg address-nya persis rack yg lagi aktif disupply
 *    (activeSupplyRackAddrs di atas) — ini yg utama, jalan sendiri dari data part tanpa perlu
 *    di-setting manual dulu.
 * 2) MANUAL: mapping HALTE_DOLLY (diatur di grid Halte & Rack, Database) kalau ada isinya utk
 *    halte yg lagi aktif — digabung (union), bukan menggantikan, biar setingan manual yg udah
 *    ada gak hilang begitu aja.
 * Set kosong kalau route-nya blm di halte manapun (mis. "START", posisi titik 0 blm masuk halte).
 */
function autoFocusDollyFor(route){
  const haltNo = activeHalteForCd(cd);
  const out = new Set();
  if(!haltNo) return out;
  const activeAddrs = activeSupplyRackAddrs(route);
  if(activeAddrs.size){
    const {groups} = dollyGroups(route);
    groups.forEach((g,i)=>{
      const primaryNum=(g.primarySlot??i)+1;
      if(dollySupplyRacks(g).some(rk=>activeAddrs.has(rk.addr))) out.add(primaryNum);
    });
  }
  const m = HALTE_DOLLY[route];
  if(m && m[haltNo]) m[haltNo].forEach(n=>out.add(n));
  return out;
}
