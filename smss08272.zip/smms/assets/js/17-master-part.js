/* =====================================================================
   17-MASTER-PART — CRUD lengkap utk Master Part: tabel checkbox+search+
   pagination, upload (mode Additional/Replace + validasi ketat + riwayat),
   Add/Edit modal (dock_code terkunci "43" saat Add), Delete confirm,
   popup detail error validasi per baris/kolom, download CSV.
   ===================================================================== */
const MP_PAGE_SIZE = 15;
const MP_COLS = [
  ["uniq_no","Uniq No"], ["part_no","Part No"], ["part_name","Part Name"], ["volume_box","Volume Box"],
  ["vol_box_day","Vol/Box Day"], ["route","Route"], ["status","Status"], ["supplier_name","Supplier Name"],
  ["dock_code","Dock Code"], ["supplier_code","Supplier Code"], ["supplier_plant_code","Supplier Plant Code"],
  ["shipping_dock","Shipping Dock"], ["ssc_code","SSC Code"],
];
const MP_SEARCH_FIELDS = ["uniq_no","supplier_name","route","status","part_name"];

let mpAllRows = [], mpFilteredRows = [], mpPage = 1;
let mpSelected = new Set(); // part_no yg dicentang di halaman manapun

/** Escape nilai supaya aman ditaruh sbg teks HTML. */
function mpEsc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;"); }

/** POST lokal (beda dari apiPost global) krn perlu body JSON penuh (termasuk `details`) walau response 400. */
async function mpApiPost(action, body, isForm=false){
  apiLoadingStart();
  try{
    const r = await fetch(API+'?action='+action, {method:'POST',
      headers: isForm?undefined:{'Content-Type':'application/json'},
      body: isForm?body:JSON.stringify(body)});
    const j = await r.json().catch(()=>null);
    return {ok:r.ok, json:j};
  } finally{ apiLoadingEnd(); }
}

/** Init/refresh section Master Part (dipanggil dari buildGrids() tiap tab Database dibuka/data berubah). */
async function initMasterPart(){
  const d = await apiGet("action=master_part_list");
  mpAllRows = d.rows||[];
  mpSelected.clear();
  mpApplySearch();
  await mpRefreshHistory();
}

/* ---------------- Tabel: search + pagination + checkbox ---------------- */

function mpApplySearch(){
  const q=(document.getElementById("mpSearch").value||"").trim().toLowerCase();
  mpFilteredRows = !q ? mpAllRows : mpAllRows.filter(r=>MP_SEARCH_FIELDS.some(f=>String(r[f]||"").toLowerCase().includes(q)));
  mpRenderTable();
}
document.getElementById("mpSearch").addEventListener("input", ()=>{ mpPage=1; mpApplySearch(); });

/** Render tabel Master Part (checkbox + 13 kolom) utk halaman saat ini. */
function mpRenderTable(){
  const box=document.getElementById("masterPartTableBox");
  const total=mpFilteredRows.length;
  const totalPages=Math.max(1,Math.ceil(total/MP_PAGE_SIZE));
  if(mpPage>totalPages) mpPage=totalPages;
  const start=(mpPage-1)*MP_PAGE_SIZE;
  const rows=mpFilteredRows.slice(start,start+MP_PAGE_SIZE);
  if(!total){
    box.innerHTML='<p class="meta">Belum ada master part — upload dulu.</p>';
    mpRenderPager(0,1); mpUpdateActionButtons();
    return;
  }
  const thead=`<tr><th style="width:26px"><input type="checkbox" id="mpSelectAll"></th>${MP_COLS.map(c=>`<th>${c[1]}</th>`).join("")}</tr>`;
  box.innerHTML=`<div style="overflow-x:auto"><table class="grid compact">${thead}`+
    rows.map(r=>`<tr><td><input type="checkbox" class="mp-rowchk" data-pn="${mpEsc(r.part_no)}" ${mpSelected.has(r.part_no)?"checked":""}></td>`+
      MP_COLS.map(c=>`<td>${c[0]==="volume_box"?(+r.volume_box).toFixed(7):mpEsc(r[c[0]]??"")}</td>`).join("")+`</tr>`).join("")+
    `</table></div>`;
  const allChk=document.getElementById("mpSelectAll");
  allChk.checked = rows.length>0 && rows.every(r=>mpSelected.has(r.part_no));
  allChk.onchange=e=>{
    rows.forEach(r=>{ if(e.target.checked) mpSelected.add(r.part_no); else mpSelected.delete(r.part_no); });
    mpRenderTable();
  };
  document.querySelectorAll(".mp-rowchk").forEach(cb=>cb.onchange=()=>{
    if(cb.checked) mpSelected.add(cb.dataset.pn); else mpSelected.delete(cb.dataset.pn);
    mpUpdateActionButtons();
  });
  mpRenderPager(total,totalPages);
  mpUpdateActionButtons();
}

/** Enable/disable tombol Edit (persis 1 row terpilih), Ubah Status & Delete (>=1 row terpilih). */
function mpUpdateActionButtons(){
  document.getElementById("mpEditBtn").disabled = mpSelected.size!==1;
  document.getElementById("mpBulkStatusBtn").disabled = mpSelected.size<1;
  document.getElementById("mpDeleteBtn").disabled = mpSelected.size<1;
}

/** Render kontrol pagination (pola sama dgn tabel Part Aktif di 10-database.js). */
function mpRenderPager(total,totalPages){
  const start=total?(mpPage-1)*MP_PAGE_SIZE+1:0;
  const end=Math.min(mpPage*MP_PAGE_SIZE,total);
  const addBtn=n=>`<button class="${n===mpPage?"on":""}" data-p="${n}">${n}</button>`;
  let pageBtns="";
  if(totalPages<=7){
    for(let i=1;i<=totalPages;i++) pageBtns+=addBtn(i);
  }else{
    const nums=new Set([1,2,totalPages-1,totalPages,mpPage-1,mpPage,mpPage+1].filter(n=>n>=1&&n<=totalPages));
    let prev=0;
    [...nums].sort((a,b)=>a-b).forEach(i=>{ if(prev&&i-prev>1) pageBtns+=`<span class="dots">…</span>`; pageBtns+=addBtn(i); prev=i; });
  }
  document.getElementById("mpPagination").innerHTML=
    `<span>Menampilkan ${start}-${end} dari ${total} data</span>
     <div class="pages">
       <button id="mpPrev" ${mpPage<=1?"disabled":""}>‹</button>
       ${pageBtns}
       <button id="mpNext" ${mpPage>=totalPages?"disabled":""}>›</button>
     </div>`;
  document.getElementById("mpPrev").onclick=()=>{ mpPage--; mpRenderTable(); };
  document.getElementById("mpNext").onclick=()=>{ mpPage++; mpRenderTable(); };
  document.querySelectorAll("#mpPagination .pages button[data-p]").forEach(b=>b.onclick=()=>{ mpPage=+b.dataset.p; mpRenderTable(); });
}

/* ---------------- Upload (popup: pilih file + mode Additional/Replace, popup error terpisah) ---------------- */

document.getElementById("mpUploadOpenBtn").onclick=()=>{
  document.getElementById("mpFile").value=""; document.getElementById("mpFileName").textContent="Belum pilih file";
  document.getElementById("mpMode").value="additional";
  document.getElementById("mpUploadModal").style.display="flex";
};
document.getElementById("mpUploadCancel").onclick=()=>document.getElementById("mpUploadModal").style.display="none";
document.getElementById("mpUploadModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });

document.getElementById("mpChooseFile").onclick=()=>document.getElementById("mpFile").click();
document.getElementById("mpFile").addEventListener("change",()=>{
  const f=document.getElementById("mpFile").files[0];
  document.getElementById("mpFileName").textContent=f?f.name:"Belum pilih file";
});
document.getElementById("mpUploadBtn").onclick=async()=>{
  const f=document.getElementById("mpFile").files[0];
  if(!f){ toast("Pilih file dulu"); return; }
  const mode=document.getElementById("mpMode").value;
  const fd=new FormData(); fd.append("file",f); fd.append("mode",mode);
  const btn=document.getElementById("mpUploadBtn"); btn.disabled=true;
  try{
    const {ok,json}=await mpApiPost("upload_master_part",fd,true);
    if(!ok){
      if(json && json.details) mpShowErrorModal(json.error, json.details);
      else toast("Gagal: "+((json&&json.error)||"upload ditolak"));
      return;
    }
    document.getElementById("mpUploadModal").style.display="none";
    toast(`Upload sukses (${mode==="replace"?"Replace":"Additional"}): ${json.rows} baris tersimpan`);
    document.getElementById("mpFile").value=""; document.getElementById("mpFileName").textContent="Belum pilih file";
    await initMasterPart();
    await bootstrap(); buildGrids(); redrawAll(); if(selRoute) renderParts();
  }catch(e){ toast("Gagal: "+e.message); }
  finally{ btn.disabled=false; }
};

/** Tampilkan popup error validasi (baris+kolom+pesan) hasil upload yang ditolak. */
function mpShowErrorModal(summary, details){
  document.getElementById("mpErrorSummary").textContent=(summary||"Validasi gagal")+` — ${details.length} masalah ditemukan (upload dibatalkan, tidak ada yang tersimpan):`;
  document.getElementById("mpErrorRows").innerHTML=details.map(d=>`<tr><td>${d.row}</td><td>${mpEsc(d.col)}</td><td>${mpEsc(d.msg)}</td></tr>`).join("");
  document.getElementById("mpErrorModal").style.display="flex";
}
document.getElementById("mpErrorClose").onclick=()=>document.getElementById("mpErrorModal").style.display="none";
document.getElementById("mpErrorModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });

/* ---------------- Riwayat upload ("Last Upload" + daftar lengkap) ---------------- */

async function mpRefreshHistory(){
  const d=await apiGet("action=master_part_upload_history");
  const rows=d.rows||[];
  const last=rows[0];
  document.getElementById("mpLastUpload").innerHTML = last
    ? `${mpEsc(last.filename)} (${last.mode==="replace"?"Replace":"Additional"}) · ${last.rows_count} baris<span class="when">${mpEsc(last.uploaded_at)}</span>`
    : "Belum pernah upload";
  document.getElementById("mpHistoryBox").innerHTML = rows.length
    ? `<table class="grid compact"><tr><th>File</th><th>Mode</th><th>Baris</th><th>Waktu</th></tr>`+
      rows.map(r=>`<tr><td>${mpEsc(r.filename)}</td><td>${r.mode==="replace"?"Replace":"Additional"}</td><td>${r.rows_count}</td><td>${r.uploaded_at}</td></tr>`).join("")+
      `</table>`
    : '<p class="meta">Belum ada riwayat upload.</p>';
}
document.getElementById("mpHistoryToggle").onclick=()=>{
  const box=document.getElementById("mpHistoryBox");
  const show = box.style.display==="none";
  box.style.display = show?"":"none";
  document.getElementById("mpHistoryToggle").textContent = "Riwayat Upload "+(show?"▴":"▾");
};

/* ---------------- Add / Edit modal (form sama, dock_code terkunci cuma pas Add) ---------------- */

let mpFormMode = "add"; // "add" | "edit"
let mpEditOriginalPartNo = null;

function mpOpenForm(mode, row){
  mpFormMode = mode;
  document.getElementById("mpFormTitle").textContent = mode==="add" ? "Tambah Part" : "Edit Part";
  document.getElementById("mpFormMsg").textContent = "";
  document.getElementById("mpfDockCode").disabled = (mode==="add"); // terkunci cuma saat Add (nilainya emang cuma boleh "43")
  if(mode==="edit" && row){
    mpEditOriginalPartNo = row.part_no;
    document.getElementById("mpfDockCode").value = row.dock_code||"43";
    document.getElementById("mpfSupplierCode").value = row.supplier_code||"";
    document.getElementById("mpfSupplierPlant").value = row.supplier_plant_code||"";
    document.getElementById("mpfShippingDock").value = row.shipping_dock||"";
    document.getElementById("mpfSscCode").value = row.ssc_code||"";
    document.getElementById("mpfPartNo").value = row.part_no||"";
    document.getElementById("mpfKanban").value = row.uniq_no||"";
    document.getElementById("mpfVolBoxDay").value = row.vol_box_day||"";
    document.getElementById("mpfSupplierName").value = row.supplier_name||"";
    document.getElementById("mpfPartName").value = row.part_name||"";
    document.getElementById("mpfVolumeBox").value = row.volume_box||"";
    document.getElementById("mpfConveyance").value = row.route||"";
    document.getElementById("mpfStatus").value = row.status||"Direct";
  } else {
    document.getElementById("mpfDockCode").value = "43";
    ["mpfSupplierCode","mpfSupplierPlant","mpfShippingDock","mpfSscCode","mpfPartNo","mpfKanban",
     "mpfVolBoxDay","mpfSupplierName","mpfPartName","mpfVolumeBox","mpfConveyance"].forEach(id=>document.getElementById(id).value="");
    document.getElementById("mpfStatus").value="Direct";
    mpEditOriginalPartNo = null;
  }
  document.getElementById("mpFormModal").style.display="flex";
}
document.getElementById("mpAddBtn").onclick=()=>mpOpenForm("add");
document.getElementById("mpEditBtn").onclick=()=>{
  if(mpSelected.size!==1) return;
  const pn=[...mpSelected][0];
  const row=mpAllRows.find(r=>r.part_no===pn);
  if(row) mpOpenForm("edit", row);
};
document.getElementById("mpFormCancel").onclick=()=>document.getElementById("mpFormModal").style.display="none";
document.getElementById("mpFormModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });

/** Kumpulkan payload dari form Add/Edit, validasi server-side, tampilkan pesan gagal di dalam modal kalau ditolak. */
document.getElementById("mpFormSave").onclick=async()=>{
  const payload={
    supplier_code: document.getElementById("mpfSupplierCode").value.trim(),
    supplier_plant_code: document.getElementById("mpfSupplierPlant").value.trim(),
    shipping_dock: document.getElementById("mpfShippingDock").value.trim(),
    ssc_code: document.getElementById("mpfSscCode").value.trim(),
    part_no: document.getElementById("mpfPartNo").value.trim(),
    uniq_no: document.getElementById("mpfKanban").value.trim(),
    vol_box_day: document.getElementById("mpfVolBoxDay").value.trim(),
    supplier_name: document.getElementById("mpfSupplierName").value.trim(),
    part_name: document.getElementById("mpfPartName").value.trim(),
    volume_box: document.getElementById("mpfVolumeBox").value.trim(),
    route: document.getElementById("mpfConveyance").value.trim(),
    status: document.getElementById("mpfStatus").value,
  };
  if(mpFormMode==="edit"){
    payload.dock_code = document.getElementById("mpfDockCode").value.trim();
    payload.part_no_original = mpEditOriginalPartNo;
  }
  const action = mpFormMode==="add" ? "master_part_add" : "master_part_edit";
  const {ok,json} = await mpApiPost(action, payload);
  if(!ok){
    document.getElementById("mpFormMsg").textContent = json && json.details
      ? json.details.map(d=>`${d.col}: ${d.msg}`).join(" · ")
      : ((json&&json.error)||"Gagal simpan");
    return;
  }
  document.getElementById("mpFormModal").style.display="none";
  toast(mpFormMode==="add" ? "Part ditambahkan" : "Part diperbarui");
  await initMasterPart();
  await bootstrap(); redrawAll(); if(selRoute) renderParts();
};

/* ---------------- Ubah Status Terpilih (bulk, popup pilih status baru) ---------------- */
/* Beda dari Edit (mpFormModal): gak perlu buka form penuh per-baris, cukup pilih banyak baris via
   checkbox lalu terapkan 1 status yg sama ke semuanya sekaligus — dipakai mis. buat nandain banyak
   part Cooling Unit (status "C/U") tanpa harus edit satu-satu. Cuma nyentuh kolom status, field lain
   tiap baris gak ikut berubah (lihat api_master_part_bulk_status di api/master_part.php). */

document.getElementById("mpBulkStatusBtn").onclick=()=>{
  if(!mpSelected.size) return;
  document.getElementById("mpBulkStatusCount").textContent = mpSelected.size;
  document.getElementById("mpBulkStatusSelect").value = "Direct";
  document.getElementById("mpBulkStatusMsg").textContent = "";
  document.getElementById("mpBulkStatusModal").style.display="flex";
};
document.getElementById("mpBulkStatusCancel").onclick=()=>document.getElementById("mpBulkStatusModal").style.display="none";
document.getElementById("mpBulkStatusModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });
document.getElementById("mpBulkStatusConfirm").onclick=async()=>{
  const partNos=[...mpSelected];
  const status=document.getElementById("mpBulkStatusSelect").value;
  try{
    const res=await apiPost("master_part_bulk_status",{part_nos:partNos, status});
    document.getElementById("mpBulkStatusModal").style.display="none";
    toast(`${res.updated} part diubah statusnya jadi ${status}`);
    mpSelected.clear();
    await initMasterPart();
    await bootstrap(); redrawAll(); if(selRoute) renderParts();
    if(typeof renderPlaneSim==="function" && document.body.classList.contains("planesim")) renderPlaneSim();
  }catch(e){ document.getElementById("mpBulkStatusMsg").textContent="Gagal ubah status: "+e.message; }
};

/* ---------------- Delete (popup konfirmasi) ---------------- */

document.getElementById("mpDeleteBtn").onclick=()=>{
  if(!mpSelected.size) return;
  document.getElementById("mpDeleteCount").textContent = mpSelected.size;
  document.getElementById("mpDeleteModal").style.display="flex";
};
document.getElementById("mpDeleteCancel").onclick=()=>document.getElementById("mpDeleteModal").style.display="none";
document.getElementById("mpDeleteModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });
document.getElementById("mpDeleteConfirm").onclick=async()=>{
  const partNos=[...mpSelected];
  try{
    const res=await apiPost("master_part_delete",{part_nos:partNos});
    document.getElementById("mpDeleteModal").style.display="none";
    toast(`${res.deleted} data terhapus`);
    mpSelected.clear();
    await initMasterPart();
    await bootstrap(); redrawAll(); if(selRoute) renderParts();
  }catch(e){ toast("Gagal hapus: "+e.message); }
};

/* Tombol Download Excel (#mpCsvBtn) adalah <a href="api.php?action=master_part_excel"> polos di index.php —
   browser yang urus proses download-nya (server kirim header Content-Disposition: attachment), gak perlu JS. */
