/* =====================================================================
   09-NAV — sidebar menu utama (Monitor/Editor/Database/Upload), dgn sub-menu
   Database (Part Aktif/.../Master Part) nested di bawah tombol Database.
   Termasuk toggle hide/unhide sidebar.
   ===================================================================== */
const navMon=document.getElementById("navMon"),navEdit=document.getElementById("navEdit"),
      navDb=document.getElementById("navDb"),navPlaneSim=document.getElementById("navPlaneSim"),
      navSetting=document.getElementById("navSetting");

/* Sidebar bisa di-hide/unhide, state-nya diingat di localStorage. Kalau belum pernah diatur
   manual, default-nya ikut ukuran layar: layar sempit (<=900px, sama dgn breakpoint mobile di
   CSS) mulai dari collapsed spy gak menutupi area kerja, layar lebar mulai dari terbuka. Di
   layar sempit sidebar cuma ngambang/overlay, jadi klik di luar sidebar (di #content) otomatis
   nutup lagi. */
(function initSidebar(){
  const saved = localStorage.getItem("smms_sidebar");
  const collapsed = saved !== null ? saved === "1" : window.innerWidth <= 900;
  document.body.classList.toggle("sidebarCollapsed", collapsed);
})();
document.getElementById("sidebarToggle").onclick = () => {
  const collapsed = document.body.classList.toggle("sidebarCollapsed");
  localStorage.setItem("smms_sidebar", collapsed ? "1" : "0");
};
document.getElementById("content").addEventListener("click", () => {
  if (window.innerWidth <= 900 && !document.body.classList.contains("sidebarCollapsed")) {
    document.body.classList.add("sidebarCollapsed");
    localStorage.setItem("smms_sidebar", "1");
  }
});

/** Pindah tab utama: toggle class body (editing/dbview/upview) & gambar ulang peta. */
function setNav(which){
  [navMon,navEdit,navDb,navPlaneSim,navSetting].forEach(b=>b.classList.remove("on"));
  which.classList.add("on");
  editing=which===navEdit;
  document.body.classList.toggle("editing",editing);
  document.body.classList.toggle("dbview",which===navDb);
  document.body.classList.toggle("planesim",which===navPlaneSim);
  document.body.classList.toggle("setting",which===navSetting);
  vp.classList.toggle("adding",editing&&mode!=="pan");
  // Layar sempit: sidebar cuma ngambang sementara, langsung nutup lagi begitu pilih menu — KECUALI
  // Database, krn sub-menunya (Part Aktif/Master Part/dst) nested di sidebar yg sama, jadi biarin
  // tetap terbuka spy usernya bisa lanjut milih section-nya dulu.
  if(window.innerWidth<=900 && which!==navDb) document.body.classList.add("sidebarCollapsed");
  redrawAll();
}
navMon.onclick=()=>setNav(navMon);
navEdit.onclick=()=>{
  setNav(navEdit);
  // Data picker "+ Sorting Plane"/"+ Dolly Supply" (editor/editor.js) ikut disegarkan tiap tab Editor
  // dibuka -- jaga2 baris config baru ditambah di Setting sejak Editor dibuka terakhir kali.
  if(typeof editorRefreshSortingPlanes==="function") editorRefreshSortingPlanes();
  if(typeof editorRefreshDollySupplies==="function") editorRefreshDollySupplies();
};
navPlaneSim.onclick=()=>{ setNav(navPlaneSim); if(typeof renderPlaneSim==="function") renderPlaneSim(); };
navSetting.onclick=()=>{
  setNav(navSetting);
  if(typeof initSortingPlane==="function") initSortingPlane();
  if(typeof initDollySupply==="function") initDollySupply();
};
navDb.onclick=()=>{
  setNav(navDb);buildDbParts();buildRacksTable();buildPathTable();
  if(typeof initMasterPart==="function") initMasterPart();
  if(typeof initPatternUnload==="function") initPatternUnload();
  if(typeof plRefreshHistory==="function") plRefreshHistory();
  if(typeof plRefreshDates==="function") plRefreshDates();
};

// Sub-nav di dalam tab Database: klik salah satu pill -> tampilkan section itu saja, sembunyikan sisanya.
document.querySelectorAll("#dbsubnav .dbnavbtn").forEach(b=>b.onclick=()=>{
  document.querySelectorAll("#dbsubnav .dbnavbtn").forEach(x=>x.classList.remove("on"));
  document.querySelectorAll("#tab-db .dbsection").forEach(x=>x.classList.remove("on"));
  b.classList.add("on");
  document.querySelector(`#tab-db .dbsection[data-sec="${b.dataset.sec}"]`).classList.add("on");
  document.getElementById("tab-db").setAttribute("data-active-sec", b.dataset.sec);
  // Layar sempit: sidebar cuma ngambang sementara, begitu pilih section-nya langsung nutup lagi.
  if(window.innerWidth<=900) document.body.classList.add("sidebarCollapsed");
});
