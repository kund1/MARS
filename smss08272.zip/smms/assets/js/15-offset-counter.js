/* =====================================================================
   15-OFFSET-COUNTER — Master Offset (smms_offset): tabel edit route -> proses
   -> posisi offset, dipakai HALTE AKTIF & POSISI AKTIF di header
   (offsetStatusFor()/offsetPositionFor(), lihat 03-countdown.js) & jalur
   Prepare/Empty di Monitor. 1 tabel tunggal (Dock|Process|Zone|Route|
   Volume|Offset, tanpa Address/Lane) -- dulu ada 2 tabel terpisah ("Counter
   Offset" + "Posisi Offset") plus kolom Address & Lane, sekarang digabung
   sesuai template Excel sumber & disederhanakan. Alamat halte 1/2/3 (dulu
   kolom Address di sini) sekarang diatur lewat menu "Atur Halte" (tab
   Database, grid, tersimpan ke smms_halte_master) — TIDAK lagi lewat
   tabel/form ini. Proses SORTING/TRANSFER dihapus total (gak kepakai).
   ===================================================================== */

// "SUPPLY" ditambah (dikonfirmasi user) — dasar rumus CD Route/Andon Supply (cdRouteFor, 03-countdown.js):
// offset_val baris process='SUPPLY' per route+volume itu SEKARANG dipakai nentuin posisi towing tiap
// route, GANTI cd bersama polos yg dulu dipakai semua route bareng2. Isi lewat form "+ Add" di tab ini
// (dropdown Process, index.php) — TIDAK perlu tabel/kolom baru, reuse smms_offset yg sudah ada.
// SORTING/TRANSFER SENGAJA tidak ada di sini (dihapus, gak kepakai Monitor sama sekali).
const OFC_PROCESSES=["SUPPLY","PREPARE","HALTE 1","HALTE 2","HALTE 3","EMPTY"];
const OFC_PAGE_SIZE=40;
let ofcAllRows=[], ofcFilteredRows=[], ofcPage=1;
let ofcSelected=new Set(); // id (string) baris yg dicentang di halaman manapun

function ofcSharedDatalist(id, values){
  let dl=document.getElementById(id);
  if(!dl){ dl=document.createElement("datalist"); dl.id=id; document.body.appendChild(dl); }
  dl.innerHTML=values.map(v=>`<option value="${puEsc(v)}">`).join("");
}

/** Render 1 halaman (OFC_PAGE_SIZE baris, read-only + checkbox) dari ofcFilteredRows, + pager.
 * Persis pola tabel Master Part (checkbox + toolbar Edit/Delete), BUKAN cell yg langsung bisa diedit —
 * edit dilakukan lewat popup (ofcOpenForm). */
function ofcRowHtml(r){
  return `<tr data-id="${r.id}"><td><input type="checkbox" class="ofc-rowchk" data-id="${r.id}" ${ofcSelected.has(String(r.id))?"checked":""}></td>`+
    `<td>${puEsc(r.dock)}</td><td>${puEsc(r.process)}</td><td>${puEsc(r.zone)}</td><td>${puEsc(r.route)}</td>`+
    `<td>${r.volume}</td><td>${puEsc(r.offset_val)}</td></tr>`;
}

function ofcRenderPage(){
  const box=document.getElementById("ofcOffsetTableBox");
  const total=ofcFilteredRows.length;
  const totalPages=Math.max(1,Math.ceil(total/OFC_PAGE_SIZE));
  if(ofcPage>totalPages) ofcPage=totalPages;
  const start=(ofcPage-1)*OFC_PAGE_SIZE;
  const pageRows=ofcFilteredRows.slice(start,start+OFC_PAGE_SIZE);
  const thead=`<tr><th style="width:26px"><input type="checkbox" id="ofcSelectAll"></th><th>Dock</th><th>Process</th><th>Zone</th><th>Route</th><th>Volume</th><th>Offset</th></tr>`;
  box.innerHTML=`<div style="overflow-x:auto"><table class="grid compact">${thead}`+
    (pageRows.length?pageRows.map(ofcRowHtml).join(""):'<tr><td colspan="7" style="text-align:center;color:var(--mut)">Belum ada data — upload atau + Add</td></tr>')+`</table></div>`;
  const allChk=document.getElementById("ofcSelectAll");
  allChk.checked = pageRows.length>0 && pageRows.every(r=>ofcSelected.has(String(r.id)));
  allChk.onchange=e=>{
    pageRows.forEach(r=>{ if(e.target.checked) ofcSelected.add(String(r.id)); else ofcSelected.delete(String(r.id)); });
    ofcRenderPage();
  };
  document.querySelectorAll(".ofc-rowchk").forEach(cb=>cb.onchange=()=>{
    if(cb.checked) ofcSelected.add(cb.dataset.id); else ofcSelected.delete(cb.dataset.id);
    ofcUpdateActionButtons();
  });
  const addBtn=n=>`<button class="${n===ofcPage?"on":""}" data-p="${n}">${n}</button>`;
  let pageBtns="";
  if(totalPages<=7){ for(let i=1;i<=totalPages;i++) pageBtns+=addBtn(i); }
  else{
    const nums=new Set([1,2,totalPages-1,totalPages,ofcPage-1,ofcPage,ofcPage+1].filter(n=>n>=1&&n<=totalPages));
    let prev=0;
    [...nums].sort((a,b)=>a-b).forEach(i=>{ if(prev&&i-prev>1) pageBtns+=`<span class="dots">…</span>`; pageBtns+=addBtn(i); prev=i; });
  }
  document.getElementById("ofcPager").innerHTML=!total?"":
    `<span>Menampilkan ${start+1}-${Math.min(start+OFC_PAGE_SIZE,total)} dari ${total} baris</span>
     <div class="pages">
       <button id="ofcPrev" ${ofcPage<=1?"disabled":""}>‹</button>${pageBtns}<button id="ofcNext" ${ofcPage>=totalPages?"disabled":""}>›</button>
     </div>`;
  if(total){
    document.getElementById("ofcPrev").onclick=()=>{ ofcPage--; ofcRenderPage(); };
    document.getElementById("ofcNext").onclick=()=>{ ofcPage++; ofcRenderPage(); };
    document.querySelectorAll("#ofcPager .pages button[data-p]").forEach(b=>b.onclick=()=>{ ofcPage=+b.dataset.p; ofcRenderPage(); });
  }
  ofcUpdateActionButtons();
}

/** Enable/disable tombol Edit (persis 1 baris terpilih) & Delete (>=1 baris terpilih) — sama pola Master Part. */
function ofcUpdateActionButtons(){
  document.getElementById("ofcEditBtn").disabled = ofcSelected.size!==1;
  document.getElementById("ofcDeleteBtn").disabled = ofcSelected.size<1;
}

/** Sinkronkan OFFSET_TABLE global (dipakai offsetStatusFor/offsetPositionFor/supplyOffsetFor/
 * cdRouteFor, 03-countdown.js, & dropdown "C/D AWAL", buildPlaneSel 08-header.js) dari data yg baru
 * di-fetch di tab ini -- SEBELUMNYA nambah/edit/hapus/upload Master Offset di sini gak kepakai di
 * Monitor sama sekali sampai halaman di-reload penuh (bootstrap ulang), krn OFFSET_TABLE gak pernah
 * disentuh dari sini. Bentuk row disamakan persis kayak yg dihasilkan api_bootstrap() (api/data.php):
 * {process,zone,route,volume,offset} -- field offset_val di-rename jadi offset. */
function ofcSyncOffsetTable(){
  OFFSET_TABLE=ofcAllRows.map(r=>({process:r.process, zone:r.zone, route:r.route, volume:+r.volume, offset:r.offset_val}));
  if(typeof buildPlaneSel==="function") buildPlaneSel(); // dropdown "C/D AWAL" ikut Volume terbaru
}

/** Ambil ulang semua baris dari server (load awal & setelah upload/simpan/hapus). */
async function buildOfcOffsetTable(){
  const d=await apiGet("action=offset_list");
  ofcAllRows=d.rows||[]; ofcFilteredRows=ofcAllRows;
  ofcSyncOffsetTable();
  ofcSelected.clear();
  ofcSharedDatalist("ofcRouteList",[...ALLR,"UNP","C/U"]);
  document.getElementById("ofcSearch").value="";
  ofcPage=1;
  ofcRenderPage();
}

document.getElementById("ofcSearch").addEventListener("input", e=>{
  const q=e.target.value.trim().toLowerCase();
  ofcFilteredRows=!q?ofcAllRows:ofcAllRows.filter(r=>[r.process,r.zone,r.route].some(v=>String(v||"").toLowerCase().includes(q)));
  ofcPage=1;
  ofcRenderPage();
});

/* ---------------- Add / Edit (popup, persis pola Master Part) ---------------- */

let ofcFormMode="add", ofcEditId=null;

function ofcOpenForm(mode, row){
  ofcFormMode=mode;
  document.getElementById("ofcFormTitle").textContent = mode==="add" ? "Tambah Baris Master Offset" : "Edit Baris Master Offset";
  document.getElementById("ofcFormMsg").textContent="";
  if(mode==="edit" && row){
    ofcEditId=row.id;
    document.getElementById("ofcfDock").value=row.dock||"43";
    document.getElementById("ofcfProcess").value=row.process;
    document.getElementById("ofcfZone").value=row.zone;
    document.getElementById("ofcfRoute").value=row.route||"";
    document.getElementById("ofcfVolume").value=row.volume||"";
    document.getElementById("ofcfOffset").value=row.offset_val||"";
  }else{
    ofcEditId=null;
    document.getElementById("ofcfDock").value="43";
    document.getElementById("ofcfProcess").value="PREPARE";
    document.getElementById("ofcfZone").value="timur";
    ["ofcfRoute","ofcfVolume","ofcfOffset"].forEach(id=>document.getElementById(id).value="");
  }
  document.getElementById("ofcFormModal").style.display="flex";
}
document.getElementById("ofcAddBtn").onclick=()=>ofcOpenForm("add");
document.getElementById("ofcEditBtn").onclick=()=>{
  if(ofcSelected.size!==1) return;
  const id=[...ofcSelected][0];
  const row=ofcAllRows.find(r=>String(r.id)===id);
  if(row) ofcOpenForm("edit", row);
};
document.getElementById("ofcFormCancel").onclick=()=>document.getElementById("ofcFormModal").style.display="none";
document.getElementById("ofcFormModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });

document.getElementById("ofcFormSave").onclick=async()=>{
  const payload={
    id: ofcFormMode==="edit" ? ofcEditId : undefined,
    dock: document.getElementById("ofcfDock").value.trim(),
    process: document.getElementById("ofcfProcess").value,
    zone: document.getElementById("ofcfZone").value,
    route: document.getElementById("ofcfRoute").value.trim(),
    volume: document.getElementById("ofcfVolume").value.trim(),
    offset_val: document.getElementById("ofcfOffset").value.trim(),
  };
  if(!payload.route){ document.getElementById("ofcFormMsg").textContent="Route wajib diisi"; return; }
  try{
    await apiPost("offset_upsert_row", payload);
    document.getElementById("ofcFormModal").style.display="none";
    toast(ofcFormMode==="add" ? "Baris ditambahkan" : "Baris diperbarui");
    await buildOfcOffsetTable();
  }catch(err){ document.getElementById("ofcFormMsg").textContent="Gagal simpan: "+err.message; }
};

/* ---------------- Delete (popup konfirmasi, bisa multi) ---------------- */

document.getElementById("ofcDeleteBtn").onclick=()=>{
  if(!ofcSelected.size) return;
  document.getElementById("ofcDeleteCount").textContent=ofcSelected.size;
  document.getElementById("ofcDeleteModal").style.display="flex";
};
document.getElementById("ofcDeleteCancel").onclick=()=>document.getElementById("ofcDeleteModal").style.display="none";
document.getElementById("ofcDeleteModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });
document.getElementById("ofcDeleteConfirm").onclick=async()=>{
  const ids=[...ofcSelected];
  try{
    await Promise.all(ids.map(id=>apiPost("offset_delete_row",{id:+id})));
    document.getElementById("ofcDeleteModal").style.display="none";
    toast(`${ids.length} baris dihapus`);
    await buildOfcOffsetTable();
  }catch(err){ toast("Gagal hapus: "+err.message); }
};

document.getElementById("ofcUploadOpenBtn").onclick=()=>{
  document.getElementById("ofcFile").value=""; document.getElementById("ofcFileName").textContent="Belum pilih file";
  document.getElementById("ofcUploadMode").value="0";
  document.getElementById("ofcUploadModal").style.display="flex";
};
document.getElementById("ofcUploadCancel").onclick=()=>document.getElementById("ofcUploadModal").style.display="none";
document.getElementById("ofcUploadModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });

document.getElementById("ofcChooseFile").onclick=()=>document.getElementById("ofcFile").click();
document.getElementById("ofcFile").addEventListener("change",()=>{
  const f=document.getElementById("ofcFile").files[0];
  document.getElementById("ofcFileName").textContent=f?f.name:"Belum pilih file";
});
document.getElementById("ofcUploadBtn").onclick=async()=>{
  const f=document.getElementById("ofcFile").files[0];
  if(!f){ toast("Pilih file dulu"); return; }
  const fd=new FormData(); fd.append("file",f); fd.append("replace",document.getElementById("ofcUploadMode").value);
  const btn=document.getElementById("ofcUploadBtn"); btn.disabled=true;
  try{
    const res=await apiPost("upload_offset",fd,true);
    document.getElementById("ofcUploadModal").style.display="none";
    toast(`Upload OK — ${res.rows} baris`);
    document.getElementById("ofcFile").value=""; document.getElementById("ofcFileName").textContent="Belum pilih file";
    await buildOfcOffsetTable();
  }catch(e){ toast("Gagal upload: "+e.message); }
  finally{ btn.disabled=false; }
};

/** Isi ulang seluruh section Counter Offset (dipanggil saat tab dibuka / setelah upload master). */
function buildOfcAll(){ buildOfcOffsetTable(); }

// Muat section ini begitu sub-nav "Counter Offset" diklik.
document.querySelector('#dbsubnav .dbnavbtn[data-sec="offset"]').addEventListener("click", buildOfcAll);
