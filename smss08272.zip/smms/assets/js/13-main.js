/* =====================================================================
   13-MAIN — util kecil (toast, jam, toggle tema) + urutan inisialisasi
   aplikasi saat halaman dibuka. Harus dimuat setelah semua modul lain.
   ===================================================================== */

/** Tampilkan notifikasi kecil di pojok kanan bawah selama ~2.4 detik. */
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400);}

setInterval(()=>{const n=new Date();
  document.getElementById("clock").textContent=n.toLocaleTimeString("id-ID",{hour12:false});
  document.getElementById("cdate").textContent=n.toLocaleDateString("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
},500);

/* ---- Toggle tema terang/gelap (disimpan di localStorage, gaya assignment-board) ---- */
const themeBtn=document.getElementById("themeToggle");

/** Terapkan tema ke <html data-theme> + update ikon & label tombol (labelnya = mode tujuan kalau diklik). */
function applyTheme(t){
  document.documentElement.setAttribute("data-theme", t);
  themeBtn.querySelector(".ico").textContent = t==="dark" ? "☀️" : "🌙";
  themeBtn.querySelector(".lbl").textContent = t==="dark" ? "Mode Terang" : "Mode Gelap";
}
themeBtn.onclick=()=>{
  const next = document.documentElement.getAttribute("data-theme")==="dark" ? "light" : "dark";
  localStorage.setItem("smms_theme", next);
  applyTheme(next);
};

/** Urutan boot aplikasi: ambil data awal, ukur gambar denah, isi semua dropdown/grid, gambar peta. */
(async()=>{
  try{
    await bootstrap();
    // plane-sim.js dimuat SETELAH file ini di <script> index.php, tapi baris top-level-nya (PS_BUFFER_SIZE/
    // PS_MAX_PLANE/psOverviewRows dari META.plane_sim_*) dieksekusi SAAT SCRIPT itu di-PARSE — race
    // condition nyata: kalau parsing plane-sim.js kelar SEBELUM await bootstrap() di atas ini resolve,
    // nilainya kebaca dari META={} (kosong) & jatuh ke fallback default (12 slot, MAX 24), BUKAN
    // setting asli user (dites langsung: browser headless kadang lebih cepat parsing script drpd
    // nunggu network round-trip bootstrap). psSyncFromMeta() (didefinisikan belakangan di plane-sim.js,
    // tapi udah pasti ke-hoist ke global scope duluan krn baris INI baru beneran jalan setelah SEMUA
    // <script> tag lain selesai di-load/parse) re-baca META yg SEKARANG udah pasti keisi bener.
    if(typeof psSyncFromMeta==="function") psSyncFromMeta();
    editorRefreshRoutes();
    await applyLayoutImage(META.layout_image||'layout.png');
    if(liveMode) await pollCounter();
    buildPlaneSel(); buildAddrList(); buildGrids();
    await loadPlane(plane);
    if(!liveMode) cd=cdStart;
    // renderPlaneSim() dipanggil SEKALI di sini (bukan cuma nunggu operator buka tab Plane Simulation,
    // atau heartbeat 20 detik plane-sim.js) supaya #psFisikWrap SUDAH keisi SEBELUM redrawAll() pertama
    // di bawah — shape "Plane Buffer" di denah (kind:'planebuffer', 06-render.js, nge-CLONE
    // #psFisikWrap) jadi langsung tampil isinya begitu app dibuka, gak nunggu placeholder "Menunggu
    // data..." sampai 20 detik atau sampai tab itu dibuka manual.
    if(typeof renderPlaneSim==="function") await renderPlaneSim();
    updateAsidePanels(); redrawAll(); refresh(); buildDbParts();
  }catch(e){
    setSaveState("GAGAL konek API — sudah jalankan install.php?");
    toast("Gagal memuat: "+e.message);
  }
  fit();
})();
// SENGAJA gak ada window.addEventListener("resize",fit) lagi — dulu tiap resize browser (atau event
// resize dari sebab lain) bikin pan/zoom Editor ke-reset otomatis ke tampilan "FIT semua", ganggu
// pas lagi kerja zoom-in di 1 area. Sekarang pan/zoom murni manual (tombol +/-/FIT, scroll, drag) —
// biar tetep bisa refit kalau perlu, tinggal klik tombol FIT sendiri.
