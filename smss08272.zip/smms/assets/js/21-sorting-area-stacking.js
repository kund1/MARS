/* =====================================================================
   21-SORTING-AREA-STACKING — fondasi kalkulasi Stack utk hierarchy Sorting Area -> Slot -> Stack ->
   Skid -> Part (menu Setting > Sorting Layout, lihat 18-sorting-plane.js). Aturan tinggi fisik SAMA
   PERSIS yg baru diperbaiki utk Plane (plane-sim/plane-sim.js: psMaxPerStackForGroup/
   psPackStacksForPlane, PS_STACK_IDEAL_HEIGHT_M=3.0/PS_STACK_MAX_HEIGHT_M=3.3) — TAPI implementasi di
   sini SENGAJA TERPISAH (bukan memanggil fungsi Plane itu langsung), krn fungsi Plane terikat erat ke
   struktur data grup Plane (g.volume/g.skidCount/g.routes) yg TIDAK ADA di Sorting sama sekali (belum
   ada 1 pun data skid real yg mengalir ke Sorting di fase ini) -- memaksa reuse literal berarti
   mengutak-atik kode Plane yg eksplisit dilarang disentuh. Konstanta & algoritma DIDUPLIKASI SADAR
   (bukan tanpa disadari) sbg fungsi generik di bawah, beroperasi di atas `items` abstrak APA PUN
   sumbernya nanti (bukan grup Plane) -- siap dipakai ulang kapan pun data skid real mulai mengalir ke
   Sorting (di luar scope task ini, TIDAK ADA animasi/pre-calc real dulu).

   TIDAK ADA 1 pun caller di jalur produksi normal yg memanggil fungsi ini sekarang (foundation murni) --
   dites via data sintetik saat verifikasi, atau dipanggil manual dari console browser oleh siapa pun
   yg mau coba (window.calculateSortingStacking tersedia global spt semua fungsi lain di app ini).
   ===================================================================== */

const SA_SKID_OVERHEAD_M=0.15, SA_STACK_IDEAL_HEIGHT_M=3.0, SA_STACK_MAX_HEIGHT_M=3.3, SA_MAX_PER_STACK=4;

/** True kalau item BERIKUTNYA (tinggi `h`, sudah termasuk overhead) masih muat ditambahkan ke stack
 * `cur` yg lagi terbuka -- max SA_MAX_PER_STACK item/stack ATAU tinggi lewat batas ABSOLUT 3.3m,
 * mana yg lebih dulu kena. */
function saFitsInStack(cur, h){
  if(!cur) return false;
  if(cur.items.length>=SA_MAX_PER_STACK) return false;
  return (cur.totalHeight+h)<=SA_STACK_MAX_HEIGHT_M;
}

/**
 * Bin-packing `items` (array `{id, height, arrivalAt}` generik -- height dalam METER, arrivalAt string
 * apa pun yg bisa di-parse `Date.parse` atau kosong) jadi Stack fisik, mengikuti prioritas PERSIS
 * yg dikonfirmasi user (poin 15, Sorting Layout & Plane stacking): (1) Height safety -- TIDAK PERNAH
 * lewat 3.3m absolut, (2) validitas stack, (3) besar di bawah/kecil di atas DALAM 1 stack, (4) arrival
 * order dipertahankan SEBISA MUNGKIN (prioritas TERENDAH -- kalah kalau bentrok sama batas tinggi).
 *
 * Cara kerja: urutkan `items` by `arrivalAt` ascending dulu (poin 4), lalu First-Fit sekuensial ke
 * stack yg lagi terbuka (`cur`) -- begitu `cur` gak muat lagi (4 item ATAU tinggi lewat 3.3m), tutup &
 * buka stack baru. Di dalam 1 stack, urutan tampil disortir ULANG besar->kecil (poin 3) -- ini TIDAK
 * mengubah keanggotaan stack (arrival order tetap yg menentukan SIAPA masuk stack MANA), cuma urutan
 * TAMPIL vertikal di dalam 1 stack yg sama.
 *
 * Return: array Stack `{stackNo, totalHeight, valid, belowMinLayers, items:[...urut besar->kecil]}` —
 * `valid`=false kalau (kasus data ekstrem) 1 item SENDIRI saja sudah > 3.3m; `belowMinLayers`=true
 * kalau stack ini < 3 item (preferensi minimum 3 layer, TAPI bukan berarti invalid -- bisa jadi wajar
 * sisa remainder di ujung data, lihat komentar sama di psPackStacksForPlane/plane-sim.js). */
function calculateSortingStacking(items){
  const sorted=[...(items||[])].sort((a,b)=>{
    const ta=Date.parse(a.arrivalAt||"")||0, tb=Date.parse(b.arrivalAt||"")||0;
    return ta-tb;
  });
  const stacks=[];
  let cur=null;
  sorted.forEach(item=>{
    const h=Math.max(0,+item.height||0)+SA_SKID_OVERHEAD_M;
    if(!saFitsInStack(cur,h)){ cur={items:[], totalHeight:0}; stacks.push(cur); }
    cur.items.push(item);
    cur.totalHeight+=h;
  });
  // Besar di bawah, kecil di atas DALAM 1 stack (poin 3) -- diurutkan desc, dirender pakai
  // column-reverse (pola sama drill-down Plane) jadi item pertama = bawah, item terakhir = atas.
  stacks.forEach(s=>s.items.sort((a,b)=>(+b.height||0)-(+a.height||0)));
  stacks.forEach((s,i)=>{
    s.stackNo=i+1;
    s.valid = s.totalHeight<=SA_STACK_MAX_HEIGHT_M;
    s.belowMinLayers = s.items.length<3;
  });
  return stacks;
}
