/* =====================================================================
   01-STATE — konstanta & variabel global aplikasi (dipakai semua modul lain).
   Harus dimuat PALING AWAL karena file lain langsung memakai isinya.
   ===================================================================== */
const API='api.php';
let IMGW=1758, IMGH=870, ASSET_V=Date.now(); // diukur ulang dari file asli saat load (lihat applyLayoutImage)

let META={}, PLANES=[], ADDRESSES=[], CD_MAP=[], HALTE_MASTER={}, HALTE_DOLLY={}, SUPPLY_ORDER={}, ROUTE_ZONE={}, OFFSET_TABLE=[];
let CFG={racks:[],paths:{},shapes:[]};
let PLANEDATA={}, PCACHE={};
const WEST=["H","L","P","O","N","J","Q","F","M"], EAST=["A","C","I","G","B","E","D","K"], ALLR=[...WEST,...EAST];

/** Semua route yg DIKENAL sistem sekarang: 17 route fisik (ALLR) + route khusus/pseudo (mis. "C/U",
 * "Unpacking") yg terdaftar di Master Offset (ROUTE_ZONE) tapi bukan bagian ALLR — dikonfirmasi user:
 * route khusus ini "berdiri sendiri" (independen dari status Master Part), dipakai di Pattern Unload/
 * Master Offset/Editor+Monitor/Grid Halte persis kayak route A-Q. Registrasi = tambah 1 baris Master
 * Offset (route+zone) — begitu ada, fungsi ini otomatis mengembalikannya, TANPA hardcode ulang di tiap
 * file (GANTI pola ALLR.forEach polos yg sebelumnya tersebar di 06-render.js/07-sidebar.js/
 * 10-database.js/16-pattern-unload.js). */
function allKnownRoutes(){
  const extra=Object.keys(ROUTE_ZONE||{}).filter(r=>!ALLR.includes(r)).sort();
  return [...ALLR, ...extra];
}

/** Zone (timur/barat) 1 route — VLOOKUP Master Offset (ROUTE_ZONE) dulu, fallback WEST/EAST hardcode
 * kalau route ini belum terdaftar di Master Offset (mis. salah satu 17 route fisik yg emang udah py
 * zone tetap sejak awal). SATU sumber dipakai semua tempat yg butuh zone 1 route (GANTI logic identik
 * yg sebelumnya diduplikasi di puRouteZone/rcolor/label WEST-EAST sidebar). */
function zoneOf(r){ return ROUTE_ZONE[r] || (WEST.includes(r) ? "barat" : "timur"); }
let plane="01", cdStart=20, cd=20, auto=false, selRoute=null, mapFocusOnly=false;
// Countdown abis (cd < CD_END) -> langsung naik ke plane berikutnya (lihat stepCd(), 08-header.js) —
// gak ada fase/state "kembali" terpisah lagi, towing langsung reset ke posisi awal plane baru.
let liveMode=false, liveOrderNo=null, liveStale=false;

// Titik referensi hasil ekstraksi vektor dari sheet "Route Int Supply By Zone" (layout Excel asli).
// Posisi per titik akurat, TAPI urutan jalur antar-titik tidak bisa direkonstruksi otomatis dengan andal
// (jalur fisik berkelok mengikuti gang antar-rack, dua metode auto-ordering menghasilkan garis ngaco) —
// jadi ditampilkan sebagai panduan titik lepas saat mode "+ Jalur", bukan jalur siap pakai.
const ROUTE_GUIDE={"A":[[742,358],[1287,365],[850,89],[1355,165],[459,296],[1361,247],[409,130],[1362,330]],"B":[[579,358],[552,200],[807,210],[1470,348],[1488,271],[599,283],[1276,211],[1176,283],[1673,408]],"C":[[561,358],[535,200],[789,210],[563,283],[1258,211],[1140,283],[1378,262]],"D":[[598,358],[571,200],[825,210],[617,283],[1295,211],[1194,283]],"E":[[867,89],[1372,165],[476,296],[480,155],[427,130],[405,168],[843,210],[1313,211],[617,358]],"F":[[777,358],[1322,365],[1442,366],[741,283],[1317,283]],"G":[[760,358],[1304,365],[1371,366],[670,283],[1247,283]],"H":[[754,487],[1306,662],[846,663],[730,651],[702,401],[1292,539],[1167,488]],"I":[[736,487],[1317,366],[580,283],[668,488],[1274,539],[1157,283],[1149,488]],"J":[[773,487],[1408,366],[702,420],[705,283],[1311,539],[1282,283],[1186,488]],"K":[[721,541],[1335,366],[1487,348],[1506,271],[636,283],[1126,539],[1213,283],[1690,408]],"L":[[704,541],[1288,662],[828,663],[734,598],[1108,539]],"M":[[811,541],[1343,662],[883,663],[748,651],[1216,539]],"N":[[777,541],[1324,662],[865,663],[752,598],[1182,539]],"O":[[758,541],[1389,366],[1489,471],[1416,597],[688,283],[1163,539],[1265,283]],"P":[[740,541],[1352,366],[1505,348],[1525,271],[654,283],[1145,539],[1231,283],[1709,408]],"Q":[[795,541],[1426,366],[723,283],[1199,539],[1300,283]]};
let editing=false, mode="pan", editRoute="H";
