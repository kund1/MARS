/* =====================================================================
   06-RENDER — gambar ulang semua isi SVG denah: jalur, rack, towing+8 dolly,
   plus animasi pergerakan saat countdown berubah.
   ===================================================================== */
const NS="http://www.w3.org/2000/svg";
const svg=document.getElementById("overlay");

/** Set viewBox + ukuran SVG overlay sesuai ukuran gambar denah saat ini (IMGW/IMGH). */
function applyStageSize(){
  svg.setAttribute("viewBox",`0 0 ${IMGW} ${IMGH}`);
  svg.setAttribute("width",IMGW);svg.setAttribute("height",IMGH);
}

/** Load gambar via Image() cuma buat dapat naturalWidth/naturalHeight-nya (Promise). */
function loadImgNatural(src){
  return new Promise((resolve,reject)=>{
    const im=new Image();
    im.onload=()=>resolve({w:im.naturalWidth,h:im.naturalHeight});
    im.onerror=()=>reject(new Error("gagal memuat gambar "+src));
    im.src=src;
  });
}

/** Ukuran denah diukur dari file asli (bukan di-hardcode) supaya ganti gambar dgn resolusi lain tetap align. */
async function applyLayoutImage(file){
  const src='assets/'+file+'?v='+ASSET_V;
  const {w,h}=await loadImgNatural(src);
  IMGW=w; IMGH=h;
  document.getElementById("layoutimg").src=src;
  applyStageSize();
}

/** Helper bikin elemen SVG (namespace-aware). */
const S=t=>document.createElementNS(NS,t);

// 17 warna 1-per-rute, tervalidasi CVD-safe (protan/deutan) berurutan sesuai daftar ALLR
// (WEST lalu EAST) — dua rute yang bersebelahan di daftar sidebar dijamin gampang dibedakan.
const ROUTE_COLOR={
  H:"#ad0445", L:"#00977d", P:"#a3136e", O:"#009554", N:"#922493", J:"#318b00", Q:"#7932af",
  F:"#727f00", M:"#5941c1", A:"#986e00", C:"#2351c6", I:"#b45a00", G:"#0061be", B:"#c54600",
  E:"#008cbd", D:"#cc3621", K:"#0094a0",
};
/** Warna khas satu route (dipakai jalur, badge towing, kotak dolly, kode di sidebar) — fallback (route
 * pseudo di luar 17 ROUTE_COLOR di atas, mis. "C/U"/"Unpacking") pakai zoneOf() (01-state.js, VLOOKUP
 * Master Offset) supaya warnanya konsisten dgn zone route itu, bukan selalu jatuh ke --east. */
const rcolor=r=>ROUTE_COLOR[r]||(zoneOf(r)==="barat"?"var(--west)":"var(--east)");
// Identitas warna per NOMOR SLOT dolly (1-8, konsisten lintas route — dolly 1 selalu warna sama di
// route manapun) — dipakai border+teks kotak dolly di denah biar gampang dibedakan sekilas tanpa
// perlu baca angkanya. Sengaja hindari oranye/kuning (bentrok var(--act), warna "lagi difokus") dan
// abu-abu (bentrok var(--mut), warna "kosong/tuntas").
const DOLLY_COLORS=["#2563EB","#16A34A","#9333EA","#0891B2","#DB2777","#65A30D","#4F46E5","#0D9488"];
const dollyColor=i=>DOLLY_COLORS[i%DOLLY_COLORS.length];
// Posisi flip (mirror) gambar towing per route DIBEKUKAN dari frame TERAKHIR dia beneran bergerak
// (moveTowings, lihat animateCd) — pas towing lagi DIAM di halte, dipakai ulang nilai ini (BUKAN
// dihitung ulang lewat towShouldFlip di posisi diam), krn kalau titik halte-nya pas di tikungan,
// towShouldFlip bisa kebaca arah yg beda dari arah datangnya towing barusan.
let lastTowFlip={};
const hcol=["","var(--h1)","var(--h2)","var(--h3)"];
const stagecol={SORTING:"var(--st-sorting)",TRANSFER:"var(--st-transfer)",EMPTY:"var(--st-empty)",PREPARE:"var(--st-prepare)"};
const stageAbbr={SORTING:"SRT",TRANSFER:"TRF",EMPTY:"EMP",PREPARE:"PRP"};

/**
 * Isi visual shape "Plane Buffer" (kind==='planebuffer', 1 shape khusus — lihat editor/editor.js) —
 * dikonfirmasi user LANGSUNG liat screenshot tab Plane Simulation: "buat visual plane benar-benar
 * seperti ini complete, ada no plane, grid kotak antar plane, data skid dll" — jadi BUKAN cuma 1 gauge
 * plane aktif lagi (versi sebelumnya), tapi SELURUH baris 12 slot (legend + axis + tiap kartu: gauge,
 * skid count, nomor plane, tag AKTIF) PERSIS kayak yg kelihatan di tab itu.
 *
 * Caranya: CLONE beneran <div id="psFisikWrap"> (+ .ps-legend di atasnya) yg SUDAH di-render tab Plane
 * Simulation (psRenderFisik(), plane-sim.js) — bukan bangun ulang manual elemen² itu satu-satu di sini.
 * Ini JAUH lebih tahan-lama drpd niru markup-nya (kalau tab aslinya nanti berubah tampilannya, clone
 * ini otomatis ikut berubah, gak perlu disinkronkan manual 2 tempat) — reuse psRenderFisik() APA
 * ADANYA lewat DOM yg sudah jadi, bukan reuse function-nya doang kayak versi sebelumnya.
 * KONSEKUENSI: hasil clone TIDAK interaktif (cloneNode() gak mbawa event listener JS `.onclick=...`
 * yg sudah ditempel psBuildPlaneCard, cuma HTML/CSS-nya) — klik nomor plane di SINI gak buka drill-down
 * (tetap harus dari tab Plane Simulation asli). `pointer-events:none` dipasang biar gak menyesatkan
 * (kelihatan gak bisa diklik, kursor gak berubah).
 *
 * `#psFisikWrap` DIISI plane-sim.js (renderPlaneSim()) YANG DIPICU dari BANYAK titik independen dari
 * tab mana yg lagi kebuka (ganti plane header, AUTO/pollCounter jalan, dst — lihat pemanggil
 * renderPlaneSim di 02-api.js/08-header.js), jadi biasanya SUDAH terisi walau operator gak pernah
 * buka tab itu sama sekali — kalau BENERAN belum pernah (baru buka app, belum ada plane berganti sekali
 * pun), tampilin placeholder teks drpd kotak kosong bikin bingung.
 *
 * Ukuran ASLI clone (dari CSS plane-sim.css: 12 kartu + axis + legend) HAMPIR PASTI beda jauh dari
 * ukuran shape yg diatur bebas oleh operator — di-scale() ke ukuran box shape SEKARANG. BEDA dari
 * pendekatan gauge tunggal sebelumnya (itu bisa dihitung dari konstanta CSS langsung, TANPA nunggu
 * layout) — konten di sini jauh lebih kompleks (12 kartu, teks panjang beda-beda per plane, dst),
 * ngitung manual by-hand jadi rapuh/gampang meleset — jadi SENGAJA dipilih ukur beneran lewat
 * getBoundingClientRect() 1 frame setelah di-append (requestAnimationFrame), BUKAN konstanta hardcode.
 * AMAN dari "kedip" krn redrawAll() (yg motong-tempel ulang elemen ini dari nol tiap dipanggil) SENDIRI
 * cuma dipicu di titik DISKRET (ganti plane, tick countdown "onArrive", ganti mode, dst) — BUKAN tiap
 * frame animasi towing (animateCd/moveTowings gerakin towing lewat setAttribute transform langsung,
 * TANPA lewat redrawAll() sama sekali, lihat animateCd) — jadi 1 frame delay scale ini gak kerasa.
 *
 * Digambar dalam koordinat LOCAL/belum-dirotasi (parent <g> shape ini yg udah dibungkus `rotate(...)`,
 * lihat redrawAll) — arah tampilan (baris horizontal biasa, atau vertikal kalau rot=90°, dst) otomatis
 * ikut rotasi yg dipilih operator sendiri lewat panel properti/handle rotasi — TIDAK perlu logic
 * rotasi khusus di sini.
 *
 * INI FASE 1 (VISUAL DOANG) — dikonfirmasi user, dikerjakan bertahap. Animasi "skid keluar dari buffer
 * -> baton pass (bergantian per route sesuai Master Offset) -> nempel dolly -> towing" itu FASE 2
 * TERPISAH (logic penjadwalan baru, belum ada presedennya di sistem) — SENGAJA belum dikerjakan di sini.
 */
function renderPlaneBufferContent(g, s){
  // Denah asli RAKSASA & di-zoom-out jauh (scale global, 04-viewport.js) biar muat di layar —
  // <foreignObject> ini hidup di koordinat SVG YANG SAMA (user-unit = px denah asli) & anak SVG
  // BIASA (gak ada mekanisme scaling sendiri) — jadi otomatis ikut nyusut/membesar bareng SELURUH
  // denah tiap `#stage` di-zoom, TANPA perlu logic kompensasi zoom terpisah di sini/fitPlaneBufferToBox
  // sama sekali (lihat komentar panjang fitPlaneBufferToBox soal ini — beda dari versi sebelumnya
  // yg salah bagi `fitScale/z`, bikin konten kegedean belasan kali lipat).
  //
  // Orientasi konten (getPlaneContentRotation, di bawah) ditentukan MURNI dari bentuk kotak lokal
  // (s.w vs s.h) vs bentuk natural konten (naturalW vs naturalH) — SAMA SEKALI TIDAK melibatkan
  // s.rot (itu rotasi SHAPE di denah, level `<g>`/redrawAll, urusan TERPISAH — lihat komentar
  // panjang fitPlaneBufferToBox). foreignObject+wrap overflow:hidden jadi jaring pengaman terakhir
  // kalau ada pembulatan sub-pixel meleset dikit.
  const fo=document.createElementNS(NS,"foreignObject");
  fo.setAttribute("x",s.x); fo.setAttribute("y",s.y); fo.setAttribute("width",s.w); fo.setAttribute("height",s.h);
  fo.style.overflow="hidden";
  const wrap=document.createElement("div");
  wrap.style.cssText=
    "width:100%;height:100%;overflow:hidden;pointer-events:none;box-sizing:border-box;"
    +"display:flex;align-items:center;justify-content:center;";

  const inner=document.createElement("div"); // konten natural-size, di-rotate+scale oleh fitPlaneBufferToBox
  inner.className="ps-planebuffer-inner";
  inner.style.cssText="width:max-content;height:max-content;padding:6px;box-sizing:border-box;transform-origin:center center;";
  wrap.appendChild(inner);

  const legend=document.querySelector("#tab-planesim .ps-legend");
  const fisikWrap=document.getElementById("psFisikWrap");
  if(fisikWrap && fisikWrap.children.length && fisikWrap.querySelector(".ps-plane-card")){
    if(legend) inner.appendChild(legend.cloneNode(true));
    const clone=fisikWrap.cloneNode(true);
    clone.removeAttribute("id"); clone.style.display=""; // clone SELALU tampil, apa pun display asalnya (mode Full Plane lagi aktif -> psFisikWrap disembunyikan di tab aslinya)
    clone.querySelectorAll("[id]").forEach(el=>el.removeAttribute("id")); // cegah id dobel di 1 dokumen (psAxis/psBuffer)
    inner.appendChild(clone);
  }else{
    const ph=document.createElement("div");
    ph.style.cssText="font-size:11px;color:#64748B;padding:8px;font-family:sans-serif;";
    ph.textContent="Menunggu data Plane Simulation... (buka tab Plane Simulation sekali, atau tunggu plane berganti)";
    inner.appendChild(ph);
  }
  fo.appendChild(wrap);
  g.appendChild(fo);
  fitPlaneBufferToBox(inner, s);
}

/** Tentukan orientasi konten Plane Buffer — 0° atau 90°, TIDAK PERNAH nilai lain — MURNI dari
 * perbandingan bentuk kotak LOKAL shape ini (s.w vs s.h) ke bentuk NATURAL konten (naturalW vs
 * naturalH). SENGAJA sama sekali TIDAK melibatkan `s.rot` (`s.rot` = rotasi SHAPE di denah, level
 * `<g>`/redrawAll — urusan TERPISAH: itu nempatin ORIENTASI kotak+konten di dunia/denah, BUKAN
 * nentuin apakah konten perlu diputar biar cocok bentuk kotaknya sendiri). Dua urusan ini digabung
 * cuma lewat PENJUMLAHAN sudut biasa saat browser ngerender (`<g>` rotate di LUAR, konten rotate di
 * DALAM foreignObject) — TIDAK saling meniadakan/membatalkan (dulu sempat salah pakai `-s.rot` utk
 * "biar teks tegak", itu SALAH krn bikin fit-nya ikut tergantung s.rot padahal harusnya independen).
 *
 * Aturan (persis dikonfirmasi user):
 *   buffer landscape (w>=h) + content landscape (naturalW>=naturalH) -> 0  (bentuk sudah cocok)
 *   buffer portrait          + content landscape                      -> 90 (konten diputar jd portrait)
 *   buffer landscape         + content portrait                       -> 90 (konten diputar jd landscape)
 *   buffer portrait          + content portrait                       -> 0  (bentuk sudah cocok)
 * Ringkasnya: rotate 90° kalau orientasi (landscape/portrait) box & content BEDA, biarkan 0° kalau SAMA. */
function getPlaneContentRotation(s, naturalW, naturalH){
  const bufferLandscape=s.w>=s.h;
  const contentLandscape=naturalW>=naturalH;
  return (bufferLandscape===contentLandscape) ? 0 : 90;
}

/** Hitung & terapkan rotate+scale `.ps-planebuffer-inner` supaya SELURUH konten clone (grid+legend+
 * label+skid count+status, satu kesatuan — BUKAN cuma .ps-plane-cols doang kayak versi sebelum2nya
 * yg pakai CSS `zoom`) muat PENUH di kotak lokal shape ini (s.w x s.h), dgn sedikit padding dari tepi.
 *
 * Langkah (urutan penting, dikonfirmasi user):
 *  1. RESET transform dulu (`inner.style.transform="none"`) SEBELUM ukur — offsetWidth/Height
 *     sebenarnya independen dari CSS transform (transform cuma visual/paint, bukan layout), tapi
 *     direset eksplisit di sini biar gak ada keraguan sama sekali kalau ukuran yg terbaca itu
 *     MURNI natural size, bukan sisa transform dari render sebelumnya.
 *  2. Ukur naturalW/naturalH (offsetWidth/Height, natural/belum di-apa2in).
 *  3. Tentukan orientasi (getPlaneContentRotation di atas) — 0 atau 90, TIDAK peduli s.rot.
 *  4. Hitung ukuran SETELAH rotate (lebar/tinggi TERTUKAR kalau orientasi=90).
 *  5. Kurangi kotak dgn padding (jarak dari tepi kotak biru — biar konten gak nempel persis garis).
 *  6. scaleX/scaleY dari ukuran-setelah-rotate vs kotak-setelah-padding, fitScale = Math.min keduanya
 *     (jaga aspect ratio, gak pernah gepeng/distorsi).
 *  7. Pasang transform gabungan `rotate(...) scale(...)` SEKALI (bukan 2 transform terpisah).
 *
 * ZOOM DENAH (`scale` global, 04-viewport.js) SENGAJA TIDAK ikut dihitung di sini — `s.w`/`s.h` (attr
 * foreignObject) & `inner.offsetWidth/Height` SAMA-SAMA hidup di 1 sistem koordinat SVG yg sama, dan
 * foreignObject ini cuma anak SVG BIASA (gak ada mekanisme scaling sendiri) — jadi otomatis ikut
 * discale bareng SELURUH denah tiap `#stage` di-zoom TANPA perlu logic tambahan di sini. Pernah dites
 * pakai kompensasi `scale(1/z)` di sini — hasilnya konten ke-scale dobel (~12-16x kegedean, sekali
 * dari `#stage`, sekali lagi salah dari sini) — makanya SEKARANG SENGAJA tidak disentuh sama sekali.
 *
 * `fitScale`+`fitRot` disimpan di `inner.dataset` biar syncOnePlaneBufferZoomScale (di bawah) bisa
 * reapply transform yg SAMA tanpa perlu ukur ulang offsetWidth/Height (nilai ini TIDAK berubah cuma
 * krn zoom denah berubah, cuma berubah kalau ukuran box/kontennya SENDIRI berubah — lihat
 * redrawAll/refreshPlaneBufferShapes, itu yg manggil fitPlaneBufferToBox ulang). */
function fitPlaneBufferToBox(inner, s){
  inner.style.transform="none"; // reset dulu -- pastikan pengukuran di bawah murni natural size
  const naturalW=inner.offsetWidth, naturalH=inner.offsetHeight;
  if(naturalW<=0 || naturalH<=0) return;

  const contentRot=getPlaneContentRotation(s, naturalW, naturalH); // 0 atau 90, TIDAK peduli s.rot
  const swapped=(contentRot===90);
  const rotatedW=swapped ? naturalH : naturalW, rotatedH=swapped ? naturalW : naturalH;

  const padding=2; // jarak dari tepi kotak biru, biar konten gak nempel persis ke garis (dikecilkan dari 8 -- sisa ruang kosong terbesar sebenarnya dari selisih aspect-ratio, bukan padding ini)
  const availableW=Math.max(1, s.w-padding*2), availableH=Math.max(1, s.h-padding*2);
  const scaleX=availableW/rotatedW, scaleY=availableH/rotatedH;
  const fitScale=Math.min(scaleX, scaleY); // Math.min -- jaga aspect ratio, gak pernah gepeng
  if(!isFinite(fitScale) || fitScale<=0) return;

  inner.dataset.fitScale=fitScale;
  inner.dataset.fitRot=contentRot;
  inner.style.transformOrigin="center center";
  inner.style.transform=`rotate(${contentRot}deg) scale(${fitScale})`;
}

/** Terapkan ULANG transform `.ps-planebuffer-inner` dari `fitScale`+`fitRot` yg SUDAH dihitung &
 * disimpan fitPlaneBufferToBox() (inner.dataset) — TIDAK ukur ulang offsetWidth/Height & TIDAK
 * menghitung ulang orientasi/fitScale apa pun (natural size & orientasi konten TIDAK berubah cuma
 * krn zoom denah berubah — lihat komentar panjang fitPlaneBufferToBox soal kenapa `scale` global gak
 * perlu dilibatkan sama sekali). Dipanggil dari syncPlaneBufferZoomScale/applyT() tiap pan-zoom
 * berubah — murni reapply idempoten (transform yg di-set SELALU SAMA), jaga-jaga kalau transform-nya
 * somehow ke-reset di antaranya, BUKAN krn beneran perlu recalculate tiap zoom tick. */
function syncOnePlaneBufferZoomScale(inner){
  const fit=parseFloat(inner.dataset.fitScale || "1");
  const rot=parseFloat(inner.dataset.fitRot || "0");
  inner.style.transform=`rotate(${rot}deg) scale(${fit})`;
}
/** Sinkronkan SEMUA shape Plane Buffer yg lagi ke-render (biasanya cuma 1, tapi jaga2) ke level zoom
 * SEKARANG — dipanggil dari applyT() (04-viewport.js) tiap scale berubah (wheel/tombol +-/FIT/dst). */
function syncPlaneBufferZoomScale(){
  document.querySelectorAll(".ps-planebuffer-inner").forEach(syncOnePlaneBufferZoomScale);
}

/** Refresh RINGAN shape "Plane Buffer" SAJA (kind:'planebuffer'), TANPA redrawAll() penuh — dipanggil
 * tiap tick countdown (refreshHeader(), 08-header.js, bareng psRefreshActiveCard) supaya gauge di
 * clone-nya ikut ngetik/drain PERSIS kayak di tab Plane Simulation asli. redrawAll() sendiri CUMA
 * dipicu titik diskret (ganti plane, dst — lihat komentar panjang renderPlaneBufferContent di atas),
 * jadi tanpa fungsi ini clone-nya bakal keliatan "beku" di antara titik2 itu walau gauge SUMBER
 * (#psFisikWrap asli) sebenarnya udah update tiap detik. Cuma bongkar-pasang <foreignObject> shape
 * INI (rect/handle-nya dibiarin apa adanya) — TIDAK nyentuh rack/jalur/towing yg gak berubah tiap tick,
 * jauh lebih murah drpd redrawAll() penuh dipanggil tiap detik. */
function refreshPlaneBufferShapes(){
  if(typeof CFG==="undefined" || !CFG.shapes || !svg) return;
  CFG.shapes.forEach((s,i)=>{
    if(s.kind!=="planebuffer") return;
    const g=svg.querySelector('g[data-shape="'+i+'"]');
    if(!g) return;
    const fo=g.querySelector("foreignObject");
    if(fo) fo.remove();
    renderPlaneBufferContent(g,s);
  });
}

/** Refresh RINGAN shape "Sorting Plane"/"Dolly Supply" SAJA (badge angka SORTING_STOCK/DOLLY_STOCK) —
 * padanan persis `refreshPlaneBufferShapes()` di atas, dipanggil dari assets/js/19-flow-anim.js tiap
 * tick (SORTING_STOCK/DOLLY_STOCK berubah tiap ada token masuk/keluar) TANPA redrawAll() penuh — cuma
 * bongkar-pasang `<g class="flow-content">` (dipasang renderRouteBoxContent di atas), `<rect>` dasar
 * shape/handle edit di `g` yg sama TIDAK disentuh. */
function refreshFlowShapeBadges(){
  if(typeof CFG==="undefined" || !CFG.shapes || !svg) return;
  CFG.shapes.forEach((s,i)=>{
    if(s.kind!=="sortingarea" && s.kind!=="dollysupply") return;
    const g=svg.querySelector('g[data-shape="'+i+'"]');
    if(!g) return;
    const old=g.querySelector(".flow-content");
    if(old) old.remove();
    if(s.kind==="sortingarea") renderSortingAreaContent(g,s); else renderDollySupplyContent(g,s);
  });
}

/**
 * Isi visual shape "Dolly Supply" (kind==='dollysupply') — shape config-only (identity Route dari
 * smms_dolly_supply, ditempatkan lewat picker "+ Dolly Supply", editor/editor.js), BUKAN shape
 * "Plane Buffer" (kind==='planebuffer', TIDAK disentuh sama sekali di sini — beda mekanisme total).
 * (Dulu fungsi generik ini juga dipakai "Sorting Plane" — DIGANTI `renderSortingAreaContent`, koreksi
 * arsitektur 2026-08-27, krn Sorting Area butuh grid Slot BERLABEL row_count x 2, bukan grid dekoratif
 * polos mengisi-lebar spt di sini.)
 *
 * BEDA dari Plane Buffer (yg clone DOM kompleks lewat <foreignObject>+ukur offsetWidth/Height): isi
 * shape ini cuma placeholder statis (2 baris teks + grid kotak dekoratif, opsional badge angka stock
 * fase animasi — lihat assets/js/19-flow-anim.js) — dirender pakai elemen SVG PRIMITIF langsung
 * (<text>+<rect> kecil), TANPA foreignObject/pengukuran DOM sama sekali. Ini SENGAJA (dikonfirmasi user:
 * "jangan buat engine transform baru") — jauh lebih murah dipanggil ulang tiap redrawAll() (termasuk
 * tiap frame drag-resize shape), & otomatis ikut rotasi <g rotate(...)> yg sudah dipasang di level
 * shape (SAMA PERSIS cara `s.text` shape generic sudah berlaku — TIDAK ada logic orientasi independen
 * ala getPlaneContentRotation/fitPlaneBufferToBox, itu preseden KHUSUS Plane Buffer krn kontennya
 * clone DOM asli, tidak relevan di sini).
 *
 * Grid dekoratif: SELALU 2 baris, jumlah kolom dihitung dari lebar box yg tersedia (mengisi-lebar,
 * BUKAN row_count x column_count spt Sorting Area — Dolly Supply belum py konsep Rows/Slot sendiri). */
function renderRouteBoxContent(g, s, headerLabel, routeValue, badgeCount, boxColor, boxStroke){
  // Semua elemen konten dibungkus 1 <g class="flow-content"> -- biar refreshFlowShapeBadges() (dipanggil
  // assets/js/19-flow-anim.js tiap tick, mirip refreshPlaneBufferShapes()) bisa buang+gambar ulang
  // KONTEN doang (badge angka stock, dst) TANPA nyentuh <rect> dasar shape/handle edit di `g` yg sama.
  const wrap=S("g"); wrap.setAttribute("class","flow-content");
  g.appendChild(wrap);
  const cx=s.x+s.w/2;
  const padTop=Math.min(16, s.h*0.2);
  const t1=S("text"); t1.setAttribute("x",cx); t1.setAttribute("y",s.y+padTop);
  t1.setAttribute("text-anchor","middle"); t1.setAttribute("font-size","9"); t1.setAttribute("font-weight","700");
  t1.setAttribute("fill",s.stroke||"#475569"); t1.textContent=headerLabel;
  wrap.appendChild(t1);

  const t2=S("text"); t2.setAttribute("x",cx); t2.setAttribute("y",s.y+padTop+16);
  t2.setAttribute("text-anchor","middle"); t2.setAttribute("font-size","13"); t2.setAttribute("font-weight","700");
  t2.setAttribute("fill",s.stroke||"#475569"); t2.textContent="ROUTE "+(routeValue||"?");
  wrap.appendChild(t2);

  if(badgeCount!==null && badgeCount!==undefined){
    const bt=S("text"); bt.setAttribute("x",s.x+s.w-6); bt.setAttribute("y",s.y+12);
    bt.setAttribute("text-anchor","end"); bt.setAttribute("font-size","11"); bt.setAttribute("font-weight","700");
    bt.setAttribute("fill",s.stroke||"#475569"); bt.textContent=String(badgeCount);
    wrap.appendChild(bt);
  }

  // Grid dekoratif 2 baris, kolom mengisi lebar tersedia -- placeholder visual MURNI, BUKAN data skid.
  const gridTop=s.y+padTop+24, gridBottom=s.y+s.h-8;
  const gridHeight=gridBottom-gridTop;
  if(gridHeight<8 || s.w<20) return;
  const rows=2, gap=Math.max(2,s.w*0.01);
  let cellH=Math.max(4,(gridHeight-gap)/rows);
  const availW=s.w-16;
  cellH=Math.min(cellH, availW); // jaga cell gak lebih lebar dari box (box sempit+tinggi)
  const cols=Math.max(1, Math.min(30, Math.floor((availW+gap)/(cellH+gap))));
  const gridW=cols*cellH+(cols-1)*gap;
  const startX=s.x+(s.w-gridW)/2;
  for(let r=0;r<rows;r++){
    for(let c=0;c<cols;c++){
      const rect=S("rect");
      rect.setAttribute("x",startX+c*(cellH+gap)); rect.setAttribute("y",gridTop+r*(cellH+gap));
      rect.setAttribute("width",cellH); rect.setAttribute("height",cellH);
      rect.setAttribute("fill",boxColor); rect.setAttribute("stroke",boxStroke); rect.setAttribute("stroke-width",0.75);
      wrap.appendChild(rect);
    }
  }
}
/** Wrapper "Dolly Supply" — badge angka (opsional) dari DOLLY_STOCK[route].length kalau layer animasi
 * (assets/js/19-flow-anim.js) sudah dimuat, null kalau belum (guard typeof, urutan load file
 * independen -- lihat komentar file itu). */
function renderDollySupplyContent(g,s){
  const badge=(typeof DOLLY_STOCK!=="undefined" && DOLLY_STOCK[s.dollyRoute]) ? DOLLY_STOCK[s.dollyRoute].length : null;
  renderRouteBoxContent(g,s,"DOLLY SUPPLY",s.dollyRoute,badge,"#DDD6FE","#6D28D9");
}

/**
 * Isi visual shape "Sorting Area" (kind==='sortingarea', GANTIKAN 'sortingplane' total — koreksi
 * arsitektur 2026-08-27) — hierarchy Sorting Area -> Slot -> Stack (lihat assets/js/18-sorting-plane.js
 * `sortingSlotsFor`, assets/js/21-sorting-area-stacking.js `calculateSortingStacking`). BEDA dari
 * `renderRouteBoxContent` (dipakai Dolly Supply, grid dekoratif polos): di sini SETIAP kotak = 1 Slot
 * BERLABEL kode-nya sendiri (mis. "SRG-01-03"), disusun persis `row_count` baris x 2 kolom (FIX) —
 * SESUAI `sortingSlotsFor`'s rumus (row=ceil(seq/2), col=((seq-1)%2)+1), BUKAN kolom-mengisi-lebar
 * kayak Dolly Supply. Isi tiap Slot SENGAJA KOSONG (belum ada 1 pun data Stack/Skid real yg mengalir
 * ke Sorting di fase ini) — jujur sesuai kondisi data, sama sikap yg diambil "Sorting Plane" sebelumnya.
 * SVG primitif murni (TANPA foreignObject), sama alasan `renderRouteBoxContent` (murah dipanggil ulang
 * tiap redrawAll()/drag-resize, otomatis ikut rotasi `<g rotate(...)>`, TIDAK ada logic orientasi
 * independen ala Plane Buffer). */
function renderSortingAreaContent(g,s){
  const wrap=S("g"); wrap.setAttribute("class","flow-content");
  g.appendChild(wrap);
  const cx=s.x+s.w/2;
  const padTop=Math.min(16, s.h*0.15);
  const t1=S("text"); t1.setAttribute("x",cx); t1.setAttribute("y",s.y+padTop);
  t1.setAttribute("text-anchor","middle"); t1.setAttribute("font-size","9"); t1.setAttribute("font-weight","700");
  t1.setAttribute("fill",s.stroke||"#475569"); t1.textContent="SORTING "+(s.sortingCode||"?");
  wrap.appendChild(t1);

  const t2=S("text"); t2.setAttribute("x",cx); t2.setAttribute("y",s.y+padTop+16);
  t2.setAttribute("text-anchor","middle"); t2.setAttribute("font-size","13"); t2.setAttribute("font-weight","700");
  t2.setAttribute("fill",s.stroke||"#475569"); t2.textContent="ROUTE "+(s.route||"?");
  wrap.appendChild(t2);

  const badge=(typeof SORTING_STOCK!=="undefined" && SORTING_STOCK[s.route]) ? SORTING_STOCK[s.route].length : null;
  if(badge!==null){
    const bt=S("text"); bt.setAttribute("x",s.x+s.w-6); bt.setAttribute("y",s.y+12);
    bt.setAttribute("text-anchor","end"); bt.setAttribute("font-size","11"); bt.setAttribute("font-weight","700");
    bt.setAttribute("fill",s.stroke||"#475569"); bt.textContent=String(badge);
    wrap.appendChild(bt);
  }

  const gridTop=s.y+padTop+26, gridBottom=s.y+s.h-6;
  const gridHeight=gridBottom-gridTop;
  const cols=2, rowCount=s.rowCount||0;
  if(gridHeight<10 || s.w<20 || rowCount<1) return;
  const slots=(typeof sortingSlotsFor==="function")
    ? sortingSlotsFor({sorting_code:s.sortingCode, row_count:rowCount, column_count:cols})
    : [];
  const gapX=Math.max(2,s.w*0.02), gapY=Math.max(2,gridHeight*0.03);
  const cellW=Math.max(4,(s.w-16-gapX*(cols-1))/cols);
  const cellH=Math.max(4,(gridHeight-gapY*(rowCount-1))/rowCount);
  const gridW=cols*cellW+(cols-1)*gapX;
  const startX=s.x+(s.w-gridW)/2;
  const fontSize=Math.max(6, Math.min(10, cellH*0.3));
  slots.forEach(slot=>{
    const cx2=startX+(slot.col-1)*(cellW+gapX);
    const cy2=gridTop+(slot.row-1)*(cellH+gapY);
    const rect=S("rect");
    rect.setAttribute("x",cx2); rect.setAttribute("y",cy2);
    rect.setAttribute("width",cellW); rect.setAttribute("height",cellH);
    rect.setAttribute("fill","#A7F3D0"); rect.setAttribute("stroke","#047857"); rect.setAttribute("stroke-width",0.75);
    wrap.appendChild(rect);
    const lbl=S("text");
    lbl.setAttribute("x",cx2+cellW/2); lbl.setAttribute("y",cy2+cellH/2);
    lbl.setAttribute("text-anchor","middle"); lbl.setAttribute("dominant-baseline","middle");
    lbl.setAttribute("font-size",fontSize); lbl.setAttribute("fill","#047857");
    lbl.textContent=slot.slot_code;
    wrap.appendChild(lbl);
  });
}

/** Render ulang seluruh overlay SVG (jalur, titik halte, rack, towing+dolly). Panggil tiap ada perubahan state. */
function redrawAll(repaint=true){
  svg.innerHTML="";
  // Shape kotak vector (background "peta bersih" gaya PPT/Google Maps, ditelusuri manual di Editor
  // di atas gambar denah asli) — LAPISAN PALING BAWAH di antara elemen SVG (tapi tetap di ATAS <img>
  // raster, krn overlay SVG memang selalu di atas gambar sesuai struktur HTML #stage, index.php).
  // Handle resize (4 sudut) + rotasi (1, di atas) CUMA digambar pas Editor aktif & shape ini lagi
  // terpilih (shSelected, editor/editor.js) — di Monitor (!editing) shape tampil polos, gak ada handle.
  (CFG.shapes||[]).forEach((s,i)=>{
    const g=S("g"); g.setAttribute("data-shape",i);
    g.setAttribute("transform",`rotate(${s.rot||0} ${s.x+s.w/2} ${s.y+s.h/2})`);
    // `g` di-attach ke `svg` SEKARANG (bukan di ujung loop kayak sebelumnya) — SEBELUM renderPlaneBufferContent()
    // dipanggil di bawah. WAJIB: fitPlaneBufferToBox() di dalamnya baca inner.offsetWidth/Height (ukuran
    // LAYOUT) yg SELALU 0 kalau elemen-nya masih "lepas"/belum jadi bagian dokumen — dites langsung,
    // bug nyata: gridZoom gak pernah kesimpen (offsetWidth/Height ke-baca 0, guard early-return kena)
    // kalau svg.appendChild(g) baru dipanggil BELAKANGAN (child rect/foreignObject boleh nyusul ditambah
    // ke `g` SETELAH `g` sendiri live — itu tetap valid & langsung ke-layout).
    svg.appendChild(g);
    const rc=S("rect");
    rc.setAttribute("x",s.x); rc.setAttribute("y",s.y);
    rc.setAttribute("width",s.w); rc.setAttribute("height",s.h);
    rc.setAttribute("fill",s.fill||"#E2E8F0"); rc.setAttribute("stroke",s.stroke||"#475569");
    rc.setAttribute("stroke-width",2);
    g.appendChild(rc);
    if(s.kind==="planebuffer") renderPlaneBufferContent(g,s);
    else if(s.kind==="sortingarea") renderSortingAreaContent(g,s);
    else if(s.kind==="dollysupply") renderDollySupplyContent(g,s);
    else if(s.text){
      const t=S("text"); t.setAttribute("x",s.x+s.w/2); t.setAttribute("y",s.y+s.h/2);
      t.setAttribute("text-anchor","middle"); t.setAttribute("dominant-baseline","middle");
      t.setAttribute("font-size","13"); t.setAttribute("fill",s.stroke||"#475569");
      t.textContent=s.text; g.appendChild(t);
    }
    if(editing){
      g.classList.add("shape-editable");
      if(typeof shSelected!=="undefined" && shSelected.has(i)){
        [[s.x,s.y,"nw"],[s.x+s.w,s.y,"ne"],[s.x,s.y+s.h,"sw"],[s.x+s.w,s.y+s.h,"se"]].forEach(([hx,hy,pos])=>{
          const hd=S("circle"); hd.setAttribute("cx",hx); hd.setAttribute("cy",hy); hd.setAttribute("r",6);
          hd.setAttribute("class","shape-handle"); hd.dataset.shape=i; hd.dataset.handle=pos;
          g.appendChild(hd);
        });
        const rh=S("circle"); rh.setAttribute("cx",s.x+s.w/2); rh.setAttribute("cy",s.y-24); rh.setAttribute("r",6);
        rh.setAttribute("class","shape-handle shape-rotate"); rh.dataset.shape=i; rh.dataset.handle="rot";
        g.appendChild(rh);
      }
    }
  });
  if(editing&&mode==="path"&&ROUTE_GUIDE[editRoute]){
    ROUTE_GUIDE[editRoute].forEach(([gx,gy])=>{
      const c=S("circle");c.setAttribute("cx",gx);c.setAttribute("cy",gy);c.setAttribute("r",7);
      c.setAttribute("fill","none");c.setAttribute("stroke","#F59E0B");c.setAttribute("stroke-width","2");
      c.setAttribute("stroke-dasharray","3,2");c.setAttribute("opacity","0.85");
      svg.appendChild(c);
    });
  }
  Object.entries(CFG.paths).forEach(([r,path])=>{
    if(mapFocusOnly && r!==selRoute) return;
    if(path.length>1){
      const pl=S("polyline");
      pl.setAttribute("points",path.map(p=>p.x+","+p.y).join(" "));
      // Pas Editor lagi aktif & mode "Semua Route" (FULL, mapFocusOnly=false), jalur route LAIN
      // diredupkan drastis — biar gak ketuker/kepencet gara2 numpuk sama jalur route yg lagi diedit
      // (mis. route P & K yg jalurnya berdekatan/numpuk sebagian).
      const dimmed = editing && !mapFocusOnly && r!==editRoute;
      pl.setAttribute("class","routepath"+(r===selRoute?" sel":"")+(dimmed?" dimmed":""));
      pl.setAttribute("stroke",rcolor(r));
      if(dimmed) pl.setAttribute("opacity","0.12");
      svg.appendChild(pl);
    }
    // Titik jalur bisa dipilih/di-drag utk route yg lagi diedit (r===selRoute) ATAU, kalau mode
    // "Semua Route" lagi aktif (!mapFocusOnly), utk SEMUA route sekaligus — biar Blok (Shift+drag)
    // & shift+klik bisa nangkep titik dari route manapun, gak kepaku ke 1 route doang.
    if(editing&&(r===selRoute||!mapFocusOnly)) path.forEach((p,i)=>{
      if(i===selectedPtIdx&&r===editRoute){
        const hl=S("circle");hl.setAttribute("cx",p.x);hl.setAttribute("cy",p.y);hl.setAttribute("r",(p.h?13:8)+6);
        hl.setAttribute("fill","none");hl.setAttribute("stroke","#F59E0B");hl.setAttribute("stroke-width","2.5");
        hl.setAttribute("stroke-dasharray","3,2");svg.appendChild(hl);
      }
      const g=S("g");g.setAttribute("data-drag","");g.dataset.route=r;g.dataset.pt=i;
      if(ptSelected.has(r+"|"+i)) g.setAttribute("class","pt-sel");
      if(r!==editRoute) g.style.opacity=0.35; // route LAIN (bukan yg lagi aktif diedit) diredupkan, tapi tetap bisa diklik/blok
      const c=S("circle");c.setAttribute("cx",p.x);c.setAttribute("cy",p.y);c.setAttribute("r",p.h?13:(p.stage?11:8));
      c.setAttribute("class","wp");c.setAttribute("stroke",p.h?hcol[p.h]:(p.stage?stagecol[p.stage]:rcolor(r)));
      g.appendChild(c);
      if(p.h){const t=S("text");t.setAttribute("x",p.x);t.setAttribute("y",p.y+1);t.textContent=p.h;g.appendChild(t);}
      else if(p.stage){const t=S("text");t.setAttribute("x",p.x);t.setAttribute("y",p.y+1);t.setAttribute("font-size","8");t.textContent=stageAbbr[p.stage];g.appendChild(t);}
      svg.appendChild(g);
    });
    else path.forEach(p=>{ if(p.h){
      const c=S("circle");c.setAttribute("cx",p.x);c.setAttribute("cy",p.y);c.setAttribute("r",10);
      c.setAttribute("fill","#fff");c.setAttribute("stroke",hcol[p.h]);c.setAttribute("stroke-width",3);svg.appendChild(c);
      const t=S("text");t.setAttribute("x",p.x);t.setAttribute("y",p.y+4.5);t.setAttribute("text-anchor","middle");
      t.setAttribute("font-size","12");t.setAttribute("font-weight","700");t.setAttribute("fill",hcol[p.h]);t.textContent=p.h;svg.appendChild(t);
    } else if(p.stage){
      const c=S("circle");c.setAttribute("cx",p.x);c.setAttribute("cy",p.y);c.setAttribute("r",10);
      c.setAttribute("fill","#fff");c.setAttribute("stroke",stagecol[p.stage]);c.setAttribute("stroke-width",3);svg.appendChild(c);
      const t=S("text");t.setAttribute("x",p.x);t.setAttribute("y",p.y+4.5);t.setAttribute("text-anchor","middle");
      t.setAttribute("font-size","8");t.setAttribute("font-weight","700");t.setAttribute("fill",stagecol[p.stage]);t.textContent=stageAbbr[p.stage];svg.appendChild(t);
    }});
  });
  // Rack digambar sbg KOTAK yg lebarnya ngikutin panjang teks address-nya sendiri (bukan lingkaran
  // ukuran tetap) — kayak chip/label. Di Monitor (!editing) rack yg lagi gak aktif disupply
  // disembunyikan total (lihat paintRacks), yg aktif ditampilkan lebih gede biar gampang dipantau
  // dari jauh; di Editor tetap kecil spy gampang diklik/digeser presisi pas nempatin banyak rack.
  const rackPadX = editing ? 3 : 8, rackBoxH = editing ? 10 : 22;
  CFG.racks.forEach((rk,i)=>{
    const g=S("g");g.setAttribute("class","rack"+(rkSelected.has(String(i))?" align-sel":""));g.setAttribute("data-drag","");g.dataset.rack=i;g.dataset.addr=rk.addr;
    const ttl=S("title");ttl.textContent=rk.addr; // hover tetap nunjukin full address kalau labelnya kepotong/kekecilan
    const lbl=S("text");lbl.setAttribute("class","rack-label");
    lbl.setAttribute("x",rk.x);lbl.setAttribute("y",rk.y);
    lbl.setAttribute("text-anchor","middle");lbl.setAttribute("dominant-baseline","middle");
    if(!editing) lbl.style.fontSize="15px";
    lbl.textContent=rk.addr;
    g.append(ttl,lbl);svg.appendChild(g); // append dulu biar getComputedTextLength() bisa diukur
    const tw=lbl.getComputedTextLength();
    const rc=S("rect");
    rc.setAttribute("x",rk.x-(tw/2+rackPadX));rc.setAttribute("y",rk.y-rackBoxH/2);
    rc.setAttribute("width",tw+rackPadX*2);rc.setAttribute("height",rackBoxH);rc.setAttribute("rx",2);
    g.insertBefore(rc,lbl); // rect di belakang teks
  });
  const TOWW=60, TOWH=38;
  const DOLLYW=28, DOLLYH=28;
  const towHref='assets/'+(META.towing_image||'towing.png')+'?v='+ASSET_V;
  // allKnownRoutes() (01-state.js) = ALLR + route khusus/pseudo (mis. "C/U"/"Unpacking") yg terdaftar
  // di Master Offset — GANTI ALLR polos, supaya route pseudo yg udah digambar jalurnya di Editor ikut
  // dapat towing+dolly di sini juga. AMAN utk route yg belum py jalur: towXY(r) return null kalau
  // CFG.paths[r] kosong, `if(!p)return` di bawah langsung skip, persis kayak route fisik yg jalurnya
  // belum digambar.
  allKnownRoutes().forEach(r=>{
    if(mapFocusOnly && r!==selRoute) return;
    const p=towXY(r); if(!p)return;
    const {groups,usedSlots}=dollyGroups(r);
    // Cuma segitiga sejumlah usedSlots yg beneran ditarik (bukan selalu 8 tetap) — sisanya (kalau data
    // plane/route ini emang cuma butuh dikit, mis. 6) gak usah digambar sama sekali, biar gak keliatan
    // ada kotak dolly "hantu" kosong nempel di belakang towing yg gak akan pernah kepake.
    const dollies=dollyPositions(r).slice(0,usedSlots);
    const sel=r===selRoute;

    // Garis sambungan (coupling) towing -> dolly 1..usedSlots, digambar duluan supaya ada di belakang
    // kotak. Dolly yg lagi "dilepas sementara" (null, lihat dollyPositions di 03-countdown.js — belum
    // lewat PREPARE atau udah lewat TRANSFER) SELALU tetap dibikin elemennya (cuma disembunyikan lewat
    // display:none), BUKAN dilewatin/gak dibikin sama sekali — kalau di-skip, dan pas redrawAll() ini
    // jalan semua/sebagian dolly-nya lagi null (mis. pas towing baru mulai dari titik PREPARE), elemen
    // itu gak akan PERNAH ada di DOM, jadi moveTowings() gak punya apa-apa buat dimunculin lagi nanti
    // begitu dolly itu seharusnya nyambung — bikin dolly gak pernah kelihatan seumur siklus (bug nyata,
    // dilaporkan user: towing jalan sampai TRANSFER sama sekali gak bawa dolly).
    const trainPts=[p,...dollies];
    for(let i=0;i<trainPts.length-1;i++){
      const a=trainPts[i], b=trainPts[i+1];
      const ln=S("line");ln.setAttribute("class","coupling");ln.dataset.route=r;ln.dataset.seg=i;
      if(a&&b){ ln.setAttribute("x1",a.x);ln.setAttribute("y1",a.y);ln.setAttribute("x2",b.x);ln.setAttribute("y2",b.y); }
      else ln.style.display="none";
      ln.setAttribute("stroke",rcolor(r));ln.setAttribute("stroke-width",sel?3:1.5);
      ln.setAttribute("opacity",sel?0.9:0.3);
      svg.appendChild(ln);
    }

    const g=S("g");g.setAttribute("class","towing");g.dataset.tow=r;
    g.setAttribute("transform",`translate(${p.x},${p.y})`);
    if(sel){const pu=S("circle");pu.setAttribute("class","tow-pulse");g.appendChild(pu);}
    const img=S("image");img.setAttribute("class","tow-img");
    img.setAttribute("href",towHref);
    img.setAttributeNS("http://www.w3.org/1999/xlink","href",towHref);
    img.setAttribute("x",-TOWW/2);img.setAttribute("y",-TOWH/2);
    img.setAttribute("width",TOWW);img.setAttribute("height",TOWH);
    img.setAttribute("preserveAspectRatio","xMidYMid meet");
    if(lastTowFlip[r]===undefined) lastTowFlip[r]=towShouldFlip(r); // render pertama sblm pernah gerak
    if(lastTowFlip[r]) img.setAttribute("transform","scale(-1,1)");
    img.style.filter=sel?"drop-shadow(0 0 6px var(--red))":"drop-shadow(0 1px 2px rgba(0,0,0,.35))";
    const bc=S("circle");bc.setAttribute("cx",TOWW/2-4);bc.setAttribute("cy",-TOWH/2+4);bc.setAttribute("r",8);
    bc.setAttribute("fill",sel?"var(--red)":"#1B2733");bc.setAttribute("stroke","#fff");bc.setAttribute("stroke-width","1");
    const tx=S("text");tx.textContent=r;tx.setAttribute("x",TOWW/2-4);tx.setAttribute("y",-TOWH/2+4+2.75);
    tx.setAttribute("text-anchor","middle");tx.setAttribute("font-size","8");tx.setAttribute("font-weight","700");tx.setAttribute("fill","#fff");
    g.append(img,bc,tx);
    g.addEventListener("click",ev=>{ if(!editing){selectRoute(r);ev.stopPropagation();} });
    svg.appendChild(g);

    // Dolly mengikuti jalur yang sama di belakang towing — 1 grup (supplier) bisa pakai >1 slot dolly
    // sekaligus kalau volumenya besar (info.boxCount>1); focusDolly selalu dinormalisasi ke info.primarySlot
    // supaya klik salah satu box dari grup yg sama tetap menyorot baris part yang sama di panel Muatan.
    dollies.forEach((dp,i)=>{
      const info=groups[i];
      const primaryNum=(info.primarySlot??i)+1;
      const dg=S("g");dg.setAttribute("class","dolly");dg.dataset.route=r;dg.dataset.dolly=i;
      // dp null = dolly ini lagi "dilepas sementara" (belum lewat PREPARE / udah lewat TRANSFER) —
      // elemennya TETAP dibikin (posisi numpang di towing head `p`, gak keliatan krn display:none),
      // biar moveTowings() bisa munculin lagi begitu posisinya valid nanti tanpa perlu redrawAll() ulang.
      dg.setAttribute("transform",`translate(${(dp||p).x},${(dp||p).y})`);
      if(!dp) dg.style.display="none";
      dg.style.opacity=sel?1:0.45;
      const isFocus=sel&&focusDolly.has(primaryNum);
      // atHalte: towing BENERAN lagi berhenti di halte (bukan cuma "dolly ini disetting utk suatu
      // halte" secara umum) — gerbang buat garis/flow-box supply & highlight baris di panel Muatan
      // (lihat paintRacks/highlightDollyRows). Gak ada animasi blink lagi (cuma beda warna, statis).
      const atHalte=isFocus&&halteInfo(cd).no>0;
      // 3 warna FILL: ORANGE (var(--act)) = lagi disupply/difokuskan (isFocus, termasuk klik manual),
      // ABU-ABU (var(--mut)) = udah TUNTAS disupply semua ATAU numpang lewat zona EMPTY, PUTIH = belum
      // giliran. isFocus menang drpd "done" (klik manual spotlight tetap oranye). Border+angka pakai
      // warna IDENTITAS per nomor dolly (dollyColor, konsisten lintas route) biar gampang dibedakan.
      const done = sel && !isFocus && (dollyFullySupplied(r,info)||dollyPassedEmpty(r,i));
      const dcol=dollyColor(i);
      const rc=S("rect");rc.setAttribute("x",-DOLLYW/2);rc.setAttribute("y",-DOLLYH/2);
      rc.setAttribute("width",DOLLYW);rc.setAttribute("height",DOLLYH);rc.setAttribute("rx",3);
      rc.setAttribute("fill",isFocus?"var(--act)":done?"var(--mut)":"#fff");rc.setAttribute("stroke",dcol);rc.setAttribute("stroke-width",sel?2:1);
      const tx2=S("text");tx2.textContent=i+1;tx2.setAttribute("text-anchor","middle");tx2.setAttribute("y",3);
      tx2.setAttribute("font-size","10");tx2.setAttribute("font-weight","700");tx2.setAttribute("fill",(isFocus||done)?"#fff":dcol);
      const ttl=S("title");
      ttl.textContent=(info.supplier?`Dolly ${i+1}: ${info.supplier}`+(info.parts.length?` (${info.parts.length} part)`:"")+(info.boxCount>1?` — box ${info.boxIndex}/${info.boxCount}`:""):`Dolly ${i+1}: kosong`)+(done?" — sudah tersupply":"");
      dg.append(ttl,rc,tx2);
      dg.addEventListener("click",ev=>{
        if(editing)return; ev.stopPropagation();
        if(!sel) selectRoute(r);
        // Toggle: klik kotak dolly nambah/ngurangin dolly itu dari set yg lagi disorot (bisa lebih dari 1).
        if(focusDolly.has(primaryNum)) focusDolly.delete(primaryNum); else focusDolly.add(primaryNum);
        redrawAll(); renderParts();
      });
      svg.appendChild(dg);
    });
  });
  if(repaint)paintRacks();
  renderRouteList();
}

/** Update posisi transform towing/dolly/coupling tanpa render ulang seluruh SVG (dipakai animasi). */
function moveTowings(cdOverride){
  document.querySelectorAll(".towing").forEach(g=>{
    const r=g.dataset.tow;
    const p=towXY(r,cdOverride); if(p)g.setAttribute("transform",`translate(${p.x},${p.y})`);
    const img=g.querySelector(".tow-img");
    const flip=towShouldFlip(r,cdOverride); lastTowFlip[r]=flip; // bekukan, dipakai lagi pas towing berhenti
    if(img)img.setAttribute("transform",flip?"scale(-1,1)":"");
  });
  const dcache={};
  // Begitu dolly ini blm/gak lagi nyambung (dollyPositions balik null di slotnya — lihat
  // 03-countdown.js), elemennya cuma DISEMBUNYIKAN (display:none), BUKAN dihapus dari DOM — kalau
  // dihapus, gak ada cara buat munculin lagi tanpa redrawAll() penuh begitu posisinya valid lagi
  // (mis. dolly baru nyambung stlh lewat PREPARE) — itu penyebab bug dolly gak pernah kelihatan
  // seumur siklus kalau pas redrawAll() dipanggil semua dolly lagi null.
  document.querySelectorAll(".dolly").forEach(dg=>{
    const r=dg.dataset.route;
    if(!dcache[r]) dcache[r]=dollyPositions(r,cdOverride);
    const pos=dcache[r][+dg.dataset.dolly];
    if(pos){ dg.style.display=""; dg.setAttribute("transform",`translate(${pos.x},${pos.y})`); }
    else dg.style.display="none";
  });
  document.querySelectorAll(".coupling").forEach(ln=>{
    const r=ln.dataset.route, i=+ln.dataset.seg;
    if(!dcache[r]) dcache[r]=dollyPositions(r,cdOverride);
    const head=towXY(r,cdOverride); const dp=dcache[r];
    const a=i===0?head:dp[i-1], b=dp[i];
    if(a&&b){ ln.style.display=""; ln.setAttribute("x1",a.x);ln.setAttribute("y1",a.y);ln.setAttribute("x2",b.x);ln.setAttribute("y2",b.y); }
    else ln.style.display="none";
  });
  // Ujung garis dolly->rack ikut geser sama dollynya (ujung satunya, rack, diam gak usah diupdate).
  document.querySelectorAll(".supply-line").forEach(ln=>{
    const r=ln.dataset.route, i=+ln.dataset.dolly;
    if(!dcache[r]) dcache[r]=dollyPositions(r,cdOverride);
    const pos=dcache[r][i];
    if(pos){ ln.setAttribute("x1",pos.x); ln.setAttribute("y1",pos.y); }
    else ln.remove();
  });
  followTowing(cdOverride);
}

/**
 * Turunin tampilan ke "state TRANSIT" — dipanggil pas towing BARU MULAI bergerak (lihat animateCd),
 * krn global cd/focusDolly sudah di-update ke nilai HALTE TUJUAN duluan (lihat stepCd di 08-header.js
 * & pollCounter di 02-api.js) walau towing visualnya baru mulai geser sepanjang animasi. Dibagi 2:
 * - Indikator "LAGI terjadi SEKARANG" (blink dolly oranye, garis putus2 dolly->rack, rack yg lagi
 *   disupply, baris part ke-highlight) — dimatiin dulu, nyala lagi begitu towing BENERAN sampai
 *   (paintRacks() + callback onArrive di animateCd). Rack SENDIRI TETAP kelihatan (cuma warna
 *   "aktif"-nya yg dicopot) — beda dari dolly/garis/list yg tetap disembunyikan/dimatiin total.
 * - Status "udah TUNTAS disupply" (dolly abu-abu) — ini FAKTA permanen (bukan "lagi terjadi"), jadi
 *   dihitung ulang & tetap ditampilkan SELAMA transit juga, gak nunggu sampai halte tujuan.
 */
function applyTransitVisuals(){
  if(selRoute){
    const {groups}=dollyGroups(selRoute);
    document.querySelectorAll(`.dolly[data-route="${selRoute}"]`).forEach(dg=>{
      const i=+dg.dataset.dolly, info=groups[i];
      const doneNow=dollyFullySupplied(selRoute,info)||dollyPassedEmpty(selRoute,i);
      const rc=dg.querySelector("rect"), tx2=dg.querySelector("text");
      if(rc) rc.setAttribute("fill", doneNow?"var(--mut)":"#fff");
      if(tx2) tx2.setAttribute("fill", doneNow?"#fff":dollyColor(i));
    });
  }
  document.querySelectorAll(".supply-line,.supply-line-dot,.supply-flow").forEach(el=>el.remove());
  if(!editing) document.querySelectorAll(".rack.active").forEach(g=>g.classList.remove("active"));
  document.querySelectorAll("#partsbox tr.hl, #partsbox tr.dollysel").forEach(tr=>tr.classList.remove("hl","dollysel"));
}

let animRAF=null;
/**
 * Geser towing dari fromCd ke toCd frame-demi-frame di sepanjang polyline asli (arc-length),
 * bukan CSS transition lurus dari titik-ke-titik — supaya benar-benar menyusuri garis, termasuk
 * tikungannya. onArrive (opsional) dipanggil TEPAT begitu towing beneran sampai di toCd — dipakai
 * caller buat nge-refresh header+focusDolly+panel Muatan bareng paintRacks(), bukan sebelum animasi
 * jalan (lihat applyTransitVisuals di atas kenapa ini penting).
 */
function animateCd(fromCd,toCd,ms=1100,onArrive){
  if(animRAF)cancelAnimationFrame(animRAF);
  if(fromCd===toCd){ moveTowings(); if(onArrive)onArrive(); paintRacks(); renderRouteList(); return; }
  applyTransitVisuals();
  const t0=performance.now();
  const step=(now)=>{
    const t=Math.min(1,(now-t0)/ms);
    moveTowings(fromCd+(toCd-fromCd)*t);
    if(t<1){ animRAF=requestAnimationFrame(step); }
    else{ animRAF=null; if(onArrive)onArrive(); paintRacks(); renderRouteList(); }
  };
  animRAF=requestAnimationFrame(step);
}

/**
 * Warnai/tampilkan rack utk route terpilih. Beda perilaku Editor vs Monitor:
 * - Editor: semua rack tetap kelihatan (biar gampang ditempatkan/diedit), diwarnai per-zona halte
 *   (on1/on2/on3) + "active" kalau persis di halte yg lagi aktif SEKARANG.
 * - Monitor (!editing): rack yg relevan (dibawa di dolly route ini, routeRackSet) TAMPIL TERUS dari
 *   awal sampai akhir towing berjalan — gak disembunyikan lagi pas lagi transit/belum gilirannya.
 *   Rack yg LAGI BENERAN disupply sekarang (activeSupplyRackAddrs) dibedain warnanya doang (kelas
 *   "active", TANPA blink — lihat app.css), bukan muncul/ilang. Rack yg sama sekali gak dipakai
 *   route ini tetap disembunyikan total.
 */
function paintRacks(){
  const active=halteInfo(cd).no;
  const activeAddrs = (!editing && selRoute) ? activeSupplyRackAddrs(selRoute) : null;
  const routeAddrs = (!editing && selRoute) ? routeRackSet(selRoute) : null;
  document.querySelectorAll(".rack").forEach(g=>{
    g.setAttribute("class","rack");
    const addr=g.dataset.addr;
    if(!editing){
      const relevant = !!(routeAddrs && routeAddrs.has(addr));
      g.style.display = relevant ? "" : "none";
      if(relevant && activeAddrs && activeAddrs.has(addr)) g.classList.add("active");
    } else {
      g.style.display = "";
      if(selRoute && routeRackSet(selRoute).has(addr)){
        const rk=CFG.racks[+g.dataset.rack];
        const h=passedHalteForRack(selRoute,rk.x,rk.y);
        g.setAttribute("class","rack "+(h===active?"active":"on"+h));
      }
    }
    // Highlight terpilih (buat Align X/Y, lihat rkSelected) — dipasang lagi di sini krn class-nya
    // ke-reset tiap paintRacks(), bukan cuma pas redrawAll() bikin ulang elemen.
    if(rkSelected.has(g.dataset.rack)) g.classList.add("align-sel");
  });
  highlightPartRows(active);
  // Sinkronkan warna+blink dolly (map) + garis dolly->rack tujuan sesuai halte aktif SEKARANG —
  // dipanggil lagi di sini (bukan cuma pas redrawAll()) krn animateCd cuma moveTowings() per-frame,
  // gak regenerasi elemen dolly. Tanpa ini, fill/blink dolly bakal "nyangkut" di warna giliran
  // SEBELUMNYA begitu towing pindah halte tanpa ada redrawAll() penuh di antaranya.
  document.querySelectorAll(".supply-line,.supply-line-dot,.supply-flow").forEach(el=>el.remove());
  if(selRoute){
    const {groups}=dollyGroups(selRoute);
    const dp=dollyPositions(selRoute);
    document.querySelectorAll(`.dolly[data-route="${selRoute}"]`).forEach(dg=>{
      const i=+dg.dataset.dolly;
      const info=groups[i];
      const primaryNum=(info.primarySlot??i)+1;
      const isFocus=focusDolly.has(primaryNum);
      const atHalte=isFocus&&active>0;
      // suppliedDone dihitung LEPAS dari isFocus (beda dari `done` di bawah, yg sengaja kalah
      // dari isFocus biar kotak dolly tetap oranye pas di-spotlight manual) — dipakai buat matiin
      // garis putus-putus tujuan rack begitu part-nya beneran udah kelewat haltenya, WALAUPUN
      // dolly ini lagi difokus manual (klik) atau cuma 1 dolly doang di grupnya.
      const suppliedDone=dollyFullySupplied(selRoute,info);
      // passedEmpty: dolly numpang lewat zona staging EMPTY (independen dari status supply part-nya
      // sendiri) — kotak dolly ikut ditampilin "kosong" (abu2) selama di zona ini juga.
      const passedEmpty=dollyPassedEmpty(selRoute,i);
      const done=!isFocus&&(suppliedDone||passedEmpty);
      const rc=dg.querySelector("rect"), tx2=dg.querySelector("text");
      if(rc) rc.setAttribute("fill", isFocus?"var(--act)":done?"var(--mut)":"#fff");
      if(tx2) tx2.setAttribute("fill", (isFocus||done)?"#fff":dollyColor(i));
      if(!atHalte || suppliedDone) return;
      const pos=dp[i]; if(!pos) return;
      // Garis dolly -> rack tujuan: cuma muncul pas dolly ini BENERAN aktif disupply (towing lagi
      // berhenti di halte-nya) DAN part-nya belum tuntas kelewat haltenya. PENTING: dicek lagi PER
      // RACK (bukan cuma level dolly/grup) — 1 dolly bisa bawa BEBERAPA rack tujuan yg beda halte
      // (atau dolly-nya lagi "focus" krn override manual HALTE_DOLLY yg gak nyambung ke rack ini sama
      // sekali) — tanpa filter ini, rack yg haltenya sendiri UDAH LEWAT (mis. jatah Halte 1) bisa
      // keikutan digambar garis "lagi disupply" lagi pas towing sudah di Halte 2, padahal seharusnya
      // udah beres/gak disupply ulang.
      dollySupplyRacks(info).forEach(rk=>{
        if(passedHalteForRack(selRoute,rk.x,rk.y)!==active) return;
        const ln=S("line");ln.setAttribute("class","supply-line");
        ln.dataset.route=selRoute;ln.dataset.dolly=i;
        ln.setAttribute("x1",pos.x);ln.setAttribute("y1",pos.y);
        ln.setAttribute("x2",rk.x);ln.setAttribute("y2",rk.y);
        ln.setAttribute("stroke",rcolor(selRoute));ln.setAttribute("stroke-width",2);
        ln.setAttribute("stroke-dasharray","5,4");ln.setAttribute("opacity",0.9);
        svg.appendChild(ln);
        const dot=S("circle");dot.setAttribute("class","supply-line-dot");
        dot.setAttribute("cx",rk.x);dot.setAttribute("cy",rk.y);dot.setAttribute("r",8);
        dot.setAttribute("fill","none");dot.setAttribute("stroke",rcolor(selRoute));dot.setAttribute("stroke-width",2);
        svg.appendChild(dot);
        // Kotak "flow" berisi nomor dolly, mengalir bolak-balik dolly->rack sepanjang garis putus2
        // di atas — nunjukin part BENERAN lagi jalan disupply, bukan cuma penanda statis. Pakai SMIL
        // <animateMotion> (loop sendiri di browser, gak perlu RAF manual) — otomatis berhenti pas
        // elemen ini dihapus (paintRacks() re-run / applyTransitVisuals() pas towing mulai jalan lagi).
        const FLOWSZ=18;
        const flow=S("g");flow.setAttribute("class","supply-flow");
        flow.dataset.route=selRoute;flow.dataset.dolly=i;
        const frc=S("rect");frc.setAttribute("x",-FLOWSZ/2);frc.setAttribute("y",-FLOWSZ/2);
        frc.setAttribute("width",FLOWSZ);frc.setAttribute("height",FLOWSZ);frc.setAttribute("rx",4);
        frc.setAttribute("fill",dollyColor(i));frc.setAttribute("stroke","#fff");frc.setAttribute("stroke-width",1.5);
        const ftx=S("text");ftx.textContent=i+1;ftx.setAttribute("text-anchor","middle");ftx.setAttribute("y",3.5);
        ftx.setAttribute("font-size","10");ftx.setAttribute("font-weight","700");ftx.setAttribute("fill","#fff");
        flow.append(frc,ftx);
        const mo=S("animateMotion");mo.setAttribute("dur","2.2s");mo.setAttribute("repeatCount","indefinite");
        mo.setAttribute("path",`M${pos.x},${pos.y} L${rk.x},${rk.y}`);
        flow.appendChild(mo);
        svg.appendChild(flow);
      });
    });
  }
  highlightDollyRows();
}
