/* =====================================================================
   14-ASSET-UPLOAD — tombol Editor "Ganti Denah" / "Ganti Towing":
   upload gambar baru, sesuaikan skala rack/jalur otomatis kalau ukurannya beda.
   ===================================================================== */
document.getElementById("btnChLayout").onclick=()=>document.getElementById("fileLayout").click();
document.getElementById("btnChTowing").onclick=()=>document.getElementById("fileTowing").click();

/** Ganti gambar denah: upload, ukur ulang, dan kalau resolusinya beda, skala ulang rack+jalur biar tetap align. */
document.getElementById("fileLayout").onchange=async function(){
  const f=this.files[0]; this.value=""; if(!f)return;
  const fd=new FormData(); fd.append("file",f); fd.append("kind","layout");
  try{
    const res=await apiPost("upload_asset",fd,true);
    const oldW=IMGW, oldH=IMGH;
    ASSET_V=Date.now();
    await applyLayoutImage(res.file);
    const sx=IMGW/oldW, sy=IMGH/oldH;
    let rescaled=false;
    if(Math.abs(sx-1)>0.01||Math.abs(sy-1)>0.01){
      if(CFG.racks.length||Object.values(CFG.paths).some(p=>p.length)){
        CFG.racks.forEach(rk=>{rk.x*=sx;rk.y*=sy;});
        Object.values(CFG.paths).forEach(path=>path.forEach(p=>{p.x*=sx;p.y*=sy;}));
        await saveCfg();
        rescaled=true;
      }
    }
    META.layout_image=res.file;
    redrawAll(); fit();
    toast("Gambar denah diganti"+(rescaled?" — posisi rack/jalur disesuaikan otomatis":""));
  }catch(e){ toast("Gagal ganti denah: "+e.message); }
};

/** Ganti ikon gambar towing (dipakai semua route, ukuran tampilan tetap sama). */
document.getElementById("fileTowing").onchange=async function(){
  const f=this.files[0]; this.value=""; if(!f)return;
  const fd=new FormData(); fd.append("file",f); fd.append("kind","towing");
  try{
    const res=await apiPost("upload_asset",fd,true);
    ASSET_V=Date.now();
    META.towing_image=res.file;
    redrawAll();
    toast("Gambar towing diganti");
  }catch(e){ toast("Gagal ganti towing: "+e.message); }
};
