/* =====================================================================
   16-PATTERN-UNLOAD — Pattern Unload (Zone Timur/Barat), model drag & drop.
   Tiap route = 1 kolom daftar supplier yang bisa di-drag urutannya (bukan
   dropdown per-cell lagi). Daftar awal per route diisi OTOMATIS dari semua
   supplier hasil VLOOKUP ke Master Part (supplier_code+shipping_dock),
   diurut abjad A-Z. Baris bisa dihapus (dikeluarkan dari urutan) & di-add
   ulang lewat dropdown "+ Supplier" (yg cuma nampilin supplier yg blm ada
   di list). IMPORT & UNPACKING BUKAN bagian dari auto-fill — ditambahkan
   manual lewat tombol "+ Import"/"+ Unpacking", boleh berkali-kali.
   ===================================================================== */

let PU_SUPPLIERS_BY_ROUTE = {}; // cache: route -> array objek grup supplier (key, code, dock, name, status, items)
let PU_NAME_CACHE_BY_ROUTE = {}; // cache: route -> {key: nama} — identitas yg PERNAH ada di Master Part (hidup/enggak), buat resolve nama baris orphan
let puState = null;
let puLoaded = false;
let puLocked = true;
let puNextId = 1; // id unik per-baris (perlu krn IMPORT/UNPACKING bisa muncul >1x dgn key yg sama)
let puSelectedIds = new Set(); // id baris (bisa lintas kolom/zone) yg dicentang buat Hapus Terpilih (bulk)

/** Escape nilai supaya aman ditaruh di atribut/isi HTML. */
function puEsc(s){ return String(s).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;"); }

/** Zone (timur/barat) route ini — delegasi tipis ke zoneOf() (01-state.js, satu sumber dipakai bareng
 * rcolor/sidebar/dst), dipertahankan sbg nama terpisah krn masih dipanggil di banyak tempat file ini. */
function puRouteZone(route){ return zoneOf(route); }

/** Semua route yg cocok utk zone ini — allKnownRoutes() (01-state.js) = ALLR + route khusus/pseudo
 * (mis. "C/U"/"Unpacking") yg sudah terdaftar di Master Offset (ROUTE_ZONE), dipakai isi dropdown
 * per-kolom & tombol "+ Route" Pattern Unload (GANTI ALLR polos — route khusus sekarang BOLEH jadi
 * kolom Pattern Unload, lihat tombol "+ C/U"/"+ Unpacking" dedicated di bawah utk pendaftaran pertama
 * kali). */
function puRoutesForZone(zone){ return allKnownRoutes().filter(r=>puRouteZone(r)===zone); }

/** Bangun puState awal dari SUPPLY_ORDER (data tersimpan) — urutan & isi baris PERSIS spt terakhir disimpan. */
function puBuildStateFromSupplyOrder(){
  const state = {timur:{cols:[],lists:{}}, barat:{cols:[],lists:{}}};
  const routesByZone = {timur:[], barat:[]};
  Object.keys(SUPPLY_ORDER).forEach(route=>{
    const entries = (SUPPLY_ORDER[route]||[]).slice().sort((a,b)=>a.seq-b.seq);
    if(!entries.length) return;
    const zone = entries[0].zone==="barat" ? "barat" : "timur";
    routesByZone[zone].push({route, entries});
  });
  ["timur","barat"].forEach(zone=>{
    state[zone].cols = routesByZone[zone].map(r=>{
      const withOffset = r.entries.find(e=>e.offset!==null && e.offset!==undefined);
      return {route:r.route, offset: withOffset ? withOffset.offset : 1};
    });
    routesByZone[zone].forEach(r=>{
      state[zone].lists[r.route] = r.entries.map(e=>{
        const code=e.supplier_code||"";
        // "UNIQ:" prefix = baris ditambah manual by Kanban No lewat tombol "+ Uniq" (puOpenUniqAddModal
        // di bawah) — key-nya SENGAJA gak match grup supplier manapun di PU_SUPPLIERS_BY_ROUTE, jadi
        // type HARUS "uniq" (bukan fallback "supplier") biar gak keflag isOrphan palsu (lihat
        // puRenderZone: isOrphan cuma dicek utk type==="supplier").
        const type = code==="IMPORT" ? "import" : code==="UNPACKING" ? "unpacking" : code.startsWith("UNIQ:") ? "uniq" : "supplier";
        return {id: puNextId++, key: code, name: e.supplier, type};
      });
    });
  });
  return state;
}

/** Fetch daftar supplier (grouping VLOOKUP) per route dari backend, di-cache di PU_SUPPLIERS_BY_ROUTE. */
async function puEnsureSupplierLists(){
  const routes = new Set();
  ["timur","barat"].forEach(zone=>{ puState[zone].cols.forEach(c=>{ if(c.route) routes.add(c.route); }); });
  const toFetch = [...routes].filter(r=>!(r in PU_SUPPLIERS_BY_ROUTE));
  if(!toFetch.length) return;
  await Promise.all(toFetch.map(async r=>{
    try{
      const d = await apiGet("action=pu_grouped_by_supplier&route="+encodeURIComponent(r));
      const foundGroup = (d.grouped_data||[]).find(g => g.route === r);
      PU_SUPPLIERS_BY_ROUTE[r] = foundGroup ? foundGroup.suppliers : [];
      PU_NAME_CACHE_BY_ROUTE[r] = foundGroup ? (foundGroup.name_cache||{}) : {};
    }catch(e){ PU_SUPPLIERS_BY_ROUTE[r] = []; PU_NAME_CACHE_BY_ROUTE[r] = {}; }
  }));
}

/** Daftar awal (auto-fill) utk 1 route: semua supplier asli (bukan IMPORT/UNPACKING), sudah abjad A-Z dari backend. */
function puAutoFillList(route){
  return (PU_SUPPLIERS_BY_ROUTE[route]||[])
    .filter(s=>s.key!=="IMPORT" && s.key!=="UNPACKING")
    .map(s=>({id:puNextId++, key:s.key, name:s.supplier_name, type:"supplier"}));
}

/** Pastikan tiap kolom route yang aktif punya list (auto-fill kalau route ini baru pertama kali dipakai). */
function puEnsureListsForCols(zone){
  const st=puState[zone];
  st.cols.forEach(c=>{
    if(c.route && !st.lists[c.route]) st.lists[c.route]=puAutoFillList(c.route);
  });
}

/** Supplier yg BELUM ada di list route ini (buat isi dropdown "+ Supplier"). */
function puAvailablePool(zone, route){
  const list = puState[zone].lists[route] || [];
  const usedKeys = new Set(list.filter(e=>e.type==="supplier").map(e=>e.key));
  return (PU_SUPPLIERS_BY_ROUTE[route]||[]).filter(s=>s.key!=="IMPORT" && s.key!=="UNPACKING" && !usedKeys.has(s.key));
}

/** Render 1 zone (Kanban: 1 kolom per route, tiap kolom daftar supplier yg bisa di-drag). */
function puRenderZone(zone){
  const st=puState[zone];
  const box=document.getElementById(zone==="timur"?"puGridTimur":"puGridBarat");
  // Simpan posisi scroll tiap kolom (.pu-list) SEBELUM innerHTML diganti, biar abis re-render (gara2
  // ganti route/offset/tambah supplier/drag-drop) baliknya ke scroll semula, gak reset ke atas — dulu
  // ini bikin susah pas ngatur urutan supplier row yg jauh di bawah tiap ganti dropdown.
  const scrollMap={}; const boxScrollLeft=box.scrollLeft;
  box.querySelectorAll(".pu-list[data-col]").forEach(ul=>{ scrollMap[ul.dataset.col]=ul.scrollTop; });
  if(!st.cols.length){ box.innerHTML='<p class="meta" style="padding:14px">Belum ada route — klik "+ Route".</p>'; return; }
  const dis = puLocked ? "disabled" : "";
  let html='<div class="pu-board">';
  st.cols.forEach((c,ci)=>{
    const route=c.route;
    const list=st.lists[route]||[];
    const pool=puAvailablePool(zone, route);
    // Route yg udah kepake di kolom LAIN (di zone yg sama) dibuang dari pilihan — 1 route cuma boleh 1 kolom.
    const usedByOthers=new Set(st.cols.filter((c2,ci2)=>ci2!==ci).map(c2=>c2.route));
    const zoneRoutes=puRoutesForZone(zone);
    const routeBase=zoneRoutes.includes(route) ? zoneRoutes : [...zoneRoutes, route]; // jaga2 data lama yg zone-nya udah gak cocok VLOOKUP terbaru
    const routeOpts=routeBase.filter(r=>r===route || !usedByOthers.has(r));
    html+=`<div class="pu-routecol">
      <div class="pu-routecolhead">
        <select data-zone="${zone}" data-col="${ci}" data-field="route" ${dis}>${routeOpts.map(r=>`<option value="${r}" ${r===route?"selected":""}>${r}</option>`).join("")}</select>
        <label class="pu-offset-lbl">Off<input type="number" min="1" max="25" value="${c.offset??1}" data-zone="${zone}" data-col="${ci}" data-field="offset" ${dis}></label>
        <button type="button" class="pu-rmcol" data-zone="${zone}" data-col="${ci}" title="Hapus kolom route ini" ${dis}>✕</button>
      </div>
      <div class="pu-addrow-toolbar">
        <button type="button" class="pu-addspecial" data-zone="${zone}" data-col="${ci}" data-kind="import" ${dis}>+ Import</button>
        <button type="button" class="pu-addspecial" data-zone="${zone}" data-col="${ci}" data-kind="unpacking" ${dis}>+ Unpacking</button>
        <button type="button" class="pu-adduniq" data-zone="${zone}" data-col="${ci}" title="Tambah 1 part manual by Kanban No (Uniq No), mis. utk part yg statusnya blm sempat ditandai di Master Part" ${dis}>+ Uniq</button>
        <select class="pu-addsupplier" data-zone="${zone}" data-col="${ci}" ${(puLocked||!pool.length)?"disabled":""}>
          <option value="">+ Supplier…</option>
          ${pool.map(s=>`<option value="${puEsc(s.key)}">${puEsc(s.supplier_name)}</option>`).join("")}
        </select>
      </div>
      <ul class="pu-list" data-zone="${zone}" data-col="${ci}">
        ${list.map((entry,ri)=>{
          // Baris tersimpan tapi kode-nya udah gak ketemu lagi di Master Part utk route ini SEKARANG
          // (mis. Master Part di-upload ulang & identitas supplier ini berubah/hilang) — supplier &
          // Import/Unpacking/Uniq selalu ketemu (fixed/manual entry), jadi ini cuma bisa kena supplier asli.
          const isOrphan = entry.type==="supplier" && !(PU_SUPPLIERS_BY_ROUTE[route]||[]).some(s=>s.key===entry.key);
          // Namanya tetap diusahakan tampil rapi (bukan kode mentah) via cache nama, kalau ada.
          const displayName = isOrphan ? ((PU_NAME_CACHE_BY_ROUTE[route]||{})[entry.key] || entry.name) : entry.name;
          // 👁 (lihat detail Uniq No via PU_SUPPLIERS_BY_ROUTE, grup by-supplier) gak relevan utk baris
          // "uniq" (1 part spesifik, ditambah manual via + Uniq) — datanya udah lengkap di nama baris
          // ini sendiri, gak ada apa2 yg bisa dicari lagi di grup supplier (key-nya emang sengaja gak
          // match grup manapun).
          const showViewBtn = !isOrphan && entry.type!=="uniq";
          return `
        <li class="pu-row pu-row-${entry.type}${isOrphan?" pu-row-orphan":""}" draggable="${!puLocked}" data-id="${entry.id}" data-zone="${zone}" data-col="${ci}">
          <input type="checkbox" class="pu-rowchk" data-id="${entry.id}" ${puSelectedIds.has(entry.id)?"checked":""} ${dis}>
          <span class="pu-draghandle">⠿</span>
          <span class="pu-rowseq">${ri+1}</span>
          <span class="pu-rowname" data-id="${entry.id}" ${isOrphan?`title="⚠ Supplier ini udah gak terdaftar di Master Part utk route ${puEsc(route)} (mungkin Master Part-nya sudah di-upload ulang). Hapus baris ini kalau memang sudah gak relevan, atau pilih ulang suppliernya dari + Supplier."`:""}>${isOrphan?"⚠ ":""}${puEsc(displayName)}</span>
          <button type="button" class="pu-renamebtn" data-zone="${zone}" data-col="${ci}" data-id="${entry.id}" title="Ubah nama tampilan baris ini (mis. jadi singkatan operator)" ${dis}>✎</button>
          ${showViewBtn?`<button type="button" class="pu-viewbtn" data-route="${puEsc(route)}" data-key="${puEsc(entry.key)}" title="Lihat Uniq No yang dibawa baris ini">👁</button>`:""}
          <button type="button" class="pu-delrow" data-zone="${zone}" data-col="${ci}" data-id="${entry.id}" title="Hapus dari urutan" ${dis}>×</button>
        </li>`;
        }).join("")}
      </ul>
    </div>`;
  });
  html+='</div>';
  box.innerHTML=html;
  box.scrollLeft=boxScrollLeft;
  box.querySelectorAll(".pu-list[data-col]").forEach(ul=>{ if(scrollMap[ul.dataset.col]!==undefined) ul.scrollTop=scrollMap[ul.dataset.col]; });
}

function puRenderAll(){ puRenderZone("timur"); puRenderZone("barat"); }

/** Terapkan status kunci ke tombol UI. */
function puApplyLockUI(){
  document.querySelectorAll(".pu-addcol").forEach(b=>b.disabled=puLocked);
  document.getElementById("puEditBtn").textContent = puLocked ? "✎ Edit" : "🔓 Kunci";
  document.getElementById("puSaveBtn").disabled = puLocked;
  const lockNote = document.getElementById("puLockNote");
  if (lockNote) lockNote.textContent = puLocked
    ? '🔒 Data terkunci — klik "Edit" dulu buat mengubah.'
    : '🔓 Data bisa diedit — klik "Simpan Data" kalau sudah selesai (otomatis terkunci lagi).';
  if(puLocked) puSelectedIds.clear(); // gak bisa pilih baris pas lagi dikunci
  puUpdateBulkDeleteBtn();
}

/** Enable/disable + update label tombol "Hapus Terpilih" sesuai jumlah baris yg dicentang. */
function puUpdateBulkDeleteBtn(){
  const btn=document.getElementById("puBulkDeleteBtn");
  const n=puSelectedIds.size;
  btn.disabled = puLocked || n===0;
  btn.textContent = n>0 ? `🗑 Hapus Terpilih (${n})` : "🗑 Hapus Terpilih";
}

document.getElementById("puEditBtn").onclick=()=>{
  puLocked = !puLocked;
  puApplyLockUI();
  puRenderAll();
};

// Switcher Zone Timur/Barat — gantian 1 layar, bukan berdampingan lagi.
document.querySelectorAll(".pu-zonebtn").forEach(b=>b.onclick=()=>{
  const zone=b.dataset.zone;
  document.querySelectorAll(".pu-zonebtn").forEach(x=>x.classList.toggle("on", x===b));
  document.querySelectorAll(".pu-zone").forEach(x=>x.classList.toggle("on", x.dataset.zone===zone));
});

/* ---- Drag & drop reorder (native HTML5 DnD, event delegation krn grid di-render ulang tiap perubahan) ---- */
let puDragId=null;

document.addEventListener("dragstart", e=>{
  const row=e.target.closest(".pu-row");
  if(!row || puLocked) return;
  puDragId=row.dataset.id;
  row.classList.add("dragging");
  e.dataTransfer.effectAllowed="move";
  e.dataTransfer.setData("text/plain", puDragId); // wajib diisi biar Firefox mau drag
});
document.addEventListener("dragend", e=>{
  const row=e.target.closest(".pu-row");
  if(row) row.classList.remove("dragging");
  document.querySelectorAll(".pu-list.drag-over").forEach(l=>l.classList.remove("drag-over"));
  puDragId=null;
});
document.addEventListener("dragover", e=>{
  const list=e.target.closest(".pu-list");
  if(!list || puDragId===null) return;
  e.preventDefault();
  list.classList.add("drag-over");
  const draggingEl=list.querySelector('.pu-row.dragging') || document.querySelector(`.pu-row[data-id="${puDragId}"]`);
  if(!draggingEl) return;
  const afterEl=puDragAfterElement(list, e.clientY);
  if(afterEl==null) list.appendChild(draggingEl);
  else list.insertBefore(draggingEl, afterEl);
});
document.addEventListener("dragleave", e=>{
  const list=e.target.closest(".pu-list");
  if(list && !list.contains(e.relatedTarget)) list.classList.remove("drag-over");
});
/** Cari elemen row mana yg harus jadi "sesudah" posisi kursor sekarang (buat nentuin titik sisip). */
function puDragAfterElement(container, y){
  const els=[...container.querySelectorAll(".pu-row:not(.dragging)")];
  return els.reduce((closest, child)=>{
    const box=child.getBoundingClientRect();
    const offset=y-box.top-box.height/2;
    if(offset<0 && offset>closest.offset) return {offset, element:child};
    return closest;
  }, {offset:-Infinity, element:null}).element;
}
document.addEventListener("drop", e=>{
  const list=e.target.closest(".pu-list");
  if(!list || puDragId===null) return;
  e.preventDefault();
  list.classList.remove("drag-over");
  // Urutan akhir di DOM (hasil geser-geser pas dragover) jadi acuan urutan baru di state.
  const zone=list.dataset.zone, col=+list.dataset.col;
  const route=puState[zone].cols[col].route;
  const oldList=puState[zone].lists[route]||[];
  const byId={}; oldList.forEach(en=>byId[en.id]=en);
  const newIds=[...list.querySelectorAll(".pu-row")].map(li=>li.dataset.id);
  puState[zone].lists[route]=newIds.map(id=>byId[id]).filter(Boolean);
  puRenderZone(zone); // render ulang biar nomor Seq & urutan pool "+ Supplier" ke-refresh
});

// Event listener perubahan (route/offset/dropdown "+ Supplier"/checkbox pilih baris)
document.addEventListener("change", async e=>{
  const el=e.target;
  if(el.matches(".pu-rowchk")){
    const id=+el.dataset.id;
    if(el.checked) puSelectedIds.add(id); else puSelectedIds.delete(id);
    puUpdateBulkDeleteBtn();
    return;
  }
  if(el.matches(".pu-addsupplier")){
    const zone=el.dataset.zone, ci=+el.dataset.col, key=el.value;
    if(!key) return;
    const route=puState[zone].cols[ci].route;
    const sup=(PU_SUPPLIERS_BY_ROUTE[route]||[]).find(s=>s.key===key);
    if(sup){
      puState[zone].lists[route]=puState[zone].lists[route]||[];
      puState[zone].lists[route].push({id:puNextId++, key:sup.key, name:sup.supplier_name, type:"supplier"});
      puRenderZone(zone);
    }
    return;
  }
  if(!el.matches('[data-zone][data-field]')) return;
  const zone=el.dataset.zone, field=el.dataset.field;
  const st=puState[zone];
  if(field==="route"){
    st.cols[+el.dataset.col].route=el.value;
    await puEnsureSupplierLists();
    puEnsureListsForCols(zone);
    puRenderZone(zone);
  }else if(field==="offset"){
    st.cols[+el.dataset.col].offset=+el.value||1;
  }
});

document.addEventListener("click", async e=>{
  const viewBtn=e.target.closest(".pu-viewbtn");
  if(viewBtn){ puShowUniqViewer(viewBtn.dataset.route, viewBtn.dataset.key); return; }

  const renameBtn=e.target.closest(".pu-renamebtn");
  if(renameBtn){ if(puLocked) return; puStartRename(renameBtn.dataset.zone, +renameBtn.dataset.col, renameBtn.dataset.id); return; }

  const delBtn=e.target.closest(".pu-delrow");
  if(delBtn){
    const zone=delBtn.dataset.zone, id=delBtn.dataset.id;
    const route=puState[zone].cols[+delBtn.dataset.col]?.route;
    const entry=route && (puState[zone].lists[route]||[]).find(en=>String(en.id)===id);
    if(!entry) return;
    // Jangan langsung hapus — tampilkan konfirmasi dulu (lihat wiring #puDeleteModal di bawah).
    // innerHTML dibangun ulang tiap kali (bukan cuma isi teksnya) krn puDeleteMsg juga dipakai bulk
    // delete yg nimpa seluruh innerHTML-nya dgn pesan beda — jaga2 biar elemen <b> di sini selalu ada.
    puPendingDelete={zone, route, id};
    document.getElementById("puDeleteMsg").innerHTML=
      `Supplier <b id="puDeleteName"></b> akan dikeluarkan dari urutan Pattern Unload route <b id="puDeleteRoute"></b>. Bisa ditambahkan lagi lewat "+ Supplier" kalau berubah pikiran.`;
    document.getElementById("puDeleteName").textContent=entry.name;
    document.getElementById("puDeleteRoute").textContent=route;
    document.getElementById("puDeleteModal").style.display="flex";
    return;
  }

  const addSpecial=e.target.closest(".pu-addspecial");
  if(addSpecial){
    const zone=addSpecial.dataset.zone, ci=+addSpecial.dataset.col, kind=addSpecial.dataset.kind;
    const route=puState[zone].cols[ci].route;
    puState[zone].lists[route]=puState[zone].lists[route]||[];
    puState[zone].lists[route].push({id:puNextId++, key:kind==="import"?"IMPORT":"UNPACKING", name:kind==="import"?"IMPORT":"UNPACKING", type:kind});
    puRenderZone(zone);
    return;
  }

  const addUniq=e.target.closest(".pu-adduniq");
  if(addUniq){ puOpenUniqAddModal(addUniq.dataset.zone, +addUniq.dataset.col); return; }

  const rm=e.target.closest(".pu-rmcol");
  if(rm){
    const zone=rm.dataset.zone, ci=+rm.dataset.col;
    puState[zone].cols.splice(ci,1);
    puRenderZone(zone);
    return;
  }
  // "+ Route" SEKARANG buka popup (puOpenRouteAddModal, bukan auto-pick nomor berikutnya lagi) --
  // dikonfirmasi user: operator ketik sendiri nama route yang mau ditambahkan (bisa route fisik A-Q
  // yang belum kepakai, ATAU route khusus bebas spt "C/U"/"UNP") lewat 1 modal terpusat, GANTI 2
  // tombol dedicated "+ C/U"/"+ Unpacking" yang sempat dicoba sebelumnya (dihapus, kurang fleksibel).
  const add=e.target.closest(".pu-addcol");
  if(add){ puOpenRouteAddModal(add.dataset.zone); }
});

/* ---- Modal "Tambah Route" (puRouteAddModal) — dipicu tombol "+ Route" tiap header zone ---- */

let puRouteAddZone=null;

/** Buka modal + isi datalist saran: route yang BELUM dipakai di zone ini (dari allKnownRoutes(),
 * 01-state.js — sudah termasuk route khusus yg pernah terdaftar spt "C/U"/"UNP") + 2 saran route
 * khusus umum ("C/U","UNP") yang mungkin belum pernah ada sama sekali, biar operator gak perlu
 * hafal ejaannya persis. Input TETAP bebas teks (bukan dropdown tertutup) — operator boleh ketik
 * nama lain yang belum ada di saran sama sekali. */
function puOpenRouteAddModal(zone){
  puRouteAddZone=zone;
  const usedRoutes=new Set(puState[zone].cols.map(c=>c.route));
  document.getElementById("puRouteAddSubtitle").textContent=
    `Ketik nama route yang mau ditambahkan ke Zone ${zone==="barat"?"Barat":"Timur"} — route fisik (A-Q) yang belum dipakai, atau route khusus (mis. "C/U","UNP").`;
  document.getElementById("puRouteAddInput").value="";
  document.getElementById("puRouteAddMsg").textContent="";
  const suggestions=[...new Set([...allKnownRoutes().filter(r=>!usedRoutes.has(r)), "C/U","UNP"])];
  document.getElementById("puRouteAddList").innerHTML=suggestions.map(r=>`<option value="${r}">`).join("");
  document.getElementById("puRouteAddModal").style.display="flex";
  document.getElementById("puRouteAddInput").focus();
}
document.getElementById("puRouteAddCancel").onclick=()=>document.getElementById("puRouteAddModal").style.display="none";
document.getElementById("puRouteAddModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });

document.getElementById("puRouteAddSave").onclick=async()=>{
  const zone=puRouteAddZone;
  const msg=document.getElementById("puRouteAddMsg");
  // Uppercase WAJIB — backend selalu strtoupper() nilai route (api_offset_upsert_row,
  // api_save_supply_order) apa pun yg dikirim; kalau di sini dibiarkan huruf campuran (mis. diketik
  // "Unpacking"), bakal ke-uppercase jadi "UNPACKING" pas disimpan, ROUTE_ZONE (optimistic update di
  // bawah) jadi gak pernah cocok lagi sama nilai yg beneran ada di server sesudah reload/bootstrap.
  const route=document.getElementById("puRouteAddInput").value.trim().toUpperCase();
  if(!route){ msg.textContent="Nama route wajib diisi."; return; }
  const st=puState[zone];
  if(st.cols.some(c=>c.route===route)){ msg.textContent=`Route ${route} sudah ada di zone ini.`; return; }
  // Registrasi ke Master Offset (smms_offset) SEKALI kalau route ini BELUM pernah terdaftar sama
  // sekali — biar otomatis ikut muncul di Editor/Monitor/Grid Halte juga (allKnownRoutes/ROUTE_ZONE),
  // bukan cuma nampil di Pattern Unload doang. Placeholder process='SUPPLY', volume=0, offset='0'
  // (baris ini murni PENANDA "route ini ada" — nilai offset sesungguhnya diisi user lewat tab
  // Database ▸ Counter Offset kalau memang dibutuhkan proses SUPPLY/HALTE utk route ini).
  if(!ROUTE_ZONE[route]){
    try{
      await apiPost("offset_upsert_row",{dock:"43",process:"SUPPLY",zone,route,volume:0,offset_val:"0"});
      ROUTE_ZONE[route]=zone; // update lokal biar langsung kepakai tanpa perlu reload/bootstrap ulang
      if(typeof editorRefreshRoutes==="function") editorRefreshRoutes();
    }catch(err){ msg.textContent="Gagal daftarkan route: "+err.message; return; }
  }
  st.cols.push({route, offset:1});
  await puEnsureSupplierLists();
  puEnsureListsForCols(zone);
  puRenderZone(zone);
  document.getElementById("puRouteAddModal").style.display="none";
};

/* ---- Modal "Tambah Uniq" (puUniqAddModal) — dipicu tombol "+ Uniq" tiap kolom route, dikonfirmasi
   user: kadang part yg statusnya blm sempat ditandai di Master Part (mis. blm ditandai C/U) perlu
   bisa ditambahkan manual by Kanban No (Uniq No) ke kolom mana pun, BUKAN cuma via auto-fill by
   status/route (lihat api_pu_grouped_by_supplier, api/pattern_unload.php). BEDA dari puUniqModal
   (tanpa "Add", itu popup LIHAT detail baris yg SUDAH ada, punya puShowUniqViewer sendiri). ---- */

let puUniqAddZoneCi=null;

function puOpenUniqAddModal(zone, ci){
  puUniqAddZoneCi={zone,ci};
  const route=puState[zone].cols[ci]?.route;
  document.getElementById("puUniqAddSubtitle").textContent=`Cari part by Kanban No (Uniq No), tambahkan manual ke kolom route ${route}.`;
  document.getElementById("puUniqAddInput").value="";
  document.getElementById("puUniqAddResults").innerHTML="";
  document.getElementById("puUniqAddMsg").textContent="";
  document.getElementById("puUniqAddModal").style.display="flex";
  document.getElementById("puUniqAddInput").focus();
}
document.getElementById("puUniqAddCancel").onclick=()=>document.getElementById("puUniqAddModal").style.display="none";
document.getElementById("puUniqAddModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });

/** Cari (action=pu_lookup_uniq) & render daftar hasil klik-utk-tambah — bisa >1 match krn uniq_no
 * bukan primary key Master Part (part_no yg PK). */
async function puUniqAddSearch(){
  const msg=document.getElementById("puUniqAddMsg");
  const box=document.getElementById("puUniqAddResults");
  const uniq=document.getElementById("puUniqAddInput").value.trim().toUpperCase();
  if(!uniq){ msg.textContent="Isi Uniq No dulu."; return; }
  msg.textContent=""; box.innerHTML="Mencari...";
  try{
    const d=await apiGet("action=pu_lookup_uniq&uniq_no="+encodeURIComponent(uniq));
    const rows=d.rows||[];
    if(!rows.length){ box.innerHTML=""; msg.textContent=`Tidak ada part dgn Uniq No "${uniq}" di Master Part.`; return; }
    box.innerHTML=rows.map((r,i)=>
      `<div class="pu-uniqresult" data-i="${i}">
        <b>${puEsc(r.part_no)}</b> — ${puEsc(r.part_name||"")}<br>
        <span class="meta">${puEsc(r.supplier_name||"-")} · status ${puEsc(r.status||"-")} · route asli ${puEsc(r.route||"-")}</span>
      </div>`
    ).join("");
    box.querySelectorAll(".pu-uniqresult").forEach(el=>el.onclick=()=>{
      const r=rows[+el.dataset.i];
      const {zone,ci}=puUniqAddZoneCi;
      const route=puState[zone].cols[ci].route;
      // Key diprefix "UNIQ:" (dibaca ulang di puBuildStateFromSupplyOrder pas reload) supaya baris
      // ini SELALU dikenali type "uniq" — TIDAK PERNAH keflag isOrphan (itu logic yg cuma berlaku
      // buat type "supplier"), krn key-nya emang sengaja unik per baris, bukan grup supplier asli.
      puState[zone].lists[route]=puState[zone].lists[route]||[];
      puState[zone].lists[route].push({id:puNextId++, key:"UNIQ:"+uniq+"|"+r.part_no, name:`${r.part_name||r.part_no} (${uniq})`, type:"uniq"});
      puRenderZone(zone);
      document.getElementById("puUniqAddModal").style.display="none";
    });
  }catch(err){ box.innerHTML=""; msg.textContent="Gagal cari: "+err.message; }
}
document.getElementById("puUniqAddSearch").onclick=puUniqAddSearch;
document.getElementById("puUniqAddInput").addEventListener("keydown",e=>{ if(e.key==="Enter"){ e.preventDefault(); puUniqAddSearch(); } });

/**
 * Ubah nama TAMPILAN 1 baris jadi bahasa operator (mis. "TRI" ketimbang nama panjang system) —
 * cuma nimpa entry.name (label di baris Pattern Unload), entry.key TETAP gak disentuh. Popup 👁
 * "Lihat Uniq No" (puShowUniqViewer) selalu pakai entry.key buat cari data asli di PU_SUPPLIERS_BY_ROUTE
 * dan nampilin sup.supplier_name (nama asli dari Master Part) — jadi tetap gak ke-mix-up biar gak
 * bingung pas cek detail part-nya, walau labelnya di baris sendiri sudah disingkat.
 */
function puStartRename(zone, ci, id){
  const route=puState[zone].cols[ci]?.route;
  const list=route && puState[zone].lists[route];
  const entry=list && list.find(en=>String(en.id)===id);
  if(!entry) return;
  const span=document.querySelector(`.pu-rowname[data-id="${id}"]`);
  if(!span) return;
  const oldName=entry.name;
  const input=document.createElement("input");
  input.type="text"; input.className="pu-rename-input"; input.value=oldName;
  span.replaceWith(input);
  input.focus(); input.select();
  let done=false;
  const commit=()=>{
    if(done) return; done=true;
    const v=input.value.trim();
    entry.name=v||oldName;
    puRenderZone(zone);
  };
  const cancel=()=>{ if(done) return; done=true; puRenderZone(zone); };
  input.addEventListener("keydown",ev=>{
    if(ev.key==="Enter"){ ev.preventDefault(); commit(); }
    else if(ev.key==="Escape"){ ev.preventDefault(); cancel(); }
  });
  input.addEventListener("blur",commit);
}

/** Popup "lihat Uniq No" — datanya sudah ada di cache PU_SUPPLIERS_BY_ROUTE, gak perlu API call lagi. */
function puShowUniqViewer(route, key){
  const sup = (PU_SUPPLIERS_BY_ROUTE[route]||[]).find(s=>s.key===key);
  const rows = sup ? sup.items : [];
  document.getElementById("puUniqTitle").textContent = key==="UNPACKING"
    ? "Detail Gabungan Unpacking Murni" : "Detail Supplier: " + (sup ? sup.supplier_name : key);
  document.getElementById("puUniqSubtitle").textContent = `Route ${route} — ${rows.length} part`;
  document.getElementById("puUniqRows").innerHTML = rows.length
    ? rows.map(r=>`<tr><td>${puEsc(r.uniq_no)}</td><td>${puEsc(r.part_no)}</td><td>${puEsc(r.part_name)}</td><td>${puEsc(r.supplier||"")}</td></tr>`).join("")
    : key==="IMPORT"
      ? `<tr><td colspan="4" style="text-align:center;color:var(--mut)">IMPORT gak terhubung ke data Master Part manapun — ini penanda manual utk slot part impor, bukan supplier asli.</td></tr>`
      : `<tr><td colspan="4" style="text-align:center;color:var(--mut)">Tidak ada part yang cocok</td></tr>`;
  document.getElementById("puUniqModal").style.display = "flex";
}
document.getElementById("puUniqClose").onclick=()=>document.getElementById("puUniqModal").style.display="none";
document.getElementById("puUniqModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });

/** Konfirmasi sebelum benar-benar hapus baris supplier dari urutan — via tombol × (1 baris) atau
 * "Hapus Terpilih" (bulk, bisa lintas kolom/zone sekaligus, lihat puSelectedIds). */
let puPendingDelete=null; // {zone, route, id} (single) ATAU {bulk:true} (pakai puSelectedIds)
function puCloseDeleteModal(){ puPendingDelete=null; document.getElementById("puDeleteModal").style.display="none"; }
document.getElementById("puDeleteCancel").onclick=puCloseDeleteModal;
document.getElementById("puDeleteModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) puCloseDeleteModal(); });
document.getElementById("puDeleteConfirm").onclick=()=>{
  if(!puPendingDelete) return;
  if(puPendingDelete.bulk){
    ["timur","barat"].forEach(zone=>{
      const st=puState[zone];
      st.cols.forEach(c=>{
        if(!c.route || !st.lists[c.route]) return;
        st.lists[c.route]=st.lists[c.route].filter(en=>!puSelectedIds.has(en.id));
      });
    });
    puSelectedIds.clear();
    puCloseDeleteModal();
    puUpdateBulkDeleteBtn();
    puRenderAll();
    return;
  }
  const {zone, route, id}=puPendingDelete;
  puState[zone].lists[route]=(puState[zone].lists[route]||[]).filter(en=>String(en.id)!==id);
  puCloseDeleteModal();
  puRenderZone(zone);
};

document.getElementById("puBulkDeleteBtn").onclick=()=>{
  const n=puSelectedIds.size;
  if(!n) return;
  puPendingDelete={bulk:true};
  document.getElementById("puDeleteMsg").innerHTML=
    `<b>${n} baris</b> terpilih akan dikeluarkan dari urutan Pattern Unload (bisa lintas kolom/route). Bisa ditambahkan lagi manual kalau berubah pikiran.`;
  document.getElementById("puDeleteModal").style.display="flex";
};

/** Kirim {rows} ke save_supply_order, DISERIALKAN (gak boleh overlap) — server (api_save_supply_order)
 * TRUNCATE lalu insert ulang penuh smms_pattern_unload, dan TRUNCATE bikin implicit commit di
 * MySQL/MariaDB (transaction-nya gak beneran ngelindungin dari request lain nyelip di tengah).
 * Pola persis sama dgn saveCfg() di 02-api.js — lihat komentarnya utk detail insiden yg melatarinya. */
let savePuChain=Promise.resolve();
function savePuOrder(rows){
  const run=()=>apiPost("save_supply_order",{rows});
  savePuChain=savePuChain.then(run,run);
  return savePuChain;
}

/** Simpan data grid ke server — tiap baris di tiap kolom route jadi 1 row {route,seq,supplier,...}, seq = posisi di list. */
document.getElementById("puSaveBtn").onclick=async()=>{
  const rows=[];
  ["timur","barat"].forEach(zone=>{
    const st=puState[zone];
    st.cols.forEach(c=>{
      if(!c.route) return;
      const list=st.lists[c.route]||[];
      list.forEach((entry,i)=>{
        rows.push({route:c.route, seq:i+1, supplier:entry.name, supplier_code:entry.key, zone, offset:c.offset??1});
      });
    });
  });
  if(!rows.length){ toast("Belum ada data utk disimpan"); return; }
  try{
    const res=await savePuOrder(rows);
    await bootstrap();
    puState=puBuildStateFromSupplyOrder();
    await puEnsureSupplierLists();
    puEnsureListsForCols("timur"); puEnsureListsForCols("barat");
    puLocked = true;
    puApplyLockUI();
    puRenderAll();
    redrawAll(); if(selRoute) renderParts();
    const orphanCount=puCountOrphans();
    toast(orphanCount>0
      ? `Pattern Unload tersimpan: ${res.rows} baris. ⚠ ${orphanCount} supplier masih tidak sinkron dgn Master Part.`
      : `Pattern Unload tersimpan: ${res.rows} baris`);
  }catch(e){ toast("Gagal simpan: "+e.message); }
};

/** Hitung total baris supplier yg udah "orphan" (kode-nya gak ketemu lagi di Master Part) di semua kolom/zone. */
function puCountOrphans(){
  let count=0;
  ["timur","barat"].forEach(zone=>{
    puState[zone].cols.forEach(c=>{
      (puState[zone].lists[c.route]||[]).forEach(entry=>{
        if(entry.type==="supplier" && !(PU_SUPPLIERS_BY_ROUTE[c.route]||[]).some(s=>s.key===entry.key)) count++;
      });
    });
  });
  return count;
}

/** Inisialisasi awal section Pattern Unload. */
async function initPatternUnload(){
  puState=puBuildStateFromSupplyOrder();
  await puEnsureSupplierLists();
  puEnsureListsForCols("timur"); puEnsureListsForCols("barat");
  puLocked = true;
  puApplyLockUI();
  puRenderAll();
  puLoaded=true;
  const orphanCount=puCountOrphans();
  if(orphanCount>0) toast(`⚠ ${orphanCount} supplier di Pattern Unload sudah tidak sinkron dengan Master Part — cek yang ditandai merah`);
}
