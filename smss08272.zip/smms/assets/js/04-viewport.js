/* =====================================================================
   04-VIEWPORT — pan & zoom kanvas denah (drag rack/titik jalur juga di sini
   karena berbagi mousedown/mousemove/mouseup yang sama dengan pan).
   ===================================================================== */
const vp=document.getElementById("viewport"), stage=document.getElementById("stage");
let scale=1,tx=0,ty=0;

/** Terapkan transform pan/zoom saat ini ke #stage. */
function applyT(){
  stage.style.transform=`translate(${tx}px,${ty}px) scale(${scale})`;
  // Shape "Plane Buffer" (kind:'planebuffer', 06-render.js) butuh kompensasi zoom biar kontennya
  // (gauge/teks, hidup di koordinat SVG yg SAMA dgn denah) selalu keliatan ukuran normal/gampang
  // dibaca, bukan ikut nyusut sekecil `scale` di atas — disinkronkan ULANG tiap zoom berubah di sini
  // (wheel/tombol +-/FIT/dst SEMUA lewat applyT()), murah (cuma update 1 CSS transform, gak render ulang).
  if(typeof syncPlaneBufferZoomScale==="function") syncPlaneBufferZoomScale();
}

/** Sesuaikan scale+offset supaya seluruh denah pas di viewport (tombol FIT & saat resize).
 * Batas mulai dari ukuran gambar denah, tapi diperluas kalau ada titik jalur/rack yg posisinya
 * di luar gambar (mis. kesalahan drag di Editor) — biar FIT selalu bisa jangkau titik itu buat
 * diklik/diedit/dihapus, bukannya kepotong/gak kelihatan gara2 FIT cuma mepet ke ukuran gambar. */
function fit(){
  const r=vp.getBoundingClientRect();
  let minX=0, minY=0, maxX=IMGW, maxY=IMGH;
  Object.values(CFG.paths||{}).forEach(pts=>(pts||[]).forEach(p=>{
    if(p.x<minX)minX=p.x; if(p.x>maxX)maxX=p.x;
    if(p.y<minY)minY=p.y; if(p.y>maxY)maxY=p.y;
  }));
  (CFG.racks||[]).forEach(rk=>{
    if(rk.x<minX)minX=rk.x; if(rk.x>maxX)maxX=rk.x;
    if(rk.y<minY)minY=rk.y; if(rk.y>maxY)maxY=rk.y;
  });
  const pad=40; minX-=pad; minY-=pad; maxX+=pad; maxY+=pad;
  const w=maxX-minX, h=maxY-minY;
  scale=Math.min(r.width/w,r.height/h);
  tx=(r.width-w*scale)/2-minX*scale; ty=(r.height-h*scale)/2-minY*scale;
  applyT();
}
document.getElementById("zin").onclick=()=>{scale*=1.25;applyT();};
document.getElementById("zout").onclick=()=>{scale/=1.25;applyT();};
document.getElementById("zfit").onclick=fit;

/* ---- Mode Follow: fullscreen + zoom 562.5% + kamera otomatis ngikutin towing route terpilih ---- */
let followMode=false;
const zfollowBtn=document.getElementById("zfollow");
const followStatusEl=document.getElementById("followStatus"), followPartsEl=document.getElementById("followParts");

/** Tampil/sembunyikan overlay info countdown/plane/status + daftar Muatan yg cuma kelihatan
 * pas Mode Follow fullscreen — begitu tampil, langsung isi kontennya (bukan nunggu tick berikutnya). */
function setFollowOverlayVisible(v){
  followStatusEl.classList.toggle("tw-hidden",!v);
  followPartsEl.classList.toggle("tw-hidden",!v);
  if(v){ refreshHeader(); if(selRoute) renderParts(); }
}

/**
 * Geser tx/ty biar towing route terpilih pas di tengah viewport (dipanggil tiap moveTowings()).
 * cdOverride WAJIB diterusin dari moveTowings() (bukan baca variabel cd global langsung) — kalau
 * enggak, kamera bakal "loncat" langsung ke posisi akhir tick (cd yg udah committed) dari frame
 * PERTAMA animasi, padahal towing-nya sendiri masih pelan-pelan jalan ke situ (towXY(r,cdOverride)
 * pas dipanggil dari moveTowings() per-frame) — kamera & towing harus baca posisi interpolasi yg
 * SAMA persis tiap frame biar geraknya bareng, gak loncat duluan.
 */
function followTowing(cdOverride){
  if(!followMode || !selRoute) return;
  const p=towXY(selRoute,cdOverride); if(!p) return;
  const r=vp.getBoundingClientRect();
  tx=r.width/2-p.x*scale; ty=r.height/2-p.y*scale;
  applyT();
}
zfollowBtn.onclick=async()=>{
  if(followMode){
    followMode=false; zfollowBtn.classList.remove("on"); setFollowOverlayVisible(false);
    if(document.fullscreenElement) await document.exitFullscreen().catch(()=>{});
    fit();
    return;
  }
  if(!selRoute){ toast("Pilih 1 towing dulu (klik towing di denah / Pilih Route) sebelum Follow"); return; }
  followMode=true; zfollowBtn.classList.add("on");
  try{ await vp.requestFullscreen(); }catch(e){}
};
// fullscreenchange nangkep DUA arah: abis beneran masuk fullscreen (baru set scale 120%+mulai follow,
// krn ukuran viewport br "final" setelah transisi selesai) & keluar fullscreen manual (mis. tombol ESC).
document.addEventListener("fullscreenchange",()=>{
  if(document.fullscreenElement){
    if(followMode){
      const r=vp.getBoundingClientRect();
      scale=Math.min(r.width/IMGW,r.height/IMGH)*5.625;
      followTowing();
      setFollowOverlayVisible(true);
    }
  }else if(followMode){
    followMode=false; zfollowBtn.classList.remove("on"); setFollowOverlayVisible(false); fit();
  }
});

// Zoom pakai scroll wheel, titik di bawah kursor jadi pusat zoom.
vp.addEventListener("wheel",e=>{e.preventDefault();
  const r=vp.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;
  const f=e.deltaY<0?1.15:1/1.15;
  tx=mx-(mx-tx)*f; ty=my-(my-ty)*f; scale*=f; applyT();
},{passive:false});

let panning=false,dragItem=null,px=0,py=0,moved=false,dragIsGroup=false,dragSnapshot=null;
// Drag shape (mode Geser, mode==="shape" cuma buat NAMBAH baru — geser/resize/rotate shape yg SUDAH
// ada tetap lewat mode "pan", sama kayak rack/titik jalur) — dragShapeHandle = lagi narik handle sudut
// (resize) ATAU handle rotasi (lihat mode:"nw"/"ne"/"sw"/"se"/"rot", 06-render.js), dragShapeMove =
// lagi narik BODY shape (geser posisi). Namespace TERPISAH dari dragItem (rack/titik jalur, [data-drag])
// krn shape pakai atribut [data-shape]/.shape-handle sendiri (editor/editor.js).
let dragShapeHandle=null, dragShapeMove=null;

/* ---- Blok (marquee) — Shift+drag di area KOSONG pas mode Geser = gambar kotak seleksi, pilih
   semua rack yg masuk area itu sekaligus (biar gak perlu shift+klik satu-satu). Gak pakai mode/tombol
   terpisah — tetap di mode "pan", cuma dibedain dari pan biasa via shiftKey + gak lagi megang [data-drag]
   (shift+drag yg MULAI di atas rack/titik tetap berarti "geser grup", lihat dragIsGroup di bawah). ---- */
let blocking=false, blockX0=0, blockY0=0, blockX1=0, blockY1=0, blockEl=null;
function blockRectScreen(x0,y0,x1,y1){ return { left:Math.min(x0,x1), top:Math.min(y0,y1), width:Math.abs(x1-x0), height:Math.abs(y1-y0) }; }

// mousedown: mulai drag rack/titik jalur, mulai kotak seleksi (Shift+drag area kosong), atau pan biasa.
vp.addEventListener("mousedown",e=>{ px=e.clientX;py=e.clientY;moved=false;
  const g=e.target.closest("[data-drag]");
  // Handle shape (resize sudut / rotasi) DICEK DULUAN, sebelum body shape -- handle-nya kecil &
  // "di dalam" grup <g data-shape> yg sama persis kayak body-nya, jadi kalau body dicek duluan bisa
  // ke-skip (closest() nemu <g> terluar duluan, handle jadi gak pernah kena).
  const shHandle = (editing&&mode==="pan") ? e.target.closest(".shape-handle") : null;
  const shBody = (!shHandle&&editing&&mode==="pan") ? e.target.closest("[data-shape]") : null;
  if(shHandle){
    dragShapeHandle={idx:+shHandle.dataset.shape, mode:shHandle.dataset.handle};
    dragSnapshot=snapshotCfg();
  } else if(shBody){
    dragShapeMove=+shBody.dataset.shape;
    dragSnapshot=snapshotCfg();
  } else if(g&&editing&&mode==="pan"){
    dragItem=g;
    // Grup ke-drag bareng HANYA kalau titik yg lagi dipegang ini emang bagian dari multi-seleksi
    // (rkSelected/ptSelected, lihat editor/editor.js) DAN seleksinya beneran >1 item — klik+geser titik
    // yg lagi gak keseleksi tetap geser 1 titik itu doang.
    dragIsGroup = isDragItemSelected(g) && (rkSelected.size+ptSelected.size>1);
    // Snapshot diambil SEBELUM drag mulai (bukan tiap mousemove) — geseran satu ATAU banyak titik
    // sekaligus (shift+drag) jadi 1 langkah undo doang, dicommit di mouseup cuma kalau beneran geser.
    dragSnapshot = snapshotCfg();
  } else if(!g&&editing&&mode==="pan"&&e.shiftKey){
    blocking=true;
    const r=vp.getBoundingClientRect(); blockX0=e.clientX-r.left; blockY0=e.clientY-r.top;
    blockEl=document.createElement("div"); blockEl.className="blockSelectBox";
    Object.assign(blockEl.style,{left:blockX0+"px",top:blockY0+"px",width:"0px",height:"0px"});
    vp.appendChild(blockEl);
  } else if(!editing || mode==="pan"){
    // Pan CUMA jalan di Monitor (!editing) ATAU mode "Geser" — dikonfirmasi user: "denah gak ikut
    // geser2 sendiri" pas lagi di mode +Rack/+Jalur/+Shape/Hapus. SEBELUMNYA klik area kosong di
    // mode APA PUN jatuh ke pan (gak ada guard mode di sini), jadi tangan yg gak 100% diam waktu
    // klik buat nambah rack/jalur/shape (geser sepersekian px) bikin denah ikut kegeser dikit +
    // moved=true, yg BAHKAN nge-block aksi klik-nya sendiri (lihat guard `if(!editing||moved)return`
    // di listener klik, editor/editor.js). Sekarang klik kosong di mode selain Geser diam aja (denah fix).
    panning=true;
  }
});
window.addEventListener("mousemove",e=>{
  const dx=e.clientX-px,dy=e.clientY-py;
  if(Math.abs(dx)+Math.abs(dy)>3)moved=true;
  if(blocking){
    const r=vp.getBoundingClientRect();
    blockX1=e.clientX-r.left; blockY1=e.clientY-r.top;
    const rect=blockRectScreen(blockX0,blockY0,blockX1,blockY1);
    Object.assign(blockEl.style,{left:rect.left+"px",top:rect.top+"px",width:rect.width+"px",height:rect.height+"px"});
  }
  else if(panning){ tx+=dx;ty+=dy;px=e.clientX;py=e.clientY;applyT(); }
  else if(dragItem){ px=e.clientX;py=e.clientY;
    // Grup cuma digeser bareng SELAMA shift lagi ditekan (dicek tiap frame, bukan cuma pas mulai
    // drag) — lepas shift di tengah jalan otomatis balik ke geser 1 titik yg lagi dipegang doang.
    if(dragIsGroup && e.shiftKey){
      const ddx=dx/scale, ddy=dy/scale;
      rkSelected.forEach(idx=>{ const o=CFG.racks[+idx]; if(o){ o.x=Math.max(0,Math.min(IMGW,o.x+ddx)); o.y=Math.max(0,Math.min(IMGH,o.y+ddy)); } });
      ptSelected.forEach(key=>{ const [r,i]=key.split("|"); const o=CFG.paths[r]&&CFG.paths[r][+i];
        if(o){ o.x=Math.max(0,Math.min(IMGW,o.x+ddx)); o.y=Math.max(0,Math.min(IMGH,o.y+ddy)); } });
      redrawAll(false);
    } else {
      const o=itemOf(dragItem); if(o){
        // Titik/rack gak boleh digeser sampai keluar batas denah — dulu bisa nyasar jauh di luar gambar
        // (mis. lupa dilepas pas masih di-drag) dan jadi susah dijangkau lagi.
        o.x=Math.max(0,Math.min(IMGW,o.x+dx/scale)); o.y=Math.max(0,Math.min(IMGH,o.y+dy/scale)); redrawAll(false);
      }
    }
  }
  else if(dragShapeHandle){ px=e.clientX;py=e.clientY;
    const s=CFG.shapes[dragShapeHandle.idx]; if(s){
      if(dragShapeHandle.mode==="rot"){
        // Rotasi bebas, dihitung dari sudut ABSOLUT (bukan delta per-frame) antara pusat shape & posisi
        // kursor SEKARANG — +90 krn handle rotasi ditaruh di ATAS pusat (bukan di kanan/sumbu-0 atan2).
        // Tahan Shift snap ke kelipatan 15° ("dilurusin" cepat, dikonfirmasi user).
        const cx=s.x+s.w/2, cy=s.y+s.h/2;
        const p=stageXY(e);
        let deg=Math.atan2(p.y-cy,p.x-cx)*180/Math.PI + 90;
        if(e.shiftKey) deg=Math.round(deg/15)*15;
        s.rot=(deg%360+360)%360;
      } else {
        // Resize: proyeksikan delta mouse (screen, per-frame) ke sumbu LOKAL shape (invers rotasi)
        // dulu, biar tetap benar arahnya walau shape-nya udah diputar (bukan cuma pas rot=0).
        const rad=-(s.rot||0)*Math.PI/180;
        const ldx=(dx*Math.cos(rad)-dy*Math.sin(rad))/scale, ldy=(dx*Math.sin(rad)+dy*Math.cos(rad))/scale;
        const MIN=20; // ukuran minimum, cegah shape "hilang" kekecilan pas ditarik kebalik
        if(dragShapeHandle.mode.includes("w")){ const nw=Math.max(MIN,s.w-ldx); s.x+=s.w-nw; s.w=nw; }
        if(dragShapeHandle.mode.includes("e")){ s.w=Math.max(MIN,s.w+ldx); }
        if(dragShapeHandle.mode.includes("n")){ const nh=Math.max(MIN,s.h-ldy); s.y+=s.h-nh; s.h=nh; }
        if(dragShapeHandle.mode.includes("s")){ s.h=Math.max(MIN,s.h+ldy); }
      }
      redrawAll(false);
    }
  }
  else if(dragShapeMove!==null){ px=e.clientX;py=e.clientY;
    const s=CFG.shapes[dragShapeMove]; if(s){ s.x+=dx/scale; s.y+=dy/scale; redrawAll(false); }
  }
});
window.addEventListener("mouseup",e=>{
  if(dragItem){
    if(moved){ pushHistory(dragSnapshot); saveCfg(); }
    dragItem=null; dragIsGroup=false; dragSnapshot=null;
  }
  if(dragShapeHandle||dragShapeMove!==null){
    if(moved){ pushHistory(dragSnapshot); saveCfg(); }
    dragShapeHandle=null; dragShapeMove=null; dragSnapshot=null;
  }
  if(blocking){
    // Konversi kotak seleksi (screen-space) -> image-space (bagi scale, kurangi pan tx/ty), lalu
    // cari semua RACK + TITIK JALUR yg (x,y)-nya jatuh di dalam kotak itu. Titik jalur: kalau mode
    // "Semua Route" lagi aktif (!mapFocusOnly), scan SEMUA route sekaligus (sama kayak titik yg
    // beneran ditampilin selectable di redrawAll()); kalau lagi fokus 1 route (mapFocusOnly), cuma
    // scan editRoute. Shift ditahan pas lepas mouse -> TAMBAH ke seleksi yg sudah ada; tanpa shift
    // -> GANTI (reset dulu).
    const rect=blockRectScreen(blockX0,blockY0,blockX1,blockY1);
    blockEl?.remove(); blockEl=null; blocking=false;
    if(rect.width>3 || rect.height>3){ // abaikan klik doang (kotak nyaris 0px) tanpa drag beneran
      const x0=(rect.left-tx)/scale, y0=(rect.top-ty)/scale;
      const x1=(rect.left+rect.width-tx)/scale, y1=(rect.top+rect.height-ty)/scale;
      if(!e.shiftKey){ rkSelected.clear(); ptSelected.clear(); }
      CFG.racks.forEach((rk,i)=>{ if(rk.x>=x0&&rk.x<=x1&&rk.y>=y0&&rk.y<=y1) rkSelected.add(String(i)); });
      const routes=mapFocusOnly?[editRoute]:Object.keys(CFG.paths);
      routes.forEach(r=>{
        const path=CFG.paths[r];
        if(path) path.forEach((p,i)=>{ if(p.x>=x0&&p.x<=x1&&p.y>=y0&&p.y<=y1) ptSelected.add(r+"|"+i); });
      });
      redrawAll();
      if(typeof rkUpdateButtons==="function") rkUpdateButtons();
      toast(`${rkSelected.size+ptSelected.size} titik terpilih`);
    }
  }
  panning=false;
});

/** Ambil objek data (rack atau titik jalur) di balik elemen SVG [data-drag] yang lagi digeser. */
function itemOf(g){
  if(g.dataset.rack!==undefined) return CFG.racks[+g.dataset.rack];
  if(g.dataset.route!==undefined&&g.dataset.pt!==undefined) return CFG.paths[g.dataset.route][+g.dataset.pt];
  return null;
}

/** True kalau elemen [data-drag] ini (rack atau titik jalur) lagi termasuk multi-seleksi sekarang
 * (rkSelected/ptSelected, editor/editor.js) — dipakai nentuin drag ini geser 1 titik doang atau segrup. */
function isDragItemSelected(g){
  if(g.dataset.rack!==undefined) return rkSelected.has(g.dataset.rack);
  if(g.dataset.route!==undefined&&g.dataset.pt!==undefined) return ptSelected.has(g.dataset.route+"|"+g.dataset.pt);
  return false;
}

/** Konversi koordinat mouse event -> koordinat ruang denah (image-space), memperhitungkan pan/zoom. */
function stageXY(e){
  const r=stage.getBoundingClientRect();
  // Diclamp ke batas denah — klik di area kosong di luar gambar (background biru muda) gak boleh
  // nambah rack/titik jalur yang nyasar di luar layout.
  const x=Math.max(0,Math.min(IMGW,(e.clientX-r.left)/scale));
  const y=Math.max(0,Math.min(IMGH,(e.clientY-r.top)/scale));
  return {x,y};
}
