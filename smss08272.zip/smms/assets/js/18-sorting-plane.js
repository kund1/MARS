/* =====================================================================
   18-SORTING-PLANE (nama file dipertahankan, isi ditulis ulang jadi "Sorting Area", koreksi
   arsitektur 2026-08-27) — menu "Setting" > Sorting Layout: physical area tempat skid hasil bongkar
   Plane menunggu proses SORTING, hierarchy Sorting Area -> Slot -> Stack -> Skid -> Part (lihat
   assets/js/21-sorting-area-stacking.js utk kalkulasi Stack). Diidentifikasi lewat ROUTE (bukan nomor
   plane). Slot DIHITUNG dari Rows x Columns(=2, fix) -- BUKAN di-CRUD satu-satu (dikonfirmasi user:
   "jangan bikin user create slot manual, slot otomatis dibangun dari Rows x 2"). Entity TERPISAH TOTAL
   dari Physical Plane (Pengaturan Fisik Plane, plane-sim/) & "Sorting Store" (belum dibuat) — JANGAN
   dicampur. Config-only fase ini: CRUD + shape di denah doang, BELUM ada movement/distribusi skid
   per-route/animasi (itu fase integrasi data berikutnya, lihat memori project).

   GANTIKAN TOTAL "Sorting Plane" (smms_sorting_plane, field Plane Capacity 1/2) yg dibangun sebelumnya
   di sesi ini -- field itu HILANG, diganti Rows (Columns selalu 2). Pola CRUD tetap sama (tabel
   sederhana + popup form Add/Edit + tombol Edit/Delete inline, sama pola CRUD config lain di app ini).
   ===================================================================== */

let SP_ALL_ROWS=[], SP_MASTER_ROUTES=[], spEditId=null;

/** Dipanggil pas nav "Setting" diklik pertama kali (09-nav.js) -- muat dropdown Route (dari Master
 * Part, BUKAN hardcode ALLR spt dropdown route lain di app ini) + tabel Sorting Area, lalu render. */
async function initSortingPlane(){
  const [routesRes, rowsRes] = await Promise.all([
    apiGet('action=master_part_routes').catch(()=>({routes:[]})),
    apiGet('action=sorting_area_list').catch(()=>({rows:[]}))
  ]);
  SP_MASTER_ROUTES = routesRes.routes || [];
  SP_ALL_ROWS = (rowsRes.rows||[]).map(r=>({id:+r.id, sorting_code:r.sorting_code, route:r.route, row_count:+r.row_count, column_count:+r.column_count}));
  spRenderTable();
}

/** Daftar Slot 1 Sorting Area -- DIHITUNG on-the-fly dari row_count x column_count (BUKAN diambil dari
 * DB, tidak ada tabel slot sama sekali, lihat komentar file atas) -- dipakai preview di sini & render
 * shape di denah (06-render.js, renderSortingAreaContent, fungsi TERPISAH tapi rumus SAMA). */
function sortingSlotsFor(area){
  const cols=area.column_count||2, rows=area.row_count||0;
  const slots=[];
  for(let seq=1; seq<=rows*cols; seq++){
    slots.push({ seq, row: Math.ceil(seq/cols), col: ((seq-1)%cols)+1, slot_code: area.sorting_code+'-'+String(seq).padStart(2,'0') });
  }
  return slots;
}

/** Kartu preview KECIL per baris (tabel Setting) — identitas Route + grid slot placeholder KOSONG
 * sesuai Rows x Columns, SENGAJA TANPA data Stack/Skid asli (belum ada 1 pun data skid real yg mengalir
 * ke Sorting di fase ini). */
function spPreviewHtml(row){
  const slots=sortingSlotsFor(row).map(s=>`<div class="sp-slot" title="${s.slot_code}"><div class="sp-slot-lbl">${s.slot_code}</div></div>`).join("");
  return `<div class="sp-preview"><div class="sp-preview-route">ROUTE ${puEsc(row.route)}</div><div class="sp-preview-slots">${slots}</div></div>`;
}

function spRenderTable(){
  const box=document.getElementById("spTableBox");
  if(!box) return;
  const thead=`<tr><th>Sorting ID</th><th>Route</th><th>Rows</th><th>Columns</th><th>Total Slot</th><th>Preview</th><th style="width:110px"></th></tr>`;
  box.innerHTML=`<div style="overflow-x:auto"><table class="grid compact">${thead}`+
    (SP_ALL_ROWS.length ? SP_ALL_ROWS.map(r=>
      `<tr><td>${puEsc(r.sorting_code)}</td><td>${puEsc(r.route)}</td><td>${r.row_count}</td><td>${r.column_count}</td><td>${r.row_count*r.column_count}</td>`+
      `<td>${spPreviewHtml(r)}</td><td>`+
      `<button class="tmode spEditBtn" data-id="${r.id}" style="padding:3px 8px;font-size:11px">✎</button> `+
      `<button class="tmode mp-danger spDelBtn" data-id="${r.id}" style="padding:3px 8px;font-size:11px">🗑</button>`+
      `</td></tr>`
    ).join("") : '<tr><td colspan="7" style="text-align:center;color:var(--mut)">Belum ada data — klik + Add Sorting Area</td></tr>')
    +`</table></div>`;
  box.querySelectorAll(".spEditBtn").forEach(b=>b.onclick=()=>spOpenForm("edit", SP_ALL_ROWS.find(r=>r.id===+b.dataset.id)));
  box.querySelectorAll(".spDelBtn").forEach(b=>b.onclick=()=>spDeleteRow(+b.dataset.id));
}

function spUpdateSlotPreview(){
  const rows=Math.max(1,+document.getElementById("spfRows").value||1);
  document.getElementById("spfTotalSlot").textContent = (rows*2)+" slot ("+rows+" baris × 2 kolom)";
}

function spOpenForm(mode, row){
  spEditId = mode==="edit" ? row.id : null;
  document.getElementById("spFormTitle").textContent = mode==="add" ? "Tambah Sorting Area" : "Edit Sorting Area";
  document.getElementById("spFormMsg").textContent="";
  document.getElementById("spfCode").value = mode==="edit" ? row.sorting_code : "";
  document.getElementById("spfCode").disabled = mode==="edit"; // sorting_code = identity unik, gak diubah pas edit (hapus+add baru kalau mau ganti kode)
  // Isi dropdown Route tiap buka form -- jaga2 Master Part berubah SEJAK initSortingPlane() terakhir
  // jalan (dikonfirmasi user: dropdown harus ikut data Master Part TERKINI, bukan snapshot lama).
  const sel=document.getElementById("spfRoute");
  sel.innerHTML = SP_MASTER_ROUTES.map(r=>`<option value="${puEsc(r)}">${puEsc(r)}</option>`).join("");
  sel.value = mode==="edit" ? row.route : (SP_MASTER_ROUTES[0]||"");
  document.getElementById("spfRows").value = mode==="edit" ? row.row_count : 1;
  spUpdateSlotPreview();
  document.getElementById("spFormModal").style.display="flex";
}
document.getElementById("spAddBtn").onclick=()=>spOpenForm("add");
document.getElementById("spFormCancel").onclick=()=>document.getElementById("spFormModal").style.display="none";
document.getElementById("spFormModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });
document.getElementById("spfRows").addEventListener("input",spUpdateSlotPreview);

document.getElementById("spFormSave").onclick=async()=>{
  const msg=document.getElementById("spFormMsg");
  const code=document.getElementById("spfCode").value.trim();
  const route=document.getElementById("spfRoute").value;
  const rows=+document.getElementById("spfRows").value;
  if(!code){ msg.textContent="Sorting ID wajib diisi (mis. SRG-01)."; return; }
  if(!route){ msg.textContent="Route wajib dipilih."; return; }
  if(!rows||rows<1){ msg.textContent="Rows wajib diisi (angka >= 1)."; return; }
  // Cek duplikat sorting_code di client jg (pola sama CRUD config lain) -- pesan error jelas TANPA
  // nunggu round-trip server dulu, backend tetap validasi ulang.
  if(SP_ALL_ROWS.some(r=>r.sorting_code===code && r.id!==spEditId)){
    msg.textContent=`Sorting Area "${code}" sudah ada — edit baris itu langsung, bukan tambah baru.`;
    return;
  }
  try{
    await apiPost("sorting_area_upsert_row",{id:spEditId, sorting_code:code, route, row_count:rows});
    document.getElementById("spFormModal").style.display="none";
    toast(`Sorting Area ${code} tersimpan`);
    await initSortingPlane();
  }catch(e){ msg.textContent="Gagal simpan: "+e.message; }
};

async function spDeleteRow(id){
  const row=SP_ALL_ROWS.find(r=>r.id===id);
  try{
    await apiPost("sorting_area_delete_row",{id});
    toast(`Sorting Area ${row?row.sorting_code:id} dihapus`);
    await initSortingPlane();
  }catch(e){ toast("Gagal hapus: "+e.message); }
}
