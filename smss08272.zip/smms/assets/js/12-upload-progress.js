/* =====================================================================
   12-UPLOAD-PROGRESS — tab Upload: upload file upload_progress_laneYYYYMMDD.xlsx
   yang mengganti penuh database part aktif. Template download + Last Upload +
   Riwayat Upload, gaya sama dgn Master Part (17-master-part.js).
   ===================================================================== */
const fxl=document.getElementById("fileXlsx");

/** Escape nilai supaya aman ditaruh sbg teks HTML. */
function plEsc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;"); }

document.getElementById("plUploadOpenBtn").onclick=()=>{
  fxl.value=""; document.getElementById("plFileName").textContent="Belum pilih file";
  document.getElementById("upmeta").textContent=""; document.getElementById("upsummary").innerHTML="";
  document.getElementById("plUploadModal").style.display="flex";
};
document.getElementById("plUploadCancel").onclick=()=>document.getElementById("plUploadModal").style.display="none";
document.getElementById("plUploadModal").addEventListener("click",e=>{ if(e.target===e.currentTarget) e.currentTarget.style.display="none"; });

document.getElementById("plChooseFile").onclick=()=>fxl.click();
fxl.addEventListener("change",()=>{
  const f=fxl.files[0];
  document.getElementById("plFileName").textContent=f?f.name:"Belum pilih file";
});
document.getElementById("plUploadBtn").onclick=async()=>{
  const f=fxl.files[0];
  if(!f){ toast("Pilih file dulu"); return; }
  await doUpload(f);
};

/** Upload & proses file progress-lane, lalu refresh seluruh state aplikasi dari data baru. */
async function doUpload(file){
  const btn=document.getElementById("plUploadBtn"); btn.disabled=true;
  document.getElementById("upmeta").textContent="Mengunggah & memproses "+file.name+" …";
  const fd=new FormData(); fd.append('file',file);
  try{
    const res=await apiPost('upload',fd,true);
    document.getElementById("upsummary").innerHTML=
      `<table class="grid"><tr><th>File</th><td>${res.file}</td></tr>
       <tr><th>Baris valid (Dock 43)</th><td>${res.rows}</td></tr>
       <tr><th>P-Lane</th><td>${res.planes.join(", ")}</td></tr>
       <tr><th>Rack address</th><td>${res.racks}</td></tr></table>`;
    document.getElementById("upmeta").textContent="Berhasil.";
    fxl.value=""; document.getElementById("plFileName").textContent="Belum pilih file";
    PCACHE={}; await bootstrap(); buildPlaneSel(); buildAddrList();
    await loadPlane(plane); selRoute=null;
    redrawAll(); refresh();
    dbActiveDate=null; DB_PCACHE={}; buildDbParts(); // balik liat batch aktif terbaru, bukan preview tanggal lama
    await plRefreshHistory(); await plRefreshDates();
    document.getElementById("plUploadModal").style.display="none";
    toast("Database part diganti: "+res.file);
  }catch(e){ document.getElementById("upmeta").textContent="Gagal: "+e.message+". Coba lagi."; }
  finally{ btn.disabled=false; }
}

/** Tampilkan cuma upload TERAKHIR (nama file + waktu) di kotak "LAST UPLOAD" (lihat .dbt-lastupload). */
async function plRefreshHistory(){
  const d=await apiGet("action=progress_lane_upload_history");
  const r=(d.rows||[])[0];
  document.getElementById("plLastUpload").innerHTML = r
    ? `${plEsc(r.filename)}<span class="when">${plEsc(r.uploaded_at)}</span>`
    : "—";
}

/** Format tanggal ISO ("2026-08-04") jadi "04 Agu 2026" buat label pill tombol. */
function plFormatDateLabel(iso){
  const bulan=["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];
  const [y,m,d]=iso.split("-").map(Number);
  return `${String(d).padStart(2,"0")} ${bulan[m-1]} ${y}`;
}

/** Render pill tombol pilih tanggal (preview tabel Progress Lane tab Database SAJA — gak
 * ngaruh ke Monitor, lihat dbActiveDate di 10-database.js). Batch yang masih ada = hasil
 * retensi poka-yoke H-1/H+1 di server (api_progress_lane_dates()). */
async function plRefreshDates(){
  const box=document.getElementById("dbDatePills");
  if(!box) return;
  const d=await apiGet("action=progress_lane_dates").catch(()=>({rows:[]}));
  const rows=d.rows||[];
  if(!rows.length){ box.innerHTML=""; return; }
  box.innerHTML=rows.map(r=>{
    const on = dbActiveDate ? r.data_date===dbActiveDate : r.active;
    return `<button type="button" class="pl-datebtn${on?" on":""}" data-date="${r.data_date}" title="${plEsc(r.filename)} · ${r.rows_count} baris">${plFormatDateLabel(r.data_date)}</button>`;
  }).join("");
  box.querySelectorAll(".pl-datebtn").forEach(b=>b.onclick=()=>{
    dbActiveDate=b.dataset.date;
    document.querySelectorAll("#dbDatePills .pl-datebtn").forEach(x=>x.classList.remove("on"));
    b.classList.add("on");
    buildDbParts();
  });
}

// ==========================================
// AUTO-SYNC DETEKSI KERJA ROBOT PYTHON
// ==========================================
let lastKnownUploadTime = null;

async function checkRobotUpdate() {
    try {
        // Panggil endpoint riwayat upload yang sudah ada di sistem PHP lu
        const d = await apiGet("action=progress_lane_upload_history");
        const r = (d.rows || [])[0];
        
        if (r && r.uploaded_at) {
            // Jika ini pertama kalinya dicek, simpan referensi waktunya
            if (!lastKnownUploadTime) {
                lastKnownUploadTime = r.uploaded_at;
                return;
            }
            
            // Jika waktu upload di database BERBEDA (artinya robot baru saja sukses memasukkan data)
            if (lastKnownUploadTime !== r.uploaded_at) {
                lastKnownUploadTime = r.uploaded_at;
                
                // Berikan notifikasi toast ke admin
                if (typeof toast === 'function') {
                    toast("🤖 Data baru dimasukkan oleh Robot Otomatis: " + r.filename);
                }
                
                // Segarkan seluruh komponen halaman web secara otomatis
                if (typeof PCACHE !== 'undefined') PCACHE = {};
                if (typeof bootstrap === 'function') await bootstrap();
                if (typeof buildPlaneSel === 'function') buildPlaneSel();
                if (typeof buildAddrList === 'function') buildAddrList();
                if (typeof loadPlane === 'function' && typeof plane !== 'undefined') await loadPlane(plane);
                if (typeof redrawAll === 'function') redrawAll();
                if (typeof refresh === 'function') refresh();
                dbActiveDate=null; DB_PCACHE={}; // batch baru masuk — jangan nyangkut di preview tanggal lama
                if (typeof buildDbParts === 'function') buildDbParts();
                if (typeof plRefreshHistory === 'function') await plRefreshHistory();
                if (typeof plRefreshDates === 'function') await plRefreshDates();
            }
        }
    } catch (err) {
        // Silent catch agar tidak mengganggu console jika koneksi sesaat terputus
    }
}
// Contoh diubah jadi 2 menit sekali (120000 ms)
setInterval(checkRobotUpdate, 120000);