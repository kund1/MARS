/* =====================================================================
   08-HEADER — kontrol counter di header (P-Lane, C/D Awal, countdown +/-,
   AUTO), dan loop update tampilan header/jam.
   ===================================================================== */
const planeSel=document.getElementById("planeSel"), cdStartSel=document.getElementById("cdStartSel");
const dbPlane=document.getElementById("dbPlane"), dbRoute=document.getElementById("dbRoute");

/** Isi ulang dropdown P-Lane (header & tab Database) dan C/D Awal, plus teks meta sumber data. */
function buildPlaneSel(){
  planeSel.innerHTML="";dbPlane.innerHTML="";
  PLANES.forEach(p=>{const o=document.createElement("option");o.value=o.textContent=p;planeSel.appendChild(o);
                     const o2=document.createElement("option");o2.value=o2.textContent=p;dbPlane.appendChild(o2);});
  planeSel.value=plane;
  // Pilihan "C/D AWAL" (Volume) SEKARANG diambil dari Master Offset (OFFSET_TABLE.volume) -- BUKAN
  // dari smms_cd_mapping (CD_MAP) lagi. Dulu 2 sumber ini gak sinkron: Master Offset bisa punya lebih
  // banyak Volume terisi datanya (mis. 12: 14-25) drpd smms_cd_mapping (mis. cuma 8: 17-24) -- akibatnya
  // Volume yg sudah lengkap Supply Offset-nya di Master Offset tapi belum ada baris Countdown->Halte-nya
  // jadi TIDAK BISA dipilih sama sekali sbg C/D AWAL. Sekarang semua Volume yg ADA datanya di Master
  // Offset bisa dipilih (diurut besar->kecil, "cd terbesar" di atas) -- kalau Volume itu kebetulan belum
  // py baris di CD_MAP, towing tetap jalan (activeHalteForCd fallback ke posisi proporsional, lihat
  // 03-countdown.js), cuma belum berhenti presisi di titik halte 1/2/3.
  cdStartSel.innerHTML="";
  const cdVolumes=[...new Set(OFFSET_TABLE.map(r=>+r.volume))].filter(v=>v>0).sort((a,b)=>b-a);
  cdVolumes.forEach(s=>{const o=document.createElement("option");o.value=o.textContent=s;cdStartSel.appendChild(o);});
  if(cdVolumes.length && !cdVolumes.includes(cdStart)) cdStart=cdVolumes[0]; // fallback: Volume terbesar yg ada datanya
  cdStartSel.value=cdStart;
  document.getElementById("hdCdDuration").value=+(META.cd_duration_sec||2);
  document.getElementById("hdTowSpeed").value=TOW_SPEED;
  document.getElementById("dbmeta").textContent=`Sumber: ${META.parts_source||'?'} · ${META.parts_rows||'?'} baris · upload ${META.parts_uploaded||'-'}`;
  document.getElementById("upmeta").textContent=`Database aktif: ${META.parts_source||'?'} (${META.parts_rows||'?'} baris)`;
}
planeSel.onchange=async()=>{
  plane=planeSel.value; await loadPlane(plane); if(selRoute)renderParts(); refresh();
  // Ganti manual lewat dropdown ini beda dari stepCd (lompat bebas ke plane manapun, bukan sekedar
  // "lanjut ke slot berikutnya") -- reset seluruh state konveyor (slot aktif + penomoran recycle)
  // biar Plane Simulation kalkulasi ULANG dari posisi plane baru ini, bukan nyambung dari sebelumnya.
  if(typeof renderPlaneSim==="function"){ if(typeof psResetConveyor==="function") psResetConveyor(); renderPlaneSim(); }
};
cdStartSel.onchange=()=>{
  cdStart=+cdStartSel.value; cd=Math.min(cd,cdStart); refresh();
  // Rasio Auto-Scaling Plane Simulation (psRecomputeTimeLapseRatio, plane-sim.js) tergantung cdStart —
  // segarkan biar durasi total waktu simulasi ikut nyesuain begitu operator ubah C/D Awal, bukan nunggu
  // heartbeat 20 detik (lihat setInterval renderPlaneSim, plane-sim.js).
  if(typeof renderPlaneSim==="function") renderPlaneSim();
};
document.getElementById("cdMinus").onclick=()=>stepCd(-1);
document.getElementById("cdPlus").onclick=()=>stepCd(1);

/** Durasi 1 tick countdown (detik), diatur di header — dipakai heartbeat di bawah utk jarak antar-tick. */
const hdCdDuration=document.getElementById("hdCdDuration");
hdCdDuration.onchange=async()=>{
  const sec=Math.max(1,+hdCdDuration.value||2);
  hdCdDuration.value=sec;
  try{ await apiPost("save_offset_settings",{cd_duration_sec:sec}); META.cd_duration_sec=String(sec); toast("Durasi countdown tersimpan"); }
  catch(e){ toast("Gagal simpan durasi: "+e.message); }
};

/** Kecepatan towing manual (px/detik, dropdown di header) — dipakai towTickDurationMs (03-countdown.js)
 * buat ngitung durasi animasi tiap tick. Tersimpan di smms_meta.tow_speed, ke-load lagi pas bootstrap(). */
const hdTowSpeed=document.getElementById("hdTowSpeed");
hdTowSpeed.onchange=async()=>{
  const speed=+hdTowSpeed.value||30;
  TOW_SPEED=speed;
  try{ await apiPost("save_offset_settings",{tow_speed:speed}); META.tow_speed=String(speed); toast("Kecepatan towing tersimpan"); }
  catch(e){ toast("Gagal simpan kecepatan towing: "+e.message); }
};

/** Majukan/mundurkan countdown 1 langkah. Kalau habis (Supply selesai), naik ke plane berikutnya
 * lewat jeda "towing keluar" dulu (semua towing/dolly/coupling disembunyikan ~1.5 detik, ngasih
 * kesan towing beneran ninggalin jalur biar manusia bisa masuk) SEBELUM plane baru dimuat & towing
 * muncul lagi di titik 0 — dari situ "disusun" (dolly nyambung satu-satu dari PREPARE, lihat
 * dollyPositions di 03-countdown.js) otomatis kejadian sendiri pas tick normal berikutnya jalan,
 * gak perlu animasi terpisah. planeSwitching jadi guard biar heartbeat/klik manual gak nyelonong
 * tick lain di tengah jeda ini (bisa balapan ganti plane 2x kalau durasi countdown disetel pendek). */
let planeSwitching=false;
async function stepCd(d){
  if(planeSwitching) return;
  const prevCd=cd;
  cd+=d;
  if(cd>cdStart) cd=cdStart;

  if(cd < CD_END){
    planeSwitching=true;
    document.querySelectorAll(".towing,.dolly,.coupling").forEach(el=>el.style.display="none");
    await new Promise(res=>setTimeout(res,1500));
    const i=(PLANES.indexOf(plane)+1)%PLANES.length;
    plane=PLANES[i];
    planeSel.value=plane;
    cd=cdStart;
    await loadPlane(plane);
    // Reset ke halte 0 (titik awal) berarti gak ada dolly yg aktif — refresh focusDolly juga di sini,
    // bukan cuma di tick normal di bawah, supaya gak kebawa nyala dolly dari plane SEBELUMNYA.
    if(selRoute){ focusDolly=autoFocusDollyFor(selRoute); renderParts(); }
    refreshHeader();
    redrawAll();
    if(typeof psAdvanceActiveSlot==="function") psAdvanceActiveSlot();
    if(typeof renderPlaneSim==="function") renderPlaneSim();
    planeSwitching=false;
    return;
  }

  // Durasi animasi ikut jarak ASLI yg ditempuh route terpilih dibagi TOW_SPEED (03-countdown.js) — supaya
  // kecepatan towing konsisten, bukan durasi tetap gak peduli jarak antar-halte-nya beda-beda.
  const ms = selRoute ? towTickDurationMs(selRoute, prevCd, cd) : undefined;
  // Header (angka COUNT DOWN, HALTE AKTIF, dst) & focusDolly+panel Muatan baru disegarkan begitu
  // towing BENERAN SAMPAI (onArrive), BUKAN sebelum animasi mulai — kalau enggak, angka countdown
  // bakal "lompat" ke nilai baru duluan padahal towing-nya sendiri masih keliatan jalan (lihat
  // applyTransitVisuals di 06-render.js).
  animateCd(prevCd, cd, ms, ()=>{ refreshHeader(); refreshFocusAndParts(); });
}

document.getElementById("btnAuto").onclick=function(){ auto=!auto; this.classList.toggle("on",auto); this.textContent=auto?"⏸ AUTO":"▶ AUTO"; };
// Heartbeat jalanin tick countdown tiap "Durasi Countdown" detik (default 2 detik kalau belum
// di-setting, lihat Database > Counter & Offset) — cuma jalan kalau AUTO nyala.
let lastTickAt=0;
setInterval(()=>{
  if(liveMode || !auto) return;
  // Playback speed (Plane Simulation, "🐛 Debug"/toolbar Speed, koreksi 2026-08-27) -- murni membagi
  // JARAK antar-tick, TIDAK menyentuh business logic apa pun (stepCd/calculatePlaneState dkk gak tau
  // speed ini sama sekali) -- kalau plane-sim.js belum sempat load/isi variabelnya, default 1x apa adanya.
  const durMs=Math.max(1,+(META.cd_duration_sec||2))*1000/(typeof psPlaybackSpeed==="number"&&psPlaybackSpeed>0?psPlaybackSpeed:1);
  const now=Date.now();
  // animRAF (06-render.js) masih jalan = animasi tick SEBELUMNYA blm kelar (bisa lama krn TOW_SPEED
  // pelan) — jangan motong di tengah jalan (nyebabin towing "lompat" snap ke posisi baru), tunggu
  // beneran kelar dulu baru boleh tick berikutnya, biarpun durMs udah lewat.
  if(now-lastTickAt<durMs || animRAF || planeSwitching) return;
  lastTickAt=now;
  stepCd(-1);
},250);
setInterval(()=>{ if(liveMode)pollCounter(); },5000);

/** Refresh angka-angka di header (countdown, halte aktif, order no) + badge live — plus overlay
 * status Mode Follow fullscreen (#folPlane/#folCd/#folHalte/#folPosisi, 04-viewport.js), sengaja
 * cuma cerminan konten yg sama, bukan sumber data terpisah. */
function refreshHeader(){
  const info=halteInfo(cd); // TETAP `cd` mentah -- halteInfo() manggil towXY(selRoute,val) di dalamnya,
                            // yg SEKARANG udah nerjemahin ke CD Route sendiri lewat towProgress
                            // (03-countdown.js, cdRouteFor) -- gak perlu diterjemahkan 2x di sini.
  document.getElementById("hdCd").textContent = cd; // Andon Plane, cd mentah -- TETAP TIDAK BERUBAH
                                                      // (dikonfirmasi user: "cd di header tetap, cd utamanya").
  // "Andon Supply" route yg lagi dipilih (selRoute) — GANTI `cd` polos jadi cdRouteFor(...): HALTE
  // AKTIF/POSISI AKTIF di bawah ini SEKARANG dicocokkan pakai CD Route (Plane+Supply Offset, wrap
  // Volume), bukan cd mentah lagi (dikonfirmasi user, lihat cdRouteFor/03-countdown.js).
  const routeCd = selRoute ? cdRouteFor(selRoute, cd, cdStart) : cd;
  // "HALTE AKTIF" ikut Master Offset kalau ada baris yg cocok utk route terpilih (offsetStatusFor,
  // di-cek pakai CD Route & Volume=cdStart sekarang) — fallback ke halte cd_mapping lama kalau gak ada.
  const offsetStatus = offsetStatusFor(selRoute, routeCd, cdStart);
  const halteTxt = offsetStatus ? offsetStatus : (info.no ? "Halte "+info.no : "—");
  document.getElementById("hdHalte").textContent = halteTxt;
  // "POSISI AKTIF" — SEKARANG dari tabel Master Offset yang sama dgn "HALTE AKTIF" di atas (dulu
  // tabel terpisah smms_offset_position, sudah digabung jadi 1, lihat offsetPositionFor/
  // 03-countdown.js). Tetap fungsi & dicek terpisah (bukan fallback satu sama lain) — kalau gak ada
  // baris yg cocok utk route ini, tampil "—" (atau fallback threshold PREPARE/EMPTY bawaan).
  const posStatus = offsetPositionFor(selRoute, routeCd, cdStart);
  const posTxt = posStatus || "—";
  document.getElementById("hdPosisi").textContent = posTxt;
  document.getElementById("hdOrder").textContent=liveMode&&liveOrderNo ? liveOrderNo : (META.parts_source||'').replace(/\D/g,'').slice(0,8)+plane;
  document.getElementById("folPlane").textContent = plane;
  document.getElementById("folCd").textContent = cd;
  document.getElementById("folHalte").textContent = halteTxt;
  document.getElementById("folPosisi").textContent = posTxt;
  applyLiveUi();
  if(typeof psRefreshActiveCard==="function") psRefreshActiveCard();
  // Refresh clone shape "Plane Buffer" di denah (kalau ada) tiap tick juga, bareng psRefreshActiveCard
  // di atas (SUMBER-nya) — biar gauge-nya keliatan ikut ngetik/drain, bukan cuma update pas ganti plane.
  if(typeof refreshPlaneBufferShapes==="function") refreshPlaneBufferShapes();
}

/** Refresh menyeluruh (dipanggil setelah ganti plane/route): header, posisi towing, rack, sidebar. */
function refresh(){ refreshHeader(); moveTowings(); paintRacks(); renderRouteList(); }
