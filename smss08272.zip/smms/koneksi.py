import mysql.connector

try:
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="smms" # PENTING: Ganti dengan nama database web PHP lu
    )

    if db.is_connected():
        print("MANTAP! Python berhasil nyambung ke MySQL!")
py koneksi.py
    db.close()

except Exception as e:
    print("Yaaah gagal nyambung. Ini errornya:")
    print(e)