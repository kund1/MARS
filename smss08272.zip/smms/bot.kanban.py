import os
import time
import pandas as pd
import mysql.connector
import schedule
from datetime import datetime, timedelta

# ==========================================
# 1. FUNGSI BANTUAN (CLEANING DATA EXCEL)
# ==========================================
# Pandas kadang membaca angka sebagai desimal (misal: 43 jadi 43.0), ini untuk merapikannya.
def bersihkan_teks(val, max_len=None):
    if pd.isna(val): return ""
    v = str(val).strip()
    if v.endswith('.0'): v = v[:-2] 
    return v[:max_len] if max_len else v

def bersihkan_angka(val):
    if pd.isna(val): return 0
    try: return int(float(val))
    except: return 0

# ==========================================
# 2. FUNGSI ALERT JIKA GAGAL
# ==========================================
def kirim_alert_gagal(pesan_error):
    waktu = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    pesan = f"[{waktu}] 🚨 ALERT: {pesan_error}"
    print(pesan)
    with open("error_log.txt", "a") as file:
        file.write(pesan + "\n")

# ==========================================
# 2.5 FUNGSI LAPOR STATUS KE WEB (PHP)
# ==========================================
def lapor_status_ke_web(status_teks, tipe_alert="danger"):
    try:
        db = mysql.connector.connect(host="localhost", user="root", password="", database="smms")
        cursor = db.cursor()
        waktu = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # Simpan status ke smms_meta biar bisa dibaca sama PHP
        cursor.executemany(
            "REPLACE INTO smms_meta (k, v) VALUES (%s, %s)",
            [
                ('bot_status_pesan', status_teks),
                ('bot_status_tipe', tipe_alert), # Bisa 'danger', 'success', atau 'warning'
                ('bot_last_cek', waktu)
            ]
        )
        db.commit()
        cursor.close()
        db.close()
    except Exception as e:
        print(f"Gagal lapor ke DB: {e}")

# ==========================================
# 3. FUNGSI UTAMA: TARIK DATA & INSERT KE DB
# ==========================================
def tarik_data_kanban():
    maksimal_percobaan = 3
    jeda_waktu = 300 # Jeda 300 detik (5 menit) jika gagal
    
    print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Memulai eksekusi task Get Data H+1...")

    for percobaan in range(1, maksimal_percobaan + 1):
        try:
            # --- A. SETTING PATH & TANGGAL (H+1) ---
            folder_path = r"C:\Users\HYPE AMD\TMMIN\DIRECTORATE MANUFACTURING - 2026\08. Aug 2026"
            besok = datetime.now() + timedelta(days=1)
            nama_file_target = f"Order by Receiving {besok.strftime('%Y%m%d')}.xlsx"
            target_file_path = os.path.join(folder_path, nama_file_target)

            if not os.path.exists(target_file_path):
                raise Exception(f"File '{nama_file_target}' belum ada di folder OneDrive.")

            # --- B. BACA EXCEL ---
            df = pd.read_excel(target_file_path, engine='openpyxl')
            df.columns = df.columns.astype(str).str.lower().str.strip()
            
            if 'dock' not in df.columns:
                raise Exception("Kolom 'dock' tidak ditemukan di Excel!")

            # Filter Dock 43 dan Route A-Q
            df['dock_str'] = df['dock'].astype(str).str.strip()
            df['route_str'] = df.get('conveyance route', '').astype(str).str.strip()
            
            df_filtered = df[
                (df['dock_str'].str.startswith('43')) & 
                (df['route_str'].str.match(r'^[A-Q]$'))
            ]

            if df_filtered.empty:
                print("Data Dock 43 dengan Route A-Q kosong hari ini. Eksekusi selesai (Skip).")
                lapor_status_ke_web(f"File {nama_file_target} kosong (Dock 43 / Route A-Q tidak ada).", "warning")
                return 

            # --- C. KONEKSI MYSQL & MULAI TRANSAKSI ---
            db = mysql.connector.connect(
                host="localhost", user="root", password="", database="smms"
            )
            cursor = db.cursor()
            db.start_transaction()

            waktu_sekarang = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            jumlah_baris = len(df_filtered)
            # Tanggal data ini SEBENARNYA buat tanggal berapa — bot selalu narik file H+1, jadi
            # tanggalnya udah pasti "besok" (gak perlu tebak dari order_no kayak di PHP). Dipakai
            # poka-yoke retensi H-1/H+1 + preview per-tanggal di tab Database (lihat
            # api/progress_lane.php di sisi web).
            data_date = besok.strftime('%Y-%m-%d')

            # --- D. CEK APAKAH FILE DENGAN TANGGAL H+1 INI PERNAH DI-UPLOAD SEBELUMNYA ---
            # Jika filenya sudah pernah masuk, hapus data upload lama dan part lamanya biar gak double!
            cursor.execute("SELECT id FROM smms_progress_lane_uploads WHERE filename = %s", (nama_file_target,))
            existing_batches = cursor.fetchall()

            if existing_batches:
                batch_ids_to_delete = [str(row[0]) for row in existing_batches]
                format_batch_ids = ','.join(batch_ids_to_delete)

                print(f"⚠️ Data untuk {nama_file_target} sudah ada sebelumnya. Melakukan replace data lama...")
                cursor.execute(f"DELETE FROM smms_progress_lane WHERE batch_id IN ({format_batch_ids})")
                cursor.execute(f"DELETE FROM smms_progress_lane_uploads WHERE id IN ({format_batch_ids})")

            # 1. Catat History Upload Baru (Ambil Batch ID)
            planes_unik = sorted(df_filtered['mros'].dropna().astype(str).str.zfill(2).unique().tolist())
            planes_str = ",".join(planes_unik)

            cursor.execute(
                "INSERT INTO smms_progress_lane_uploads (filename, rows_count, planes, uploaded_at, data_date) VALUES (%s, %s, %s, %s, %s)",
                (nama_file_target, jumlah_baris, planes_str, waktu_sekarang, data_date)
            )
            batch_id = cursor.lastrowid

            # 2. Insert ke smms_progress_lane (Lengkap 18 Kolom)
            query_insert = """
            INSERT INTO smms_progress_lane (
                batch_id, plane, route, part_no, part_name, kanban, qty, lot, addr, 
                supplier, uniq_no, order_no, supplier_code, supplier_plant, 
                supplier_dock, plant_no, build_out_flag, route_order_seq
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            
            data_insert = []
            for _, row in df_filtered.iterrows():
                kanban_no = bersihkan_teks(row.get('kanban no', ''))
                data_insert.append((
                    batch_id,
                    bersihkan_teks(row.get('mros', '')).zfill(2),                 
                    bersihkan_teks(row.get('conveyance route', '')),              
                    bersihkan_teks(row.get('part no', '')),                       
                    bersihkan_teks(row.get('parts name', ''), 40),                
                    kanban_no,                                                    
                    bersihkan_angka(row.get('quantity per container', 0)),        
                    bersihkan_angka(row.get('order plan quantity(lot)', 0)),      
                    bersihkan_teks(row.get('kanban print address', '')).replace(" ", ""), 
                    bersihkan_teks(row.get('supplier name', ''), 40),             
                    kanban_no,                                                    
                    bersihkan_teks(row.get('order .', '')),                       
                    bersihkan_teks(row.get('supplier', ''), 20),                  
                    bersihkan_teks(row.get('s.plant', ''), 10),                   
                    bersihkan_teks(row.get('s.dock', ''), 20),                    
                    bersihkan_teks(row.get('plant', ''), 10),                     
                    bersihkan_teks(row.get('build out flag', ''), 10),            
                    bersihkan_teks(row.get('main route order seq', ''), 10)       
                ))

            cursor.executemany(query_insert, data_insert)

            # 3. Update smms_meta
            cursor.executemany(
                "REPLACE INTO smms_meta (k, v) VALUES (%s, %s)",
                [
                    ('parts_source', f'{nama_file_target} (Auto-Robot)'),
                    ('parts_rows', str(jumlah_baris)),
                    ('parts_uploaded', waktu_sekarang)
                ]
            )

            # 4. Retensi poka-yoke: buang batch yang data_date-nya udah di luar jendela wajar H-1..H+1
            # dari tanggal SEKARANG (real, bukan "besok") — batch baru ini ($batch_id) selalu
            # dikecualikan, dan kalau ternyata bakal nyisain 0 batch lain, 1 batch tersisa dijaga
            # biar Monitor gak pernah kehabisan data sama sekali (sama polanya kayak di PHP).
            lo = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
            hi = (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')
            cursor.execute(
                "SELECT id FROM smms_progress_lane_uploads WHERE id<>%s AND (data_date IS NULL OR data_date NOT BETWEEN %s AND %s) ORDER BY id DESC",
                (batch_id, lo, hi)
            )
            stale_ids = [row[0] for row in cursor.fetchall()]
            cursor.execute("SELECT COUNT(*) FROM smms_progress_lane_uploads")
            total_batches = cursor.fetchone()[0]
            if len(stale_ids) >= total_batches:
                stale_ids.pop()  # sisain minimal 1 batch lain selain yg baru
            if stale_ids:
                format_ids = ','.join(str(i) for i in stale_ids)
                cursor.execute(f"DELETE FROM smms_progress_lane WHERE batch_id IN ({format_ids})")
                cursor.execute(f"DELETE FROM smms_progress_lane_uploads WHERE id IN ({format_ids})")

            # --- E. SELESAI ---
            db.commit()
            print(f"✅ SUKSES! {jumlah_baris} baris masuk ke DB (Replaced & Batch ID: {batch_id}).")
            
            # Lapor ke web biar admin tahu robot sukses update
            lapor_status_ke_web(f"Sukses memproses {nama_file_target} ({jumlah_baris} baris).", "success")

            cursor.close()
            db.close()
            return 

        except Exception as e:
            pesan = f"Percobaan {percobaan}/{maksimal_percobaan} GAGAL: {e}"
            kirim_alert_gagal(pesan)
            
            if percobaan < maksimal_percobaan:
                print(f"Sistem akan mencoba kembali dalam {jeda_waktu // 60} menit...\n")
                time.sleep(jeda_waktu)
            else:
                fatal_pesan = "🚨 FATAL: Tarik data gagal setelah 3x percobaan!"
                kirim_alert_gagal(fatal_pesan)
                lapor_status_ke_web(fatal_pesan, "danger")

# ==========================================
# 4. SCHEDULER: JALAN SETIAP JAM 19:00 SORE
# ==========================================
schedule.every().day.at("14:35").do(tarik_data_kanban)

# Hapus tanda '#' di bawah ini HANYA JIKA lu mau ngetes langsung sekarang tanpa nunggu jam 7 malam
# tarik_data_kanban() 

print("==================================================")
print("🤖 ROBOT TASK SCHEDULER AKTIF")
print("Target: Setiap hari pukul 19:00 menarik file H+1")
print("Biarkan terminal ini tetap terbuka...")
print("==================================================")

while True:
    schedule.run_pending()
    time.sleep(1)