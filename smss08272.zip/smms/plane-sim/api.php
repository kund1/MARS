<?php
/* =====================================================================
   PLANE-SIM/API.PHP — helper backend khusus menu "Plane Simulation".
   BUKAN endpoint ter-routing sendiri (gak didaftarkan di $ROUTES, api.php)
   — file ini di-require dari api/progress_lane.php pas parsing upload,
   krn 3 kolom yg dipakai Plane Simulation (Sub Route Group Code, 1st Cross
   Dock Arrival/Departcher Date & Time) diekstrak SEKALIAN pas upload
   Progress Lane yg sama (1 pipeline upload, bukan duplikat) — cuma
   HELPER-nya yg ditaruh di sini. SEMUA berkas fitur Plane Simulation
   disatukan di 1 folder plane-sim/: api.php (ini), plane-sim.css,
   plane-sim.js, view.php — biar gampang dirawat dari 1 tempat. Data
   hasilnya sendiri diambil menu ini lewat endpoint YG SAMA dgn Monitor
   (action=plane, data.php) — SENGAJA gak diduplikasi jadi endpoint baru
   krn isinya emang persis sama (semua part 1 plane), lihat catatan index
   tiap baris di api/data.php.
   ===================================================================== */

/** Cari index kolom header dari beberapa KEMUNGKINAN nama (case-insensitive) — dipakai utk kolom yg
 * nama persisnya di file sumber belum dipastikan (Sub Route Code / Cross Dock Arrival & Departure
 * Date), coba beberapa varian umum, gak ketemu semua ya -1 (kolom itu dianggap gak ada, opsional). */
function findH($H, array $candidates) {
    foreach ($candidates as $c) { if (isset($H[strtolower($c)])) return $H[strtolower($c)]; }
    return -1;
}

/** Validasi + normalisasi nilai tanggal cell buat kolom DATETIME nullable (cd_arrival_at/
 * cd_departure_at) — return null kalau kosong ATAU "tanggal nol" (mis. "0000-00-00",
 * "0000-00-00 00:00:00", "00:00:00") yg dipakai file sumber sbg placeholder "belum ada tanggal"
 * (ketemu langsung di data asli: semua baris pas dicek malah keisi literal string ini, bukan bener2
 * blank — kalau diloloskan gitu aja bakal keinsert sbg tanggal nol yg valid, BUKAN NULL, jadi
 * ke-anggap "ada data" padahal harusnya kosong).
 * Format ASLI kolom ini di file sumber (dicek langsung ke file "Order by Receiving" real, kolom
 * AJ/AK) BUKAN Excel date native, tapi angka rapat "YYYYMMDDHHmm" (12 digit tanpa pemisah, mis.
 * "202608200843" = 2026-08-20 08:43). Detik (SS) juga diterima kalau suatu saat ada ("YYYYMMDDHHmmSS",
 * 14 digit) — opsional, default "00" kalau gak ada.
 * PENTING: fallback SELALU null (BUKAN return $s apa adanya) kalau isinya gak cocok pola manapun —
 * dulu return $s mentah bikin nilai gak dikenal (mis. "0.0", sisa pembulatan sel numerik OpenSpout
 * utk sel kosong yg keformat sbg "General") ke-insert apa adanya ke kolom DATETIME, MySQL diam2
 * nolak & nyimpennya jadi "0000-00-00 00:00:00" (tanggal nol yg valid scr kolom, tapi keanggep
 * "ada data" padahal kosong) — itu penyebab bug nyata: ~67% baris smms_progress_lane kesimpen
 * tanggal nol, bikin Plane Simulation (psSkidCountForGroup, plane-sim.js) salah ngitung skid krn
 * string tanggal nol itu truthy di JS jadi keanggep 1 timestamp asli yg sama² utk semua baris itu. */
function validDateOrNull($s) {
    $s = trim((string)$s);
    if ($s === '') return null;
    // Cek "tanggal nol" DULUAN (sebelum parse digit) — cegah kasus tepi "000000000000" (12 nol)
    // ikut lolos parse jadi string "0000-00-00 00:00:00" yg keliru dianggap "ada data".
    if (preg_match('/^0[00\-\/: ]*$/', $s)) return null; // "0000-00-00", "0000-00-00 00:00:00", "00:00:00", dst
    if (preg_match('/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})?(?:\.0+)?$/', $s, $m)) {
        $sec = $m[6] ?? '00';
        return "$m[1]-$m[2]-$m[3] $m[4]:$m[5]:$sec"; // "YYYYMMDDHHmm[SS]" -> "Y-m-d H:i:s"
    }
    // Kalau OpenSpout kebetulan mbaca sel ini sbg tanggal Excel native (t=date) — cellstr() di
    // progress_lane.php sudah mem-format DateTimeInterface-nya jadi "Y-m-d H:i:s" duluan sebelum
    // sampai sini, jadi itu udah format MySQL valid apa adanya, gak perlu (& gak boleh) diproses ulang.
    if (preg_match('/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}$/', $s)) return $s;
    return null; // selain semua pola di atas (mis. "0.0" sisa cast float sel kosong, teks lain yg gak
                 // dikenal) — JANGAN pernah diloloskan mentah ke kolom DATETIME (lihat komentar di atas
                 // soal bug tanggal nol yg ini cegah), aman dianggap "gak ada data" drpd salah/korup.
}

// ===============================================================================
// Bagian di bawah ini BEDA dari 2 helper di atas — dua endpoint SUNGGUHAN (ke-routing
// lewat $ROUTES di api.php, action=plane_sim_save_settings / plane_sim_upload_config)
// buat sub-menu "Pengaturan Fisik Plane": kalibrasi berapa MAX PLANE yg dipakai (24/28/
// 30/32/dst) — 1 angka INI yg jadi patokan gimana 12 slot fisik (posisi tetap, lihat
// plane-sim.js) diisi nomor plane-nya seiring waktu, PERSIS pola di tabel referensi user
// ("VERSI FISIK 12 P-LANE SPIRAL"): isi berurutan 1..MAX_PLANE nyebar di 12 kolom (A-L)
// row demi row, begitu lewat MAX_PLANE angkanya BALIK ke 1 & LANJUT ngisi (bukan reset
// tabel) — makanya kolom TERTENTU aja yg biasa dpt "01" lagi (sesuai MAX_PLANE mod 12).
// ===============================================================================

/** action=plane_sim_save_settings (POST) — simpan MAX PLANE + jumlah slot fisik manual (reuse
 * smms_meta, pola sama kayak cd_duration_sec/tow_speed di api_save_offset_settings). slot_count
 * opsional (kalau gak dikirim, gak diubah — biar endpoint ini tetap bisa dipanggil cuma buat
 * max_plane doang dari alur upload, lihat api_plane_sim_upload_config).
 * max_plane_mode opsional ('auto'|'manual') — 'auto': MAX PLANE dihitung LIVE di JS dari MROS
 * tertinggi yg lagi ada di data Progress Lane sekarang (psAutoMaxPlane(), plane-sim.js), $max yg
 * dikirim di request ini cuma snapshot buat ditampilin/fallback (mis. sblm JS sempat itung ulang
 * setelah reload) — TETAP disimpan biar smms_meta.plane_sim_max_plane gak pernah nyangkut kosong.
 * 'manual' (default kalau field ini gak dikirim, demi kompatibel install lama): angka $max murni
 * dari input operator, gak pernah dihitung ulang otomatis. */
function api_plane_sim_save_settings($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    $max = (int)($in['max_plane'] ?? 0);
    if ($max < 12 || $max > 999) fail('max_plane harus antara 12-999');
    $st = $db->prepare("REPLACE INTO smms_meta (k,v) VALUES ('plane_sim_max_plane',?)");
    $st->bind_param('s', $max); $st->execute();
    $out = ['ok'=>true,'max_plane'=>$max];
    if (array_key_exists('slot_count', $in)) {
        $slots = (int)$in['slot_count'];
        if ($slots < 9 || $slots > 12) fail('slot_count harus antara 9-12');
        $st2 = $db->prepare("REPLACE INTO smms_meta (k,v) VALUES ('plane_sim_slot_count',?)");
        $st2->bind_param('s', $slots); $st2->execute();
        $out['slot_count'] = $slots;
    }
    if (array_key_exists('max_plane_mode', $in)) {
        $mode = ($in['max_plane_mode'] === 'auto') ? 'auto' : 'manual';
        $st3 = $db->prepare("REPLACE INTO smms_meta (k,v) VALUES ('plane_sim_max_plane_mode',?)");
        $st3->bind_param('s', $mode); $st3->execute();
        $out['max_plane_mode'] = $mode;
    }
    // Jumlah baris tumpukan per kolom overview — SAMA prinsipnya dgn slot_count (angka fisik tetap,
    // bukan hasil kalkulasi data lagi — lihat komentar psOverviewRows di plane-sim.js).
    if (array_key_exists('overview_rows', $in)) {
        $rows = (int)$in['overview_rows'];
        if ($rows < 4 || $rows > 60) fail('overview_rows harus antara 4-60');
        $st4 = $db->prepare("REPLACE INTO smms_meta (k,v) VALUES ('plane_sim_overview_rows',?)");
        $st4->bind_param('s', $rows); $st4->execute();
        $out['overview_rows'] = $rows;
    }
    // Offset "waktu simulasi" (milidetik, boleh negatif) — dikonfirmasi user: kategori kosong/lagi
    // diisi/penuh (psCategoryForNumber/calculatePlaneState, plane-sim.js) BUKAN dibandingin ke jam
    // komputer beneran (Date.now()) apa adanya lagi, tapi ke "waktu simulasi" yg operator atur sendiri
    // (psSimNow() = Date.now()+offset ini) — biar bisa demo pakai data lama (mis. 21 Agustus) serasa
    // "sekarang" tanpa nunggu tanggal aslinya. Offset TETAP (bukan snapshot titik waktu absolut) supaya
    // waktu simulasi tetap MAJU ngikutin kecepatan wall-clock asli abis diset, cuma titik awalnya digeser.
    if (array_key_exists('sim_time_offset', $in)) {
        $offset = (int)$in['sim_time_offset'];
        $st5 = $db->prepare("REPLACE INTO smms_meta (k,v) VALUES ('plane_sim_time_offset',?)");
        $st5->bind_param('s', $offset); $st5->execute();
        $out['sim_time_offset'] = $offset;
    }
    // Mode "waktu simulasi" — 'aktual' (default): psSimNow() = jam beneran+offset di atas. 'simulasi':
    // psSimNow() direntang otomatis sepanjang bar countdown (cd/cdStart) dari arrival/departure paling
    // awal s/d paling akhir di Plane yg lagi aktif (dihitung LIVE di JS, lihat PS_TIME_MODE/psSimNow,
    // plane-sim.js) — field ini murni nyimpen PILIHAN mode-nya, bukan hasil hitungnya.
    if (array_key_exists('time_mode', $in)) {
        $tmode = ($in['time_mode'] === 'simulasi') ? 'simulasi' : 'aktual';
        $st6 = $db->prepare("REPLACE INTO smms_meta (k,v) VALUES ('plane_sim_time_mode',?)");
        $st6->bind_param('s', $tmode); $st6->execute();
        $out['time_mode'] = $tmode;
    }
    // Retensi Progress Lane berbasis COUNT (lihat api_upload_progress_lane, api/progress_lane.php).
    // Field ini SEBENARNYA ngatur retensi Progress Lane KESELURUHAN (bukan cuma cakupan Plane
    // Simulation, ikut mempengaruhi Monitor & tab Database juga) — ditaruh di sini krn user eksplisit
    // minta lokasi kontrolnya di modal "Pengaturan Fisik Plane".
    if (array_key_exists('retain_batches', $in)) {
        $n = (int)$in['retain_batches'];
        if ($n < 1 || $n > 30) fail('retain_batches harus antara 1-30');
        $st7 = $db->prepare("REPLACE INTO smms_meta (k,v) VALUES ('plane_sim_retain_batches',?)");
        $st7->bind_param('s', $n); $st7->execute();
        $out['retain_batches'] = $n;
    }
    out($out);
}

/** action=plane_sim_upload_config (POST, multipart file) — cara ALTERNATIF ngisi MAX PLANE:
 * upload file referensi (xlsx/csv, format bebas mirip tabel "VERSI FISIK 12 P-LANE") — nilai
 * ANGKA TERBESAR yg ketemu di seluruh sheet dianggap MAX PLANE-nya (krn scr definisi, angka
 * itu emang selalu muncul literal di tabel referensi ini apapun formatnya). */
function api_plane_sim_upload_config($db) {
    if (empty($_FILES['file'])) fail('file?');
    $tmp = $_FILES['file']['tmp_name'];
    $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
    $max = 0;
    if (in_array($ext, ['xlsx','xls'])) {
        $reader = new \OpenSpout\Reader\XLSX\Reader();
        $reader->open($tmp);
        foreach ($reader->getSheetIterator() as $sheet) {
            foreach ($sheet->getRowIterator() as $row) {
                foreach ($row->toArray() as $cell) {
                    if (is_numeric($cell)) $max = max($max, (int)$cell);
                }
            }
        }
        $reader->close();
    } else {
        $lines = file($tmp, FILE_IGNORE_NEW_LINES);
        foreach ($lines as $line) {
            foreach (preg_split('/[,;\t]/', $line) as $cell) {
                $cell = trim($cell);
                if (is_numeric($cell)) $max = max($max, (int)$cell);
            }
        }
    }
    if ($max < 12) fail('Gak ketemu angka MAX PLANE yg masuk akal (minimal 12) di file ini');
    $st = $db->prepare("REPLACE INTO smms_meta (k,v) VALUES ('plane_sim_max_plane',?)");
    $st->bind_param('s', $max); $st->execute();
    // Upload file referensi = angka TETAP dari dokumen (bukan patokan hidup dari data MROS) — paksa
    // mode balik ke 'manual' biar gak ke-timpa diam2 sama recompute otomatis (psSyncAutoMaxPlane,
    // plane-sim.js) begitu operator baru aja eksplisit ngisi dari file.
    $st2 = $db->prepare("REPLACE INTO smms_meta (k,v) VALUES ('plane_sim_max_plane_mode','manual')");
    $st2->execute();
    out(['ok'=>true,'max_plane'=>$max,'max_plane_mode'=>'manual','detected_from'=>$_FILES['file']['name']]);
}

/** action=plane_sim_save_conveyor (POST) — simpan state "konveyor" (slot aktif + generasi tiap
 * slot) ke smms_meta sbg JSON. WAJIB ada ini krn state ini sebelumnya CUMA hidup di variabel JS
 * browser (psActiveSlot/psSlotGen) — begitu halaman di-refresh atau dibuka di layar/monitor lain,
 * variabel itu ke-reset ke awal (semua balik "generasi 0"), padahal siklus aslinya udah jalan jauh
 * (bug yg dilaporkan user: "plane 3 harusnya ganti ke plane 13, bukan balik ke 1"). Dipanggil tiap
 * kali beneran ada slot yg selesai/direcycle (psAdvanceActiveSlot, plane-sim.js), fire-and-forget
 * dari sisi JS (gak nunggu respons, gak boleh bikin UI keteteran). */
function api_plane_sim_save_conveyor($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    if (!is_array($in) || !isset($in['activeSlot']) || !isset($in['slotGen'])) fail('payload?');
    $json = json_encode(['activeSlot'=>(int)$in['activeSlot'], 'slotGen'=>$in['slotGen']]);
    $st = $db->prepare("REPLACE INTO smms_meta (k,v) VALUES ('plane_sim_conveyor_state',?)");
    $st->bind_param('s', $json); $st->execute();
    out(['ok'=>true]);
}

/** action=plane_sim_bulk&dates=2026-08-24,2026-08-25 — SEMUA part utk SEMUA plane di tanggal-tanggal
 * itu sekaligus (query SAMA PERSIS dgn api_plane() di api/data.php, JOIN Master Part identik, cuma
 * tanpa filter satu plane) -- dipakai Plane Simulation buat prefetch penuh sebelum
 * psGetGlobalTimeRange() (Auto-Scaling waktu) & rentang multi-tanggal, GANTI kirim 1 request per
 * (tanggal,plane) yg bisa puluhan-ratusan kalau rentangnya lebar. Return: {"2026-08-24|05":
 * {routes...}, "2026-08-24|06": ..., ...} -- key SAMA formatnya dgn PS_PCACHE di frontend
 * (date+"|"+plane) biar tinggal di-merge langsung, gak perlu diolah ulang. */
function api_plane_sim_bulk($db) {
    $dates = array_filter(array_map('trim', explode(',', $_GET['dates'] ?? '')));
    if (!$dates) out(['data'=>(object)[]]);
    $out = [];
    foreach ($dates as $date) {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) continue;
        $batch = current_parts_batch($db, $date);
        $st = $db->prepare("
            SELECT sp.plane, sp.route, sp.part_no, sp.part_name, sp.kanban, sp.qty, sp.lot, sp.addr, sp.supplier, sp.uniq_no, sp.order_no,
                   COALESCE(mp.volume_box,0) AS volume_box, COALESCE(mp.status,'Direct') AS status,
                   COALESCE((
                     SELECT mp2.supplier_name FROM smms_master_part mp2
                     WHERE mp2.supplier_code=sp.supplier_code AND mp2.supplier_plant_code=sp.supplier_plant
                       AND mp2.shipping_dock=sp.supplier_dock AND mp2.route=sp.route
                     LIMIT 1
                   ), sp.supplier) AS vlookup_supplier,
                   sp.supplier_code, sp.supplier_plant, sp.supplier_dock, COALESCE(mp.dock_code,'') AS dock_code,
                   sp.sub_route_code, sp.cd_arrival_at, sp.cd_departure_at
            FROM smms_progress_lane sp
            LEFT JOIN smms_master_part mp ON mp.part_no = sp.part_no
            WHERE sp.batch_id=? ORDER BY sp.plane, sp.route, sp.id
        ");
        $st->bind_param('i', $batch); $st->execute();
        $res = $st->get_result();
        while ($r = $res->fetch_row()) {
            $pl = array_shift($r); $rt = array_shift($r);
            $out["$date|$pl"][$rt][] = $r;
        }
    }
    out(['data'=>(object)$out]);
}

if ($act === 'plane_sim_save_settings' && $_SERVER['REQUEST_METHOD']==='POST') api_plane_sim_save_settings($db);
if ($act === 'plane_sim_upload_config' && $_SERVER['REQUEST_METHOD']==='POST') api_plane_sim_upload_config($db);
if ($act === 'plane_sim_save_conveyor' && $_SERVER['REQUEST_METHOD']==='POST') api_plane_sim_save_conveyor($db);
if ($act === 'plane_sim_bulk') api_plane_sim_bulk($db);
