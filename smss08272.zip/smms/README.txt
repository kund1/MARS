=====================================================
SMMS - Supply Mapping Monitoring System (Localhost)
=====================================================

CARA INSTALL (XAMPP):
1. Copy folder "smms" ini ke  c:\xampp\htdocs\
   sehingga menjadi        c:\xampp\htdocs\smms\
2. Nyalakan Apache + MySQL di XAMPP Control Panel.
3. Buka sekali:  http://localhost/smms/install.php
   -> membuat database "smms", semua tabel, dan mengisi:
      - mapping countdown (Pembagian Halte Supply)
      - master halte (stratifikasi 20 April 2026)
      - 16.286 part dari upload_progress_lane20260720.xlsx (Dock 43)
4. Buka aplikasi:  http://localhost/smms/

STRUKTUR DATABASE (MySQL "smms"):
  smms_progress_lane        -> part per plane/route (dari upload progress lane)
  smms_racks        -> posisi rack di denah (dipasang via Editor)
  smms_route_path   -> titik jalur towing per route (digambar via Editor)
  smms_cd_mapping   -> range countdown -> halte (editable di tab Database)
  smms_halte_master -> referensi halte per route (editable)
  smms_meta         -> info sumber data terakhir

UPLOAD PROGRESS LANE:
  Tab "UPLOAD PROGRESS LANE" menerima file xlsx asli PICS.
  - Hanya baris Dock 43 yang diambil, route valid A-Q.
  - Parser server-side tanpa PhpSpreadsheet (ringan, aman utk file besar).
  - Isi tabel smms_progress_lane diganti penuh setiap upload.

KONEKSI COUNTER IIS (opsional, nanti):
  Edit config.php -> isi COUNTER_API dengan URL endpoint counter dari IIS
  (mis. http://SERVER-IIS/iis/api/counter.php yang mengembalikan JSON
  {order_no, plane, cd, line_off}). Selama kosong, counter berjalan
  mode manual/AUTO simulasi dari header aplikasi.

CATATAN:
  - Ganti kredensial DB di config.php bila MySQL memakai password.
  - Aplikasi ini untuk jaringan internal; belum ada login.
