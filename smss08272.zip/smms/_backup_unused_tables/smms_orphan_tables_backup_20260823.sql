-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: smms
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `smms_cd_override`
--

DROP TABLE IF EXISTS `smms_cd_override`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smms_cd_override` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(20) DEFAULT NULL,
  `plane` char(3) DEFAULT NULL,
  `cd_value` int(11) NOT NULL,
  `line_off` varchar(20) DEFAULT NULL,
  `next_plane` varchar(10) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smms_cd_override`
--

LOCK TABLES `smms_cd_override` WRITE;
/*!40000 ALTER TABLE `smms_cd_override` DISABLE KEYS */;
/*!40000 ALTER TABLE `smms_cd_override` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smms_halte`
--

DROP TABLE IF EXISTS `smms_halte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smms_halte` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `halte_no` tinyint(4) NOT NULL,
  `rack_address` varchar(20) DEFAULT NULL,
  `rack_name` varchar(50) DEFAULT NULL,
  `x` decimal(8,3) NOT NULL,
  `y` decimal(8,3) NOT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_route_halte` (`route_id`,`halte_no`),
  CONSTRAINT `smms_halte_ibfk_1` FOREIGN KEY (`route_id`) REFERENCES `smms_route` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smms_halte`
--

LOCK TABLES `smms_halte` WRITE;
/*!40000 ALTER TABLE `smms_halte` DISABLE KEYS */;
INSERT INTO `smms_halte` VALUES (1,1,1,'SIP1R-I16','Rack A1',11.000,79.000,'system','2026-07-20 05:43:51'),(2,1,2,'JDT1-T150','Rack A2',39.000,79.000,'system','2026-07-20 05:43:51'),(3,1,3,'SPC1-R07','Rack A3',69.000,49.000,'system','2026-07-20 05:43:51'),(4,2,1,'SIP1R-I16','Rack A1',11.000,79.000,'system','2026-07-20 05:43:51'),(5,2,2,'JDT1-T150','Rack A2',39.000,79.000,'system','2026-07-20 05:43:51'),(6,2,3,'SPC1-R07','Rack A3',69.000,49.000,'system','2026-07-20 05:43:51'),(7,3,1,'SIP1R-I16','Rack A1',11.000,79.000,'system','2026-07-20 05:43:51'),(8,3,2,'JDT1-T150','Rack A2',39.000,79.000,'system','2026-07-20 05:43:51'),(9,3,3,'SPC1-R07','Rack A3',69.000,49.000,'system','2026-07-20 05:43:51');
/*!40000 ALTER TABLE `smms_halte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smms_layout`
--

DROP TABLE IF EXISTS `smms_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smms_layout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `image_w` int(11) DEFAULT NULL,
  `image_h` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `uploaded_by` varchar(50) DEFAULT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smms_layout`
--

LOCK TABLES `smms_layout` WRITE;
/*!40000 ALTER TABLE `smms_layout` DISABLE KEYS */;
INSERT INTO `smms_layout` VALUES (1,'Denah Assy Plant 1','https://via.placeholder.com/1200x720.png?text=Layout+Assy+Plant+1',1200,720,1,'system','2026-07-20 05:43:51');
/*!40000 ALTER TABLE `smms_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smms_position_log`
--

DROP TABLE IF EXISTS `smms_position_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smms_position_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `order_no` char(10) DEFAULT NULL,
  `cd_value` int(11) NOT NULL,
  `halte_no` tinyint(4) DEFAULT NULL,
  `logged_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `route_id` (`route_id`),
  CONSTRAINT `smms_position_log_ibfk_1` FOREIGN KEY (`route_id`) REFERENCES `smms_route` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smms_position_log`
--

LOCK TABLES `smms_position_log` WRITE;
/*!40000 ALTER TABLE `smms_position_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `smms_position_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smms_route`
--

DROP TABLE IF EXISTS `smms_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smms_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_code` char(2) NOT NULL,
  `plane` char(3) DEFAULT NULL,
  `zone` enum('WEST','EAST') NOT NULL DEFAULT 'WEST',
  `color` char(7) DEFAULT '#007bff',
  `towing_id` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `updated_by` varchar(50) DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_route_code` (`route_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smms_route`
--

LOCK TABLES `smms_route` WRITE;
/*!40000 ALTER TABLE `smms_route` DISABLE KEYS */;
INSERT INTO `smms_route` VALUES (1,'A','24','WEST','#2563eb','TOW-A',1,'system','2026-07-20 05:43:51'),(2,'B','20','WEST','#f97316','TOW-B',1,'system','2026-07-20 05:43:51'),(3,'C','17','EAST','#dc2626','TOW-C',1,'system','2026-07-20 05:43:51');
/*!40000 ALTER TABLE `smms_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smms_route_parts`
--

DROP TABLE IF EXISTS `smms_route_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smms_route_parts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `dock` char(2) DEFAULT NULL,
  `part_no` varchar(20) NOT NULL,
  `part_name` varchar(255) DEFAULT NULL,
  `kanban_no` varchar(10) DEFAULT NULL,
  `qty_box` int(11) DEFAULT 0,
  `order_lot` int(11) DEFAULT 0,
  `supplier_code` varchar(10) DEFAULT NULL,
  `supplier_name` varchar(255) DEFAULT NULL,
  `address` varchar(20) DEFAULT NULL,
  `conveyance` varchar(10) DEFAULT NULL,
  `phase_month` char(7) DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `create_date` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_route_part_unique` (`route_id`,`part_no`,`kanban_no`,`address`,`phase_month`),
  CONSTRAINT `smms_route_parts_ibfk_1` FOREIGN KEY (`route_id`) REFERENCES `smms_route` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smms_route_parts`
--

LOCK TABLES `smms_route_parts` WRITE;
/*!40000 ALTER TABLE `smms_route_parts` DISABLE KEYS */;
INSERT INTO `smms_route_parts` VALUES (1,1,'A1','P-100','Bracket Plate','K001',4,1,'S1','PT Supplier','SIP1R-I16','K388','2026-07','system','2026-07-20 05:43:51'),(2,2,'B1','P-200','Cover Sheet','K002',3,1,'S2','PT Supplier B','JDT1-T150','K388','2026-07','system','2026-07-20 05:43:51'),(3,3,'C1','P-300','Guide Rail','K003',2,1,'S3','PT Supplier C','SPC1-R07','K388','2026-07','system','2026-07-20 05:43:51');
/*!40000 ALTER TABLE `smms_route_parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smss_master_part`
--

DROP TABLE IF EXISTS `smss_master_part`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smss_master_part` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dock_code` enum('43') NOT NULL,
  `supplier_code` char(4) NOT NULL,
  `supplier_plant` char(1) NOT NULL,
  `shipping_dock` varchar(10) DEFAULT NULL,
  `ssc_code` varchar(30) DEFAULT NULL,
  `part_no` char(12) NOT NULL,
  `kanban_no` char(4) NOT NULL,
  `vol_box` int(11) DEFAULT NULL,
  `supplier_name` varchar(100) DEFAULT NULL,
  `part_name` varchar(150) DEFAULT NULL,
  `volume_box` decimal(10,8) DEFAULT NULL,
  `conveyance` varchar(10) DEFAULT NULL,
  `status` enum('direct','sorting','unpacking murni') NOT NULL,
  `status_2` enum('direct','sorting','unpacking murni') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smss_master_part`
--

LOCK TABLES `smss_master_part` WRITE;
/*!40000 ALTER TABLE `smss_master_part` DISABLE KEYS */;
/*!40000 ALTER TABLE `smss_master_part` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-23 16:17:31
