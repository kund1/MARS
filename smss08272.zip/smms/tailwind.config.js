/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./index.php", "./assets/js/**/*.js"],
  // Preflight (reset CSS bawaan Tailwind) DIMATIKAN sengaja -- app.css yang sudah ada dibangun
  // tanpa asumsi ada reset modern jalan duluan (banyak style default tabel/tombol/modal dst
  // yang mengandalkan default browser), jadi Tailwind di sini cuma nambahin utility class baru,
  // gak nimpa/reset apa pun yang udah ada.
  corePlugins: { preflight: false },
  // WAJIB pakai prefix: app.css yang sudah ada punya banyak nama class generik satu-kata
  // (.grid, .active, .hl, .on, dst) yang PERSIS sama kayak nama utility bawaan Tailwind (mis.
  // ".grid{display:grid}" bakal nabrak "table.grid" punya app.css) -- tanpa prefix, class Tailwind
  // yang ke-generate bisa diam-diam nimpa/nabrak style lama yang udah jalan. Jadi tiap utility baru
  // dipakai sebagai tw-grid, tw-flex, dst, gak pernah bentrok sama nama class apa pun yang udah ada.
  prefix: "tw-",
  theme: { extend: {} },
  plugins: [],
};
