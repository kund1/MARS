# ================================================================
# BOT ANDON — Ambil countdown Andon PER ROUTE dari sistem IIS (WordPress) yang SUDAH
# mengolah datanya sendiri, BUKAN dari PICS langsung. Disimpan ke tabel smms_andon_countdown.
# ================================================================
# Sumbernya: database MySQL lokal `project_iis`, tabel wp_app_offset + wp_app_t_progress_counter
# (dipakai juga oleh c:\xampp\htdocs\iis\counter.php buat COUNTER_API SMMS). Query di bawah ini
# adalah versi ringkas dari sse_get_andon_baton_pass() di
# iis/wp-content/themes/generatepress_child/inc/app.php (baris ~1612) — logic ASLI yang dipakai
# tab "Andon Baton Pass" di sistem IIS buat ngitung "route ini tinggal berapa countdown lagi".
#
# INSTALL DULU (kalau belum ada): pip install mysql-connector-python

import time
from datetime import datetime
import mysql.connector

IIS_MYSQL_CONFIG  = dict(host="localhost", user="root", password="", database="project_iis")
SMMS_MYSQL_CONFIG = dict(host="localhost", user="root", password="", database="smms")

DOCK = "43"
ZONES = ["WEST", "EAST"]

POLL_INTERVAL_SECONDS = 5  # andon sifatnya real-time, jadi narik tiap beberapa detik aja


def kirim_alert_gagal(pesan_error):
    waktu = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    pesan = f"[{waktu}] 🚨 ALERT ANDON: {pesan_error}"
    print(pesan)
    with open("error_log.txt", "a") as f:
        f.write(pesan + "\n")


def ambil_volume_order_aktif(cur):
    """Order_no & volume (jumlah kendaraan) yang lagi jalan sekarang — sama logic app_get_pics(43)
    + $sql_volume di sse_get_andon_baton_pass(). Balikin (None, None) kalau data belum ada/stale total."""
    cur.execute("""
        SELECT order_no FROM wp_app_t_progress_counter
        WHERE counter_no = 1 ORDER BY update_date DESC LIMIT 1
    """)
    row = cur.fetchone()
    if not row:
        return None, None
    order_no = row[0]

    cur.execute("""
        SELECT number_of_vehicles FROM wp_app_w_progress_unload_extraction_ready
        WHERE receiving_dock_code = %s AND order_no = %s
    """, (DOCK, order_no))
    row = cur.fetchone()
    volume = row[0] if row else None
    return order_no, volume


def ambil_countdown_per_zone(cur, zone, volume):
    """Countdown SUPPLY per route di 1 zone (WEST/EAST) — versi ringkas sql_all_route di
    sse_get_andon_baton_pass(), cuma ambil kolom route + current_count_down (gak perlu next_mros/
    scw_id/description kayak versi UI aslinya, di sini cuma butuh angka countdown-nya aja)."""
    if volume is None:
        return []  # sama kayak versi PHP: volume NULL -> WHERE volume=NULL -> gak match apa-apa
    cur.execute("""
        SELECT a.route AS route, b.current_count_down AS current_count_down
        FROM wp_app_offset a
        LEFT JOIN (
            SELECT
                IF(@comp=counter_no, @i:=@i+1, @i:=0) counter_offset,
                @comp:=counter_no,
                counter_value AS current_count_down,
                order_no AS current_order_no
            FROM wp_app_t_progress_counter, (SELECT @i:=0, @comp:=0) X
            WHERE counter_no = 1 AND number_of_line_off <> 0
            ORDER BY update_date DESC
        ) b ON a.offset = b.counter_offset
        WHERE a.volume = %s AND a.dock = %s AND a.process = 'SUPPLY' AND a.zone = %s
        GROUP BY a.route
        ORDER BY b.current_order_no, b.current_count_down ASC
    """, (volume, DOCK, zone))
    return cur.fetchall()  # [(route, current_count_down), ...]


def sinkron_andon_countdown():
    try:
        iis = mysql.connector.connect(**IIS_MYSQL_CONFIG)
        cur = iis.cursor()

        order_no, volume = ambil_volume_order_aktif(cur)
        hasil = []
        for zone in ZONES:
            hasil += ambil_countdown_per_zone(cur, zone, volume)
        cur.close()
        iis.close()

        if not hasil:
            return  # gak ada data (mis. IIS lagi stale) — skip diem-diem, jangan spam alert tiap siklus

        waktu = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        data = [(str(route).strip(), int(cd), waktu) for route, cd in hasil if route]

        smms = mysql.connector.connect(**SMMS_MYSQL_CONFIG)
        cursor = smms.cursor()
        cursor.executemany(
            """INSERT INTO smms_andon_countdown (route, countdown_value, updated_at)
               VALUES (%s, %s, %s)
               ON DUPLICATE KEY UPDATE countdown_value=VALUES(countdown_value), updated_at=VALUES(updated_at)""",
            data
        )
        smms.commit()
        cursor.close()
        smms.close()
        print(f"[{waktu}] OK — order {order_no}, {len(data)} route ke-update.")
    except Exception as e:
        kirim_alert_gagal(str(e))


if __name__ == "__main__":
    print("==================================================")
    print("🤖 BOT ANDON COUNTDOWN AKTIF (sumber: IIS/project_iis, bukan PICS langsung)")
    print(f"Narik data tiap {POLL_INTERVAL_SECONDS} detik...")
    print("Tekan Ctrl+C buat berhenti.")
    print("==================================================")
    while True:
        sinkron_andon_countdown()
        time.sleep(POLL_INTERVAL_SECONDS)
