import os
import pandas as pd
from datetime import datetime, timedelta

# 1. Path folder OneDrive lu (Udah di-update dengan path asli)
folder_path = r"C:\Users\HYPE AMD\TMMIN\DIRECTORATE MANUFACTURING - 2026\08. Aug 2026"

# 2. Logic H+1
hari_ini = datetime.now()
besok = hari_ini + timedelta(days=1)
format_tanggal_besok = besok.strftime("%Y%m%d") # Outputnya bakal jadi "20260804"

# Susun nama file target sesuai format di folder lu
nama_file_target = f"Order by Receiving {format_tanggal_besok}.xlsx"
target_file_path = os.path.join(folder_path, nama_file_target)

print("========================================")
print(f"Tanggal Hari Ini : {hari_ini.strftime('%Y-%m-%d')}")
print(f"Mencari File H+1 : {nama_file_target}")
print("========================================\n")

try:
    # 3. Cek spesifik apakah file target H+1 itu ada di folder
    if not os.path.exists(target_file_path):
        print(f"Waduh, file '{nama_file_target}' belum ada di folder OneDrive lu!")
        print("Mungkin sistem dari sananya belum generate file untuk besok.")
    else:
        print(f"File H+1 ditemukan! Mulai membaca data...")

        # 4. Baca pakai Pandas
        df = pd.read_excel(target_file_path, engine='openpyxl')
        
        # Normalisasi nama kolom
        df.columns = df.columns.astype(str).str.lower().str.strip()
        
        # 5. Filter Data Dock 43
        if 'dock' in df.columns:
            df_filtered = df[df['dock'].astype(str).str.strip() == '43']
            
            print("\n=== HASIL FILTER DOCK 43 ===")
            print(f"Total baris awal di Excel : {len(df)}")
            print(f"Total baris (Dock 43)     : {len(df_filtered)}")
            
            print("\nPreview 5 Data Pertama:")
            cols_to_show = [col for col in ['part no', 'parts name', 'dock', 'conveyance route'] if col in df.columns]
            print(df_filtered[cols_to_show].head())
        else:
            print("Error: Kolom 'dock' nggak ketemu di Excel!")

except FileNotFoundError:
    print("Folder OneDrive tidak ditemukan! Cek path foldernya.")
except Exception as e:
    print(f"Ada error sistem: {e}")