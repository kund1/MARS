/* =====================================================================
   EDITOR/EDITOR.JS — tab Editor: mode toolbar (geser/rack/jalur/shape/hapus),
   tambah/sisip/hapus titik jalur, shape kotak vector (background peta bersih),
   tandai halte/stage. SEMUA berkas fitur Editor disatukan di 1 folder editor/:
   editor.js (ini), view.php, api.php — biar gampang dirawat dari 1 tempat
   (pola sama persis dgn plane-sim/, lihat komentar header plane-sim.js).
   Tetap di-load di posisi urutan yg SAMA (sesudah 04-viewport.js, sebelum
   06-render.js) di <script> index.php — dipakai bareng banyak global dari
   file assets/js/01..04 (CFG, editing, mode, stageXY, dst) & disambung balik
   oleh 06-render.js (redrawAll baca shSelected dari sini) & 10-database.js
   (rkSelected, rkUpdateButtons). ===================================================================== */
const modeBtns=document.querySelectorAll("#toolbar .tmode");
modeBtns.forEach(b=>b.onclick=()=>{
  modeBtns.forEach(x=>x.classList.remove("on")); b.classList.add("on"); mode=b.dataset.m;
  vp.classList.toggle("adding",mode!=="pan"); selectedPtIdx=null; ptSelected.clear();
  // Freshest-mungkin data picker pas operator BENERAN mau pakainya (jaga2 baris config baru ditambah
  // di Setting sejak Editor dibuka terakhir kali, lihat juga navEdit.onclick, 09-nav.js).
  if(mode==="sortingarea") editorRefreshSortingAreas();
  else if(mode==="dollysupply") editorRefreshDollySupplies();
  redrawAll();
});
const editRouteSel=document.getElementById("editRouteSel");
/** Isi ulang pilihan route di Editor: route fisik A-Z (ALLR) + route khusus (C/U, Unpacking, dst)
 * yang ketemu di Master Offset (ROUTE_ZONE) tapi bukan bagian ALLR — supaya bisa digambar jalur/titik
 * stage-nya sendiri di map. Route khusus ini SEKARANG juga bisa jadi kolom Pattern Unload (lihat
 * allKnownRoutes/zoneOf, 01-state.js — GANTI batasan lama "itu tetap cuma ALLR"). */
function editorRefreshRoutes(){
  const routes=allKnownRoutes();
  const prev=editRouteSel.value;
  editRouteSel.innerHTML="";
  routes.forEach(r=>{const o=document.createElement("option");o.value=o.textContent=r;editRouteSel.appendChild(o);});
  if(routes.includes(prev)) editRouteSel.value=prev;
}
editorRefreshRoutes();
editRouteSel.onchange=()=>{editRoute=editRouteSel.value; selRoute=editRoute; selectedPtIdx=null; ptSelected.clear(); redrawAll(); };
const dl=document.getElementById("addrlist");

/* ---- Picker "+ Sorting Area" / "+ Dolly Supply" — dua shape BARU (kind:'sortingarea'/'dollysupply',
   smms_shapes) yg identity-nya (Route, dst) diambil dari baris CONFIG yg sudah dibuat di menu Setting
   (smms_sorting_area/smms_dolly_supply, lihat assets/js/18-sorting-plane.js & 20-dolly-supply.js) --
   BUKAN diketik bebas di sini. 1 baris config = maksimal 1 shape (mirip "Plane Buffer" yg maks 1 shape
   di seluruh denah, tapi di sini per-baris-config, bukan global) -- picker cuma nawarin baris yg BELUM
   punya shape, biar operator gak nempatin 1 baris config dobel jadi 2 shape berbeda.
   (kind='sortingarea' GANTIKAN 'sortingplane' total, koreksi arsitektur 2026-08-27 -- Sorting Area py
   Rows/Columns, bukan Plane Capacity 1/2.) ---- */
let SORTING_AREA_ROWS=[], DOLLY_SUPPLY_ROWS=[];
async function editorRefreshSortingAreas(){
  const d=await apiGet('action=sorting_area_list').catch(()=>({rows:[]}));
  SORTING_AREA_ROWS=d.rows||[];
  editorRebuildSortingAreaSelect();
}
async function editorRefreshDollySupplies(){
  const d=await apiGet('action=dolly_supply_list').catch(()=>({rows:[]}));
  DOLLY_SUPPLY_ROWS=d.rows||[];
  editorRebuildDollySupplySelect();
}
/** Isi ulang <select id="edSortingAreaSel"> -- SYNC, tanpa fetch (dipanggil ulang tiap CFG.shapes
 * berubah terkait shape ini: sesudah add baru, sesudah hapus, sesudah undo/redo). Cuma tampilkan baris
 * config yg id-nya BELUM dipakai shape manapun di CFG.shapes (sortingAreaId). */
function editorRebuildSortingAreaSelect(){
  const sel=document.getElementById("edSortingAreaSel");
  if(!sel) return;
  const used=new Set(CFG.shapes.filter(s=>s.kind==="sortingarea").map(s=>s.sortingAreaId));
  const avail=SORTING_AREA_ROWS.filter(r=>!used.has(+r.id));
  const prev=sel.value;
  sel.innerHTML=avail.map(r=>`<option value="${r.id}">${r.sorting_code} — Route ${r.route} (${r.row_count}×${r.column_count})</option>`).join("");
  if(avail.some(r=>String(r.id)===prev)) sel.value=prev;
}
function editorRebuildDollySupplySelect(){
  const sel=document.getElementById("edDollySupplySel");
  if(!sel) return;
  const used=new Set(CFG.shapes.filter(s=>s.kind==="dollysupply").map(s=>s.dollySupplyId));
  const avail=DOLLY_SUPPLY_ROWS.filter(r=>!used.has(+r.id));
  const prev=sel.value;
  sel.innerHTML=avail.map(r=>`<option value="${r.id}">Dolly ${r.dolly_supply_num} — Route ${r.route}</option>`).join("");
  if(avail.some(r=>String(r.id)===prev)) sel.value=prev;
}
editorRefreshSortingAreas();
editorRefreshDollySupplies();

/** Isi ulang datalist alamat rack (dari daftar address yang pernah muncul di data part) — address
 * yang RACK-nya udah ditempatkan di denah dikosongkan dari pilihan (gak bisa ditambah dobel lagi,
 * lihat juga guard-nya di klik "+ Rack" bawah). Dipanggil ulang tiap CFG.racks berubah (add/edit/hapus). */
function buildAddrList(){
  dl.innerHTML="";
  const used=new Set(CFG.racks.map(r=>r.addr));
  ADDRESSES.filter(a=>!used.has(a)).forEach(a=>{const o=document.createElement("option");o.value=a;dl.appendChild(o);});
}

let selectedPtIdx=null; // titik jalur (route=editRoute) yang sedang dipilih untuk ditandai sebagai halte

/* ---- Undo/Redo (Ctrl+Z / Ctrl+Y) — 3 langkah, khusus mutasi CFG.racks/CFG.paths/CFG.shapes dari tab
   Editor (tambah/geser/hapus rack & titik jalur, shape kotak, tandai halte/stage, Align X/Y). Snapshot
   diambil SEBELUM tiap mutasi, jadi undo balikin ke keadaan tepat sebelum aksi itu; drag digrup jadi 1
   langkah lewat dragSnapshot di 04-viewport.js (bukan snapshot per-frame mousemove). ---- */
let undoStack=[], redoStack=[];
const HISTORY_MAX=3;
function snapshotCfg(){ return JSON.stringify({racks:CFG.racks,paths:CFG.paths,shapes:CFG.shapes}); }
function pushHistory(snap){ undoStack.push(snap); if(undoStack.length>HISTORY_MAX)undoStack.shift(); redoStack.length=0; }
async function applyHistorySnap(snap){
  const s=JSON.parse(snap); CFG.racks=s.racks; CFG.paths=s.paths; CFG.shapes=s.shapes||[];
  rkSelected.clear(); ptSelected.clear(); selectedPtIdx=null; shSelected.clear(); updateShapePanel();
  await saveCfg(); redrawAll(); buildAddrList();
  editorRebuildSortingAreaSelect(); editorRebuildDollySupplySelect();
}
async function doUndo(){
  if(!undoStack.length){ toast("Tidak ada yang bisa di-undo"); return; }
  const cur=snapshotCfg(); const prev=undoStack.pop();
  redoStack.push(cur); if(redoStack.length>HISTORY_MAX)redoStack.shift();
  await applyHistorySnap(prev); toast(`Undo · ${undoStack.length} langkah tersisa`);
}
async function doRedo(){
  if(!redoStack.length){ toast("Tidak ada yang bisa di-redo"); return; }
  const cur=snapshotCfg(); const next=redoStack.pop();
  undoStack.push(cur); if(undoStack.length>HISTORY_MAX)undoStack.shift();
  await applyHistorySnap(next); toast(`Redo · ${redoStack.length} langkah tersisa`);
}
document.addEventListener("keydown",e=>{
  if(!editing) return;
  const tag=(e.target.tagName||"").toLowerCase();
  if(tag==="input"||tag==="textarea"||tag==="select"||e.target.isContentEditable) return;
  if(!(e.ctrlKey||e.metaKey)) return;
  const k=e.key.toLowerCase();
  if(k==="z"){ e.preventDefault(); doUndo(); }
  else if(k==="y"){ e.preventDefault(); doRedo(); }
});

// Multi-seleksi titik JALUR (mode Geser, shift+klik) — key-nya "route|index", PARALEL sama rkSelected
// (rack, di 10-database.js). Sengaja Set TERPISAH (bukan digabung ke rkSelected) krn rack diindeks
// per-CFG.racks sedangkan titik jalur diindeks per-route — tapi keduanya bisa DICAMPUR jadi 1 grup
// yg digeser bareng sekaligus (lihat mousemove di 04-viewport.js), gak saling menghapus seleksi lain.
let ptSelected=new Set();

// Seleksi shape (mode Geser) — Set berisi 1 index CFG.shapes (BUKAN multi-select kayak rack/titik
// jalur, cukup 1 shape aja yg bisa di-resize/rotate/atur warna-teks sekaligus lewat panel properti
// toolbar, lihat updateShapePanel). Namespace TERPISAH dari rkSelected/ptSelected (data-shape, bukan
// data-drag, lihat redrawAll 06-render.js) — milih shape otomatis lepas seleksi rack/titik jalur & sebaliknya.
let shSelected=new Set();

/** Tampilkan/isi panel properti shape (#shapePanel, editor/view.php) HANYA kalau tepat 1 shape
 * terpilih — sebaliknya sembunyikan. Dipanggil tiap seleksi shape berubah (klik pilih/lepas, Undo/Redo, hapus). */
function updateShapePanel(){
  const panel=document.getElementById("shapePanel");
  if(!panel) return;
  const idx=[...shSelected][0];
  const s=idx!==undefined?CFG.shapes[idx]:null;
  if(!s){ panel.style.display="none"; return; }
  panel.style.display="";
  document.getElementById("shFill").value=s.fill||"#E2E8F0";
  document.getElementById("shStroke").value=s.stroke||"#475569";
  document.getElementById("shText").value=s.text||"";
}
/** Tulis 1 properti shape yg lagi terpilih ke CFG lalu render+simpan — dipakai input warna/teks &
 * tombol lurusin cepat 0/90/180/270 (panel properti). pushHistory 1x per "sesi edit" (bukan tiap
 * keystroke input teks) biar Undo gak kepecah jadi puluhan langkah cuma gara2 ngetik 1 kata. */
let shPropSnapshot=null;
function shSetProp(mutate){
  const idx=[...shSelected][0]; const s=idx!==undefined?CFG.shapes[idx]:null;
  if(!s) return;
  if(!shPropSnapshot) shPropSnapshot=snapshotCfg();
  mutate(s);
  redrawAll();
}
function shCommitProp(){ if(shPropSnapshot){ pushHistory(shPropSnapshot); shPropSnapshot=null; saveCfg(); } }
document.getElementById("shFill")?.addEventListener("input",()=>shSetProp(s=>s.fill=document.getElementById("shFill").value));
document.getElementById("shFill")?.addEventListener("change",shCommitProp);
document.getElementById("shStroke")?.addEventListener("input",()=>shSetProp(s=>s.stroke=document.getElementById("shStroke").value));
document.getElementById("shStroke")?.addEventListener("change",shCommitProp);
document.getElementById("shText")?.addEventListener("input",()=>shSetProp(s=>s.text=document.getElementById("shText").value));
document.getElementById("shText")?.addEventListener("change",shCommitProp);
[0,90,180,270].forEach(deg=>{
  document.getElementById("shRot"+deg)?.addEventListener("click",()=>{
    shSetProp(s=>s.rot=deg); shCommitProp();
  });
});

/** Slider "Denah asli" (opacity #layoutimg) — MURNI pratinjau client-side, TIDAK dipersist ke server
 * (dikonfirmasi cukup: reload balik ke 100% default) — buat coba lihat hasil "peta bersih" (shape
 * doang, gambar raster memudar/hilang) sebelum beneran diputuskan mau didim permanen atau enggak. */
document.getElementById("layoutOpacity")?.addEventListener("input",e=>{
  const img=document.getElementById("layoutimg");
  if(img) img.style.opacity=(+e.target.value/100);
});

/**
 * Cari segmen jalur (antara 2 titik berurutan) yang paling dekat dgn klik; kalau dalam toleransi,
 * kembalikan index tempat nyisip titik baru DI ANTARA keduanya (bukan cuma nambah di ujung akhir).
 */
function nearestSegmentInsert(path,x,y,maxDist){
  let best=-1, bestDist=maxDist;
  for(let i=0;i<path.length-1;i++){
    const a=path[i], b=path[i+1];
    const dx=b.x-a.x, dy=b.y-a.y;
    const len2=dx*dx+dy*dy;
    let t = len2 ? ((x-a.x)*dx+(y-a.y)*dy)/len2 : 0;
    t = Math.max(0, Math.min(1, t));
    const d = Math.hypot(x-(a.x+dx*t), y-(a.y+dy*t));
    if(d<bestDist){ bestDist=d; best=i+1; }
  }
  return best;
}

// Klik di kanvas saat Editor aktif: tambah rack / shape / tambah-sisip titik jalur / hapus, tergantung mode toolbar.
vp.addEventListener("click",e=>{
  if(!editing||moved)return;
  const p=stageXY(e);
  if(mode==="rack"){
    const addr=document.getElementById("addrInput").value.trim();
    if(!addr){toast("Isi address rack dulu (mis. FNL2-K117)");return;}
    // Rack yg address-nya udah ada di denah gak boleh ditambah lagi (cegah duplikat) — kalau memang
    // mau dipindah posisinya, geser aja yg sudah ada (mode Geser), bukan nambah baru.
    if(CFG.racks.some(r=>r.addr===addr)){ toast(`Rack "${addr}" sudah ada di denah — gak bisa ditambah lagi, geser aja yg sudah ada`); return; }
    pushHistory(snapshotCfg());
    CFG.racks.push({addr,x:p.x,y:p.y}); saveCfg(); redrawAll(); buildAddrList();
  }else if(mode==="shape"){
    // Tambah 1 shape kotak baru, klik = TITIK TENGAHnya (bukan pojok kiri-atas, lebih intuitif — mirip
    // "+ Rack" yg juga nempatin di titik klik) — dikonfirmasi user: background vector gaya PPT/Google
    // Maps, digambar manual nelusurin garis besar bangunan di atas denah asli.
    pushHistory(snapshotCfg());
    CFG.shapes.push({x:p.x-40,y:p.y-30,w:80,h:60,rot:0,fill:"#E2E8F0",stroke:"#475569",text:""});
    shSelected=new Set([CFG.shapes.length-1]);
    rkSelected.clear(); ptSelected.clear();
    saveCfg(); redrawAll(); updateShapePanel();
  }else if(mode==="planebuffer"){
    // Area "Plane Buffer" — SATU-satunya shape khusus (kind:'planebuffer') yg nampilin isi buffer
    // plane AKTIF beneran (skid, dari PLANEDATA milik Monitor — lihat redrawAll, 06-render.js), bukan
    // kotak polos. Cuma boleh 1 di seluruh denah (dikonfirmasi user: ini representasi 1 area fisik
    // nyata) — klik ulang tombol ini kalau sudah ada CUMA milih yg sudah ada (gak nambah baru lagi),
    // biar operator gampang balik nemuin & geser/atur ulang tanpa nyariin manual di mode Geser.
    // Default rot=90 & lebih lebar dari shape polos (dikonfirmasi user: "in" di kiri, "out" ke dolly
    // di kanan — lihat komentar render kind==='planebuffer').
    const existingIdx=CFG.shapes.findIndex(s=>s.kind==="planebuffer");
    if(existingIdx>=0){
      shSelected=new Set([existingIdx]);
      rkSelected.clear(); ptSelected.clear();
      redrawAll(); updateShapePanel();
      toast("Area Plane Buffer sudah ada — dipilih, geser/resize/rotate lewat mode Geser");
    }else{
      pushHistory(snapshotCfg());
      CFG.shapes.push({x:p.x-120,y:p.y-60,w:240,h:120,rot:90,fill:"#E0F2FE",stroke:"#0369A1",text:"",kind:"planebuffer"});
      shSelected=new Set([CFG.shapes.length-1]);
      rkSelected.clear(); ptSelected.clear();
      saveCfg(); redrawAll(); updateShapePanel();
    }
  }else if(mode==="sortingarea"){
    // Shape "Sorting Area" — identity (Route/Rows/Columns dkk) diambil dari baris smms_sorting_area
    // yg SUDAH dikonfigurasi di Setting (dropdown edSortingAreaSel), BUKAN diketik bebas di sini. 1
    // baris config = maks 1 shape (klik lagi baris yg SUDAH punya shape -> pilih yg sudah ada, mirip
    // pola "Plane Buffer" di atas, tapi keyed per-row bukan singleton global).
    const pickedId=+document.getElementById("edSortingAreaSel").value||0;
    if(!pickedId){ toast("Pilih Sorting Area dulu (atau buka Setting > Sorting Layout untuk menambah)"); return; }
    const existingIdx=CFG.shapes.findIndex(s=>s.kind==="sortingarea"&&s.sortingAreaId===pickedId);
    if(existingIdx>=0){
      shSelected=new Set([existingIdx]); rkSelected.clear(); ptSelected.clear();
      redrawAll(); updateShapePanel();
      toast("Sorting Area ini sudah punya shape — dipilih, geser/resize/rotate lewat mode Geser");
    }else{
      const row=SORTING_AREA_ROWS.find(r=>+r.id===pickedId);
      if(!row){ toast("Data Sorting Area tidak ditemukan, refresh halaman"); return; }
      pushHistory(snapshotCfg());
      // Tinggi default proporsional ke Rows (biar muat grid slot yg digambar renderSortingAreaContent,
      // 06-render.js) -- BUKAN tetap 110 spt shape kind lain, krn Rows TANPA batas maksimum.
      const h=Math.max(110, row.row_count*40+40);
      CFG.shapes.push({x:p.x-100,y:p.y-h/2,w:200,h,rot:0,fill:"#DCFCE7",stroke:"#16A34A",text:"",
        kind:"sortingarea", sortingAreaId:+row.id, sortingCode:row.sorting_code,
        route:row.route, rowCount:+row.row_count});
      shSelected=new Set([CFG.shapes.length-1]); rkSelected.clear(); ptSelected.clear();
      saveCfg(); redrawAll(); updateShapePanel(); editorRebuildSortingAreaSelect();
    }
  }else if(mode==="dollysupply"){
    // Shape "Dolly Supply" — padanan persis "Sorting Plane" di atas, sumber baris smms_dolly_supply,
    // TANPA field capacity.
    const pickedId=+document.getElementById("edDollySupplySel").value||0;
    if(!pickedId){ toast("Pilih Dolly Supply dulu (atau buka Setting > Dolly Supply untuk menambah)"); return; }
    const existingIdx=CFG.shapes.findIndex(s=>s.kind==="dollysupply"&&s.dollySupplyId===pickedId);
    if(existingIdx>=0){
      shSelected=new Set([existingIdx]); rkSelected.clear(); ptSelected.clear();
      redrawAll(); updateShapePanel();
      toast("Dolly Supply ini sudah punya shape — dipilih, geser/resize/rotate lewat mode Geser");
    }else{
      const row=DOLLY_SUPPLY_ROWS.find(r=>+r.id===pickedId);
      if(!row){ toast("Data Dolly Supply tidak ditemukan, refresh halaman"); return; }
      pushHistory(snapshotCfg());
      CFG.shapes.push({x:p.x-100,y:p.y-55,w:200,h:110,rot:0,fill:"#EDE9FE",stroke:"#7C3AED",text:"",
        kind:"dollysupply", dollySupplyId:+row.id, dollySupplyNum:+row.dolly_supply_num,
        dollyRoute:row.route});
      shSelected=new Set([CFG.shapes.length-1]); rkSelected.clear(); ptSelected.clear();
      saveCfg(); redrawAll(); updateShapePanel(); editorRebuildDollySupplySelect();
    }
  }else if(mode==="pan"){
    // Klik rack ATAU titik jalur (tanpa geser) di mode Geser -> pilih. Shift+klik nambah/ngurangin
    // dari seleksi yg sudah ada (multi-select, BISA CAMPUR rack & titik jalur sekaligus dalam 1 grup —
    // makanya rkSelected & ptSelected gak saling di-clear pas shift+klik), klik biasa (tanpa shift)
    // reset semua seleksi & pilih 1 item ini aja. rkSelected dipakai bareng tabel Posisi Rack di
    // Database (10-database.js); ptSelected khusus titik jalur, lihat mousemove di 04-viewport.js
    // buat gimana grup ini digeser bareng.
    const g=e.target.closest("[data-drag]");
    if(g){
      const isRack=g.dataset.rack!==undefined, isPt=g.dataset.route!==undefined&&g.dataset.pt!==undefined;
      if(!isRack && !isPt) return;
      if(e.shiftKey){
        if(isRack){ const idx=g.dataset.rack; if(rkSelected.has(idx)) rkSelected.delete(idx); else rkSelected.add(idx); }
        else{ const key=g.dataset.route+"|"+g.dataset.pt; if(ptSelected.has(key)) ptSelected.delete(key); else ptSelected.add(key); }
      }else{
        rkSelected.clear(); ptSelected.clear();
        if(isRack) rkSelected.add(g.dataset.rack); else ptSelected.add(g.dataset.route+"|"+g.dataset.pt);
      }
      if(shSelected.size){ shSelected.clear(); updateShapePanel(); }
      redrawAll();
      if(typeof rkUpdateButtons==="function") rkUpdateButtons();
      return;
    }
    // Gak kena rack/titik jalur ([data-drag]) — cek shape (namespace TERPISAH, data-shape, lihat
    // redrawAll 06-render.js, BUKAN data-drag). Klik body shape (bukan handle resize/rotate, itu
    // diurus tersendiri lewat mousedown 04-viewport.js buat drag) -> pilih SATU shape ini & buka
    // panel properti. Klik area kosong -> lepas seleksi shape (rack/titik jalur SENGAJA gak ikut
    // kehapus di sini, sama kayak perilaku lama).
    const sh=e.target.closest("[data-shape]");
    if(sh && !e.target.closest(".shape-handle")){
      shSelected=new Set([+sh.dataset.shape]);
      rkSelected.clear(); ptSelected.clear();
      redrawAll(); updateShapePanel();
      if(typeof rkUpdateButtons==="function") rkUpdateButtons();
    }else if(!sh && shSelected.size){
      shSelected.clear(); redrawAll(); updateShapePanel();
    }
  }else if(mode==="path"){
    const g=e.target.closest("[data-drag]");
    if(g&&g.dataset.route===editRoute&&g.dataset.pt!==undefined){
      selectedPtIdx=+g.dataset.pt; redrawAll();
      toast(`Titik ${selectedPtIdx+1} route ${editRoute} dipilih — klik HALTE 1/2/3 untuk menandai`);
      return;
    }
    const path=CFG.paths[editRoute]||[];
    const insertAt = path.length>=2 ? nearestSegmentInsert(path,p.x,p.y,14/scale) : -1;
    if(insertAt>=0){
      pushHistory(snapshotCfg());
      path.splice(insertAt,0,{x:p.x,y:p.y,h:0});
      selectedPtIdx=insertAt;
      selRoute=editRoute; saveCfg(); redrawAll();
      toast(`Titik baru disisipkan di antara titik ${insertAt} & ${insertAt+1} route ${editRoute}`);
      return;
    }
    pushHistory(snapshotCfg());
    (CFG.paths[editRoute]=CFG.paths[editRoute]||[]).push({x:p.x,y:p.y,h:0});
    selectedPtIdx=CFG.paths[editRoute].length-1;
    selRoute=editRoute; saveCfg(); redrawAll();
  }else if(mode==="del"){
    const g=e.target.closest("[data-drag]");
    if(g){
      pushHistory(snapshotCfg());
      if(g.dataset.rack!==undefined){ CFG.racks.splice(+g.dataset.rack,1); }
      else if(g.dataset.route!==undefined){ CFG.paths[g.dataset.route].splice(+g.dataset.pt,1); selectedPtIdx=null; }
      saveCfg(); redrawAll(); buildAddrList();
      return;
    }
    const sh=e.target.closest("[data-shape]");
    if(sh){
      pushHistory(snapshotCfg());
      CFG.shapes.splice(+sh.dataset.shape,1);
      shSelected.clear(); updateShapePanel();
      saveCfg(); redrawAll();
      // Baris config Sorting Plane/Dolly Supply yg shape-nya baru dihapus jadi tersedia lagi di picker
      // (config-nya SENDIRI TIDAK ikut kehapus, cuma shape-nya).
      editorRebuildSortingAreaSelect(); editorRebuildDollySupplySelect();
    }
  }
});

/** Tandai titik jalur yang sedang dipilih (atau titik terakhir) sebagai Halte 1/2/3. */
function tagHalte(h){
  const path=CFG.paths[editRoute];
  if(!path||!path.length){toast("Gambar titik jalur dulu untuk route "+editRoute);return;}
  const idx=(selectedPtIdx!==null&&selectedPtIdx<path.length)?selectedPtIdx:path.length-1;
  pushHistory(snapshotCfg());
  path.forEach(p=>{if(p.h===h)p.h=0;});
  path[idx].h=h;
  saveCfg(); redrawAll(); toast(`Titik ${idx+1} route ${editRoute} = Halte ${h}`);
}

/** Tandai titik jalur yang sedang dipilih (atau titik terakhir) sebagai titik stage (SORTING/TRANSFER/
 * EMPTY/PREPARE), terpisah dari Halte 1/2/3 (yang tetap khusus per-route proses SUPPLY).
 *
 * SORTING/TRANSFER/EMPTY SECARA FISIK sama persis di semua route (1 area staging bersama yg dilewati
 * semua towing) — jadi SEKALI klik di titik 1 route, otomatis ikut nandain titik jalur yg PALING
 * DEKAT (vertex yg sudah ada) di SEMUA route lain juga, gak perlu diulang manual satu-satu.
 * PREPARE DIKECUALIKAN dari auto-propagate ini — titiknya BEDA-BEDA per route (dikonfirmasi user),
 * jadi tetap ditandai per-route aja kayak cara lama. */
function tagStage(stage){
  const path=CFG.paths[editRoute];
  if(!path||!path.length){toast("Gambar titik jalur dulu untuk route "+editRoute);return;}
  const idx=(selectedPtIdx!==null&&selectedPtIdx<path.length)?selectedPtIdx:path.length-1;
  pushHistory(snapshotCfg());
  path.forEach(p=>{if(p.stage===stage)p.stage=null;});
  path[idx].stage=stage;
  if(stage==='PREPARE'){
    saveCfg(); redrawAll(); toast(`Titik ${idx+1} route ${editRoute} = ${stage}`);
    return;
  }
  const refX=path[idx].x, refY=path[idx].y;
  let routeCount=1;
  Object.keys(CFG.paths).forEach(r=>{
    if(r===editRoute) return;
    const pts=CFG.paths[r]; if(!pts||!pts.length) return;
    let bestI=-1, bestD=Infinity;
    pts.forEach((p,i)=>{ const d=(p.x-refX)**2+(p.y-refY)**2; if(d<bestD){ bestD=d; bestI=i; } });
    if(bestI<0) return;
    pts.forEach(p=>{if(p.stage===stage)p.stage=null;});
    pts[bestI].stage=stage;
    routeCount++;
  });
  saveCfg(); redrawAll(); toast(`${stage} ditandai di ${routeCount} route sekaligus`);
}
