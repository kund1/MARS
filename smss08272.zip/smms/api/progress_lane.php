<?php
// ================= UPLOAD PROGRESS LANE (.xlsx PICS e-Kanban, via OpenSpout — streaming) =================
// File asli 66 kolom & bisa puluhan ribu baris, jadi dibaca streaming (OpenSpout, bukan load semua ke
// memori) + cuma 16 kolom yang dipakai yang diekstrak per baris (RedFilter) + insert tetap per-chunk 500.

use OpenSpout\Reader\XLSX\Reader as XlsxStreamReader;

// findH() & validDateOrNull() (dipakai buat parsing 3 kolom Plane Simulation: Sub Route Group Code +
// 1st Cross Dock Arrival/Departcher Date & Time) ada di folder plane-sim/ (SEMUA berkas fitur Plane
// Simulation disatukan di 1 folder itu: JS, CSS, HTML partial, API helper) — pipeline upload-nya
// sendiri tetap SATU di sini, cuma helper-nya yg diambil dari sana.
require_once __DIR__.'/../plane-sim/api.php';

/** Ubah nilai sel OpenSpout (bisa string/int/float/bool/DateTime/null) jadi string aman buat trim(). */
function cellstr($v) { return $v instanceof \DateTimeInterface ? $v->format('Y-m-d H:i:s') : (string)($v ?? ''); }

/**
 * action=upload (POST) — parse file "Progress Line Contain YYYYMMDD.xlsx" (format PICS e-Kanban asli,
 * 66 kolom total di file), ganti penuh smms_progress_lane. Cuma 16 kolom yang diambil (sisanya diabaikan):
 * Supplier, SPlant, SDock, Plant, Dock, Order., Part No, KANBAN Print Address, Kanban No,
 * Order Plan Quantity(Lot), Build Out Flag, Supplier Name, Parts Name, Main Route Order Seq,
 * Conveyance Route, MROS. Header dibaca by NAMA (baris pertama), bukan posisi tetap.
 */
function api_upload_progress_lane($db) {
    if (empty($_FILES['file'])) fail('file?');
    set_time_limit(300);
    ini_set('memory_limit', '512M');
    $fname = $_FILES['file']['name'];

    $reader = new XlsxStreamReader();
    try { $reader->open($_FILES['file']['tmp_name']); }
    catch (\Throwable $e) { fail('Bukan file xlsx yang valid'); }

$H = null; 
    $routesOk = array_flip(str_split('ABCDEFGHIJKLMNOPQ'));
    $ins = []; $n = 0; $planes = []; $addrs = [];

    // Variabel untuk menyimpan letak index (angka) setiap kolom
    $iD = $iRt = $iMros = $iAddr = $iPNo = $iPName = $iKnbn = null;
    $iQCont = $iQLot = $iSName = $iOrd = $iSup = $iSPlnt = $iSDck = $iPlnt = $iBOut = $iMSeq = null;
    $iSubRt = $iArrDt = $iDepDt = null;

    // Pilih sheet yang bener2 berisi data mentah 66+ kolom — file sumber ("Progress lane contain
    // YYYYMMDD.xlsx") kadang punya sheet TAMBAHAN di depan (pivot ringkasan 8 kolom: "Before",
    // "Sheet2", "After", dst — namanya beda-beda tiap file, dikonfirmasi dari beberapa file harian)
    // SEBELUM sheet data aslinya, jadi ambil "sheet pertama" begitu aja dulu suka salah baca sheet
    // ringkasan itu (upload jadi ditolak "Kolom Part No tidak ditemukan" krn baris 1 sheet ringkasan
    // itu kosong). Sheet data mentah SELALU bernama "Sheet1" & SELALU di posisi TERAKHIR (konsisten
    // di semua file harian yg dicek) — cari by NAMA dulu (paling presisi), fallback ke sheet
    // TERAKHIR kalau gak ketemu sheet bernama persis "Sheet1" (jaga-jaga kalau penamaannya berubah
    // lagi di masa depan).
    $targetSheet = null; $lastSheet = null;
    foreach ($reader->getSheetIterator() as $sheet) {
        $lastSheet = $sheet;
        if (strcasecmp(trim($sheet->getName()), 'Sheet1') === 0) { $targetSheet = $sheet; break; }
    }
    if ($targetSheet === null) $targetSheet = $lastSheet;
    if ($targetSheet === null) { $reader->close(); fail('File tidak punya sheet apapun'); }

    {
        $sheet = $targetSheet;
        foreach ($sheet->getRowIterator() as $row) {
            $cells = $row->toArray();
            
            // ===============================================================
            // 1. MAPPING HEADER (HANYA BERJALAN 1 KALI SAAT BARIS PERTAMA)
            // ===============================================================
            if ($H === null) {
                $H = [];
                foreach ($cells as $i => $h) {
                    $H[strtolower(trim(cellstr($h)))] = $i;
                }
                
                // Validasi kolom wajib (bisa ditambah jika perlu). "main route order seq" WAJIB juga
                // (bukan cuma opsional lagi) krn SEKARANG jadi patokan nomor `plane` (dikonfirmasi user
                // — GANTI dari kolom MROS, lihat komentar $m di bawah) — kalau kolom ini gak ketemu tapi
                // tetap dibiarkan lolos, SEMUA baris bakal diam2 kepadding jadi plane="00" (str_pad
                // string kosong), lolos validasi 2-digit tanpa ketahuan — mending upload ditolak jelas.
                $labels = ['part no' => 'Part No', 'mros' => 'Plane (MROS)', 'main route order seq' => 'Main Route Order Seq'];
                foreach ($labels as $k => $label) {
                    if (!isset($H[$k])) { $reader->close(); fail("Kolom '$label' tidak ditemukan"); }
                }

                // Konversi nama kolom menjadi index angka agar akses memori super cepat
                $iD     = $H['dock'] ?? -1;
                $iRt    = $H['conveyance route'] ?? -1;
                $iMros  = $H['mros'] ?? -1;
                $iAddr  = $H['kanban print address'] ?? -1;
                $iPNo   = $H['part no'] ?? -1;
                $iPName = $H['parts name'] ?? -1;
                $iKnbn  = $H['kanban no'] ?? -1;
                $iQCont = $H['quantity per container'] ?? -1;
                $iQLot  = $H['order plan quantity(lot)'] ?? -1;
                $iSName = $H['supplier name'] ?? -1;
                $iOrd   = $H['order .'] ?? -1;
                $iSup   = $H['supplier'] ?? -1;
                $iSPlnt = $H['splant'] ?? -1;
                $iSDck  = $H['sdock'] ?? -1;
                $iPlnt  = $H['plant'] ?? -1;
                $iBOut  = $H['build out flag'] ?? -1;
                $iMSeq  = $H['main route order seq'] ?? -1;

                // Kolom baru (opsional, buat urutan skid asli di menu Plane Simulation) — ketiga
                // nama header ini udah dikonfirmasi user persis dari screenshot header file asli:
                // "Sub Route Group Code", "1st Cross Dock Arrival Date & Time", "1st Cross Dock
                // Departcher Date & Time" ("Departcher" emang typo bawaan di file sumbernya sendiri,
                // bukan salah ketik di sini) — tetap pakai findH (beberapa varian sekaligus) sbg jaga2
                // kalau template file berubah dikit di masa depan, gak ketemu ya kolomnya kosong/NULL.
                $iSubRt = findH($H, ['sub route group code', 'sub route code', 'sub route', 'subroute code']);
                $iArrDt = findH($H, ['1st cross dock arrival date & time', 'cross dock arrival date & time',
                    'cross dock arrival date', 'cd arrival date', 'arrival date']);
                $iDepDt = findH($H, ['1st cross dock departcher date & time', '1st cross dock departure date & time',
                    'cross dock departcher date & time', 'cross dock departure date & time',
                    'cross dock departure date', 'cd departure date', 'departure date']);

                continue; // Skip baris ini, lanjut ke baris isi data
            }

            // ===============================================================
            // 2. FILTER DOCK 43 PALING AWAL (SUPER CEPAT)
            // ===============================================================
            // Langsung tembak index-nya, jika bukan 43, langsung buang!
            if (!isset($cells[$iD]) || trim(cellstr($cells[$iD])) !== '43') {
                continue; 
            }

            // ===============================================================
            // 3. JIKA LOLOS DOCK 43, EKSTRAK DATA LAINNYA
            // ===============================================================
            $rt = isset($cells[$iRt]) ? trim(cellstr($cells[$iRt])) : '';
            // Patokan nomor `plane` (dikonfirmasi user, GANTI dari kolom MROS): "Main Route Order Seq"
            // (kolom AB, header dibaca by-nama lewat $iMSeq) dipadding 2 digit — SAMA persis cara MROS
            // dulu diformat, cuma sumber kolomnya beda. MROS mentah TETAP direkam terpisah ($mrosRaw,
            // -> kolom mros_raw) sbg arsip, TIDAK lagi dipakai nentuin identitas plane.
            $m  = str_pad(isset($cells[$iMSeq]) ? trim(cellstr($cells[$iMSeq])) : '', 2, '0', STR_PAD_LEFT);
            $mrosRaw = isset($cells[$iMros]) ? trim(cellstr($cells[$iMros])) : '';
            $a  = preg_replace('/\s+/', '', isset($cells[$iAddr]) ? cellstr($cells[$iAddr]) : '');

            // Validasi route dan main route order seq (patokan plane)
            if (!isset($routesOk[$rt]) || !preg_match('/^\d\d$/', $m) || $a === '') continue;

            $n++;
            $planes[$m] = 1;
            $addrs[$a] = 1;

            $kanbanNo = isset($cells[$iKnbn]) ? trim(cellstr($cells[$iKnbn])) : '';

            // Masukkan ke array batch insert persis sesuai urutan kolom tabel kamu
            $ins[] = [
                $m, 
                $rt, 
                isset($cells[$iPNo]) ? trim(cellstr($cells[$iPNo])) : '', 
                mb_substr(isset($cells[$iPName]) ? trim(cellstr($cells[$iPName])) : '', 0, 40), 
                $kanbanNo,
                (int)(isset($cells[$iQCont]) ? trim(cellstr($cells[$iQCont])) : 0), 
                (int)(isset($cells[$iQLot]) ? trim(cellstr($cells[$iQLot])) : 0),
                $a, 
                mb_substr(isset($cells[$iSName]) ? trim(cellstr($cells[$iSName])) : '', 0, 40),
                $kanbanNo, 
                isset($cells[$iOrd]) ? trim(cellstr($cells[$iOrd])) : '',
                mb_substr(isset($cells[$iSup]) ? trim(cellstr($cells[$iSup])) : '', 0, 20), 
                mb_substr(isset($cells[$iSPlnt]) ? trim(cellstr($cells[$iSPlnt])) : '', 0, 10),
                mb_substr(isset($cells[$iSDck]) ? trim(cellstr($cells[$iSDck])) : '', 0, 20), 
                mb_substr(isset($cells[$iPlnt]) ? trim(cellstr($cells[$iPlnt])) : '', 0, 10),
                mb_substr(isset($cells[$iBOut]) ? trim(cellstr($cells[$iBOut])) : '', 0, 10),
                mb_substr(isset($cells[$iMSeq]) ? trim(cellstr($cells[$iMSeq])) : '', 0, 10),
                mb_substr($mrosRaw, 0, 10),
                // Kolom baru (opsional) — sub_route_code string biasa, ke-2 tanggal PHP null kalau
                // kosong/kolomnya gak ketemu (biar keinsert NULL beneran, bukan string kosong yg gak
                // valid utk kolom DATETIME — lihat konversi $v===null?'NULL':... di bawah).
                mb_substr(isset($cells[$iSubRt]) ? trim(cellstr($cells[$iSubRt])) : '', 0, 20),
                $iArrDt>=0 && isset($cells[$iArrDt]) ? validDateOrNull(cellstr($cells[$iArrDt])) : null,
                $iDepDt>=0 && isset($cells[$iDepDt]) ? validDateOrNull(cellstr($cells[$iDepDt])) : null
            ];
        }
    }

    $reader->close();
    if ($H === null) fail('File kosong');
    if (!$n) fail('Tidak ada baris Dock 43 + route A–Q yang valid');

    // Tanggal data ini SEBENARNYA buat tanggal berapa — modus (paling sering muncul) dari 8 digit
    // pertama order_no tiap baris (lihat extract_date_from_order_no() di helpers.php). Dipakai
    // poka-yoke retensi H-1/H+1 di bawah + preview per-tanggal di tab Database. Fallback ke hari
    // ini kalau order_no gak ada yang match (harusnya gak pernah kejadian, tapi jaga-jaga).
    $dateCount = [];
    foreach ($ins as $r) { $d = extract_date_from_order_no($r[10]); if ($d) $dateCount[$d] = ($dateCount[$d] ?? 0) + 1; }
    arsort($dateCount);
    $dataDate = $dateCount ? array_key_first($dateCount) : date('Y-m-d');

    $db->begin_transaction();

    // Upload dgn NAMA FILE PERSIS SAMA kayak batch yg udah ada -> anggap ini versi PENGGANTI (bukan
    // batch baru terpisah) — hapus batch lama itu duluan (data + riwayat upload-nya) sebelum nyimpen
    // yg baru (dikonfirmasi user: data plane progress "saling membelah" pas malam krn tiap kali bot
    // narik ulang file H+1 yg nama-nya sama, kepisah jadi batch baru terus2an alih2 gantiin yg lama).
    $staleSameName = $db->query("SELECT id FROM smms_progress_lane_uploads WHERE filename='".$db->real_escape_string($fname)."'");
    $sameNameIds = []; while ($row = $staleSameName->fetch_row()) $sameNameIds[] = (int)$row[0];
    if ($sameNameIds) {
        $in = implode(',', $sameNameIds);
        $db->query("DELETE FROM smms_progress_lane WHERE batch_id IN ($in)");
        $db->query("DELETE FROM smms_progress_lane_uploads WHERE id IN ($in)");
    }

    // Catat riwayat upload dulu — id auto-increment-nya dipakai sbg batch_id, penanda generasi
    // data upload ini (bukan TRUNCATE lagi, biar upload sebelumnya masih ada sbg cadangan).
    ksort($planes);
    $planesStr = implode(',', array_keys($planes));
    $now = date('Y-m-d H:i:s');
    $st = $db->prepare("INSERT INTO smms_progress_lane_uploads (filename,rows_count,planes,uploaded_at,data_date) VALUES (?,?,?,?,?)");
    $st->bind_param('sisss', $fname, $n, $planesStr, $now, $dataDate);
    $st->execute();
    $batchId = $db->insert_id;

    // Simpan data baru, ditandai batch_id upload ini
    $chunk = [];
    $insCols = "(batch_id,plane,route,part_no,part_name,kanban,qty,lot,addr,supplier,uniq_no,order_no,
        supplier_code,supplier_plant,supplier_dock,plant_no,build_out_flag,route_order_seq,mros_raw,
        sub_route_code,cd_arrival_at,cd_departure_at)";
    foreach ($ins as $r) {
        $vals = implode(",", array_map(fn($v)=>$v===null ? 'NULL' : "'".$db->real_escape_string((string)$v)."'", $r));
        $chunk[] = "($batchId,$vals)";
        if (count($chunk) >= 500) { $db->query("INSERT INTO smms_progress_lane $insCols VALUES ".implode(',',$chunk)); $chunk=[]; }
    }
    if ($chunk) $db->query("INSERT INTO smms_progress_lane $insCols VALUES ".implode(',',$chunk));
    $db->query("REPLACE INTO smms_meta VALUES ('parts_source','".$db->real_escape_string($fname)." (Dock 43)'),('parts_rows','$n'),('parts_uploaded','".date('Y-m-d H:i:s')."')");

    // Retensi berbasis COUNT (GANTI jendela tanggal H-1/H+1 lama) -- simpan cuma N data_date DISTINCT
    // TERBARU, N diatur user lewat modal "Pengaturan Fisik Plane" di menu Plane Simulation (smms_meta
    // key 'plane_sim_retain_batches', default 5) -- dikonfirmasi user: perlu histori tanggal lebih
    // panjang drpd H-1/H+1 supaya ada cukup pilihan buat rentang multi-tanggal di Plane Simulation
    // (lihat action=plane_sim_bulk, plane-sim/api.php). "N TERBARU" diranking dari NILAI data_date
    // (kalender), bukan urutan upload/id -- konsisten sama cara action=progress_lane_dates dedup (per
    // data_date, bukan per waktu upload). Batch yang baru diinsert ini ($batchId) SELALU dikecualikan
    // dari kandidat hapus (sama pola pengaman kayak versi lama) -- jadi minimal 1 batch selalu tersisa
    // tanpa perlu guard "sisain 1 batch lain" terpisah lagi.
    $retainRow = $db->query("SELECT v FROM smms_meta WHERE k='plane_sim_retain_batches'")->fetch_assoc();
    $retainN = (int)($retainRow['v'] ?? 5);
    if ($retainN < 1) $retainN = 5;
    $keepRes = $db->query("SELECT data_date FROM smms_progress_lane_uploads WHERE data_date IS NOT NULL GROUP BY data_date ORDER BY data_date DESC LIMIT $retainN");
    $keepDates = []; while ($row = $keepRes->fetch_row()) $keepDates[] = $row[0];
    $keepDatesSql = $keepDates ? "'".implode("','", array_map(fn($d)=>$db->real_escape_string($d), $keepDates))."'" : "''";
    $staleRes = $db->query("SELECT id FROM smms_progress_lane_uploads WHERE id<>$batchId AND (data_date IS NULL OR data_date NOT IN ($keepDatesSql))");
    $staleIds = []; while ($row = $staleRes->fetch_row()) $staleIds[] = (int)$row[0];
    if ($staleIds) {
        $in = implode(',', $staleIds);
        $db->query("DELETE FROM smms_progress_lane WHERE batch_id IN ($in)");
        $db->query("DELETE FROM smms_progress_lane_uploads WHERE id IN ($in)");
    }

    $db->commit();
    out(['ok'=>true,'file'=>$fname,'rows'=>$n,'planes'=>array_keys($planes),'racks'=>count($addrs)]);
}

/** action=progress_lane_dates — daftar tanggal data yang masih tersisa (setelah retensi H-1/H+1),
 * dipakai tombol pilih tanggal di tab Database (preview, TIDAK mengubah batch aktif Monitor). */
function api_progress_lane_dates($db) {
    $active = current_parts_batch($db);
    // Kolom `planes` (CSV nomor plane, sudah diisi saat upload — lihat $planesStr di
    // api_upload_progress_lane) diikutkan supaya Plane Simulation dapat daftar nomor plane per-tanggal
    // tanpa query tambahan (lihat PS_PLANES_BY_DATE, plane-sim.js).
    $q = $db->query("SELECT id AS batch_id, data_date, filename, rows_count, planes FROM smms_progress_lane_uploads WHERE data_date IS NOT NULL ORDER BY data_date ASC, id DESC");
    $seen = []; $rows = [];
    while ($r = $q->fetch_assoc()) {
        if (isset($seen[$r['data_date']])) continue; // 1 baris per tanggal — ambil upload TERBARU utk tanggal itu
        $seen[$r['data_date']] = true;
        $r['batch_id'] = (int)$r['batch_id'];
        $r['rows_count'] = (int)$r['rows_count'];
        $r['active'] = $r['batch_id'] === $active;
        $rows[] = $r;
    }
    out(['rows'=>$rows]);
}

/** action=progress_lane_upload_history — daftar riwayat upload Progress Lane (file, baris, plane, waktu). */
function api_progress_lane_upload_history($db) {
    $q = $db->query("SELECT filename,rows_count,planes,uploaded_at FROM smms_progress_lane_uploads ORDER BY uploaded_at DESC, id DESC LIMIT 1");
    out(['rows'=>$q->fetch_all(MYSQLI_ASSOC)]);
}

/** action=progress_lane_excel&p=NN&route=X — download data Progress Lane (P-Lane+Route yg lagi
 * dipilih di tabel Database, batch aktif) dalam bentuk .xlsx (OpenSpout, streaming, sama pola dgn
 * api_master_part_excel()). Kolom Status = VLOOKUP ke Master Part by part_no, query-nya sama persis
 * dgn api_plane() di data.php biar nilainya konsisten dengan yg tampil di tabel & panel Muatan. */
function api_progress_lane_excel($db) {
    $p = $_GET['p'] ?? ''; if (!preg_match('/^\d\d$/', $p)) fail('plane?');
    $route = strtoupper(trim($_GET['route'] ?? '')); if ($route === '') fail('route?');
    $batch = current_parts_batch($db);
    $st = $db->prepare("
        SELECT sp.uniq_no, sp.order_no, sp.part_no, sp.part_name, sp.kanban, sp.qty, sp.lot, sp.addr, sp.supplier,
               COALESCE(mp.status,'Direct') AS status
        FROM smms_progress_lane sp
        LEFT JOIN smms_master_part mp ON mp.part_no = sp.part_no
        WHERE sp.plane=? AND sp.route=? AND sp.batch_id=? ORDER BY sp.id
    ");
    $st->bind_param('ssi', $p, $route, $batch);
    $st->execute();
    $res = $st->get_result();

    $writer = new \OpenSpout\Writer\XLSX\Writer();
    $writer->openToBrowser("progress_lane_{$p}_{$route}_".date('Ymd_His').".xlsx");
    $writer->addRow(\OpenSpout\Common\Entity\Row::fromValues(['No','Uniq','Order No','Part No','Nama','Kanban','Qty','Lot','Rack Address','Supplier','Status']));
    $i = 0;
    while ($r = $res->fetch_row()) { $i++; $writer->addRow(\OpenSpout\Common\Entity\Row::fromValues(array_merge([$i], $r))); }
    $writer->close();
    exit;
}

if ($act === 'upload' && $_SERVER['REQUEST_METHOD']==='POST') api_upload_progress_lane($db);
if ($act === 'progress_lane_upload_history') api_progress_lane_upload_history($db);
if ($act === 'progress_lane_excel') api_progress_lane_excel($db);
if ($act === 'progress_lane_dates') api_progress_lane_dates($db);
