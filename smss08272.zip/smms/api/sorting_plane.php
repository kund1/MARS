<?php
/* =====================================================================
 * SORTING PLANE — DIGANTIKAN TOTAL oleh "Sorting Area" (koreksi arsitektur 2026-08-27), lihat
 * api/sorting_area.php. File ini SENGAJA dikosongkan (bukan dihapus fisik) sbg jejak riwayat --
 * TIDAK didaftarkan lagi di $ROUTES (api.php root), jadi action `sorting_plane_*` sekarang
 * mengembalikan "action tidak dikenal". Tabel smms_sorting_plane DIBIARKAN ada di DB (unused, tidak
 * di-drop), konsisten preseden smms_plane_manual.
 * ===================================================================== */
