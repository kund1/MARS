<?php
// ================= UPLOAD ASSET IMAGE (gambar denah / ikon towing) =================

/** action=upload_asset (POST, kind=layout|towing) — validasi gambar asli, ganti file di assets/, catat nama file ke smms_meta. */
function api_upload_asset($db) {
    $kindMap = ['layout'=>'layout', 'towing'=>'towing'];
    $base = $kindMap[$_POST['kind'] ?? ''] ?? null;
    if (!$base) fail('kind?');
    if (empty($_FILES['file'])) fail('file?');
    $tmp = $_FILES['file']['tmp_name'];
    $info = @getimagesize($tmp);
    if ($info === false) fail('Bukan file gambar yang valid');
    $extMap = [IMAGETYPE_JPEG=>'jpg', IMAGETYPE_PNG=>'png', IMAGETYPE_GIF=>'gif', IMAGETYPE_WEBP=>'webp'];
    $ext = $extMap[$info[2]] ?? null;
    if (!$ext) fail('Format gambar tidak didukung (pakai JPG/PNG/GIF/WEBP)');
    $dir = dirname(__DIR__).'/assets';
    foreach (['jpg','jpeg','png','gif','webp'] as $e) {
        $old = "$dir/$base.$e";
        if (is_file($old)) @unlink($old);
    }
    $destName = "$base.$ext";
    if (!move_uploaded_file($tmp, "$dir/$destName")) fail('Gagal menyimpan file');
    $key = $base.'_image';
    $st = $db->prepare("REPLACE INTO smms_meta VALUES (?,?)");
    $st->bind_param('ss', $key, $destName);
    $st->execute();
    out(['ok'=>true,'file'=>$destName,'w'=>$info[0],'h'=>$info[1]]);
}

if ($act === 'upload_asset' && $_SERVER['REQUEST_METHOD']==='POST') api_upload_asset($db);
