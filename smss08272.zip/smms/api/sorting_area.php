<?php
/* =====================================================================
 * SORTING AREA (smms_sorting_area) — GANTIKAN "Sorting Plane" total (koreksi arsitektur 2026-08-27).
 * Physical area tempat skid hasil bongkar Plane menunggu proses SORTING, hierarchy Sorting Area ->
 * Slot -> Stack -> Skid -> Part. Diidentifikasi lewat ROUTE (bukan nomor plane). Slot DIHITUNG dari
 * row_count*column_count (BUKAN di-CRUD satu-satu -- "jangan bikin user create slot manual",
 * dikonfirmasi user), column_count SELALU 2 (fix, diabaikan kalau ada di payload). Stack/Skid BELUM
 * ada tabelnya (belum ada data skid real yg mengalir ke Sorting di fase ini) -- lihat
 * assets/js/21-sorting-area-stacking.js utk fungsi kalkulasi stacking-nya (foundation, generik).
 * Entity TERPISAH TOTAL dari Physical Plane (Pengaturan Fisik Plane, plane-sim/) & "Sorting Store"
 * (belum dibuat, entity beda, lihat memori project). Config-only fase ini -- BELUM ada movement/
 * distribusi skid per-route/animasi.
 * ===================================================================== */

/** action=sorting_area_list (GET) — semua baris, urut sorting_code. */
function api_sorting_area_list($db) {
    $q = $db->query("SELECT id,sorting_code,route,row_count,column_count FROM smms_sorting_area ORDER BY sorting_code");
    out(['rows'=>$q->fetch_all(MYSQLI_ASSOC)]);
}

/** action=sorting_area_upsert_row (POST) — tambah/edit 1 baris (sorting_code UNIQUE, dicek manual di
 * PHP dulu sblm insert biar pesan errornya jelas). row_count minimal 1, TANPA batas maksimum
 * (dikonfirmasi user). column_count SELALU 2 -- input dari client diabaikan, server yang menentukan. */
function api_sorting_area_upsert_row($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    if (!is_array($in)) fail('payload?');
    $id = (int)($in['id'] ?? 0);
    $code = trim((string)($in['sorting_code'] ?? '')); if ($code === '') fail('sorting_code?');
    $route = strtoupper(trim($in['route'] ?? '')); if ($route === '') fail('route?');
    $rowCount = (int)($in['row_count'] ?? 0);
    if ($rowCount < 1) fail('row_count harus >= 1');
    $columnCount = 2; // FIX, tidak bisa diatur user

    // Cek duplikat sorting_code -- kecuali baris yg sedang diedit (id sendiri).
    $st = $db->prepare("SELECT id FROM smms_sorting_area WHERE sorting_code=? AND id<>?");
    $dummyId = $id ?: -1;
    $st->bind_param('si', $code, $dummyId);
    $st->execute();
    if ($st->get_result()->num_rows > 0) fail("Sorting Area \"$code\" sudah ada");

    if ($id > 0) {
        $st = $db->prepare("UPDATE smms_sorting_area SET sorting_code=?,route=?,row_count=?,column_count=? WHERE id=?");
        $st->bind_param('ssiii', $code, $route, $rowCount, $columnCount, $id);
        $st->execute();
        out(['ok'=>true,'id'=>$id]);
    } else {
        $st = $db->prepare("INSERT INTO smms_sorting_area (sorting_code,route,row_count,column_count) VALUES (?,?,?,?)");
        $st->bind_param('ssii', $code, $route, $rowCount, $columnCount);
        $st->execute();
        out(['ok'=>true,'id'=>$db->insert_id]);
    }
}

/** action=sorting_area_delete_row (POST) — hapus 1 baris by id. */
function api_sorting_area_delete_row($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    $id = (int)($in['id'] ?? 0);
    if ($id <= 0) fail('id?');
    $st = $db->prepare("DELETE FROM smms_sorting_area WHERE id=?");
    $st->bind_param('i', $id);
    $st->execute();
    out(['ok'=>true]);
}

if ($act === 'sorting_area_list') api_sorting_area_list($db);
if ($act === 'sorting_area_upsert_row' && $_SERVER['REQUEST_METHOD']==='POST') api_sorting_area_upsert_row($db);
if ($act === 'sorting_area_delete_row' && $_SERVER['REQUEST_METHOD']==='POST') api_sorting_area_delete_row($db);
