<?php
/* =====================================================================
 * DOLLY SUPPLY (smms_dolly_supply) — physical area penyimpanan Dolly per Route, padanan Sorting Plane
 * (lihat api/sorting_plane.php, pola CRUD PERSIS sama) TAPI tanpa field capacity (gak ada analog
 * "1-2 Plane" utk Dolly). Shape-nya di denah (kind='dollysupply', smms_shapes) TERPISAH TOTAL dari
 * mekanisme towing-dolly arc-length yg sudah jalan di Monitor (03-countdown.js dollyGroups/
 * dollyPositions) — config-only, BELUM ada movement/distribusi skid.
 * ===================================================================== */

/** action=dolly_supply_list (GET) — semua baris, urut dolly_supply_num. */
function api_dolly_supply_list($db) {
    $q = $db->query("SELECT id,dolly_supply_num,route FROM smms_dolly_supply ORDER BY dolly_supply_num");
    out(['rows'=>$q->fetch_all(MYSQLI_ASSOC)]);
}

/** action=dolly_supply_upsert_row (POST) — tambah/edit 1 baris (dolly_supply_num UNIQUE, dicek manual
 * di PHP dulu sblm insert biar pesan errornya jelas, bukan cuma "Duplicate entry" mentah dari DB
 * constraint). */
function api_dolly_supply_upsert_row($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    if (!is_array($in)) fail('payload?');
    $id = (int)($in['id'] ?? 0);
    $num = (int)($in['dolly_supply_num'] ?? 0);
    if ($num <= 0) fail('dolly_supply_num?');
    $route = strtoupper(trim($in['route'] ?? '')); if ($route === '') fail('route?');

    // Cek duplikat dolly_supply_num -- kecuali baris yg sedang diedit (id sendiri).
    $st = $db->prepare("SELECT id FROM smms_dolly_supply WHERE dolly_supply_num=? AND id<>?");
    $dummyId = $id ?: -1;
    $st->bind_param('ii', $num, $dummyId);
    $st->execute();
    if ($st->get_result()->num_rows > 0) fail("Dolly Supply $num sudah ada");

    if ($id > 0) {
        $st = $db->prepare("UPDATE smms_dolly_supply SET dolly_supply_num=?,route=? WHERE id=?");
        $st->bind_param('isi', $num, $route, $id);
        $st->execute();
        out(['ok'=>true,'id'=>$id]);
    } else {
        $st = $db->prepare("INSERT INTO smms_dolly_supply (dolly_supply_num,route) VALUES (?,?)");
        $st->bind_param('is', $num, $route);
        $st->execute();
        out(['ok'=>true,'id'=>$db->insert_id]);
    }
}

/** action=dolly_supply_delete_row (POST) — hapus 1 baris by id. */
function api_dolly_supply_delete_row($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    $id = (int)($in['id'] ?? 0);
    if ($id <= 0) fail('id?');
    $st = $db->prepare("DELETE FROM smms_dolly_supply WHERE id=?");
    $st->bind_param('i', $id);
    $st->execute();
    out(['ok'=>true]);
}

if ($act === 'dolly_supply_list') api_dolly_supply_list($db);
if ($act === 'dolly_supply_upsert_row' && $_SERVER['REQUEST_METHOD']==='POST') api_dolly_supply_upsert_row($db);
if ($act === 'dolly_supply_delete_row' && $_SERVER['REQUEST_METHOD']==='POST') api_dolly_supply_delete_row($db);
