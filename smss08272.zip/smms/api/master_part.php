<?php
// ================= MASTER PART: upload (strict validasi+riwayat), CRUD per-baris, CSV export =================
// Field wajib divalidasi (SEMUA baris ditolak bareng-bareng kalau ada 1 saja yang salah):
//   Dock Code = "43" persis | Supplier Code 4 karakter huruf/angka | Supplier Plant Code 1 karakter |
//   Part No 12 karakter | Kanban No 4 karakter huruf/angka | Status = Direct/Sorting/Unpacking Murni/C-U.
// Kolom lain (Shipping Dock, SSC Code, Vol/Box Day, Supplier Name, Part Name, Conveyance, Volume Box)
// tidak divalidasi ketat — cuma disimpan sbg referensi.
//
// Status "C/U" (Cooling Unit) — status TAMBAHAN (dikonfirmasi user) khusus part yg jumlah skid-nya
// BUKAN dihitung dari volume_box/timestamp kayak status lain, tapi dari LOT (qty pesanan) dibagi
// kapasitas fisik 4 unit/skid, dibulatkan ke atas — lihat psIsCoolingUnitGroup()/psSkidCountForGroup()
// di plane-sim/plane-sim.js. Ditandai di sini (status di smms_master_part) supaya grouping-nya bisa
// tahu part mana yg perlu rumus khusus itu, tanpa hardcode daftar part_no di kode.

/** Validasi 1 baris/record master part. $rec dilewatkan by-reference krn status dinormalisasi kapitalisasinya. Return array error (kosong = valid). */
function master_part_validate(&$rec) {
    $errs = [];
    // Validasi Dock 43
    if (($rec['dock_code'] ?? '') !== '43')
        $errs[] = ['col'=>'Dock Code', 'msg'=>"Harus Dock '43' ,(ditemukan '".($rec['dock_code'] ?? '')."')"];
    //Validasi Supplier Code 4 karakter
    if (!preg_match('/^[A-Za-z0-9]{4}$/', $rec['supplier_code'] ?? ''))
        $errs[] = ['col'=>'Supplier Code / Exporter', 'msg'=>"harus 4 karakter (ditemukan '".($rec['supplier_code'] ?? '')."')"];
    //validasi Supplier Plant Code 1 karakter
    if (mb_strlen($rec['supplier_plant_code'] ?? '') !== 1)
        $errs[] = ['col'=>'Supplier Plant Code', 'msg'=>"harus 1 karakter (ditemukan '".($rec['supplier_plant_code'] ?? '')."')"];
    $partNo = $rec['part_no'] ?? '';
    // Validasi Part No 12 karakter 
    if (mb_strlen($partNo) !== 12)
        $errs[] = ['col'=>'Part No', 'msg'=>"harus 12 karakter (ditemukan '$partNo', ".mb_strlen($partNo)." karakter)"];
    // Validasi Kanban No 4 karakter
    if (!preg_match('/^[A-Za-z0-9]{4}$/', $rec['uniq_no'] ?? ''))
        $errs[] = ['col'=>'Kanban No', 'msg'=>"harus 4 karakter (ditemukan '".($rec['uniq_no'] ?? '')."')"];
    // Validasi Status: Direct/Sorting/Unpacking Murni/C-U — "X" & "SCHEDULE" dari PICS diterima juga,
    // dinormalisasi ke status yg perlakuannya sama (X -> Unpacking Murni, SCHEDULE -> Direct). C/U
    // (Cooling Unit) diterima dalam beberapa ejaan umum ("C/U", "C-U", "CU", "Cooling Unit") biar
    // upload dari Excel gak gagal cuma gara2 beda pemisah, semua dinormalisasi ke "C/U".
    $statusMap = [
        'direct'=>'Direct', 'sorting'=>'Sorting', 'unpacking murni'=>'Unpacking Murni',
        'x'=>'Unpacking Murni', 'schedule'=>'Direct',
        'c/u'=>'C/U', 'c-u'=>'C/U', 'cu'=>'C/U', 'cooling unit'=>'C/U',
    ];
    $statusKey = strtolower(trim($rec['status'] ?? ''));
    if (!isset($statusMap[$statusKey])) {
        $errs[] = ['col'=>'Status', 'msg'=>"harus Direct/Sorting/Unpacking Murni/C-U/X/Schedule (ditemukan '".($rec['status'] ?? '')."')"];
    } else {
        $rec['status'] = $statusMap[$statusKey]; // normalisasi kapitalisasi biar konsisten tersimpan
    }
    return $errs;
}

/** Status yg boleh dipakai action=master_part_bulk_status (bulk edit, checkbox banyak baris sekaligus). */
const MASTER_PART_BULK_STATUSES = ['Direct', 'Sorting', 'Unpacking Murni', 'C/U'];

/** action=master_part_bulk_status (POST JSON {part_nos:[...], status:"..."}) — ubah status BANYAK
 * baris sekaligus (dari checkbox tabel Master Part) ke 1 nilai yg sama, tanpa perlu buka form Edit
 * satu-satu per baris. Cuma nyentuh kolom status — field lain tiap baris gak disentuh. */
function api_master_part_bulk_status($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    $partNos = is_array($in['part_nos'] ?? null) ? $in['part_nos'] : [];
    if (!$partNos) fail('part_nos?');
    $status = trim($in['status'] ?? '');
    if (!in_array($status, MASTER_PART_BULK_STATUSES, true)) {
        fail('status harus salah satu dari: '.implode(', ', MASTER_PART_BULK_STATUSES));
    }
    $vals = array_map(fn($v)=>"'".$db->real_escape_string(trim((string)$v))."'", $partNos);
    $st = $db->prepare('UPDATE smms_master_part SET status=? WHERE part_no IN ('.implode(',', $vals).')');
    $st->bind_param('s', $status);
    $st->execute();
    out(['ok'=>true, 'status'=>$status, 'updated'=>$db->affected_rows]);
}

/** Simpan/refresh 1 identitas supplier ke cache nama (dipakai Pattern Unload biar tetap kebaca nama-nya
 *  walau identitasnya udah gak ada lagi di smms_master_part yg "live"). Lihat catatan di install.php. */
function cache_supplier_name($db, $rec) {
    if (($rec['supplier_code'] ?? '') === '') return;
    $st = $db->prepare('INSERT INTO smms_supplier_name_cache (supplier_code,shipping_dock,route,supplier_name)
        VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE supplier_name=VALUES(supplier_name)');
    $st->bind_param('ssss', $rec['supplier_code'], $rec['shipping_dock'], $rec['route'], $rec['supplier_name']);
    $st->execute();
}

//Validasi Header Upload Master Part (nama header di file => nama field internal/kolom DB)
const MASTER_PART_REQUIRED_HEADERS = [
    'dock code'=>'dock_code', 'supplier code / exporter'=>'supplier_code',
    'supplier plant code'=>'supplier_plant_code', 'shipping dock'=>'shipping_dock',
    'ssc code'=>'ssc_code', 'part no'=>'part_no', 'kanban no'=>'uniq_no',
    'vol/box day'=>'vol_box_day', 'supplier / exporter name'=>'supplier_name',
    'part name'=>'part_name', 'volume box'=>'volume_box', 'conveyance'=>'route', 'status'=>'status',
];

/**
 * action=upload_master_part (POST, field: file, mode=replace|additional) — upload STRICT: harus
 * sesuai template (semua header wajib ada) dan tiap baris lolos validasi, kalau tidak SELURUH upload
 * ditolak (tidak ada yang tersimpan sebagian) dan dikembalikan detail baris+kolom yang bermasalah.
 * mode=replace: ganti seluruh isi tabel. mode=additional: cuma nambah, part_no yg BEDA dari yg sudah
 * ada di database & sesama file (duplikat di dalam file sendiri pun ditolak).
 */
//Uplaod Master Part    
function api_upload_master_part($db) {
    // Wajib ada file yang diupload
    if (empty($_FILES['file'])) fail('file?');
    $fname = $_FILES['file']['name'];
    // Validasi format nama file: harus masterpart_YYYYMM.xlsx/.xlsm
    if (!preg_match('/^masterpart_\d{6}\.xls[xm]$/i', $fname)) {
        fail('Format nama file salah! File harus bernama masterpart_yyyymm (contoh: masterpart_202607.xlsx)');
    }

    // Mode upload: replace (ganti semua) atau additional (tambah baru saja)
    $mode = ($_POST['mode'] ?? 'additional') === 'replace' ? 'replace' : 'additional';
    set_time_limit(300);
    // Baca isi file xlsx/xlsm jadi array baris
    $rows = read_xlsx_rows($_FILES['file']['tmp_name']);
    if ($rows === null) fail('Bukan file xlsx/xlsm yang valid');
    if (count($rows) < 2) fail('File kosong');

    // Cari baris header (yang punya kolom 'Part No') di antara 5 baris pertama
    $headerRow = -1; $H = [];
    for ($i=0; $i<min(5,count($rows)); $i++) {
        $map = [];
        foreach ($rows[$i] as $ci=>$h) $map[strtolower(trim((string)$h))] = $ci;
        if (isset($map['part no'])) { $headerRow = $i; $H = $map; break; }
    }
    if ($headerRow < 0) fail("Template salah — baris header (kolom 'Part No') tidak ditemukan di 5 baris pertama. Pakai Download Template.");

    // Validasi semua kolom wajib ada di header
    $missing = [];
    foreach (MASTER_PART_REQUIRED_HEADERS as $name=>$field) if (!isset($H[$name])) $missing[] = $name;
    if ($missing) fail('Template salah — kolom wajib tidak ada: '.implode(', ', $missing).'. Pakai Download Template.');
    $g = fn($r,$k)=> isset($H[$k]) && isset($r[$H[$k]]) ? trim((string)$r[$H[$k]]) : '';

    // Baca & validasi tiap baris data (mulai setelah baris header)
    $records = []; $errors = []; $seenInFile = [];
    for ($i=$headerRow+1; $i<count($rows); $i++) {
        $r = $rows[$i];
        if (!count(array_filter($r, fn($v)=>trim((string)$v)!==''))) continue; // baris kosong, lewati
        $excelRow = $i+1; // nomor baris asli di Excel (1-based)
        // Ambil nilai tiap kolom sesuai mapping header
        $rec = [
            'part_no'             => $g($r,'part no'),
            'volume_box'          => (float)str_replace(',', '.', $g($r,'volume box')),
            'status'              => $g($r,'status'),
            'dock_code'           => $g($r,'dock code'),
            'supplier_code'       => $g($r,'supplier code / exporter'),
            'supplier_plant_code' => $g($r,'supplier plant code'),
            'shipping_dock'       => $g($r,'shipping dock'),
            'ssc_code'            => $g($r,'ssc code'),
            'uniq_no'             => $g($r,'kanban no'),
            'vol_box_day'         => $g($r,'vol/box day'),
            'supplier_name'       => mb_substr($g($r,'supplier / exporter name'),0,100),
            'part_name'           => mb_substr($g($r,'part name'),0,150),
            'route'               => $g($r,'conveyance'),
        ];
        // Validasi format tiap kolom (dock/supplier code/part no/kanban/status)
        foreach (master_part_validate($rec) as $e) $errors[] = ['row'=>$excelRow, 'col'=>$e['col'], 'msg'=>$e['msg']];
        // Cek duplikat part_no di dalam file yang sama
        if (isset($seenInFile[$rec['part_no']]))
            $errors[] = ['row'=>$excelRow, 'col'=>'Part No', 'msg'=>"duplikat dengan baris {$seenInFile[$rec['part_no']]} di file ini"];
        $seenInFile[$rec['part_no']] = $excelRow;
        $records[] = ['excelRow'=>$excelRow, 'rec'=>$rec];
    }
    if (!$records) fail('Tidak ada baris data di file ini');

    // Mode additional: part_no yang sudah ada di database dianggap konflik (harus data baru semua)
    if ($mode === 'additional') {
        $partNos = array_column(array_column($records,'rec'), 'part_no');
        $existing = [];
        foreach (array_chunk($partNos, 500) as $chunk) {
            $vals = array_map(fn($v)=>"'".$db->real_escape_string($v)."'", $chunk);
            $res = $db->query('SELECT part_no FROM smms_master_part WHERE part_no IN ('.implode(',', $vals).')');
            while ($row = $res->fetch_row()) $existing[$row[0]] = true;
        }
        if ($existing) {
            foreach ($records as $rrec) {
                if (isset($existing[$rrec['rec']['part_no']]))
                    $errors[] = ['row'=>$rrec['excelRow'], 'col'=>'Part No', 'msg'=>"'{$rrec['rec']['part_no']}' sudah ada di database (mode Additional harus data baru)"];
            }
        }
    }

    // Kalau ada error di baris manapun, tolak SELURUH upload (tidak ada yang tersimpan sebagian)
    if ($errors) { http_response_code(400); out(['error'=>'Validasi gagal, upload ditolak', 'details'=>$errors]); }

    $db->begin_transaction();
    // Mode replace: kosongkan tabel dulu sebelum insert data baru
    if ($mode === 'replace') $db->query('TRUNCATE smms_master_part');
    // Simpan semua baris yang sudah lolos validasi
    $st = $db->prepare('REPLACE INTO smms_master_part
        (part_no,volume_box,status,dock_code,supplier_code,supplier_plant_code,shipping_dock,
         ssc_code,uniq_no,vol_box_day,supplier_name,part_name,route)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
    // Cache nama supplier per identitas — TIDAK ikut ke-TRUNCATE walau mode replace, biar supplier yg
    // udah dipilih di Pattern Unload tapi ilang dari upload baru ini tetap kelihatan namanya (bukan kode mentah).
    $cachedKeys = [];
    foreach ($records as $rrec) {
        $rec = $rrec['rec'];
        $st->bind_param('sdsssssssssss', $rec['part_no'], $rec['volume_box'], $rec['status'], $rec['dock_code'],
            $rec['supplier_code'], $rec['supplier_plant_code'], $rec['shipping_dock'], $rec['ssc_code'],
            $rec['uniq_no'], $rec['vol_box_day'], $rec['supplier_name'], $rec['part_name'], $rec['route']);
        $st->execute();
        $cacheKey = $rec['supplier_code'].'|'.$rec['shipping_dock'].'|'.$rec['route'];
        if (!isset($cachedKeys[$cacheKey])) { $cachedKeys[$cacheKey] = true; cache_supplier_name($db, $rec); }
    }
    // Catat riwayat upload (nama file, mode, jumlah baris, waktu)
    $n = count($records);
    $now = date('Y-m-d H:i:s');
    $st2 = $db->prepare('INSERT INTO smms_master_part_uploads (filename,mode,rows_count,uploaded_at) VALUES (?,?,?,?)');
    $st2->bind_param('ssis', $fname, $mode, $n, $now);
    $st2->execute();
    $db->commit();
    out(['ok'=>true, 'file'=>$fname, 'mode'=>$mode, 'rows'=>$n]);
}

/** action=master_part_add (POST JSON) — tambah 1 baris manual. dock_code dikunci "43" (abaikan input klien). */
function api_master_part_add($db) {
    // Ambil payload JSON dari body request
    $in = json_decode(file_get_contents('php://input'), true);
    if (!is_array($in)) fail('payload?');
    // Susun record dari input klien — dock_code dikunci "43", abaikan apapun yg dikirim klien
    $rec = [
        'part_no'             => trim($in['part_no'] ?? ''),
        'volume_box'          => (float)str_replace(',', '.', (string)($in['volume_box'] ?? 0)),
        'status'              => trim($in['status'] ?? ''),
        'dock_code'           => '43',
        'supplier_code'       => trim($in['supplier_code'] ?? ''),
        'supplier_plant_code' => trim($in['supplier_plant_code'] ?? ''),
        'shipping_dock'       => trim($in['shipping_dock'] ?? ''),
        'ssc_code'            => trim($in['ssc_code'] ?? ''),
        'uniq_no'             => trim($in['uniq_no'] ?? ''),
        'vol_box_day'         => trim($in['vol_box_day'] ?? ''),
        'supplier_name'       => mb_substr(trim($in['supplier_name'] ?? ''),0,100),
        'part_name'           => mb_substr(trim($in['part_name'] ?? ''),0,150),
        'route'               => trim($in['route'] ?? ''),
    ];
    // Validasi format field (sama seperti upload)
    $errs = master_part_validate($rec);
    if ($errs) { http_response_code(400); out(['error'=>'Validasi gagal', 'details'=>array_map(fn($e)=>['row'=>1,'col'=>$e['col'],'msg'=>$e['msg']], $errs)]); }
    // Tolak kalau part_no sudah ada (part_no = primary key)
    $chk = $db->prepare('SELECT 1 FROM smms_master_part WHERE part_no=?');
    $chk->bind_param('s', $rec['part_no']); $chk->execute();
    if ($chk->get_result()->num_rows > 0) fail("Part No '{$rec['part_no']}' sudah ada");
    // Simpan baris baru
    $st = $db->prepare('INSERT INTO smms_master_part
        (part_no,volume_box,status,dock_code,supplier_code,supplier_plant_code,shipping_dock,
         ssc_code,uniq_no,vol_box_day,supplier_name,part_name,route)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $st->bind_param('sdsssssssssss', $rec['part_no'], $rec['volume_box'], $rec['status'], $rec['dock_code'],
        $rec['supplier_code'], $rec['supplier_plant_code'], $rec['shipping_dock'], $rec['ssc_code'],
        $rec['uniq_no'], $rec['vol_box_day'], $rec['supplier_name'], $rec['part_name'], $rec['route']);
    $st->execute();
    cache_supplier_name($db, $rec);
    out(['ok'=>true]);
}

/** action=master_part_edit (POST JSON, wajib part_no_original) — ubah 1 baris (part_no boleh diganti). */
function api_master_part_edit($db) {
    // Ambil payload JSON, wajib bawa part_no_original (kunci buat cari baris yg diedit)
    $in = json_decode(file_get_contents('php://input'), true);
    if (!is_array($in)) fail('payload?');
    $original = trim($in['part_no_original'] ?? '');
    if ($original === '') fail('part_no_original?');
    // Susun record hasil edit (part_no & dock_code boleh diganti di sini, beda dgn Add)
    $rec = [
        'part_no'             => trim($in['part_no'] ?? ''),
        'volume_box'          => (float)str_replace(',', '.', (string)($in['volume_box'] ?? 0)),
        'status'              => trim($in['status'] ?? ''),
        'dock_code'           => trim($in['dock_code'] ?? ''),
        'supplier_code'       => trim($in['supplier_code'] ?? ''),
        'supplier_plant_code' => trim($in['supplier_plant_code'] ?? ''),
        'shipping_dock'       => trim($in['shipping_dock'] ?? ''),
        'ssc_code'            => trim($in['ssc_code'] ?? ''),
        'uniq_no'             => trim($in['uniq_no'] ?? ''),
        'vol_box_day'         => trim($in['vol_box_day'] ?? ''),
        'supplier_name'       => mb_substr(trim($in['supplier_name'] ?? ''),0,100),
        'part_name'           => mb_substr(trim($in['part_name'] ?? ''),0,150),
        'route'               => trim($in['route'] ?? ''),
    ];
    // Validasi format field (sama seperti upload/add)
    $errs = master_part_validate($rec);
    if ($errs) { http_response_code(400); out(['error'=>'Validasi gagal', 'details'=>array_map(fn($e)=>['row'=>1,'col'=>$e['col'],'msg'=>$e['msg']], $errs)]); }
    // Kalau part_no diganti, pastikan nama baru belum dipakai baris lain
    if ($rec['part_no'] !== $original) {
        $chk = $db->prepare('SELECT 1 FROM smms_master_part WHERE part_no=?');
        $chk->bind_param('s', $rec['part_no']); $chk->execute();
        if ($chk->get_result()->num_rows > 0) fail("Part No '{$rec['part_no']}' sudah dipakai baris lain");
    }
    // Update baris berdasar part_no lama (original)
    $st = $db->prepare('UPDATE smms_master_part SET
        part_no=?, volume_box=?, status=?, dock_code=?, supplier_code=?, supplier_plant_code=?, shipping_dock=?,
        ssc_code=?, uniq_no=?, vol_box_day=?, supplier_name=?, part_name=?, route=?
        WHERE part_no=?');
    $st->bind_param('sdssssssssssss', $rec['part_no'], $rec['volume_box'], $rec['status'], $rec['dock_code'],
        $rec['supplier_code'], $rec['supplier_plant_code'], $rec['shipping_dock'], $rec['ssc_code'],
        $rec['uniq_no'], $rec['vol_box_day'], $rec['supplier_name'], $rec['part_name'], $rec['route'], $original);
    $st->execute();
    cache_supplier_name($db, $rec);
    out(['ok'=>true]);
}

/** action=master_part_delete (POST JSON {part_nos:[...]}) — hapus banyak baris sekaligus (checkbox). */
function api_master_part_delete($db) {
    // Ambil daftar part_no yang mau dihapus (dari checkbox terpilih di UI)
    $in = json_decode(file_get_contents('php://input'), true);
    $partNos = is_array($in['part_nos'] ?? null) ? $in['part_nos'] : [];
    if (!$partNos) fail('part_nos?');
    // Hapus semua baris sekaligus
    $vals = array_map(fn($v)=>"'".$db->real_escape_string(trim((string)$v))."'", $partNos);
    $db->query('DELETE FROM smms_master_part WHERE part_no IN ('.implode(',', $vals).')');
    out(['ok'=>true, 'deleted'=>$db->affected_rows]);
}

/** action=master_part_list — seluruh katalog smms_master_part (dipakai render tabel di tab Database). */
function api_master_part_list($db) {
    // Ambil seluruh baris master part, urut berdasar uniq_no (Kanban No)
    $q = $db->query('SELECT part_no,volume_box,status,dock_code,supplier_code,supplier_plant_code,
        shipping_dock,ssc_code,uniq_no,vol_box_day,supplier_name,part_name,route
        FROM smms_master_part ORDER BY uniq_no');
    out(['rows'=>$q->fetch_all(MYSQLI_ASSOC)]);
}

/** action=master_part_routes — distinct route yg ada di Master Part, urut abjad — dipakai dropdown
 * Route "Sorting Plane" (assets/js/18-sorting-plane.js) supaya gak hardcode daftar route (dikonfirmasi
 * user eksplisit: route WAJIB dari data Master Part, bukan ALLR/daftar tetap kayak dropdown lain di
 * app ini). SATU-satunya tempat query ini ditulis -- reuse kalau ada dropdown Route dari Master Part
 * lain di masa depan, jangan bikin query serupa di file lain. */
function api_master_part_routes($db) {
    $q = $db->query("SELECT DISTINCT route FROM smms_master_part WHERE route<>'' ORDER BY route");
    $routes = [];
    while ($r = $q->fetch_row()) $routes[] = $r[0];
    out(['routes'=>$routes]);
}

/** action=master_part_upload_history — daftar riwayat upload (nama file, mode, jumlah baris, waktu). */
function api_master_part_upload_history($db) {
    // Ambil 30 riwayat upload terakhir, terbaru duluan
    $q = $db->query('SELECT filename,mode,rows_count,uploaded_at FROM smms_master_part_uploads ORDER BY uploaded_at DESC, id DESC LIMIT 30');
    out(['rows'=>$q->fetch_all(MYSQLI_ASSOC)]);
}

/** action=master_part_excel — download seluruh katalog Master Part dalam bentuk .xlsx (OpenSpout,
 * streaming langsung ke browser — sama pola dgn read_xlsx_rows di helpers.php, tanpa PhpSpreadsheet). */
function api_master_part_excel($db) {
    // Ambil seluruh data master part
    $q = $db->query('SELECT part_no,volume_box,status,dock_code,supplier_code,supplier_plant_code,
        shipping_dock,ssc_code,uniq_no,vol_box_day,supplier_name,part_name,route
        FROM smms_master_part ORDER BY uniq_no');
    $writer = new \OpenSpout\Writer\XLSX\Writer();
    $writer->openToBrowser('master_part_'.date('Ymd_His').'.xlsx');
    $writer->addRow(\OpenSpout\Common\Entity\Row::fromValues(['Part No','Volume Box','Status','Dock Code','Supplier Code','Supplier Plant Code',
        'Shipping Dock','SSC Code','Kanban No','Vol/Box Day','Supplier Name','Part Name','Conveyance']));
    while ($r = $q->fetch_assoc()) $writer->addRow(\OpenSpout\Common\Entity\Row::fromValues(array_values($r)));
    $writer->close();
    exit;
}

/**
 * action=master_part_template — download file template (isi tetap, cuma disk-nya generik). Nama file
 * yang di-download SELALU dihitung ulang saat request (bukan nama statis di disk), format
 * masterpart_YYYYMM.xlsx sesuai bulan berjalan WIB — jadi otomatis benar tiap bulan tanpa perlu
 * rename manual filenya di server.
 */
function api_master_part_template() {
    // Cek file template ada di server
    $path = __DIR__.'/../assets/templates/template_master_part.xlsx';
    if (!file_exists($path)) fail('Template tidak ditemukan di server');
    // Nama file yang di-download dihitung ulang tiap request (bulan berjalan WIB)
    $downloadName = 'masterpart_'.date('Ym').'.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="'.$downloadName.'"');
    header('Content-Length: '.filesize($path));
    readfile($path);
    exit;
}

if ($act === 'master_part_list') api_master_part_list($db);
if ($act === 'master_part_routes') api_master_part_routes($db);
if ($act === 'master_part_excel') api_master_part_excel($db);
if ($act === 'master_part_upload_history') api_master_part_upload_history($db);
if ($act === 'master_part_template') api_master_part_template();
if ($act === 'upload_master_part' && $_SERVER['REQUEST_METHOD']==='POST') api_upload_master_part($db);
if ($act === 'master_part_add' && $_SERVER['REQUEST_METHOD']==='POST') api_master_part_add($db);
if ($act === 'master_part_edit' && $_SERVER['REQUEST_METHOD']==='POST') api_master_part_edit($db);
if ($act === 'master_part_delete' && $_SERVER['REQUEST_METHOD']==='POST') api_master_part_delete($db);
if ($act === 'master_part_bulk_status' && $_SERVER['REQUEST_METHOD']==='POST') api_master_part_bulk_status($db);
