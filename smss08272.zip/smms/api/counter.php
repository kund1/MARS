<?php
// ================= COUNTER PROXY (opsional, konek ke IIS kalau ada) =================

/** action=counter — proxy ke COUNTER_API kalau diisi di config.php, else mode simulasi (frontend polling). */
function api_counter() {
    if (COUNTER_API === '') out(['sim'=>true]);
    $ctx = stream_context_create(['http'=>['timeout'=>2]]);
    $json = @file_get_contents(COUNTER_API, false, $ctx);
    if ($json === false) out(['sim'=>true, 'error'=>'Tidak bisa konek ke counter API']);
    $data = json_decode($json, true);
    out($data ?: ['sim'=>true, 'error'=>'Respons counter API tidak valid']);
}

if ($act === 'counter') api_counter();
