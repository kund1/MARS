<?php
// ================= UPLOAD MASTER DATA (halte, cd mapping, rack, jalur route, urutan supply) =================

// action=upload_halte_master (POST) — kolom: Route | Halte1 | Halte2 | Halte3 (rack address)
function api_upload_halte_master($db) {
    upload_master($db, 'SMMS_HALTE_MASTER', 2, [
        //Pengosongan data
        'truncate' => fn($db) => $db->query("TRUNCATE smms_halte_master"),
        //Aksi Pemrosesan Baris Data (Row)
        'row' => function($db, $r) {
            $route = strtoupper(trim($r[0] ?? ''));
            if ($route === '') return;
            //Replace Data Halte Master
            $st = $db->prepare("REPLACE INTO smms_halte_master VALUES (?,?,?)");
            //Looping Data Halte (Sampai 3 Halte per Rute)
            for ($h=1; $h<=3; $h++) {
                $addr = trim($r[$h] ?? '');
                if ($addr === '') continue;
                $st->bind_param('sis', $route, $h, $addr); $st->execute();
            }
        },
    ]);
}

/** action=upload_cd_mapping (POST) — kolom: C/D Awal | H1Max | H1Min | H2Max | H2Min | H3Max | H3Min. */
function api_upload_cd_mapping($db) {
    upload_master($db, 'SMMS_CD_MAPPING', 3, [
        //Pengosongan data
        'truncate' => fn($db) => $db->query("TRUNCATE smms_cd_mapping"),
        'row' => function($db, $r) {
            $start = (int)($r[0] ?? 0); if ($start <= 0) return;
            $st = $db->prepare("REPLACE INTO smms_cd_mapping VALUES (?,?,?,?)");
            for ($h=1; $h<=3; $h++) {
                $max = (int)($r[1+($h-1)*2] ?? 0); $min = (int)($r[2+($h-1)*2] ?? 0);
                $st->bind_param('iiii', $start, $h, $max, $min); $st->execute();
            }
        },
    ]);
}

/** action=upload_racks (POST) — kolom: Address | X | Y. */
function api_upload_racks($db) {
    upload_master($db, 'SMMS_RACKS', 3, [
        'truncate' => fn($db) => $db->query("TRUNCATE smms_racks"),
        'row' => function($db, $r) {
            $addr = trim($r[0] ?? ''); if ($addr === '') return;
            $st = $db->prepare("INSERT INTO smms_racks (addr,x,y) VALUES (?,?,?)");
            $x = (float)($r[1] ?? 0); $y = (float)($r[2] ?? 0);
            $st->bind_param('sdd', $addr, $x, $y); $st->execute();
        },
    ]);
}

/** action=upload_route_path (POST) — kolom: Route | Seq | X | Y | Halte 0-3. Replace hanya route yg ada di file. */
function api_upload_route_path($db) {
    if (empty($_FILES['file'])) fail('file?');
    $fname = $_FILES['file']['name'];
    if (!preg_match('/\.xlsx$/i', $fname)) fail('Hanya file .xlsx yang diterima');
    $rows = read_xlsx_rows($_FILES['file']['tmp_name']);
    if ($rows === null) fail('Bukan file xlsx yang valid');
    $got = trim((string)($rows[0][0] ?? ''));
    if ($got !== 'SMMS_ROUTE_PATH') fail("Template salah — cell A1 harus 'SMMS_ROUTE_PATH', ditemukan '$got'. Pakai Download Template.");
    $data = array_slice($rows, 3);
    // kelompokkan per route, urutkan pakai kolom Seq (bukan urutan baris) supaya tahan re-order manual di Excel
    $byRoute = [];
    foreach ($data as $r) {
        $route = strtoupper(trim($r[0] ?? '')); if ($route === '') continue;
        $seq = (float)($r[1] ?? 0); $x = (float)($r[2] ?? 0); $y = (float)($r[3] ?? 0); $h = (int)($r[4] ?? 0);
        $byRoute[$route][] = ['seq'=>$seq,'x'=>$x,'y'=>$y,'h'=>$h];
    }
    if (!$byRoute) fail('Tidak ada baris data yang valid di file ini');
    foreach ($byRoute as $route => $pts) { usort($pts, fn($a,$b)=>$a['seq']<=>$b['seq']); $byRoute[$route]=$pts; }

    $db->begin_transaction();
    if (!empty($_POST['replace']) && $_POST['replace']=='1') {
        // replace: hapus hanya route yang ada di file (route lain yang sudah digambar manual tidak ikut terhapus)
        $st = $db->prepare("DELETE FROM smms_route_path WHERE route=?");
        foreach (array_keys($byRoute) as $route) { $st->bind_param('s',$route); $st->execute(); }
    }
    $st = $db->prepare("INSERT INTO smms_route_path (route,seq,x,y,h) VALUES (?,?,?,?,?)");
    $n = 0;
    foreach ($byRoute as $route => $pts) {
        foreach ($pts as $i => $p) { $st->bind_param('siddi', $route, $i, $p['x'], $p['y'], $p['h']); $st->execute(); $n++; }
    }
    $db->commit();
    out(['ok'=>true,'file'=>$fname,'rows'=>$n,'routes'=>array_keys($byRoute)]);
}

/**
 * action=upload_supply_order (POST) — terima langsung format asli dokumen Operation
 * "UNLOAD PATTERN BASE ON SUPPLY ROUTE": blok "ZONE TIMUR"/"ZONE BARAT", masing2 diikuti
 * baris Urutan / OFF SET / ROUTE, lalu baris data (kolom A = seq, kolom lain = nama supplier
 * per route). Kolom berlabel "UNPACKING" atau "C/U" ikut diproses sbg route BIASA (dikonfirmasi
 * user: route khusus ini "berdiri sendiri", independen dari status Master Part — SEBELUMNYA kolom
 * ini sengaja dilewati krn dianggap "bukan route towing A-Q", sekarang route towing MEMANG tidak
 * lagi dibatasi ke A-Q saja, lihat allKnownRoutes()/ROUTE_ZONE, 01-state.js & api/data.php).
 * Zone-nya otomatis benar (ikut blok "ZONE TIMUR"/"ZONE BARAT" tempat kolom ini berada di file),
 * TANPA logic tambahan — TAPI upload ini TIDAK otomatis mendaftarkan route ke smms_offset/ROUTE_ZONE
 * (beda dari tombol "+ C/U"/"+ Unpacking" di UI Pattern Unload), jadi route ini bisa saja belum
 * muncul di Editor/Monitor/Grid Halte sampai ada baris Master Offset utk route itu ditambahkan
 * manual. Tidak butuh marker khusus — divalidasi dari keberadaan minimal satu blok "ZONE ...".
 */
function api_upload_supply_order($db) {
    if (empty($_FILES['file'])) fail('file?');
    $fname = $_FILES['file']['name'];
    if (!preg_match('/\.xls[xm]$/i', $fname)) fail('Hanya file .xlsx/.xlsm yang diterima');
    $rows = read_xlsx_rows($_FILES['file']['tmp_name']);
    if ($rows === null) fail('Bukan file xlsx/xlsm yang valid');

    $records = []; $n = count($rows); $zonesFound = 0;
    for ($i=0; $i<$n; $i++) {
        $a0 = trim((string)($rows[$i][0] ?? ''));
        if (stripos($a0, 'ZONE') !== 0) continue;
        $zonesFound++;
        $zoneLabel = stripos($a0,'TIMUR')!==false ? 'timur' : (stripos($a0,'BARAT')!==false ? 'barat' : strtolower($a0));
        $offsetRow = $rows[$i+2] ?? []; $routeRow = $rows[$i+3] ?? [];
        if (strtoupper(trim($routeRow[0] ?? '')) !== 'ROUTE') continue;
        $colRoute = []; $colOffset = [];
        foreach ($routeRow as $c => $val) {
            if ($c === 0) continue;
            $route = strtoupper(trim((string)$val));
            if ($route === '') continue;
            $colRoute[$c] = $route;
            $colOffset[$c] = isset($offsetRow[$c]) && $offsetRow[$c] !== '' ? (int)$offsetRow[$c] : null;
        }
        for ($j = $i+4; $j < $n; $j++) {
            $seqRaw = trim((string)($rows[$j][0] ?? ''));
            if ($seqRaw === '' || !is_numeric($seqRaw)) break;
            $seq = (int)$seqRaw;
            foreach ($colRoute as $c => $route) {
                $supplier = trim((string)($rows[$j][$c] ?? ''));
                if ($supplier === '') continue;
                $records[] = [$route, $seq, mb_substr($supplier,0,40), $zoneLabel, $colOffset[$c]];
            }
        }
    }
    if (!$zonesFound) fail("Tidak ditemukan blok 'ZONE ...' — pastikan ini file urutan supply asli (ada baris 'ZONE TIMUR'/'ZONE BARAT' di kolom A)");
    if (!$records) fail('Tidak ada baris data yang valid di file ini');

    $db->begin_transaction();
    if (!empty($_POST['replace']) && $_POST['replace']=='1') $db->query("TRUNCATE smms_pattern_unload");
    $st = $db->prepare("INSERT INTO smms_pattern_unload (route,seq,supplier,zone,offset_val) VALUES (?,?,?,?,?)");
    foreach ($records as [$route,$seq,$supplier,$zone,$offset]) {
        $st->bind_param('sissi', $route, $seq, $supplier, $zone, $offset);
        $st->execute();
    }
    $db->commit();
    $routes = array_values(array_unique(array_column($records,0)));
    sort($routes);
    out(['ok'=>true,'file'=>$fname,'rows'=>count($records),'routes'=>$routes]);
}

/** action=save_supply_order (POST) — simpan seluruh grid Pattern Unload (replace penuh smms_pattern_unload). */
function api_save_supply_order($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    if (!is_array($in) || !isset($in['rows']) || !is_array($in['rows'])) fail('payload?');
    $db->begin_transaction();
    $db->query("TRUNCATE smms_pattern_unload");
    $st = $db->prepare("INSERT INTO smms_pattern_unload (route,seq,supplier,supplier_code,zone,offset_val) VALUES (?,?,?,?,?,?)");
    $n = 0;
    foreach ($in['rows'] as $r) {
        $route = strtoupper(trim($r['route'] ?? '')); if ($route === '') continue;
        $seq = (int)($r['seq'] ?? 0); if ($seq <= 0) continue;
        $supplier = mb_substr(trim($r['supplier'] ?? ''), 0, 40); if ($supplier === '') continue;
        $supplierCode = mb_substr(trim($r['supplier_code'] ?? ''), 0, 64);
        $zone = strtolower(trim($r['zone'] ?? ''));
        $offset = isset($r['offset']) && $r['offset'] !== '' ? (int)$r['offset'] : null;
        $st->bind_param('sisssi', $route, $seq, $supplier, $supplierCode, $zone, $offset);
        $st->execute();
        $n++;
    }
    $db->commit();
    out(['ok'=>true,'rows'=>$n]);
}

// Router POST ke data base
if ($act === 'save_supply_order' && $_SERVER['REQUEST_METHOD']==='POST') api_save_supply_order($db);
if ($act === 'upload_halte_master' && $_SERVER['REQUEST_METHOD']==='POST') api_upload_halte_master($db);
if ($act === 'upload_cd_mapping' && $_SERVER['REQUEST_METHOD']==='POST') api_upload_cd_mapping($db);
if ($act === 'upload_racks' && $_SERVER['REQUEST_METHOD']==='POST') api_upload_racks($db);
if ($act === 'upload_route_path' && $_SERVER['REQUEST_METHOD']==='POST') api_upload_route_path($db);
if ($act === 'upload_supply_order' && $_SERVER['REQUEST_METHOD']==='POST') api_upload_supply_order($db);
