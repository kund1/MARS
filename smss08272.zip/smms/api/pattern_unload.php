<?php
// ================= PATTERN UNLOAD: grouping langsung dari Master Part =================
// Sumber datanya SEKARANG langsung smms_master_part (bukan VLOOKUP ke Progress Lane lagi).
// Key grouping = supplier_code + shipping_dock (dalam 1 route yg sama). Kalau ada 2 grup beda
// (supplier_code beda ATAU shipping_dock beda) tapi nama supplier-nya sama persis, dipisah jadi
// 2 entri dropdown & shipping_dock ditambahkan di belakang nama biar kebeda. Tiap grup (dropdown
// option) bawa daftar uniq_no/part_no/part_name miliknya sendiri (dari baris² Master Part yg sama
// grupnya) — dipakai jg oleh popup 👁 tanpa perlu API call terpisah lagi.

/**
 * action=pu_grouped_by_supplier&route=X — daftar supplier (dikelompokkan per supplier_code+shipping_dock)
 * yang punya part di route ini, langsung dari Master Part. Supplier yg status-nya "Unpacking Murni"
 * TIDAK dimunculkan sbg entri sendiri² — semuanya digabung jadi SATU entri tetap "UNPACKING",
 * sejalan dgn entri tetap "IMPORT".
 *
 * KHUSUS route="C/U" (route pseudo, lihat allKnownRoutes/ROUTE_ZONE, 01-state.js): part-nya TIDAK
 * dicari by kolom `route` literal (part C/U tetap fisik lewat route asli A-Q masing2, cuma
 * STATUS-nya "C/U" — dikonfirmasi user, sama filter yg dipakai Plane Simulation utk part khusus,
 * lihat psPartIsSpecial di plane-sim/plane-sim.js) — jadi query-nya di-switch cari by STATUS lintas
 * SEMUA route sekaligus, TETAP dikelompokkan per-supplier spt biasa (BUKAN digabung 1 entri kayak
 * Unpacking Murni, dikonfirmasi user: supplier C/U berbeda tetap harus kelihatan terpisah).
 */
function api_pu_grouped_by_supplier($db) {
    $route = strtoupper(trim($_GET['route'] ?? ''));
    if ($route === '') fail('route?');

    if ($route === 'C/U') {
        $st = $db->prepare("
            SELECT supplier_code, shipping_dock, supplier_name, status, uniq_no, part_no, part_name
            FROM smms_master_part
            WHERE status = 'C/U'
            ORDER BY supplier_code, shipping_dock, uniq_no
        ");
        $st->execute();
    } else {
        $st = $db->prepare("
            SELECT supplier_code, shipping_dock, supplier_name, status, uniq_no, part_no, part_name
            FROM smms_master_part
            WHERE route = ?
            ORDER BY supplier_code, shipping_dock, uniq_no
        ");
        $st->bind_param('s', $route);
        $st->execute();
    }
    $res = $st->get_result();

    $groups = [];       // key "supplier_code|shipping_dock" -> grup
    $unpackItems = [];  // items gabungan semua supplier Unpacking Murni di route ini

    while ($r = $res->fetch_assoc()) {
        $code = $r['supplier_code'];
        $dock = $r['shipping_dock'];
        $status = $r['status'] ?? '';
        $item = ['uniq_no'=>$r['uniq_no'], 'part_no'=>$r['part_no'], 'part_name'=>$r['part_name'], 'supplier'=>$r['supplier_name']];

        // Unpacking Murni: jangan jadi entri dropdown sendiri, part-nya digabung ke entri tetap "UNPACKING"
        if (stripos($status, 'unpacking murni') !== false) {
            $unpackItems[] = $item;
            continue;
        }

        $key = $code . '|' . $dock;
        if (!isset($groups[$key])) {
            $groups[$key] = [
                'key'           => $key,
                'supplier_code' => $code,
                'shipping_dock' => $dock,
                'supplier_name' => $r['supplier_name'],
                'status'        => $status,
                'items'         => []
            ];
        }
        $groups[$key]['items'][] = $item;
    }

    // Kalau 2 grup beda (supplier_code/shipping_dock beda) tapi nama suppliernya sama persis,
    // tambahkan shipping_dock di belakang nama masing² biar kebeda di dropdown.
    $nameCounts = [];
    foreach ($groups as $g) $nameCounts[$g['supplier_name']] = ($nameCounts[$g['supplier_name']] ?? 0) + 1;
    foreach ($groups as $key => &$g) {
        if ($nameCounts[$g['supplier_name']] > 1 && $g['shipping_dock'] !== '') {
            $g['supplier_name'] .= " (" . $g['shipping_dock'] . ")";
        }
    }
    unset($g);

    // Supplier asli diurutkan A-Z berdasar nama (IMPORT/UNPACKING tetap dipin di paling atas, gak ikut disortir).
    $groupsList = array_values($groups);
    usort($groupsList, fn($a, $b) => strcasecmp($a['supplier_name'], $b['supplier_name']));

    // "IMPORT" gak punya data supplier asli sama sekali — selalu ditambahkan manual sbg entri
    // tetap, status "import" spy bisa dipilih berulang. "UNPACKING" gabungan semua part dari
    // supplier Unpacking Murni di route ini (items-nya sudah dikumpulin di atas).
    $suppliers = array_merge(
        [
            ['key'=>'IMPORT', 'supplier_code'=>'IMPORT', 'shipping_dock'=>'', 'supplier_name'=>'IMPORT', 'status'=>'import', 'items'=>[]],
            ['key'=>'UNPACKING', 'supplier_code'=>'UNPACKING', 'shipping_dock'=>'', 'supplier_name'=>'UNPACKING', 'status'=>'unpacking murni', 'items'=>$unpackItems],
        ],
        $groupsList
    );

    // Cache nama supplier (ketang identitas yg PERNAH ada di Master Part utk route ini, hidup atau
    // enggak). Dipakai frontend buat nampilin nama asli (bukan kode mentah) di baris Pattern Unload
    // yg supplier-nya udah gak "live" lagi di Master Part sekarang — lihat 16-pattern-unload.js.
    $nameCache = [];
    $stC = $db->prepare("SELECT supplier_code, shipping_dock, supplier_name FROM smms_supplier_name_cache WHERE route = ?");
    $stC->bind_param('s', $route);
    $stC->execute();
    $resC = $stC->get_result();
    while ($r = $resC->fetch_assoc()) $nameCache[$r['supplier_code'].'|'.$r['shipping_dock']] = $r['supplier_name'];

    out(['grouped_data' => [['route' => $route, 'suppliers' => $suppliers, 'name_cache' => (object)$nameCache]]]);
}

/** action=pu_lookup_uniq&uniq_no=XXXX — cari part di Master Part by Kanban No (uniq_no, 4 karakter),
 * dipakai tombol "+ Uniq" (tambah manual 1 part) di Pattern Unload — dikonfirmasi user: kadang part
 * yg belum sempat ditandai status C/U (atau proses lain) di Master Part perlu bisa ditambahkan
 * manual by Uniq No ke kolom route mana pun, bukan cuma via auto-fill by status/route. uniq_no BUKAN
 * primary key Master Part (part_no yg PK) — bisa >1 match, semua dibalikin, operator pilih salah
 * satu di frontend. */
function api_pu_lookup_uniq($db) {
    $uniq = strtoupper(trim($_GET['uniq_no'] ?? ''));
    if ($uniq === '') fail('uniq_no?');
    $st = $db->prepare("SELECT part_no, part_name, supplier_code, shipping_dock, supplier_name, status, route
        FROM smms_master_part WHERE uniq_no = ? ORDER BY part_no");
    $st->bind_param('s', $uniq);
    $st->execute();
    out(['rows' => $st->get_result()->fetch_all(MYSQLI_ASSOC)]);
}

if ($act === 'pu_grouped_by_supplier') api_pu_grouped_by_supplier($db);
if ($act === 'pu_lookup_uniq') api_pu_lookup_uniq($db);
