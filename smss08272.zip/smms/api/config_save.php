<?php
// ================= SIMPAN MASTER: cd mapping + halte (tab Database) =================
// action=save_config (rack+jalur+shape, tab Editor) PINDAH ke editor/api.php (lihat komentar header
// file itu) — folder editor/ menyatukan semua berkas fitur Editor, pola sama persis dgn plane-sim/.

/** action=save_master (POST) — simpan edit manual grid Countdown->Halte & Halte Master dari tab Database. */
function api_save_master($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    if(!is_array($in)) fail('payload?');
    $db->begin_transaction();
    if(isset($in['cdmap'])){
        $db->query("TRUNCATE smms_cd_mapping");
        $st=$db->prepare("INSERT INTO smms_cd_mapping VALUES (?,?,?,?)");
        foreach($in['cdmap'] as $m) foreach($m['h'] as $i=>$r){ $h=$i+1; $st->bind_param('iiii',$m['start'],$h,$r[0],$r[1]); $st->execute(); }
    }
    if(isset($in['halte'])){
        // Address halte BALIK disimpan ke smms_halte_master (bukan smms_offset lagi -- Master Offset
        // sudah digabung 1 tabel & tidak punya kolom address, lihat komentar migrasi di install.php),
        // pola REPLACE INTO sama persis dgn seed (install.php) & upload_halte_master
        // (api/master_uploads.php) -- PK-nya (route,halte_no) jadi replace otomatis upsert per baris.
        $st=$db->prepare("REPLACE INTO smms_halte_master (route,halte_no,rack_addr) VALUES (?,?,?)");
        foreach($in['halte'] as $route=>$hs) foreach($hs as $i=>$a){
            $h=$i+1; $addr=(string)($a ?? '');
            $st->bind_param('sis',$route,$h,$addr);
            $st->execute();
        }
    }
    if(isset($in['haltedolly'])){
        // Beda dgn cdmap/halte di atas: key di sini ($i) SUDAH nomor halte 1-based langsung dari JS
        // (HALTE_DOLLY[route][haltNo]), bukan index array 0-based — jadi jangan di-+1 lagi di sini.
        // Tiap halte bisa punya LEBIH dari 1 dolly (multi-select), makanya $ds berupa array nomor dolly.
        $db->query("TRUNCATE smms_halte_dolly");
        $st=$db->prepare("INSERT INTO smms_halte_dolly VALUES (?,?,?)");
        foreach($in['haltedolly'] as $route=>$hs) foreach($hs as $i=>$ds){
            $h=(int)$i; if($h<1) continue;
            foreach((array)$ds as $d){
                $d=(int)$d; if($d<1) continue; // 0/kosong = bukan dolly valid, skip
                $st->bind_param('sii',$route,$h,$d); $st->execute();
            }
        }
    }
    $db->commit();
    out(['ok'=>true]);
}

if ($act === 'save_master' && $_SERVER['REQUEST_METHOD']==='POST') api_save_master($db);
