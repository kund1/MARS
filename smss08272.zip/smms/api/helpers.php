<?php
// ================= HELPER BERSAMA API SMMS =================
// Dipakai oleh semua file di folder api/. Jangan taruh logic per-endpoint di sini.

// OpenSpout (via Composer) — dipakai utk baca file besar (Progress Lane) secara streaming per-baris,
// biar gak perlu nampung seluruh isi file (bisa puluhan ribu baris x puluhan kolom) di memori sekaligus.
require_once __DIR__.'/../vendor/autoload.php';

/** Kirim response JSON lalu selesai. */
function out($x){ echo json_encode($x); exit; }

/** Kirim error JSON (HTTP 400) lalu selesai. */
function fail($m){ http_response_code(400); out(['error'=>$m]); }

/**
 * smms_progress_lane bisa berisi beberapa generasi upload sekaligus (retensi jendela tanggal
 * H-1/H+1, lihat progress_lane.php) — termasuk batch H+1 (besok) yg bot udah tarik duluan sore/malam
 * SEBELUM harinya beneran berganti. Data yang AKTIF dipakai Monitor/dolly/Pattern Unload viewer itu
 * "2 data aktif" (dikonfirmasi user): PRIORITAS batch bertanggal HARI INI, fallback ke batch
 * KEMARIN kalau hari ini belum ada uploadnya — SENGAJA GAK PERNAH milih batch H+1 (besok) scr default
 * biar towing/Monitor gak "loncat" pakai data besok cuma krn batch_id-nya lebih besar (itu bug lama:
 * dulu asal MAX(batch_id), jadi begitu bot upload H+1 malam hari sistem langsung kepake data besok
 * padahal harinya belum ganti). Fallback terakhir MAX(batch_id) cuma jaga2 kalau 2-2nya kosong
 * (jarang, drpd Monitor gak dapet data sama sekali).
 *
 * $date (opsional, 'Y-m-d') dipakai HANYA oleh preview tabel Progress Lane di tab Database (lihat
 * action=plane&date= di api/data.php) buat liat batch upload lain (termasuk H+1) — Monitor tidak
 * pernah kirim parameter ini.
 */
function current_parts_batch($db, $date = null) {
    if ($date !== null && $date !== '') {
        $date = $db->real_escape_string($date);
        $r = $db->query("SELECT id FROM smms_progress_lane_uploads WHERE data_date='$date' ORDER BY id DESC LIMIT 1");
        $row = $r->fetch_assoc();
        if ($row) return (int)$row['id'];
    } else {
        foreach ([date('Y-m-d'), date('Y-m-d', strtotime('-1 day'))] as $d) {
            $r = $db->query("SELECT id FROM smms_progress_lane_uploads WHERE data_date='$d' ORDER BY id DESC LIMIT 1");
            $row = $r->fetch_assoc();
            if ($row) return (int)$row['id'];
        }
    }
    $r = $db->query("SELECT MAX(batch_id) AS b FROM smms_progress_lane");
    $row = $r->fetch_assoc();
    return $row['b'] !== null ? (int)$row['b'] : 0;
}

/** Ekstrak tanggal (Y-m-d) dari 8 digit pertama order_no (mis. "2026080412" -> "2026-08-04"). */
function extract_date_from_order_no($orderNo) {
    return preg_match('/^(\d{4})(\d{2})(\d{2})/', (string)$orderNo, $m) ? "{$m[1]}-{$m[2]}-{$m[3]}" : null;
}

/**
 * Parser xlsx ringan (ZipArchive + XMLReader, tanpa PhpSpreadsheet) — aman utk file besar.
 * Dipakai oleh upload master data (halte/cd/rack/jalur/supply order/master part).
 * Return: array baris, tiap baris array nilai sel berindeks kolom (0-based), string sudah diresolusi.
 */
function read_xlsx_rows($tmpPath) {
    $zip = new ZipArchive();
    if ($zip->open($tmpPath) !== true) return null;

    $shared = [];
    $ss = $zip->getFromName('xl/sharedStrings.xml');
    if ($ss !== false) {
        $x = new XMLReader(); $x->XML($ss); $cur = null;
        while ($x->read()) {
            if ($x->nodeType==XMLReader::ELEMENT && $x->name=='si') { $cur=''; }
            if ($x->nodeType==XMLReader::ELEMENT && $x->name=='t') { $cur .= $x->readString(); }
            if ($x->nodeType==XMLReader::END_ELEMENT && $x->name=='si') { $shared[]=$cur; }
        }
    }
    $sheet = $zip->getFromName('xl/worksheets/sheet1.xml');
    $zip->close();
    if ($sheet === false) return null;

    $x = new XMLReader(); $x->XML($sheet);
    $rows = []; $row = null; $ctype=''; $cref=''; $inInline=false; $inlineBuf='';
    // Konversi ref kolom Excel ("C", "AB", ...) jadi index 0-based.
    $colIdx = function($ref){ $l=preg_replace('/\d+/','',$ref); $n=0; foreach(str_split($l) as $ch)$n=$n*26+ord($ch)-64; return $n-1; };
    while ($x->read()) {
        if ($x->nodeType==XMLReader::ELEMENT && $x->name=='row') $row=[];
        if ($x->nodeType==XMLReader::ELEMENT && $x->name=='c'){ $ctype=$x->getAttribute('t')??''; $cref=$x->getAttribute('r')??''; }
        if ($x->nodeType==XMLReader::ELEMENT && $x->name=='is'){ $inInline=true; $inlineBuf=''; }
        if ($inInline && $x->nodeType==XMLReader::ELEMENT && $x->name=='t'){ $inlineBuf .= $x->readString(); }
        if ($x->nodeType==XMLReader::END_ELEMENT && $x->name=='is'){
            $inInline=false; if($row!==null && $cref!=='') $row[$colIdx($cref)]=$inlineBuf;
        }
        if ($x->nodeType==XMLReader::ELEMENT && $x->name=='v'){
            $v=$x->readString();
            if($ctype==='s') $v=$shared[(int)$v]??'';
            if($row!==null && $cref!=='') $row[$colIdx($cref)]=$v;
        }
        if ($x->nodeType==XMLReader::END_ELEMENT && $x->name=='row'){ $rows[]=$row?:[]; $row=null; }
    }
    return $rows;
}

/**
 * Upload master data generik (pola sama dengan Master Offset di IIS):
 * marker di A1, header di baris 3, data mulai baris 4, opsi replace, TRUNCATE+INSERT.
 * $insertFn = ['truncate'=>fn($db)=>..., 'row'=>fn($db,$row)=>...]
 */
function upload_master($db, $marker, $minCols, $insertFn) {
    if (empty($_FILES['file'])) fail('file?');
    $fname = $_FILES['file']['name'];
    if (!preg_match('/\.xlsx$/i', $fname)) fail('Hanya file .xlsx yang diterima');
    $rows = read_xlsx_rows($_FILES['file']['tmp_name']);
    if ($rows === null) fail('Bukan file xlsx yang valid');
    $got = trim((string)($rows[0][0] ?? ''));
    if ($got !== $marker) fail("Template salah — cell A1 harus '$marker', ditemukan '$got'. Pakai Download Template.");
    $data = array_slice($rows, 3); // baris 1=marker, 2=kosong, 3=header, 4+=data
    $n = 0;
    $db->begin_transaction();
    if (!empty($_POST['replace']) && $_POST['replace']=='1') $insertFn['truncate']($db);
    foreach ($data as $r) {
        if (count(array_filter($r, fn($v)=>trim((string)$v)!=='')) < $minCols) continue; // skip baris kosong
        $insertFn['row']($db, $r);
        $n++;
    }
    $db->commit();
    if (!$n) fail('Tidak ada baris data yang valid di file ini');
    out(['ok'=>true,'file'=>$fname,'rows'=>$n]);
}
