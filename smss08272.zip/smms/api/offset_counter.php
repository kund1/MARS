<?php
/* =====================================================================
 * MASTER OFFSET (smms_offset) — 1 tabel tunggal, kolom: Dock | Process | Zone | Route | Volume |
 * Offset. Dipakai HALTE AKTIF & POSISI AKTIF di header (offsetStatusFor()/offsetPositionFor(),
 * lihat 03-countdown.js) & Supply Offset/CD Route (supplyOffsetFor()/cdRouteFor()). Offset boleh
 * 1 angka (posisi) ATAU rentang teks "max-min". Process HANYA: SUPPLY, PREPARE, HALTE 1/2/3,
 * EMPTY — SORTING & TRANSFER dihapus total (user putuskan gak kepakai sama sekali), lihat
 * cleanup di install.php.
 *
 * Dulu ada 2 tabel terpisah ("Counter Offset" 8 kolom dgn Address, & "Posisi Offset" 6 kolom dgn
 * offset_max/offset_min terpisah) -- DIGABUNG jadi 1 tabel ini (user kirim foto header Excel sumber
 * asli, minta persis segitu kolomnya). Rentang posisi yg dulu offset_max/offset_min sekarang
 * ditulis sbg teks "max-min" di kolom offset_val yang sama (format yg sudah dipakai HALTE 1/2/3).
 * Address & Lane dihapus total dari tabel ini -- alamat halte sekarang di smms_halte_master
 * (lihat api/data.php, api/config_save.php); Lane diputuskan user gak diperlukan sama sekali.
 * ===================================================================== */

/** action=offset_list (GET) — semua master offset (dipakai render tabel Master Offset di tab Database). */
function api_offset_list($db) {
    $q = $db->query("SELECT id,dock,process,zone,route,volume,offset_val FROM smms_offset ORDER BY process,zone,route,volume");
    out(['rows'=>$q->fetch_all(MYSQLI_ASSOC)]);
}

/** action=offset_upsert_row (POST) — tambah/edit 1 baris Master Offset (dari tabel edit manual di Database). */
function api_offset_upsert_row($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    if (!is_array($in)) fail('payload?');
    $dock = trim($in['dock'] ?? '43'); if ($dock === '') $dock = '43';
    $process = strtoupper(trim($in['process'] ?? '')); if ($process === '') fail('process?');
    if (in_array($process, ['SORTING','TRANSFER'], true)) fail('Proses SORTING/TRANSFER sudah tidak dipakai');
    $zone = strtolower(trim($in['zone'] ?? '')); if ($zone === '') fail('zone?');
    $route = strtoupper(trim($in['route'] ?? '')); if ($route === '') fail('route?');
    $volume = (int)($in['volume'] ?? 0);
    $offset = trim($in['offset_val'] ?? $in['offset'] ?? '');
    $id = (int)($in['id'] ?? 0);
    if ($id > 0) {
        $st = $db->prepare("UPDATE smms_offset SET dock=?,process=?,zone=?,route=?,volume=?,offset_val=? WHERE id=?");
        $st->bind_param('ssssisi', $dock, $process, $zone, $route, $volume, $offset, $id);
        $st->execute();
        out(['ok'=>true,'id'=>$id]);
    } else {
        $st = $db->prepare("REPLACE INTO smms_offset (dock,process,zone,route,volume,offset_val) VALUES (?,?,?,?,?,?)");
        $st->bind_param('ssssis', $dock, $process, $zone, $route, $volume, $offset);
        $st->execute();
        out(['ok'=>true,'id'=>$db->insert_id]);
    }
}

/** action=offset_delete_row (POST) — hapus 1 baris Master Offset by id. */
function api_offset_delete_row($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    $id = (int)($in['id'] ?? 0);
    if ($id <= 0) fail('id?');
    $st = $db->prepare("DELETE FROM smms_offset WHERE id=?");
    $st->bind_param('i', $id);
    $st->execute();
    out(['ok'=>true]);
}

/** action=offset_template (GET) — download template xlsx (marker SMMS_OFFSET + header + contoh baris). */
function api_offset_template() {
    $path = __DIR__.'/../assets/templates/template_offset.xlsx';
    if (!file_exists($path)) fail('Template tidak ditemukan di server');
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="template_offset.xlsx"');
    header('Content-Length: '.filesize($path));
    readfile($path);
    exit;
}

/**
 * action=upload_offset (POST) — kolom: Dock | Process | Zone | Route | Volume | Offset.
 * Process utk halte SUPPLY ditulis literal "HALTE 1"/"HALTE 2"/"HALTE 3" (bukan "SUPPLY"+angka terpisah).
 * Offset boleh angka tunggal (posisi) ATAU rentang teks "max-min" (dipakai HALTE 1/2/3, & bekas Posisi Offset).
 * Terima 2 format: (a) template resmi (marker "SMMS_OFFSET" di A1, header di baris manapun sesudahnya —
 * dicari otomatis dgn cek kolom pertama = "Dock"), atau (b) file asli tanpa marker, header langsung baris 1.
 * Zone di file boleh "EAST"/"WEST" ala sistem sumber, ATAU langsung "timur"/"barat" ala SMMS — dinormalisasi
 * ke "timur"/"barat" (kosakata zone yang dipakai di seluruh SMMS) supaya offset_status&zone=... konsisten.
 * Baris dgn process SORTING/TRANSFER dilewati (dihapus dari fitur ini, lihat komentar header file).
 */
function api_upload_offset($db) {
    if (empty($_FILES['file'])) fail('file?');
    $fname = $_FILES['file']['name'];
    if (!preg_match('/\.xlsx$/i', $fname)) fail('Hanya file .xlsx yang diterima');
    $rows = read_xlsx_rows($_FILES['file']['tmp_name']);
    if ($rows === null) fail('Bukan file xlsx yang valid');

    $a1 = trim((string)($rows[0][0] ?? ''));
    $hasMarker = (strcasecmp($a1, 'SMMS_OFFSET') === 0);
    $headerIdx = null;
    foreach ($rows as $i => $r) {
        if (strcasecmp(trim((string)($r[0] ?? '')), 'Dock') === 0) { $headerIdx = $i; break; }
    }
    $data = $headerIdx !== null ? array_slice($rows, $headerIdx + 1) : array_slice($rows, $hasMarker ? 1 : 0);

    $n = 0;
    $db->begin_transaction();
    if (!empty($_POST['replace']) && $_POST['replace']=='1') $db->query("TRUNCATE smms_offset");
    $st = $db->prepare("REPLACE INTO smms_offset (dock,process,zone,route,volume,offset_val) VALUES (?,?,?,?,?,?)");
    foreach ($data as $r) {
        if (count(array_filter($r, fn($v)=>trim((string)$v)!=='')) < 4) continue; // skip baris kosong
        $dock = trim($r[0] ?? '43'); if ($dock === '') $dock = '43';
        $process = strtoupper(trim($r[1] ?? '')); if ($process === '') continue;
        if (in_array($process, ['SORTING','TRANSFER'], true)) continue; // proses ini gak dipakai lagi
        $zone = strtolower(trim($r[2] ?? ''));
        if ($zone === 'east') $zone = 'timur'; elseif ($zone === 'west') $zone = 'barat';
        if ($zone === '') continue;
        $route = strtoupper(trim($r[3] ?? '')); if ($route === '') continue;
        $volume = (int)($r[4] ?? 0);
        $offset = trim($r[5] ?? '');
        $st->bind_param('ssssis', $dock, $process, $zone, $route, $volume, $offset);
        $st->execute();
        $n++;
    }
    $db->commit();
    if (!$n) fail('Tidak ada baris data yang valid di file ini');
    out(['ok'=>true,'file'=>$fname,'rows'=>$n]);
}

/**
 * action=save_offset_settings (POST) — durasi 1 tick countdown dalam detik (mm:ss di UI, disimpan
 * sbg integer detik), plus (opsional) tow_speed = kecepatan towing manual (px/detik, dropdown di
 * header). Dua-duanya reuse tabel key-value smms_meta yg sama, masing2 cuma ditulis kalau memang
 * dikirim di payload-nya (biar simpan cd_duration_sec gak nimpa/ngosongin tow_speed, atau sebaliknya).
 * Volume TIDAK di-setting terpisah lagi — dipakai langsung dari cdStart yg lagi aktif di Monitor,
 * karena rentang Volume di Master Offset persis sama dgn rentang cdStart yg sudah ada.
 */
function api_save_offset_settings($db) {
    $in = json_decode(file_get_contents('php://input'), true);
    if (!is_array($in)) fail('payload?');
    if (array_key_exists('cd_duration_sec', $in)) {
        $durSec = (int)$in['cd_duration_sec'];
        $st = $db->prepare("REPLACE INTO smms_meta (k,v) VALUES ('cd_duration_sec',?)");
        $dStr = (string)$durSec;
        $st->bind_param('s', $dStr);
        $st->execute();
    }
    if (array_key_exists('tow_speed', $in)) {
        $speed = (int)$in['tow_speed'];
        $st = $db->prepare("REPLACE INTO smms_meta (k,v) VALUES ('tow_speed',?)");
        $sStr = (string)$speed;
        $st->bind_param('s', $sStr);
        $st->execute();
    }
    out(['ok'=>true]);
}

if ($act === 'offset_list') api_offset_list($db);
if ($act === 'upload_offset' && $_SERVER['REQUEST_METHOD']==='POST') api_upload_offset($db);
if ($act === 'save_offset_settings' && $_SERVER['REQUEST_METHOD']==='POST') api_save_offset_settings($db);
if ($act === 'offset_upsert_row' && $_SERVER['REQUEST_METHOD']==='POST') api_offset_upsert_row($db);
if ($act === 'offset_delete_row' && $_SERVER['REQUEST_METHOD']==='POST') api_offset_delete_row($db);
if ($act === 'offset_template') api_offset_template();
