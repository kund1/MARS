<?php
// ================= KONFIGURASI SMMS =================
// Pabrik ada di WIB (Asia/Jakarta) — default server (Europe/Berlin) bikin semua timestamp
// (riwayat upload, meta, dll) salah beberapa jam kalau tidak di-set eksplisit di sini.
date_default_timezone_set('Asia/Jakarta');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');            // default XAMPP
define('DB_NAME', 'smms');

// Sumber counter eksternal (opsional).
// Kosongkan untuk mode simulasi/manual.
// Contoh jika nanti IIS expose API: 'http://10.x.x.x/iis/api/counter.php'
// Live: 'http://localhost/iis/counter.php' (sudah dibuat & tes OK — lihat counter.php di root IIS).
// Kosongkan tetap di sini karena mesin dev ini tidak bisa menjangkau SQL Server PICS 10.64.6.11,
// jadi datanya akan selalu STALE. Isi baris di atas saat deploy di jaringan pabrik.
define('COUNTER_API', '');

function db() {
    static $c = null;
    if ($c === null) {
        $c = new mysqli(DB_HOST, DB_USER, DB_PASS);
        if ($c->connect_error) { http_response_code(500); die('DB error: '.$c->connect_error); }
        $c->set_charset('utf8mb4');
        $c->query("CREATE DATABASE IF NOT EXISTS `".DB_NAME."` CHARACTER SET utf8mb4");
        $c->select_db(DB_NAME);
    }
    return $c;
}
